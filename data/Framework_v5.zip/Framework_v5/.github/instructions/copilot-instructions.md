# GitHub Copilot System Instructions - Python Automation Framework

*Last Updated: November 04, 2025*

## 🎯 PRIMARY OBJECTIVE
**Take your time to think step by step.** Generate production-ready Python automation code following established framework patterns for web scraping, data processing, and business workflows.

**Think carefully about each request before responding.** Always analyze the problem thoroughly and consider multiple approaches with their probabilities.

## 📋 CORE REQUIREMENTS
1. **ALWAYS check utils index first** before writing new code
2. **Follow class-based structure** with `run_flow()` method
3. **Use existing utilities** from `src/utils/` directory
4. **Apply SOLID principles** for maintainable code
5. **Include comprehensive error handling** and logging

---

## Generated Project Structure

When a project is created, the generator produces this structure:

```
{project_name}/
├── .github/
│   ├── copilot-instructions.md    # GitHub Copilot configuration
│   └── utils_index.md             # Function index documentation
├── src/
│   ├── utils/                     # Framework utility functions
│   ├── library/                   # Custom libraries
│   └── process_scripts/           # RPA process implementations
├── input/
│   ├── email_files/               # Email templates
│   ├── _file_input/               # Input data files
│   └── _recipients.xlsx           # Email recipients configuration
├── output/
│   ├── _logs/                     # Execution logs
│   └── _others/                   # Other output files
├── docs/                          # Project documentation
├── process_data/                  # Process-specific data
├── dev_data/                      # Development data
├── main.py                        # Main execution script
├── runner.py                      # Project runner
├── config.jsonc                   # Project configuration
├── README.md                      # Project documentation
├── requirements.txt               # Python dependencies
├── azure-pipelines.yml           # CI/CD pipeline
├── .gitignore                     # Git ignore rules
├── .env                           # Environment variables
└── LICENSE                        # License file
```

## Project Context

### Directory Structure
```
├── main.py                     # Main entry point
├── runner.py                   # Alternative runner
├── config.jsonc                # Configuration file
├── src/
│   ├── process_scripts/        # Automation scripts
│   │   └── test/              # Test, validation, and debug scripts
│   └── utils/                  # Reusable utilities
├── docs/                       # All markdown documentation
│   ├── technical/             # Technical specifications
│   ├── guides/                # User guides and tutorials
│   ├── api/                   # API documentation
│   ├── processes/             # Process documentation
│   └── architecture/          # Architecture documentation
├── input/                      # Input data
├── output/                     # Generated output
├── process_data/               # Temporary processing
├── dev_data/                   # Development/testing
└── .github/instructions/utils_index.md  # Utility function reference
```

## Code Generation Rules

### 1. Solution Strategy
- **Think Step by Step**: Analyze the problem methodically before writing code
- **Identify Approaches**: Evaluate multiple solutions with their probabilities and choose the best one (The higher probability of success)
- **Optimize For**: Performance > Maintainability > Simplicity
- **Document Choice**: Briefly explain why the chosen approach is optimal

### 2. Code Generation Constraints
- **Token Efficiency**: Prioritize concise, working code over verbose examples
- **Response Format**: Provide code first, then brief explanation
- **Decision Making**: If unsure between approaches, choose the one using existing utilities

### 3. Code Standards
- **Style**: Strict PEP8 compliance with type hints
- **Imports**: Use relative imports within `src/` (e.g., `from src.utils import`)
- **Structure**: Class-based with `run_flow()` method pattern
- **Error Handling**: Wrap all operations in try-except blocks
- **Returns**: Boolean success indicators from main methods

### 4. Required Imports Pattern
```python
import logging
import sys
import os
import inspect  # REQUIRED for function tracking
from typing import Optional

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from utils.fmw_utils import start_logging, Config
from utils.send_exceptions_emails import ExceptionEmails
from utils.credentials_utils import Credentials
```

### 5. Mandatory Class Structure
```python
class ProcessScript:
    """Process script with standard initialization."""
    
    def __init__(self):
        """Initialize with required components."""
        self.config = Config()  # REQUIRED
        self.exception_handler = ExceptionEmails()  # REQUIRED
        
    def run_flow(self) -> bool:
        """Main execution method - REQUIRED signature."""
        func_name = inspect.currentframe().f_code.co_name  # REQUIRED for tracking
        logging.info(f"--- START FOR SCRIPT: {func_name} ---")  # REQUIRED function start log
        
        try:
            start_logging()  # REQUIRED first line
            logging.info("Starting process flow")
            
            # Implementation with individual try-except blocks
            
            return True
        except Exception as e:
            logging.error(f"Process failed: {e}")
            self.exception_handler.send_system_exception(str(e))
            return False

    def example_function(self) -> bool:
        """
        Example function to demonstrate function tracking pattern.
        All functions should include function name logging for debugging.
        """
        func_name = inspect.currentframe().f_code.co_name  # REQUIRED
        logging.info(f"--- START FOR SCRIPT: {func_name} ---")  # REQUIRED
        
        try:
            # Function implementation
            logging.info(f"Function {func_name} completed successfully")
            return True
        except Exception as e:
            logging.error(f"Function {func_name} failed: {e}")
            return False

def main():
    """Standard entry point."""
    script = ProcessScript()
    return script.run_flow()
```

### 6. Function Standards
- All functions MUST have type hints
- All functions MUST return bool or raise exception
- All functions MUST use individual try-except blocks
- All functions MUST include function name logging using inspect
- Use descriptive function names
- Include docstrings with purpose description

### Function Tracking Pattern
```python
def any_function(self) -> bool:
    """Function description."""
    func_name = inspect.currentframe().f_code.co_name  # REQUIRED
    logging.info(f"--- START FOR SCRIPT: {func_name} ---")  # REQUIRED
    
    try:
        # Function implementation
        logging.info(f"Function {func_name} completed successfully")
        return True
    except Exception as e:
        logging.error(f"Function {func_name} failed: {e}")
        return False
```

### 7. Utility Usage Priority

**ALWAYS check and use existing utilities before creating new code:**

#### Utility Index Reference
- **Primary Reference**: Check `.github/instructions/utils_index.md` for complete function/class inventory
- **Before Coding**: Search the index for existing implementations
- **After Adding Functions**: Update the index with new utilities

#### Core Utilities (Always Import)
- `fmw_utils.py`: Configuration, logging, file operations
  - `start_logging()`, `Config()`, `read_json()`, `save_excel_file()`
- `selenium_utils.py`: Web automation
  - `SeleniumUtils()`, `element_exists()`, `click_element()`, `populate_field()`
- `send_exceptions_emails.py`: Error reporting
  - `ExceptionEmails()`, `send_system_exception()`, `send_business_exception()`
- `credentials_utils.py`: Secure credential handling
  - `Credentials()`, `inti_desiered_credentials()`

#### Protected Files (Never Modify)
- `monitoring.py`, `robot_date.py`, `base_workflow.py`
- `credentials.py`, `send_email_utils.py`

### 7. Selenium Automation Pattern
```python
def __init__(self):
    self.config = Config()
    self.driver: Optional[SeleniumUtils] = None
    
def run_flow(self) -> bool:
    try:
        self.driver = SeleniumUtils(
            download_folder=self.config.build_config()['paths']['output'],
            excecute_headless=False,
            max_timeout=30
        )
        # Automation logic
        return True
    finally:
        if self.driver:
            self.driver.close_driver()
```

### 8. Documentation Requirements

**Every function must include:**
```python
def function_name(param: type) -> return_type:
    """
    Brief description.
    
    Args:
        param: Description with type info.
        
    Returns:
        Description of return value.
        
    Raises:
        ExceptionType: When this occurs.
        
    Example:
        >>> function_name(value)
        expected_output
    """
```

### 9. File Management Rules
- **Input**: Use `input/` directory for all input files
- **Output**: Use `output/` directory for generated results
- **Temp**: Use `process_data/` directory for temporary processing files
- **Test Files**: Save all test, check, validation, verify, and debug scripts in `src/process_scripts/test/`
- **Documentation**: Save all markdown documentation files in `docs/` directory
- **Paths**: Always use `Config()` for path resolution

#### Test File Naming Conventions
- **Unit Tests**: `test_<module_name>.py`
- **Integration Tests**: `integration_test_<feature>.py`
- **Debug Scripts**: `debug_<issue_description>.py`
- **Validation Scripts**: `validate_<component>.py`
- **Check Scripts**: `check_<functionality>.py`

#### Documentation File Organization
- **Technical Specs**: `docs/technical/<feature_name>.md`
- **User Guides**: `docs/guides/<guide_name>.md`
- **API Documentation**: `docs/api/<module_name>.md`
- **Process Documentation**: `docs/processes/<process_name>.md`
- **Architecture**: `docs/architecture/<component_name>.md`

### 10. Error Handling Pattern
```python
try:
    # Operation
    result = self.perform_operation()
except SpecificException as e:
    logging.error(f"Operation failed: {e}")
    self.exception_handler.send_business_exception(str(e))
    return False
except Exception as e:
    logging.error(f"Unexpected error: {e}")
    self.exception_handler.send_system_exception(str(e))
    return False
```

### 11. Logging Best Practices
- **INFO**: Major workflow steps
- **DEBUG**: Detailed operation data
- **WARNING**: Recoverable issues
- **ERROR**: Failures requiring attention
- **Never log**: Passwords, API keys, personal data

## 🔄 Decision Tree

**When asked to generate code, think step by step and follow this order:**
1. **First**: Check utils index for existing functions
2. **Second**: Use existing utilities with modifications  
3. **Third**: Create new code following framework patterns
4. **Last**: Suggest framework improvements if needed

**Take time to consider each step before proceeding to the next.**

## Quick Reference Checklist

When generating code, ensure:
- [ ] **Utils first**: Check index, use existing functions
- [ ] **Class structure**: `__init__()` + `run_flow()` pattern
- [ ] **Required components**: `Config()`, `ExceptionEmails()`, `start_logging()`
- [ ] **Error handling**: Try-except blocks with specific exceptions
- [ ] **Type hints**: All parameters and returns annotated
- [ ] **Documentation**: Docstrings with Args/Returns/Examples
- [ ] **Returns**: Boolean success indicators from main methods

## 📝 Code Examples

### ✅ **Using Existing Utility (Preferred)**
```python
# Correct - using existing utility
from src.utils.selenium_utils import SeleniumUtils
self.driver = SeleniumUtils(download_folder=self.config.paths['output'])
```

### ✅ **Creating New Function (when no utility exists)**
```python
def process_data(self, data: pd.DataFrame) -> bool:
    """Process data with proper error handling."""
    try:
        # Implementation
        return True
    except Exception as e:
        logging.error(f"Data processing failed: {e}")
        return False
```

### ❌ **Common Mistakes to Avoid**
```python
# Wrong - hardcoded paths
file_path = "/Users/someone/data.xlsx"

# Wrong - no error handling
data = pd.read_excel(file_path)

# Wrong - missing type hints
def process(data):
```

## 🎯 Context-Aware Suggestions

### Web Scraping Tasks
```python
# Use SeleniumUtils, not raw Selenium
self.driver = SeleniumUtils(download_folder=config.paths['output'])
if self.driver.element_exists("//button[@id='submit']"):
    self.driver.click_element("//button[@id='submit']")
```

### Data Processing Tasks
```python
# Use existing pandas utilities
from src.utils.pandas_utils import save_excel_file
save_excel_file(df, output_path, sheet_name="Results")
```

### Email Tasks
```python
# Use framework email utilities
from src.utils.send_email_utils import send_email
send_email(recipients, subject, body_html)
```

## ⚠️ Common Pitfalls to Avoid

1. **Don't hardcode paths** - Use `Config()` class
2. **Don't skip error handling** - Every operation needs try-except
3. **Don't ignore utils index** - Check before coding
4. **Don't mix frameworks** - Use established patterns
5. **Don't forget cleanup** - Use finally blocks for resources

## 🔍 Validation Checkpoints

**Think through each checkpoint carefully:**

Before generating code:
- [ ] **Checked utils index** for existing solutions
- [ ] **Identified reusable utilities** from `src/utils/`
- [ ] **Planned error handling** for each operation
- [ ] **Confirmed class structure** follows framework pattern

After generating code:
- [ ] **Verified imports** are relative and correct
- [ ] **Confirmed error handling** is comprehensive
- [ ] **Validated type hints** on all functions
- [ ] **Checked docstring** completeness

## 📤 Response Format

**Always pause to think before responding. Consider the request carefully.**

### For Code Generation Requests:
1. **Brief analysis** (1-2 sentences)
2. **Working code** with framework patterns
3. **Key decisions** explained (why this approach)
4. **Usage example** if needed

### For Debugging/Issues:
1. **Problem identification**
2. **Root cause** analysis
3. **Solution** with code
4. **Prevention** tips

### For Architecture Questions:
1. **Current state** assessment
2. **Recommended approach** with rationale
3. **Implementation steps**
4. **Trade-offs** considered

## 🏗️ SOLID Principles Integration

Apply these principles to generated code:

### Single Responsibility Principle
```python
class DataExtractor:
    """Only handles data extraction."""
    def extract_from_excel(self, path: str) -> pd.DataFrame: ...

class DataProcessor:
    """Only handles data processing."""
    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame: ...
```

### Dependency Inversion
```python
class ProcessScript:
    def __init__(self, config: Config = None, notifier: ExceptionEmails = None):
        self._config = config or Config()
        self._notifier = notifier or ExceptionEmails()
```

### Interface Segregation (using Protocol)
```python
from typing import Protocol

class Readable(Protocol):
    def read(self) -> str: ...

class DataSource(Readable):
    def read(self) -> str:
        # Implementation
        return data
```

## Remember
- **Prioritize**: Existing utilities > New implementations (check utils_index.md first)
- **Structure**: Always use class-based design with standard methods
- **Quality**: Type hints, docstrings, and error handling are mandatory
- **Security**: Use Credentials() for sensitive data, never hardcode
- **Testing**: Consider edge cases and error scenarios
- **Indentation**: Always validate proper Python indentation (4 spaces, no tabs)
- **Formatting**: Use consistent spacing and follow PEP8 style guidelines
- **Maintenance**: Update utils_index.md when adding/modifying utilities

## Code Quality Validation

Before submitting any code, ensure:

### Syntax & Style
- [ ] **Indentation**: Consistent 4-space indentation (no tabs)
- [ ] **Line Length**: Maximum 88 characters per line
- [ ] **Imports**: Organized (standard → third-party → local) at file top, never inside functions
- [ ] **Spacing**: Proper whitespace around operators and after commas
- [ ] **Naming**: snake_case for functions/variables, PascalCase for classes

### Functionality
- [ ] **Type Hints**: All function parameters and return types annotated
- [ ] **Docstrings**: Complete with Args, Returns, Raises, and Examples
- [ ] **Error Handling**: Try-except blocks for all risky operations
- [ ] **Resource Cleanup**: Finally blocks or context managers for resources
- [ ] **Logging**: Appropriate log levels for different scenarios (don't use emojis and special characters like '✅' or '❌' in logs)

### Framework Compliance
- [ ] **Utilities**: Checked existing utils before implementing new code
- [ ] **Patterns**: Followed mandatory class structure with `run_flow()`
- [ ] **Configuration**: Used `Config()` class for all paths and settings
- [ ] **Credentials**: Used `Credentials()` for sensitive data access
- [ ] **Imports**: Used relative imports within `src/` directory

## Maintaining the Utils Index

To keep `.github/instructions/utils_index.md` up-to-date, follow these practices:

### Manual Update Process (Immediate)
- [ ] **Every utility change**: When adding, modifying, or removing functions/classes in `src/utils/`, immediately update the index
- [ ] **Update timestamp**: Change the "Last Updated" date at the top of the file
- [ ] **During development**: Add new entries to the table with proper descriptions
- [ ] **Code review**: Reviewers must verify the index is updated for any utility changes

### Automated Update Process (Recommended)
Create an automation script to scan `src/utils/` and regenerate the index:

```python
# scripts/update_utils_index.py
import os
import ast
import re

def scan_utils_directory():
    """Scan src/utils for all functions and classes."""
    entries = []
    utils_path = "src/utils"
    
    for root, dirs, files in os.walk(utils_path):
        for file in files:
            if file.endswith('.py') and not file.startswith('__'):
                file_path = os.path.join(root, file)
                entries.extend(extract_functions_and_classes(file_path))
    
    return sorted(entries, key=lambda x: x[0].lower())

def extract_functions_and_classes(file_path):
    """Extract function and class definitions from a Python file."""
    entries = []
    relative_path = file_path.replace("\\", "/")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        try:
            tree = ast.parse(f.read())
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                    # Skip private functions/classes
                    if not node.name.startswith('_'):
                        docstring = ast.get_docstring(node) or "No description available"
                        # Extract first line of docstring for description
                        description = docstring.split('\n')[0][:100]
                        entries.append((node.name, relative_path, description))
        except Exception as e:
            print(f"Error parsing {file_path}: {e}")
    
    return entries

def generate_markdown_table(entries):
    """Generate the markdown table for utils_index.md."""
    from datetime import datetime
    current_date = datetime.now().strftime("%B %d, %Y")
    
    lines = [
        "# Helper Functions Index (`src/utils`)\n",
        f"*Last Updated: {current_date}*\n",
        "| Function/Class Name         | File Path                                 | Description |",
        "|----------------------------|-------------------------------------------|-------------|"
    ]
    
    for name, path, description in entries:
        lines.append(f"| {name:<26} | {path:<41} | {description} |")
    
    lines.extend([
        "",
        "**Configuration variables are managed in `config.jsonc` at the project root. If present, use `src/utils/constants.py` for project-wide constants.**",
        "",
        "Files excluded: monitoring.py, robot_date.py, base_workflow.py"
    ])
    
    return '\n'.join(lines)

if __name__ == "__main__":
    entries = scan_utils_directory()
    markdown_content = generate_markdown_table(entries)
    
    # Configure output path and ensure directory exists
    output_path = os.path.join(".github", "instructions", "utils_index.md")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    print(f"Updated utils_index.md with {len(entries)} entries")
```

### When to Update the Index

- [ ] **New utility functions**: Immediately after adding new functions/classes to `src/utils/`
- [ ] **Function modifications**: When changing function signatures or descriptions
- [ ] **Deprecations**: Mark deprecated functions and eventually remove them
- [ ] **Code reviews**: Verify index updates are included in PRs touching utilities

### Index Update Checklist

- [ ] Function/class name matches exactly
- [ ] File path is correct and relative to project root
- [ ] Description is concise (under 100 characters)
- [ ] Entry is alphabetically sorted
- [ ] No duplicate entries exist
- [ ] Private functions (starting with `_`) are excluded
- [ ] **Last Updated date** is current and accurate

### Updating Missing Descriptions

When functions show "No description available" in the utils index:

**Process:**

1. **Identify Missing Descriptions**: Search utils_index.md for "No description available"
2. **Examine Source Code**: Open the referenced file in `src/utils/` and read the function/class implementation
3. **Analyze Functionality**: Understand what the function does from its code logic
4. **Add Proper Docstring**: If missing, add a docstring to the source function/class:

   ```python
   def function_name(param1: str) -> bool:
       """
       Brief description of what the function does.
       
       Args:
           param1 (str): Description of parameter
           
       Returns:
           bool: Description of return value
       """
   ```

5. **Regenerate Index**: Run the update script to pick up new descriptions:

   ```bash
   python scripts/update_utils_index.py
   ```

**Writing Guidelines:**

- **Be Specific**: Describe actual functionality, not generic terms
- **Use Action Verbs**: Start with "Load", "Check", "Convert", "Send", etc.
- **Include Key Details**: Mention important parameters or dependencies
- **Stay Concise**: Keep first line under 100 characters
- **Match Style**: Use similar language as existing descriptions

---

## 📚 Additional Best Practices & Recommendations

### Test Development Guidelines

When creating test files in `src/process_scripts/test/`:

1. **Test Structure**: Follow the same class-based pattern as production code
2. **Test Isolation**: Each test should be independent and not rely on other tests
3. **Mock External Dependencies**: Use mocking for external services, APIs, databases
4. **Clear Assertions**: Use descriptive assertion messages
5. **Test Coverage**: Aim for at least 80% code coverage on critical paths

#### Example Test File Structure
```python
# src/process_scripts/test/test_example_process.py
import unittest
from unittest.mock import Mock, patch
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from process_scripts.example_process import ExampleProcess

class TestExampleProcess(unittest.TestCase):
    """Test suite for ExampleProcess."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.process = ExampleProcess()
    
    def tearDown(self):
        """Clean up after tests."""
        pass
    
    def test_run_flow_success(self):
        """Test successful execution of run_flow."""
        result = self.process.run_flow()
        self.assertTrue(result, "run_flow should return True on success")
    
    @patch('process_scripts.example_process.SeleniumUtils')
    def test_with_mocked_selenium(self, mock_selenium):
        """Test with mocked Selenium driver."""
        mock_selenium.return_value.element_exists.return_value = True
        result = self.process.some_selenium_method()
        self.assertTrue(result)

if __name__ == '__main__':
    unittest.main()
```

### Documentation Standards

When creating markdown files in `docs/`:

1. **Use Templates**: Create consistent templates for each documentation type
2. **Clear Hierarchy**: Use proper heading levels (H1 for title, H2 for sections, etc.)
3. **Code Examples**: Include working code examples with syntax highlighting
4. **Table of Contents**: Add TOC for documents longer than 200 lines
5. **Cross-References**: Link to related documentation files
6. **Keep Updated**: Add "Last Updated" timestamp at the top
7. **Version Info**: Include version information when documenting features

#### Documentation Template Example
```markdown
# Feature Name

*Last Updated: [Date]*
*Version: [Version Number]*

## Overview
Brief description of the feature.

## Prerequisites
- List required dependencies
- List required configurations

## Usage
Step-by-step usage instructions with examples.

## API Reference
Detailed function/class documentation.

## Examples
Complete working examples.

## Troubleshooting
Common issues and solutions.

## Related Documentation
- [Link to related doc 1](./related1.md)
- [Link to related doc 2](./related2.md)
```

### Project Organization Recommendations

1. **Create a README in test directory**:
   - Add `src/process_scripts/test/README.md` explaining test structure and how to run tests
   
2. **Create a docs index**:
   - Add `docs/README.md` as a central documentation hub with links to all docs
   
3. **Add pre-commit hooks**:
   - Validate code formatting (black, flake8)
   - Check for hardcoded credentials
   - Run quick smoke tests
   
4. **Version Control**:
   - Add `.gitignore` entries for `output/`, `process_data/`, and `dev_data/`
   - Keep test data separate from production data
   
5. **Configuration Management**:
   - Create `config.template.jsonc` for new developers
   - Document all config options in `docs/technical/configuration.md`
   
6. **Logging Strategy**:
   - Save logs to `output/_logs/` with date-based naming
   - Implement log rotation to prevent disk space issues
   - Create different log levels for dev vs production
   
7. **Dependency Management**:
   - Keep `requirements.txt` updated
   - Consider `requirements-dev.txt` for development dependencies
   - Document version constraints and reasons
   
8. **Code Review Checklist**:
   - Create `docs/processes/code_review_checklist.md`
   - Include framework compliance checks
   - Add security review items
   
9. **Performance Monitoring**:
   - Add execution time logging for critical functions
   - Create performance baseline documentation
   - Set up alerts for slow operations
   
10. **Error Documentation**:
    - Create `docs/troubleshooting/common_errors.md`
    - Document solutions for recurring issues
    - Include error code reference guide

### Security Best Practices

1. **Never commit sensitive data**:
   - Use `.gitignore` for credential files
   - Use environment variables or secure vaults
   - Scan commits for accidentally added secrets

2. **Input Validation**:
   - Validate all external inputs (files, APIs, user input)
   - Sanitize data before processing
   - Use type hints and validation libraries (pydantic)

3. **Audit Logging**:
   - Log all security-relevant events
   - Include user actions, access attempts, failures
   - Store security logs separately from application logs

4. **Dependency Security**:
   - Regularly update dependencies
   - Use `pip-audit` or similar tools to check for vulnerabilities
   - Document security updates in changelog

### Continuous Improvement

1. **Code Metrics**:
   - Track code complexity (cyclomatic complexity)
   - Monitor test coverage trends
   - Measure code duplication

2. **Refactoring Schedule**:
   - Review and refactor utilities quarterly
   - Update deprecated patterns
   - Consolidate duplicate functionality

3. **Knowledge Sharing**:
   - Document lessons learned in `docs/lessons_learned.md`
   - Create internal wikis or knowledge bases
   - Conduct code review sessions

---

## 🎯 **Final Success Criteria**

Generated code should be:

- **Functional**: Works correctly on first try
- **Framework-compliant**: Follows established patterns
- **Maintainable**: Easy to modify and extend
- **Documented**: Clear docstrings and type hints
- **Error-resistant**: Comprehensive exception handling
- **Efficient**: Uses existing utilities when possible
