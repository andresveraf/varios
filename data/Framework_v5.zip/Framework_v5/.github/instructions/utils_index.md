
# file_name:   github_copilot_index.py
# created_on:  2025-07-21 ; andres.vera       
# modified_on: 2025-07-23 ; andres.vera 

# Project Generator Functions Index

## Core Generator Functions (`version4_sin_git.py`)

| Function Name               | Description |
|----------------------------|-------------|
| create_directories         | Creates the complete directory structure for a new RPA project, including src/, input/, output/, docs/, and .github/ folders. |
| copy_files                 | Copies template files (email templates, recipient files) from the framework to the new project, adapting paths based on the current user. |
| generate_files             | Generates all project files from templates, including Python scripts, configuration files, README, and project metadata. |
| generate_project_template  | Main orchestration function that validates input, creates directories, copies files, and generates the complete project template. |

## Template Modules (`framework_templates/`)

| Module Path                 | Content Type               | Description |
|----------------------------|----------------------------|-------------|
| Module Path                 | Content Type               | Description |
|----------------------------|----------------------------|-------------|
| main/main.py               | Main Script Template      | Main execution script template for RPA projects. |
| main/runner.py             | Runner Script Template    | Project runner script with execution control. |
| main/azure_pipeline.py     | CI/CD Template            | Azure DevOps pipeline configuration template. |
| main/gitignore.py          | Git Configuration         | .gitignore file template for RPA projects. |
| main/github_copilot.py     | Copilot Instructions      | GitHub Copilot instructions template. |
| main/github_copilot_index.py | Function Index          | Helper functions index template. |
| config/config_jsonc.py     | Configuration Template    | JSONC configuration file template with project-specific settings. |
| readme/readme_new.py       | Documentation Template    | README.md template with project documentation structure. |
| process_scripts/base_process.py | Base Process Class   | Base class template for RPA process implementations. |
| process_scripts/omi_test1.py | Test Script Template   | Test script template 1 for process validation. |
| process_scripts/omi_test2.py | Test Script Template   | Test script template 2 for process validation. |
| utils/base_workflow.py     | Workflow Base Class       | Base workflow class template for RPA processes. |
| utils/fmw_utils.py         | Framework Utilities       | Core framework utility functions template. |
| utils/monitoring_met.py    | MET Monitoring           | Monitoring utilities template for MET organization. |
| utils/monitoring_prv.py    | PRV Monitoring           | Monitoring utilities template for PRV organization. |
| utils/robot_date.py        | Date Utilities           | Date and time utility functions template. |
| utils/selenium_utils.py    | Selenium Automation      | Selenium web automation utilities template. |
| utils/excel_utils.py       | Excel Operations         | Excel file manipulation utilities template. |
| utils/send_email_utils.py  | Email Functionality      | Email sending and management utilities template. |
| utils/send_exceptions_emails.py | Exception Handling  | Exception notification utilities template. |
| utils/credentials_utils.py | Credentials Management   | Encrypted credentials handling utilities template. |
| email_files/               | Email Templates          | Collection of email body templates for different notification types. |
| recipients/                | Recipient Configuration  | Excel file template with email recipient configurations. |

## Generated Project Structure

When a project is created, the generator produces this structure:

```
{project_name}/
├── .github/
│   ├── copilot-instructions.md    # GitHub Copilot configuration
│   └── utils_index.md             # Function index documentation
├── src/
│   ├── utils/                     # Framework utility functions
│   ├── library/                   # Custom libraries
│   └── process_scripts/           # RPA process implementations
├── input/
│   ├── email_files/               # Email templates
│   ├── _file_input/               # Input data files
│   └── _recipients.xlsx           # Email recipients configuration
├── output/
│   ├── _logs/                     # Execution logs
│   └── _others/                   # Other output files
├── docs/                          # Project documentation
├── process_data/                  # Process-specific data
├── dev_data/                      # Development data
├── main.py                        # Main execution script
├── runner.py                      # Project runner
├── config.jsonc                   # Project configuration
├── README.md                      # Project documentation
├── requirements.txt               # Python dependencies
├── azure-pipelines.yml           # CI/CD pipeline
├── .gitignore                     # Git ignore rules
├── .env                           # Environment variables
└── LICENSE                        # License file
```

## Configuration Parameters

The generator accepts these parameters:

- **process_code**: Unique identifier for the process (e.g., "GC1111111")
- **process_name**: Descriptive name for the process (e.g., "PRUEBA")
- **n_gerencia**: Organization unit ("PRV", "MET", "DM", "INV", "GC", "OPS")
- **n_area**: Area within the organization ("PRV", "DEV_A", "DEV_B", "DEV_C")
- **area**: Folder name for project organization
- **author_name**: Project author (automatically retrieved from system)
