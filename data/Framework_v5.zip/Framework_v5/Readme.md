py -3.13 -m pip install pandas
py -3.13 -m pip install cryptography
py -3.13 -m pip install selenium
py -3.13 -m pip install pyodbc
py -3.13 -m pip install openpyxl
py -3.13 -m pip install xlwings

#force:
py -3.13 -m pip --trusted-host pypi.org --trusted-host files.pythonhosted.org install pandas

##

py -3.13 -m pip install selenium==4.15.2
py -3.13 -m pip uninstall selenium