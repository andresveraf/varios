"""
modified_on: 2025-11-04 ; daniel.hermosilla
versionV0501: secction aggregated LIBRARY en FRAMEWORK
Configuration JSONC template
EMAIL section updated to include SUCCESS_REPORT
UTILS section aggregated SUCCESS_REPORT
PROCESS_SCRIPT aggregated SUCCESS_REPORT
"""
def config_json(process_code,process_name,n_gerencia,n_area,author_name,today,country):
    CONFIG_JSONC=f'''
    {{
    "METADATA": {{
        "ENVIRONMENT":     "DEV",   // DEV, QAS, PRD
        "PROCESS_CODE":    "{process_code}",
        "PROCESS_NAME":    "{process_name}",
        "N_GERENCIA":      "{n_gerencia}", // Se obtiene de diccionario, en mayuscula
        "N_AREA":          "{n_area}",     // Se obtiene de diccionario, en mayuscula
        "AUTHOR":          "{author_name}",
        "START_DATE":      "{today}",
        "COUNTRY":         "{country}",
        "LAST_MOD_AUTHOR": "",
        "LAST_MOD_DATE":   "2025-11-10"
    }},
    "FRAMEWORK": {{
        "VERSION": "V0501", //
        "PROCESS_DATA": "../process_data",
        "INPUT":  "../input",
        "OUTPUT": "../output",
        "LIBRARY": "../src/library",                  // AGREGADA ---
        "DEV_DATA": "../dev_data",
        "LOG_FOLDER": "{{OUTPUT}}\\\\_logs",
        "MAX_TRIES": 2,
        "DELETE_PROCESS_DATA_BEFORE_EXE": true,
        "ACTIVE_ROBOT_TRAY": true,
        "KILL_PROCESSES" : true,
        "LIST_PROCESESS_TO_KILL": ["excel.exe"] //, "msedge.exe", "word.exe"]
    }},
        "GLOBAL": {{
            // FMW initial parameters
            "GLOBAL_PARAM_1": "{{ENV_PARAM_1}}\\\\GLOBAL_PARAM_1",
            "WORKTRAY_FILE": "{{PROCESS_DATA}}\\\\worktray.xlsx",                           // remove it if process doesn't use worktray
            "DOWNLOAD_DIR": "{{PROCESS_DATA}}\\\\downloads",
            // PAD parameters (remove this paramaters if PAD is not used)
            "PAD_CONFIG_FILE": "{{PROCESS_DATA}}\\\\pad\\\\pad_config.xlsx",                    // remove it if process doesn't use PAD
            "TRIGGER_EMAIL_SUBJECT": "EJECUTAR PROCESO [{{0}}]", // 0: PROCESS_CODE         // remove it if process doesn't use PAD
            "FLOW_FINISHED_LOG_FILE_PATH": "{{PROCESS_DATA}}\\\\pad\\\\pad_flow_finished.log",  // remove it if process doesn't use PAD
            "PAD_FLOW_EXECUTION_LIMIT": 600, // in minutes, depends on the PAD flow        // remove it if process doesn't use PAD
            // Date parameters
            "PROCESSING_DAY_OFFSET": 0 // default X, chage the name if needed
            // Process parameters
    }},
        "DEV": {{
            "ENV_PARAM_1": "DEV_PARAM_1",
            "EXCEL_VISIBLE":true,
            "EXECUTION_DAY_OFFSET":   0, // default 0
            "EXECUTION_MONTH_OFFSET": 0, // default 0
            "EXECUTION_YEAR_OFFSET":  0, // default 0
            "PROCESS_SHARED_FOLDER": "{{DEV_DATA}}",
            "OUTPUT_DIR": "{{OUTPUT}}\\\\others\\\\{{1}}\\\\{{0}}",
            // PAD parameters (remove this paramaters if PAD is not used)
            "CREDENTIALS_FILE_PATH": "C:\\\\Users\\\\user\\\\MetLife\\\\RSP Transformacion - RPA\\\\ACELERAR 2.0\\\\Credenciales\\\\credenciales_bots.xlsx",
            "GET_CREDS_SCRIPT_PATH": "C:\\\\Users\\\\user\\\\MetLife\\\\RSP Transformacion - RPA\\\\ACELERAR 2.0\\\\Libs\\\\get_credential_powershell.py",
            "PAD_TRIGGER_RECIPIENTS": ["robot.robops@metlifeexternos.cl"],
            "CREDENTIALS": ""
    }},
        "QAS": {{
            "ENV_PARAM_1": "QAS_PARAM_1",
            "EXECUTION_DAY_OFFSET":   0, // deafult 0
            "EXECUTION_MONTH_OFFSET": 0, // deafult 0
            "EXECUTION_YEAR_OFFSET":  0, // deafult 0
            "PROCESS_SHARED_FOLDER": "STEP_TP_PRD",
            "OUTPUT_DIR": "{{OUTPUT}}\\\\others\\\\{{1}}\\\\{{0}}"
    }}, 
        "PRD": {{
            "ENV_PARAM_1": "PRD_PARAM_1",
            "EXCEL_VISIBLE":false,
            "EXECUTION_DAY_OFFSET":   0, // deafult 0
            "EXECUTION_MONTH_OFFSET": 0, // deafult 0
            "EXECUTION_YEAR_OFFSET":  0, // deafult 0
            "PROCESS_SHARED_FOLDER": "SHAREPOINT_PATH",
            "OUTPUT_DIR": "{{OUTPUT}}\\\\others\\\\{{1}}\\\\{{0}}"
    }}, 
            "EMAIL": {{
            "RECIPIENTS_PATH": "{{INPUT}}\\\\_recipients.xlsx",
            "WRAPPER_FILE": "{{INPUT}}\\\\email_files\\\\email_wrapper_main.html",
            "ENABLE_CLIENT_SYS_EXC": true,
            "SIZE_LIMIT_ATTACHMENT" : 100, // Size in MB
            "SEND_AS_USER": null,
            "MONITORING_REPORT":{{ // Do not modify
            "SUBJECT": "[{{1}}][{{0}}] Monitoreo de ejecución",                 // 0: PROCESS_CODE; 1:Now["%Y%m%d_%H%M%S"]
            "BODY_FILE": "{{INPUT}}\\\\email_files\\\\body_monitoring_report.txt"
            }},
            "EXECUTION_REPORT_USER":{{ // same as the header in the _recipients.xlsx
            "SUBJECT": "[{{1}}][{{0}}] Reporte de ejecución",   // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_execution_report_user.txt"
            }},
            "EXECUTION_REPORT":{{ // same as the header in the _recipients.xlsx
            "SUBJECT": "[{{1}}][{{0}}] Reporte de ejecución",   // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_execution_report.txt"
            }},
            "SYS_EXC_REPORT":{{ // Do not modify
            "SUBJECT": "[{{1}}][{{0}}] Revisar la ejecución", // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_system_exception.txt"
            }},
            "SYS_EXC_REPORT_USER":{{ // same as the header in the _recipients.xlsx  
            "SUBJECT": "[{{1}}][{{0}}] No se pudo completar la ejecución", // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_system_exception_user.txt"
            }},
            "BE_REPORT":{{ // same as the header in the _recipients.xlsx  
            "SUBJECT": "[{{1}}][{{0}}] Excepción de negocio en la ejecución", // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_business_exception.txt"  
            }},
            "SUCCESS_REPORT":{{ // same as the header in the _recipients.xlsx
            "SUBJECT": "[{{1}}][{{0}}]Reporte TEST CAMBIAR NOMBRE EN CONFIG", // 0: PROCESS_CODE; 1:Now["%d-%m-%y"]
            "BODY_FILE": "../input/email_files/body_success.txt",
            "MESSAGE_BODY": "El informe se a completado exitosamente"
            }}
        }}
    }}
    '''

    return CONFIG_JSONC