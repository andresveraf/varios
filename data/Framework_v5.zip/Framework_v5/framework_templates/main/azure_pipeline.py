AZURE_PIPELINE = """
# file_name:   azure_pipeline.py
# created_on:  2025-07-21 ; alonso.riquelme       
# modified_on: 2025-07-23 ; dandres.vera 
trigger: none

resources:
  repositories:
    - repository: devsecops-cicd
      type: git
      name: '3e28f9aa-923b-4b44-a3e1-7f3041958773/devsecops-cicd-templates'
      ref: refs/heads/master

stages:
  - template: azure-pipelines-dummy.yml@devsecops-cicd
"""
