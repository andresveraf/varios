GITHUB_INDEX='''
# file_name:   github_copilot.py
# created_on:  2025-07-21 ; andres.vera       
# modified_on: 2025-07-23 ; andres.vera 
# Copilot System Instructions

This project is a Python automation and utility framework. Copilot should assist in developing and maintaining 
Python code using a modular code structure. When creating or modifying any function or step, always add clear and descriptive docstrings.

## Copilot Guidance

1. **Solution Search & Ranking**
   - Before answering a question or generating code, search for possible solutions or approaches.
   - Evaluate and rank these solutions based on relevance, efficiency, maintainability, and alignment with project standards.
   - Select and present the best-ranked solution, and briefly mention if alternatives were considered.

2. **Code Style & Structure**
   - Follow PEP8 style and Python best practices.
   - Organize code into reusable, modular functions and classes.
   - Use relative imports within the `src` folder.

3. **Documentation**
   - Every new or modified function, class, or step must include a docstring describing its purpose, parameters, and return values.
   - When suggesting or documenting code, include file paths and concise descriptions for clarity.

4. **Utilities & Helpers**
   - Prefer using existing helper functions and classes from `src/utils`.  
     (See `github/utils_index.md` for a full index.)
   - When creating new helpers, update the index in `github/utils_index.md`.

5. **Exclusions**
   - You may read code from the following files for reference, but do not suggest edits or generate documentation for:  
     `monitoring.py`, `robot_date.py`, `base_workflow.py`.

6. **Configuration & Constants**
   - Use `config.jsonc` at the project root for configuration variables.
   - Use `src/utils/constants.py` for constants, if present.

7. **Special Functionality**
   - For exception handling and reporting, use the `ExceptionEmails` class in `src/utils/send_exceptions_emails.py`.
   - For logging, credentials, Selenium automation, or email sending, use the provided utility functions/classes.

## Project Structure Reference

- **Main scripts:** `main.py`, `runner.py`
- **Utilities:** `src/utils/`
- **Process scripts:** `src/process_scripts/`
- **Data:** `input/`, `output/`, `process_data/`, `dev_data/`
- **Documentation:** `docs/`, `github/`

For a full list of available helper functions and their descriptions, see [`github/utils_index.md`](utils_index.md).

'''