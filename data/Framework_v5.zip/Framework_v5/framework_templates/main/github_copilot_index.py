GITHUB_COPILOT='''
# file_name:   github_copilot_index.py
# created_on:  2025-07-21 ; andres.vera       
# modified_on: 2025-07-23 ; dandres.vera 

# Helper Functions Index (`src/utils`)

| Function/Class Name         | File Path                                 | Description |
|----------------------------|-------------------------------------------|-------------|
| Credentials (class)        | src/utils/credentials_utils.py            | Handles encrypted credentials, loads and decrypts user credentials from Excel files. |
| decrypt_msg                | src/utils/credentials_utils.py            | Decrypts an encrypted message using a key. |
| inti_desiered_credentials  | src/utils/credentials_utils.py            | Loads and sets the desired credentials from the Excel file. |
| start_logging              | src/utils/fmw_utils.py                    | Initializes logging to file and/or console with custom formatting. |
| Config (class)             | src/utils/fmw_utils.py                    | Loads and builds configuration from JSONC files, manages config paths. |
| build_config               | src/utils/fmw_utils.py                    | Builds and returns the full configuration dictionary. |
| read_config                | src/utils/fmw_utils.py                    | Reads the main config file and returns it as a dictionary. |
| get_config_tag_keys        | src/utils/fmw_utils.py                    | Recursively collects tag keys from config dictionaries. |
| build_absolute_config_paths| src/utils/fmw_utils.py                    | Converts relative config paths to absolute paths. |
| read_json                  | src/utils/fmw_utils.py                    | Reads a JSON file and returns its contents. |
| read_jsonc                 | src/utils/fmw_utils.py                    | Reads a JSONC (JSON with comments) file and returns its contents. |
| save_json_file             | src/utils/fmw_utils.py                    | Saves a dictionary as a JSON file. |
| delete_folder              | src/utils/fmw_utils.py                    | Deletes a folder and its contents. |
| create_folder              | src/utils/fmw_utils.py                    | Creates a folder if it does not exist. |
| save_excel_file            | src/utils/fmw_utils.py                    | Saves a pandas DataFrame to an Excel file with formatting. |
| kill_processes             | src/utils/fmw_utils.py                    | Kills a list of processes by name using PowerShell. |
| add_dt_offset              | src/utils/fmw_utils.py                    | Adds a time offset to a datetime object. |
| last_day_in_month          | src/utils/fmw_utils.py                    | Returns the last day of the month for a given datetime. |
| dt_to_spanish              | src/utils/fmw_utils.py                    | Converts a datetime to its Spanish month or day name. |
| SeleniumUtils (class)      | src/utils/selenium_utils.py               | Utility class for automating web browsers with Selenium, including driver setup and common actions. |
| init_edge_driver           | src/utils/selenium_utils.py               | Initializes the Edge web driver with custom options. |
| open_website               | src/utils/selenium_utils.py               | Opens a website in the browser. |
| close_website              | src/utils/selenium_utils.py               | Closes a specific website tab. |
| close_all_websites         | src/utils/selenium_utils.py               | Closes all open browser tabs. |
| switch_to_tab              | src/utils/selenium_utils.py               | Switches to a browser tab by URL or index. |
| element_exists             | src/utils/selenium_utils.py               | Checks if a web element exists on the page. |
| click_element              | src/utils/selenium_utils.py               | Clicks a web element, with optional hover. |
| populate_field             | src/utils/selenium_utils.py               | Fills a form field with text. |
| switch_frame               | src/utils/selenium_utils.py               | Switches to a specific iframe on the page. |
| close_driver               | src/utils/selenium_utils.py               | Closes the Selenium web driver. |
| check_unfinished_downloads | src/utils/selenium_utils.py               | Checks for unfinished downloads in the download folder. |
| wait_for_element            | src/utils/selenium_utils.py               | Wait for an element to be present and visible. Returns the element or raises TimeoutException. |
| scroll_to_bottom            | src/utils/selenium_utils.py               | Scroll to the bottom of the page. |
| get_all_links              | src/utils/selenium_utils.py               | Retrieve all hyperlinks from the current page as a list of URLs. |
| take_screenshot             | src/utils/selenium_utils.py               | Take a screenshot of the current page, with an optional filename prefix. |
| read_recipients_file       | src/utils/send_email_utils.py             | Reads an Excel file and returns recipient lists for email (to, cc, bcc) based on environment and type. |
| df2html                    | src/utils/send_email_utils.py             | Converts a pandas DataFrame to an HTML table for email. |
| send_email                 | src/utils/send_email_utils.py             | Sends an email with subject, recipients, body, and attachments using Outlook. |
| ExceptionEmails (class)    | src/utils/send_exceptions_emails.py       | Handles sending exception-related emails (system, user, business exceptions). |
| send_user_system_exception | src/utils/send_exceptions_emails.py       | Sends a user system exception email. |
| send_system_exception      | src/utils/send_exceptions_emails.py       | Sends a system exception email with error details. |
| send_business_exception    | src/utils/send_exceptions_emails.py       | Sends a business exception email with custom info. |

**Configuration variables are managed in `config.jsonc` at the project root. If present, use `src/utils/constants.py` for project-wide constants.**

Files excluded: monitoring.py, robot_date.py, base_workflow.py
'''