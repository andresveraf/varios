GITIGNORE='''
# file_name:   gitignore.py
# created_on:  2025-07-21 ; daniel.hermosilla.omi       
# modified_on: 2025-07-23 ; daniel.hermosilla.omi
#####################################
#Carpetas documentos
#docs
#####################################
#Carpetas input
input/2025
#####################################
#Carpetas de output
output
*.xlsx
*.csv
*.txt
*.xls
*.zip
*.log
omi_test1.py
omi_test2.py
output/_logs
output/_others
#####################################
msedgedriver
#####################################
#Carpetas de process_data
process_data
process_data/_execution_datetime.txt
#####################################
#Carpetas dev_data
dev_data
#####################################
#Carpetas de src/process_scripts    
# src/process_scripts/base_process.py 
# src/process_scripts/omi_test1.py    
# src/process_scripts/omi_test2.py
#####################################
#Carpetas del copilot
.github
.github/copilot-instructions.md
.github/utils_index.md
#####################################
*.pyc
__pycache__/
*.egg-info/
dist/
build/
venv/
.env
#####################################
'''