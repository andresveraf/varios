BASE_PROCESS_PY='''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Base class template for RPA process implementations
Compatible with Python 3.13.4
"""

import os
import sys
import logging
import pandas as pd
import datetime as dt

sys.path.append(os.path.abspath(
                    os.path.dirname(
                    os.path.dirname(
                    os.path.abspath(__file__))))
)
from src.utils.base_workflow import Base #template to email_send #not use
from src.utils.robot_date import RobotDate
from src.utils.fmw_utils import *

class ProcessBase(Base):
    def __init__(self, config:dict):        
        Base.__init__(self, config=config)
        self.state_name               = type(self).__name__  
        self.robot_date               = RobotDate(config=config)
        logging.info(f"Robot date:     {self.robot_date}") 
        self.day,self.month,self.year = self.robot_date.set_up_int
        self.worktray_path            = self.config_global["WORKTRAY_FILE"]
        self.download_dir             = self.config_global["DOWNLOAD_DIR"]
        self.output_dir               = self.config_env["OUTPUT_DIR"].format(self.robot_date.month, self.robot_date.year)
        print(f'self.robot_date.month:{self.robot_date.month}')
        print(f'self.robot_date.year:{self.robot_date.year}')
        print(f'self.output_dir :{self.output_dir }')
    def _build_business_exception(self, error:str):
        now_string = dt.datetime.now().strftime("%d-%m-%y")
        be_mail_type   = "BE_REPORT"
        be_config_dict = self.config_emails[be_mail_type]
        be_body_file   = be_config_dict["BODY_FILE"]
        process_name   = self.config["METADATA"]["PROCESS_NAME"]
        process_code   = self.config["METADATA"]["PROCESS_CODE"]
        be_subject     = be_config_dict["SUBJECT"].format(process_code, now_string)
        attachments = []
        body_fields = [process_name, error]
        self.be_info = {
            "BODY_FILE": be_body_file,
            "SUBJECT": be_subject,
            "MAIL_TYPE": be_mail_type,
            "ATTACHMENTS": attachments,
            "BODY_FIELDS": body_fields
        }
    def valid_execution_date(self):
        if not os.path.exists(self.file_stop_process):
            return True
        else:
            logging.info(f"PASSING THE PROCESS FOR INVALID EXECUTION DATE...")
            return False
    def close_excel(self, workbook, save:bool=True):
        if save:
            logging.info(f"Saving workbook {workbook.Name}")
            workbook.Save()
        logging.info(f"Closing workbook {workbook.Name}")
        workbook.Close()
if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    process_base = ProcessBase(config=config)
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
'''
