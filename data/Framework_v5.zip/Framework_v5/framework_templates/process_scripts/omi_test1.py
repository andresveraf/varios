"""
modified_on: 2025-11-04 ; daniel.hermosilla
"""
OMI_TEST1_PY='''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script template 1 for process validation
Compatible with Python 3.13.4
file_name: _base_process_class.py
modified_on: 2024-01-03 ; daniel.hermosilla.omi ; Template
"""

import os
import sys
import logging
import datetime as dt
from src.utils.fmw_utils import *
from src.utils.selenium_utils import *
from src.utils.credentials_utils import *
from src.process_scripts.base_process import ProcessBase
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) )  # move to modules 
from src.utils.email_success import send_process_notification_email

class Template_omi_new1(ProcessBase):
    # This is an example of how the funcions you create should look like
    # omi .bless
    def __init__(self, config:dict):
        ProcessBase.__init__(self, config=config) 
        self.state_name    = "Workflow"  # Change with the class name 
        self.now           = dt.datetime.now()
        self.template_parameter_1 = self.config_env["ENV_PARAM_1"]
        self.template_parameter_2 = self.config_global["GLOBAL_PARAM_1"]
        # USE IF YOU NEED DRIVER AND CREDS
        # self.driver        = SeleniumUtils(excecute_headless=False, download_folder=self.dev_data, max_timeout=300)
        # self.creds         = Credentials(config=config, cred_config_name='CREDENTIALS')
        # self.user          = self.creds.desiered_creds_dict['USER']
        # self.password      = self.creds.creds
        # These variables already exist by inheritance
        # self.config              = config
        # self.environment         = config["METADATA"]["ENVIRONMENT"].upper()
        # self.config_env          = config[self.environment]
        # self.config_global       = config["GLOBAL"]
        # self.config_fmw          = config["FRAMEWORK"]        
        # self.process_data        = self.config_fmw["PROCESS_DATA"]
        # self.config_emails       = self.config["EMAIL"]

    def script_function_1(self): #Change with the function name 
        logging.info(f"--- DESCRIPTIVE START FOR SPRIPT 1 ---")
        logging.info(f"----- example  this is my first script funtion_1 -----".upper())
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        print(f'This is a test business exception1')
        logging.info(f"step 1 {self.template_parameter_1}")
        logging.info(f"please describe what they are in  the fuction 1")
        return 0
    
    def script_function_2(self): #Change with the function name 
        logging.info(f"--- DESCRIPTIVE START FOR SPRIPT 2 ---")
        logging.info(f"----- example  this is my first script funtion_2 -----".upper())
        print(f'This is a test business exception2')
        logging.info(f"tep 2 {self.template_parameter_2}")
        logging.info(f"please describe what they are in  the fuction 2 ")
        return 0

###importante para los que desarrollen run_flow corre en gran mededa todos los script y les agrega los logs
### CODEN EN script_function_1 O 2 COMO EJEMPLO      
    def run_flow(self):
        logging.info(f"----- Starting state: {self.state_name} -----")
        try: # Add workflow in try block bellow
            self.script_function_1()        
            self.script_function_2()
            send_process_notification_email(
            self,
            mensaje_personalizado=f' MENSAJE PERSONALIZADO DENTRO DEL SUCCESS REPORT.',
            
            sharepoint_url=rf'https://my.metlife.com/teams/RS-RPA-Transformacion-Operaciones/Documentos%20compartidos/Forms/AllItems.aspx?id=%2Fteams%2FRS%2DRPA%2DTransformacion%2DOperaciones%2FDocumentos%20compartidos%2FDOCS%20AUTOMATIZACIONES&viewid=f8b2a362%2D4f98%2D4ff4%2Dad9d%2D8c2deb89a743&FolderCTID=0x01200034DAFE1A1D0D0243BF496C57EA0B3EEF',
            nombre_reporte=f'NOMBRE_REPORTE'
            )
        except BusinessException as error:
            self._build_business_exception(error)
            raise error
        except Exception as error:
            raise error  
        logging.info(f"Finished state: {self.state_name}")

if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = Template_omi_new1(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
'''
