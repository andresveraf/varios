# Template readme.py

def readme(project_name,author_name):
  README_MD=f"""
## Titulo: **{project_name}**
### Autor: *{author_name}*
#
## Descripción:
#### [Una breve descripción general del proyecto]

### Objetivos:
- [x] [Objetivo 1]
- [ ] Objetivo 2
- [ ] \(Optional)Objetivo 3
...
#
### Requisitos técnicos:
- Python [versión específica]
- [Otras librerías o dependencias necesarias]
#
### Estructura del proyecto:
- [Módulo o archivo 1]
    -   Módulo interior
- [Módulo o archivo 2]
- [Módulo o archivo 3]
...
#
### Modulo/archivo 1:
#### Descripción: ```Hola  ```
###### [Descripción detallada del módulo o archivo 1]

Funciones/métodos:
- [Función o método 1]
- [Función o método 2]
- [Función o método 3]
...

Variables/objetos:
- [Variable/objeto 1]
- [Variable/objeto 2]
- [Variable/objeto 3]
...

Ejemplos de uso:

[Código de ejemplo que muestra cómo utilizar la función/método de este módulo/archivo]
#
### Modulo/archivo 2:
#### Descripción:
##### [Descripción detallada del módulo o archivo 2]

Funciones/métodos:
- [Función o método 1]
- [Función o método 2]
- [Función o método 3]
...

Variables/objetos:
- [Variable/objeto 1]
- [Variable/objeto 2]
- [Variable/objeto 3]
...
#
### Ejemplos de uso:

[Código de ejemplo que muestra cómo utilizar la función/método de este módulo/archivo]

...
#
### Pruebas:
#### [Descripción de las pruebas que se han realizado en el proyecto, incluyendo ejemplos de código y resultados obtenidos]
#
### Instalación y uso:

#### [Aquí se incluyen instrucciones detalladas para instalar y utilizar el proyecto, también se pueden incluir ejemplos y capturas de pantalla si es necesario]
"""
  return README_MD
 