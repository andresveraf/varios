# file_name:   readme_new.py
# created_on:  2023-06-28 ; daniel.hermosilla
# modified_on: 2023-06-29 ; daniel.hermosilla
# modified_on: 2023-08-13 ; daniel.hermosilla


def readme_folders(project_name,author_name):
  README_MD=f'''
Estructuras de carpeta del frmw_v4
==================================================
Nombre_proyecto: {project_name}
Autor: {author_name}
==================================================
'''
  return README_MD