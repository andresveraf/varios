# file_name:   readme_new.py
# created_on:  2023-06-28 ; daniel.hermosilla
# modified_on: 2023-06-29 ; daniel.hermosilla
# modified_on: 2023-08-22 ; andres.vera ; provida

def readme(project_name,author_name):
  README_MD=f'''
Python Automation Framework v4 by CHILE RPA INSURANCE
==================================================
Nombre_proyecto: {project_name}
Autor: {author_name}

A modular Python automation and utility framework designed for web scraping, data processing, and business automation workflows.

🚀 Overview
This framework provides a robust foundation for building automated business processes with features including:

Web Automation: Selenium-based browser automation utilities
Data Processing: Excel, JSON, and file manipulation tools
Email Integration: Automated email notifications and reports
Error Handling: Comprehensive exception management with email alerts
Configuration Management: Centralized JSONC-based configuration
Credential Management: Secure encrypted credential handling
Logging System: Structured logging with multiple output formats


📁 Project Structure
├── main.py                     # Main entry point and orchestrator
├── runner.py                   # Alternative runner/launcher
├── config.jsonc                # Main configuration file
├── requirements.txt            # Python dependencies
├── src/
│   ├── process_scripts/        # Main automation scripts and workflows
│   │   ├── base_process.py     # Base class for all process scripts
│   │   ├── omi_test1.py        # Example process script 1
│   │   └── omi_test2.py        # Example process script 2
│   └── utils/                  # Reusable utility modules
│       ├── fmw_utils.py        # Core framework utilities
│       ├── selenium_utils.py   # Web automation utilities
│       ├── credentials_utils.py # Credential management
│       ├── send_email_utils.py # Email utilities
│       └── [other utils...]
├── input/                      # Input data files
│   ├── _recipients.xlsx        # Email recipients configuration
│   └── _file_input/           # Input file storage
├── output/                     # Generated output files
│   ├── _logs/                 # Application logs
│   └── _others/               # Other output files
├── process_data/              # Temporary processing data
├── dev_data/                  # Development/testing data
└── docs/                      # Project documentation 

🛠️ Installation
Prerequisites
Python 3.13.4
Windows OS (framework optimized for Windows environments)
Microsoft Edge WebDriver (for Selenium automation)
Microsoft Outlook (for email functionality)
Setup
Clone the repository: bash git clone <repository-url> cd Test_Test

Install dependencies: bash pip install -r requirements.txt

Configure the framework:

Edit config.jsonc with your environment settings
Set up credential files in the appropriate format
Configure email recipients in input/_recipients.xlsx


🔄 Framework Workflow
Main Execution Flow
graph TD
    A[main.py] --> B[Load Configuration]
    B --> C[Initialize Logging]
    C --> D[Execute Process Scripts]
    D --> E[Process Script 1]
    D --> F[Process Script 2]
    E --> G[Generate Reports]
    F --> G
    G --> H[Send Notifications]
    H --> I[Cleanup & Exit]
Process Script Lifecycle
Initialization: Load configuration and initialize utilities
Execution: Run business logic via run_flow() method
Error Handling: Catch and report exceptions via email
Cleanup: Release resources and close connections
Reporting: Generate execution summaries and logs


📞 Support
For support and questions:
Transformacion Operational CHILE

Author: omi
Last Updated: July 23, 2025
Framework Version: V0401

📄 License
This project is Tranformacion Operational CHILE dessing by daniel.hermosilla with ex-aceleration 1.0 and colaboration of the team ONEOPS
special thanks to:
-matias.aravena
-matias.tejos
-andres.vera
-bastian.clausse
-alonso.riquelme  
and team aceleracion 2.0.
This is the achievement of moving forward.

Copyright (c) 2023-2025 CHILE RPA INSURANCE and CHILE RPA PROVIDA. All rights reserved.
This project is licensed under the MIT License - see the LICENSE file for details.
'''
  return README_MD