'''


📝 Creating Process Scripts
Basic Process Script Template
#!/usr/bin/env python3
"""
Example Process Script

This script demonstrates the standard pattern for creating automation workflows.
"""

import logging
import sys
import os
from typing import Optional

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from utils.fmw_utils import start_logging, Config
from utils.send_exceptions_emails import ExceptionEmails
from utils.credentials_utils import Credentials
from process_scripts.base_process import ProcessBase

class ExampleProcess(ProcessBase):
    """Example automation process."""
    
    def __init__(self, config: dict):
        """Initialize the process with configuration."""
        super().__init__(config=config)
        self.state_name = "ExampleWorkflow"
        self.exception_handler = ExceptionEmails()
        
    def run_flow(self) -> bool:
        """
        Execute the main workflow.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        try:
            logging.info("Starting example process flow")
            
            # Your business logic here
            self.step_1_data_collection()
            self.step_2_data_processing()
            self.step_3_report_generation()
            
            logging.info("Process flow completed successfully")
            return True
            
        except Exception as e:
            logging.error(f"Process flow failed: {e}")
            self.exception_handler.send_system_exception(str(e))
            return False
    
    def step_1_data_collection(self):
        """Collect data from various sources."""
        logging.info("Executing data collection step")
        # Implementation here
        
    def step_2_data_processing(self):
        """Process collected data."""
        logging.info("Executing data processing step")
        # Implementation here
        
    def step_3_report_generation(self):
        """Generate reports and outputs."""
        logging.info("Executing report generation step")
        # Implementation here

def main():
    """Main execution function."""
    config = read_config()
    process = ExampleProcess(config)
    success = process.run_flow()
    return success

if __name__ == "__main__":
    main()
Web Automation Example
from utils.selenium_utils import SeleniumUtils
from utils.credentials_utils import Credentials

class WebAutomationProcess(ProcessBase):
    """Web automation process using Selenium."""
    
    def __init__(self, config: dict):
        super().__init__(config=config)
        self.state_name = "WebAutomation"
        self.su: Optional[SeleniumUtils] = None
        self.creds = Credentials(config=config, cred_config_name='WEB_CREDENTIALS')
        
    def run_flow(self) -> bool:
        """Execute web automation workflow."""
        try:
            # Initialize Selenium driver
            self.su = SeleniumUtils(
                download_folder=self.config_global['DOWNLOAD_DIR'],
                excecute_headless=False,
                max_timeout=30
            )
            
            # Perform web automation tasks
            self.login_to_website()
            self.extract_data()
            self.download_reports()
            
            return True
            
        except Exception as e:
            logging.error(f"Web automation failed: {e}")
            raise
        finally:
            if self.su:
                self.su.close_driver()
    
    def login_to_website(self):
        """Login to the target website."""
        self.su.open_website("https://example.com/login")
        
        # Fill login form
        self.su.populate_field("input[name='username']", self.creds.user)
        self.su.populate_field("input[name='password']", self.creds.password)
        self.su.click_element("button[type='submit']")
        
        # Wait for dashboard to load
        self.su.wait_for_element("div.dashboard", timeout=10)
        logging.info("Successfully logged in")
    
    def extract_data(self):
        """Extract data from web pages."""
        # Navigate to data page
        self.su.click_element("a[href='/data']")
        
        # Extract table data
        table_elements = self.su.find_elements("table.data-table tr")
        data = []
        for row in table_elements[1:]:  # Skip header
            cells = row.find_elements("td")
            data.append([cell.text for cell in cells])
        
        # Save extracted data
        df = pd.DataFrame(data, columns=['Col1', 'Col2', 'Col3'])
        save_excel_file(df, f"{self.output_path}/extracted_data.xlsx")
        logging.info(f"Extracted {len(data)} rows of data")
    
    def download_reports(self):
        """Download reports from the website."""
        self.su.click_element("a[href='/reports']")
        self.su.click_element("button.download-btn")
        
        # Wait for download completion
        self.su.wait_for_download_completion(
            download_folder=self.config_global['DOWNLOAD_DIR'],
            timeout=60
        )
        logging.info("Reports downloaded successfully")
🧰 Available Utilities
Core Utilities (fmw_utils.py)
Configuration Management:

Config(): Load and manage configuration from JSONC files
read_json(), read_jsonc(): JSON file operations
build_absolute_config_paths(): Path resolution
Logging & Monitoring:

start_logging(): Initialize structured logging
log_worktray_metadata(): Log process metadata
File Operations:

save_excel_file(): Excel file creation with formatting
create_folder(), delete_folder(): Directory management
save_txt_file(), read_txt(): Text file operations
Date & Time:

add_dt_offset(): Date calculations
dt_to_spanish(): Localization utilities
Web Automation (selenium_utils.py)
Browser Management:

SeleniumUtils(): Main automation class
init_edge_driver(): Browser initialization
open_website(), close_website(): Navigation
Element Interaction:

element_exists(): Element presence checking
click_element(): Click with optional hover
populate_field(): Form field population
wait_for_element(): Element waiting strategies
Advanced Features:

switch_frame(): iframe handling
take_screenshot(): Page capture
wait_for_download_completion(): File download monitoring
Email & Communication (send_email_utils.py)
Email Operations:
send_email(): Send formatted emails via Outlook
read_recipients_file(): Load recipients from Excel
df2html(): Convert DataFrames to HTML tables
Credential Management (credentials_utils.py)
Security:
Credentials(): Handle encrypted credentials
decrypt_msg(): Message decryption
inti_desiered_credentials(): Load specific credential sets
Exception Handling (send_exceptions_emails.py)
Error Reporting:
ExceptionEmails(): Exception email notifications
send_system_exception(): System error reporting
send_business_exception(): Business logic error reporting
🔧 Usage Examples
Running the Framework
# Run main process
python main.py

# Run with specific parameters
python runner.py --environment DEV --state 2
Configuration Usage
from utils.fmw_utils import Config

# Load configuration
config = Config()
config_dict = config.build_config()

# Access environment-specific settings
environment = config_dict['METADATA']['ENVIRONMENT']
db_settings = config_dict[environment]['DATABASE']
Logging Example
from utils.fmw_utils import start_logging
import logging

# Initialize logging
start_logging()

# Use structured logging
logging.info("Process started")
logging.warning("Data validation issue detected")
logging.error("Critical error occurred", exc_info=True)
Email Notification Example
from utils.send_email_utils import send_email, df2html
import pandas as pd

# Create sample data
df = pd.DataFrame({'Name': ['John', 'Jane'], 'Score': [95, 87]})

# Send email with data table
send_email(
    subject="Daily Report",
    to_recipients=["manager@company.com"],
    body_text="Please find the daily report below:",
    html_body=df2html(df),
    attachment_paths=["output/report.xlsx"]
)
🚦 Error Handling
The framework implements comprehensive error handling:

Exception Types
System Exceptions: Infrastructure and technical errors
Business Exceptions: Logic and data validation errors
User Exceptions: Input and configuration errors
Error Reporting Flow
try:
    # Process logic here
    result = process_data()
except BusinessException as e:
    # Handle business logic errors
    exception_handler.send_business_exception(str(e))
except Exception as e:
    # Handle system errors
    exception_handler.send_system_exception(str(e))
    raise
📊 Monitoring & Reporting
Execution Summary
The framework automatically generates execution summaries including:

Process execution status
Runtime duration
Error counts and types
File processing statistics
System resource usage
Log Analysis
Logs are structured for easy analysis:

2025-07-23 10:30:15,123 - INFO - [ProcessName] Starting workflow execution
2025-07-23 10:30:16,456 - INFO - [DataCollection] Processing 150 records
2025-07-23 10:30:20,789 - WARNING - [Validation] 3 records failed validation
2025-07-23 10:30:25,012 - INFO - [ProcessName] Workflow completed successfully
🔐 Security Considerations
Credential Encryption: All sensitive data is encrypted at rest
Secure Configuration: Environment-specific settings isolation
Audit Logging: Comprehensive activity logging
Access Control: Role-based configuration management
🧪 Testing
Unit Testing
import unittest
from src.process_scripts.example_process import ExampleProcess

class TestExampleProcess(unittest.TestCase):
    
    def setUp(self):
        """Set up test configuration."""
        self.config = {
            'METADATA': {'ENVIRONMENT': 'DEV'},
            'DEV': {'EXCEL_VISIBLE': False},
            'GLOBAL': {'WORKTRAY_FILE': 'test_worktray.xlsx'}
        }
        self.process = ExampleProcess(self.config)
    
    def test_data_collection(self):
        """Test data collection functionality."""
        result = self.process.step_1_data_collection()
        self.assertTrue(result)
    
    def test_error_handling(self):
        """Test error handling mechanisms."""
        with self.assertRaises(BusinessException):
            self.process.invalid_operation()

if __name__ == '__main__':
    unittest.main()
📈 Performance Optimization
Best Practices
Resource Management: Always close drivers and connections
Memory Efficiency: Process data in chunks for large datasets
Parallel Processing: Use threading for independent operations
Caching: Cache frequently accessed configuration data
Error Recovery: Implement retry mechanisms for transient failures
Monitoring Performance
import time
from utils.fmw_utils import log_worktray_metadata

def timed_operation(func):
    """Decorator to measure operation timing."""
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        duration = time.time() - start_time
        logging.info(f"{func.__name__} completed in {duration:.2f} seconds")
        return result
    return wrapper

@timed_operation
def process_data():
    # Your processing logic here
    pass
🤝 Contributing
Development Guidelines
Code Style: Follow PEP8 and project coding standards
Documentation: Include comprehensive docstrings
Testing: Write unit tests for new functionality
Error Handling: Implement proper exception management
Logging: Add appropriate logging statements
Creating New Utilities
Place new utilities in src/utils/
Update .github/utils_index.md with new functions
Follow the established naming conventions
Include usage examples in docstrings


'''