EMAIL_SUCCESS = '''
"""
Módulo para envío de correos de reporte SUCCESS_REPORT
Adaptado al framework actual del proyecto
file_name:   correo_type.py
created_on:  2025-07-11 ; daniel.hermosilla
modified_on: 2025-08-22 ; daniel.hermosilla
modified_on: 2025-08-29 ; daniel.hermosilla
modified_on: 2025-10-15 ; daniel.hermosilla
modified_on: 2025-11-04 ; daniel.hermosilla

"""

from src.utils.send_email_utils import read_recipients_file, send_email
import logging
from datetime import datetime


def send_process_notification_email(self,mensaje_personalizado='',sharepoint_url='',nombre_reporte=''):

    try:
        logging.info("--- INICIANDO ENVÍO DE CORREO DE NOTIFICACIÓN ---")
        
        # 1. Obtener configuración del framework
        recipients_file = self.config["EMAIL"]["RECIPIENTS_PATH"]
        wrapper_file = self.config["EMAIL"]["WRAPPER_FILE"]
        environment = self.config["METADATA"]["ENVIRONMENT"]
        process_code = self.config["METADATA"]["PROCESS_CODE"]
        process_name = self.config["METADATA"]["PROCESS_NAME"]
        
        logging.info(f"Configuración obtenida:")
        logging.info(f"  - Recipients file: {recipients_file}")
        logging.info(f"  - Environment: {environment}")
        logging.info(f"  - Process code: {process_code}")
        
        # 2. Generar timestamp para el subject
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # 3. Leer destinatarios desde recipients.xlsx usando SUCCES_REPORT
        logging.info(f"Leyendo destinatarios desde: {recipients_file}")
        to, cc, bcc = read_recipients_file(
            recipients_file_path=recipients_file,
            environment=environment,
            mail_type='SUCCES_REPORT'  # Usar SUCCES_REPORT como tipo de email (columna en _recipients.xlsx)
        )
        
        logging.info(f"Destinatarios obtenidos:")
        logging.info(f"  - TO: {to}")
        logging.info(f"  - CC: {cc}")
        logging.info(f"  - BCC: {bcc}")
        
        # 4. Obtener configuración de SUCCESS_REPORT desde config.jsonc
        success_config = self.config.get("EMAIL", {}).get("SUCCESS_REPORT", {})
        
        # Obtener subject y body_file desde SUCCESS_REPORT
        subject_template = success_config.get("SUBJECT", "[{0}][{1}] Reporte de ejecución")
        body_file = success_config.get("BODY_FILE", "../input/email_files/body_success.txt")
        default_message = success_config.get("MESSAGE_BODY", "El informe se ha completado exitosamente")
        
        # Formatear subject: {0} = PROCESS_CODE, {1} = timestamp
        timestamp_short = datetime.now().strftime("%d-%m-%y")
        
        # Si se proporciona nombre_reporte personalizado, reemplazar el texto del config
        if nombre_reporte:
            # Reemplazar "Reporte Prepagos BECS" por el nombre_reporte personalizado
            subject_template_custom = subject_template.replace("Reporte Prepagos BECS", nombre_reporte)
            subject = subject_template_custom.format(process_code, timestamp_short)
            logging.info(f"Usando nombre de reporte PERSONALIZADO: '{nombre_reporte}'")
        else:
            # Usar el template por defecto del config
            subject = subject_template.format(process_code, timestamp_short)
            logging.info(f"Usando nombre de reporte POR DEFECTO del config")
        
        logging.info(f"Configuración SUCCESS_REPORT obtenida:")
        logging.info(f"  - Subject template: {subject_template}")
        logging.info(f"  - Subject formateado: {subject}")
        logging.info(f"  - Body file: {body_file}")
        logging.info(f"  - Default message: {default_message}")
        
        # 5. Construir mensaje del cuerpo (usar MESSAGE_BODY si no hay mensaje personalizado)
        if not mensaje_personalizado:
            mensaje_personalizado = f""
        
        # 6. URL de SharePoint por defecto si no se proporciona
        if not sharepoint_url:
            sharepoint_url = "https://metlife.sharepoint.com/sites/RPA_Transformacion_Operaciones"
        
        # 7. Campos para el body del correo
        body_fields = [
            process_name,              # s1: Nombre del proceso
            mensaje_personalizado,     # s2: Texto personalizado
            sharepoint_url             # s3: URL de SharePoint
        ]
        
        # 8. Enviar correo SIN archivos adjuntos (lista vacía)
        logging.info(f"Enviando correo:")
        logging.info(f"  - Subject: {subject}")
        logging.info(f"  - Body file: {body_file}")
        logging.info(f"  - Archivos adjuntos: NINGUNO (solo notificación)")
        
        send_email(
            to=to,
            cc=cc,
            bcc=bcc,
            subject=subject,
            body_file=body_file,
            body_fields=body_fields,
            wrapper_file=wrapper_file,
            attachments=[],  # SIN ADJUNTOS - Solo notificación
            environment=environment
        )
        
        logging.info("=" * 60)
        logging.info("CORREO DE NOTIFICACIÓN ENVIADO EXITOSAMENTE")
        logging.info(f"  - Destinatarios TO: {', '.join(to)}")
        logging.info(f"  - Destinatarios CC: {', '.join(cc) if cc else 'Ninguno'}")
        logging.info(f"  - Tipo: SUCCESS_REPORT")
        logging.info(f"  - Subject: {subject}")
        logging.info(f"  - Timestamp: {timestamp}")
        logging.info("=" * 60)
        
        return True
        
    except FileNotFoundError as fnf:
        logging.error(f"Archivo no encontrado: {str(fnf)}")
        logging.error(f"  Verifica que exista: {recipients_file}")
        raise
        
    except KeyError as ke:
        logging.error(f"Configuración faltante en config.jsonc: {str(ke)}")
        logging.error(f"  Verifica las secciones EMAIL y METADATA")
        raise
        
    except Exception as e:
        logging.error("=" * 60)
        logging.error("ERROR AL ENVIAR CORREO DE NOTIFICACIÓN")
        logging.error(f"  Error: {str(e)}")
        logging.error(f"  Tipo: {type(e).__name__}")
        logging.error("=" * 60)
        raise

'''