#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
RPA Framework Project Generator v4 (Con Git)
Compatible with Python 3.13.4

Author: Daniel Hermosilla
Created: 2025-07-21
Modified: 2025-07-23
Python Version: 3.13.4 (backward compatible from 3.9.13)
"""
import os
import time
import traceback
import datetime as dt
import win32api
import getpass
user = getpass.getuser()

from framework_templates.main.main import MAIN_PY
from framework_templates.main.runner import RUNNER_PY
from framework_templates.main.azure_pipeline import AZURE_PIPELINE
from framework_templates.main.gitignore import GITIGNORE
from framework_templates.main.github_copilot import GITHUB_INDEX
from framework_templates.main.github_copilot_index import GITHUB_COPILOT

from framework_templates.config.config_jsonc import config_json

# from framework_templates.readme.readme import readme#OLD
from framework_templates.readme.readme_new import readme#NEW
from framework_templates.readme.readme_folder_alone import readme_folders#NEW

from framework_templates.process_scripts.base_process import BASE_PROCESS_PY
from framework_templates.process_scripts.omi_test1 import OMI_TEST1_PY
from framework_templates.process_scripts.omi_test2 import OMI_TEST2_PY

from framework_templates.utils.base_workflow import BASE_WORKFLOW_PY
from framework_templates.utils.fmw_utils import FMW_UTILS_PY
from framework_templates.utils.monitoring_met import MONITORING_MET
from framework_templates.utils.monitoring_prv import MONITORING_PRV
from framework_templates.utils.robot_date import ROBOT_DATE_PY
from framework_templates.utils.selenium_utils import SELENIUM_UTILS_PY
from framework_templates.utils.excel_utils import EXCEL_UTILS_PY
from framework_templates.utils.send_email_utils import SEND_EMAILS
from framework_templates.utils.send_exceptions_emails import SEND_EXCEPTION
from framework_templates.utils.credentials_utils import CREDENTIALS_PY
from framework_templates.utils.email_success import EMAIL_SUCCESS
from framework_templates.library.library_utils_selenium import SELENIUM_UTILS_LIBRARY
import shutil


# Modularización del proceso de generación de proyecto
def create_directories(project_path):
    os.makedirs(project_path, exist_ok=True)
    os.makedirs(f"{project_path}/docs", exist_ok=True)
    os.makedirs(f"{project_path}/.github", exist_ok=True)
    os.makedirs(f"{project_path}/process_data", exist_ok=True)
    os.makedirs(f"{project_path}/input", exist_ok=True)
    os.makedirs(f"{project_path}/input/email_files", exist_ok=True)
    os.makedirs(f"{project_path}/dev_data", exist_ok=True)
    os.makedirs(f"{project_path}/input/_file_input", exist_ok=True)
    os.makedirs(f"{project_path}/output", exist_ok=True)
    os.makedirs(f"{project_path}/output/_logs", exist_ok=True)
    os.makedirs(f"{project_path}/output/_others", exist_ok=True)
    os.makedirs(f"{project_path}/src", exist_ok=True)
    os.makedirs(f"{project_path}/src/utils", exist_ok=True)
    os.makedirs(f"{project_path}/src/library", exist_ok=True)
    os.makedirs(f"{project_path}/src/process_scripts", exist_ok=True)


def copy_files(project_path, user):
    if user == 'hermosillad':
        shutil.copytree(rf"C:\RPA\create_project\Framework_v5\framework_templates\email_files",
                    f"{project_path}/input/email_files", dirs_exist_ok=True)
        shutil.copy(rf"C:\RPA\create_project\Framework_v5\framework_templates\recipients\_recipients.xlsx",
                    f"{project_path}/input")
    elif user == 'robopsr':
        shutil.copytree(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\email_files",
                    f"{project_path}/input/email_files", dirs_exist_ok=True)
        shutil.copy(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\recipients\_recipients.xlsx",
                    f"{project_path}/input")
    elif user == 'veraan':
        shutil.copytree(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\email_files",
                    f"{project_path}/input/email_files", dirs_exist_ok=True)
        shutil.copy(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\recipients\_recipients.xlsx",
                    f"{project_path}/input")
    elif user == 'tejosmh':
        shutil.copytree(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\email_files",
                    f"{project_path}/input/email_files", dirs_exist_ok=True)
        shutil.copy(rf"C:\Users\{user}\MetLife\RSP Transformacion - RPA\Create_proyect\Framework_v5\framework_templates\recipients\_recipients.xlsx",
                    f"{project_path}/input")
    else:
        shutil.copytree(rf"C:\Users\{user}\MetLife\RSP Transformacion - Documentos\RPA\Create_proyect\Framework_v5\framework_templates\email_files",
                    f"{project_path}/input/email_files", dirs_exist_ok=True)
        shutil.copy(rf"C:\Users\{user}\MetLife\RSP Transformacion - Documentos\RPA\Create_proyect\Framework_v5\framework_templates\recipients\_recipients.xlsx",
                    f"{project_path}/input")


def generate_files(project_path, process_name, author_name, process_code, n_gerencia,country, n_area):
    # .GITHUB_COPILOT
    with open(f"{project_path}/.github/copilot-instructions.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(GITHUB_INDEX)
    with open(f"{project_path}/.github/utils_index.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(GITHUB_COPILOT)
    # src/process_scripts
    with open(f"{project_path}/src/process_scripts/base_process.py", "w", encoding="utf-8") as base_process_file:
        base_process_file.write(BASE_PROCESS_PY)
    with open(f"{project_path}/src/process_scripts/omi_test1.py", "w", encoding="utf-8") as omi_test1_file:
        omi_test1_file.write(OMI_TEST1_PY)
    with open(f"{project_path}/src/process_scripts/omi_test2.py", "w", encoding="utf-8") as omi_test2_file:
        omi_test2_file.write(OMI_TEST2_PY)
    # src/utils
    with open(f"{project_path}/src/utils/base_workflow.py", "w", encoding="utf-8") as base_workflow_file:
        base_workflow_file.write(BASE_WORKFLOW_PY)
    with open(f"{project_path}/src/utils/fmw_utils.py", "w", encoding="utf-8") as fmw_utils_file:
        fmw_utils_file.write(FMW_UTILS_PY)
    with open(f"{project_path}/src/utils/credentials_utils.py", "w", encoding="utf-8") as credentials_file:
        credentials_file.write(CREDENTIALS_PY)
    with open(f"{project_path}/src/utils/robot_date.py", "w", encoding="utf-8") as robot_date_file:
        robot_date_file.write(ROBOT_DATE_PY)
    with open(f"{project_path}/src/utils/selenium_utils.py", "w", encoding="utf-8") as selenium_utils_file:
        selenium_utils_file.write(SELENIUM_UTILS_PY)
    with open(f"{project_path}/src/utils/excel_utils.py", "w", encoding="utf-8") as excel_utils_file:
        excel_utils_file.write(EXCEL_UTILS_PY)
    with open(f"{project_path}/src/utils/send_email_utils.py", "w", encoding="utf-8") as send_email_utils:
        send_email_utils.write(SEND_EMAILS)
    with open(f"{project_path}/src/utils/send_exceptions_emails.py", "w", encoding="utf-8") as send_exceptions_emails:
        send_exceptions_emails.write(SEND_EXCEPTION)

    with open(f"{project_path}/src/utils/email_success.py", "w", encoding="utf-8") as email_success_file:
        email_success_file.write(EMAIL_SUCCESS)
    with open(f"{project_path}/src/library/email_success.py", "w", encoding="utf-8") as selenium_library_utils:
        selenium_library_utils.write(SELENIUM_UTILS_LIBRARY)


    if "PRV" in n_gerencia:
        with open(f"{project_path}/src/utils/monitoring.py", "w", encoding="utf-8") as monitoring_file:
            monitoring_file.write(MONITORING_PRV)
    else:
        with open(f"{project_path}/src/utils/monitoring.py", "w", encoding="utf-8") as monitoring_file:
            monitoring_file.write(MONITORING_MET)
    # README
    with open(f"{project_path}/README.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme(process_name,author_name))
    # main.py, runner.py, azure-pipelines.yml (mantener legacy por ahora)
    with open(f"{project_path}/main.py", "w", encoding="utf-8") as main_file:
        main_file.write(MAIN_PY)
    with open(f"{project_path}/runner.py", "w", encoding="utf-8") as runner_file:
        runner_file.write(RUNNER_PY)
    with open(f"{project_path}/azure-pipelines.yml", "w", encoding="utf-8") as pipeline:
        pipeline.write(AZURE_PIPELINE)
    # Config
    with open(f"{project_path}/config.jsonc", "w", encoding="utf-8") as config_jsonc:
        config_jsonc.write(config_json(process_code,process_name,n_gerencia,n_area,author_name,dt.datetime.now().strftime("%Y-%m-%d_%H:%M:%S"),country=country))
    # Otros archivos
    with open(f"{project_path}/.gitignore", "w", encoding="utf-8") as gitignore_file:
        gitignore_file.write(GITIGNORE)
    with open(f"{project_path}/LICENSE", "w", encoding="utf-8") as license_file:
        license_file.write(f"Transformacion operacional Chile \nCopyright (c) {author_name}\n")
    with open(f"{project_path}/requirements.txt", "w", encoding="utf-8") as requirements_file:
        requirements_file.write(f"pandas==2.2.2\nnumpy==1.26.4\npdfplumber==0.10.3\nselenium==4.20.0\nPyAutoGUI==0.9.54\nXlsxWriter==3.2.0\nopenpyxl==3.1.2\npywin32==306\nxlrd==2.0.1\nPySimpleGUI==4.60.5\ncommentjson==0.9.0\ncryptography==42.0.5\nxlwings==0.32.0\ndateutil==2.8.2")
    with open(f"{project_path}/process_data/_execution_datetime.txt", "w", encoding="utf-8") as execution_datetime:
        execution_datetime.write(f'2025-07-23 15:41:21')
    with open(f"{project_path}/.env", "w", encoding="utf-8") as env_file:
        env_file.write("VAR1=valor1\nVAR2=valor2\nVAR3=valor3")
    # README#Library
    with open(f"{project_path}/src/library/README_library.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))
    # README#dev_data
    with open(f"{project_path}/dev_data/README_dev_data.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))
    # README#docs
    with open(f"{project_path}/docs/README_docs.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))
    # README#input/_file_input
    with open(f"{project_path}/input/_file_input/README_input.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))
    # README#output/_logs
    with open(f"{project_path}/output/_logs/README_logs.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))
    # README#output/_others
    with open(f"{project_path}/output/_others/README_others.md", "w", encoding='utf-8') as readme_file:
        readme_file.write(readme_folders(process_name,author_name))

def init_git(project_path):
    os.chdir(project_path)
    os.system("git add .")
    os.system("git commit -m 'init_process'")
    time.sleep(10)
    os.system("git push origin init")
    # os.system("git push origin master")
    time.sleep(10)
    # os.system("git checkout develop")
    # os.system("git pull origin master")
    # time.sleep(10) 

def generate_project_template(author_name, area, process_code, process_name, n_gerencia,country, n_area):
    area=area.upper()
    n_gerencia = n_gerencia.upper()
    n_area = n_area.upper()
    process_code = process_code.upper()
    process_name = process_name.lower()
    process_name = process_code + '_' + process_name
    repo = f"https://MetLife-Global@dev.azure.com/MetLife-Global/Chile/_git/{process_name}"
    target_directory = rf"C:\RPA\repositorio\{area}\{process_name}"
    user = getpass.getuser()
    # Clonar repo y crear estructura
    if os.path.exists(target_directory):
        print(f"⚠️ El proyecto ya existe\n has ctrl+click para acceder: {target_directory}")
        return
    os.makedirs(target_directory, exist_ok=True)
    print(f"git clone {repo} {target_directory}")
    os.system(f"git clone {repo} {target_directory}")
    os.chdir(target_directory)
    os.system(f"git checkout -b init")
    project_path = target_directory
    create_directories(project_path)
    copy_files(project_path, user)
    generate_files(project_path, process_name, author_name, process_code, n_gerencia,country, n_area)
    init_git(project_path)
    os.system("git add .")
    os.system("git commit -m 'init_process'")
    time.sleep(10)
    os.system("git push origin init")
    print("\nCambios subidos a la rama 'init'.\n")
    print("Ahora crea un Pull Request de 'init' hacia 'master' en Azure DevOps:\n")
    print(f"   https://dev.azure.com/MetLife-Global/Chile/_git/{process_name}/pullrequests?_a=mine\n")
    print(f"   feat:Primer commit del template\n")

    print(f"Ruta del proyecto: {target_directory}\n")
    print(f"Successfully Crear {process_name} project template!")
    
if __name__ == '__main__':
    """
    project creator:
    - Compatible with Python 3.13.4
    - All generated projects use updated dependencies for Python 3.13.4
    """




    process_code    = 'PRV146'              # process_code = "DM001"
    process_name    = 'carga_escritos_parental'  # proyect_name
    n_gerencia      = 'PRV'                  # n_gerencia = "PS", INV,DM,OPS,
    n_area          = 'PRV'                  # n_area = "DEV_A" o "DEV_B" o "DEV_C"
    area            = 'PRV'                # example area = "ACELERAR 2.0" #nombre de la carpeta
    country         = 'CL'                # country = "CL , COL , ARG, BR, URU, MX"
    try:
        # process_name = process_code + '_' + process_name
        author_name = win32api.GetUserNameEx(3)
        generate_project_template(author_name,
                                area,
                                process_code,
                                process_name,
                                n_gerencia,
                                n_area,
                                country)

    except Exception as error:
        print(f'Error en la generacion de proyecto: {error}')
        execute_error=traceback.format_exc()
        print(f'traceback en la generacion de proyecto: {execute_error}')