# PII Analysis Expert - Configuration Guide

This document provides configuration details and usage examples for the PII Analysis Expert chat mode.

## Chat Mode Activation

To activate this specialized chat mode, ensure the `pii-analysis-expert.md` file is placed in your `.github/chatmodes/` directory and reference it when starting a conversation about PII analysis.

## Sample Commands

### Basic Analysis Commands
- "Analyze the PII detection results in file X"
- "Generate a comprehensive PII analysis report"
- "Validate PII detection accuracy for the latest results"
- "Compare detection performance across different sources"

### Specific Analysis Requests
- "Show me the detection accuracy by PII type"
- "Identify potential false positives in the results"
- "Analyze sensitivity level distribution"
- "Check for quality issues in name detection"
- "Compare regex vs ML vs hybrid detection performance"

### Troubleshooting Commands
- "Why are single words being detected as full names?"
- "Find business terms incorrectly classified as PII"
- "Identify patterns in false positive detections"
- "Suggest improvements for detection accuracy"

## Expected File Structure

The PII analysis expects Excel files with the following columns:

### Required Columns
- **PII_RESULTS**: Boolean (true/false) indicating if PII was detected
- **Page**: Page number where PII was found
- **PII_Type**: Type of PII detected (e.g., ChileanFullName, Person, Email)
- **PII_Length**: Length of the detected PII entity
- **Source**: Detection source (regex, ML, hybrid)
- **Source_Type**: Specific source type identifier
- **Label**: Label assigned to the detection
- **Sensitivity_Level**: Sensitivity classification of the detected PII

### Optional Columns
- **PII_Value**: Actual detected PII content (for pattern analysis)
- **Confidence**: Detection confidence score
- **Position**: Position within document

## Analysis Output Format

The expert will provide structured analysis in JSON format:

```json
{
  "executive_summary": {
    "total_records": 15234,
    "detection_accuracy": 94.2,
    "false_positive_rate": 3.1,
    "key_findings": [
      "High accuracy for email detection (98.5%)",
      "Single words being detected as names (723 cases)",
      "Business terms misclassified as PII (156 cases)"
    ]
  },
  "detailed_analysis": {
    "pii_type_performance": {},
    "source_comparison": {},
    "page_distribution": {},
    "length_patterns": {},
    "sensitivity_assessment": {}
  },
  "quality_issues": [
    {
      "type": "Single words as names",
      "severity": "HIGH",
      "count": 723,
      "recommendation": "Implement multi-word validation for name detection"
    }
  ],
  "recommendations": {
    "immediate_actions": [
      "Review single-word name detections",
      "Update regex patterns to exclude business terms"
    ],
    "optimization_suggestions": [
      "Increase ML model confidence threshold",
      "Add post-processing validation rules"
    ]
  }
}
```

## Integration with Analysis Script

The chat mode leverages the enhanced `analyze_results.py` script which includes:

### New Analysis Methods
- `analyze_detection_accuracy()`: Analyzes PII_RESULTS true/false patterns
- `analyze_sensitivity_levels()`: Examines sensitivity level distribution and performance

### Enhanced Features
- Detection accuracy calculations by PII type
- Cross-analysis between sensitivity levels and detection rates
- Improved quality issue detection
- Better visualization outputs

### Usage Example
```python
# Direct script usage
analyzer = PIIResultsAnalyzer("path/to/results.xlsx")
analyzer.run_complete_analysis()

# Or use via chat mode commands
# "Analyze PII results in output/latest_results.xlsx"
```

## Quality Assessment Criteria

### Accuracy Thresholds
- Overall detection accuracy: >95%
- False positive rate: <2%
- False negative rate: <3%

### Quality Issue Priorities
1. **HIGH**: Business terms as PII, single words as names
2. **MEDIUM**: Length anomalies, source bias
3. **LOW**: Minor formatting inconsistencies

## Customization Options

### Analysis Parameters
You can customize the analysis by modifying these parameters in the script:
- Minimum detection threshold
- Quality issue severity levels
- Visualization preferences
- Report output format

### Adding New PII Types
To add support for new PII types:
1. Update the PII type analysis patterns
2. Add specific quality checks for the new type
3. Include in the visualization categories

## Troubleshooting Common Issues

### Missing Columns
If required columns are missing, the expert will:
- Identify which columns are missing
- Suggest alternative analysis approaches
- Provide partial analysis with available data

### Data Quality Issues
For data quality problems, the expert will:
- Identify and categorize the issues
- Provide specific examples
- Suggest remediation steps
- Prioritize fixes by impact

### Performance Optimization
For large datasets:
- Use sampling for initial analysis
- Focus on specific PII types or pages
- Generate summary statistics first
- Create targeted deep-dive analyses

## Best Practices

### Before Analysis
1. Ensure Excel file is properly formatted
2. Verify all required columns are present
3. Check for data consistency issues
4. Have clear analysis objectives

### During Analysis
1. Start with overview analysis
2. Focus on accuracy metrics first
3. Investigate quality issues systematically
4. Compare performance across dimensions

### After Analysis
1. Review all quality issues identified
2. Prioritize fixes based on severity
3. Implement recommended improvements
4. Re-analyze to validate improvements

## Support and Updates

This chat mode configuration is designed to be:
- Easily updatable with new analysis methods
- Extensible for additional PII types
- Compatible with various Excel file formats
- Scalable for different dataset sizes

For updates and improvements, modify the `pii-analysis-expert.md` file and the corresponding `analyze_results.py` script as needed.
