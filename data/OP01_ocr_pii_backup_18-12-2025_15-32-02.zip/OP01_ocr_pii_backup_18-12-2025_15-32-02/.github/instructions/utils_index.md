# Helper Functions Index (`src/utils`)

| Function/Class Name         | File Path                                 | Description |
|----------------------------|-------------------------------------------|-------------|
| Credentials (class)        | src/utils/credentials_utils.py            | Handles encrypted credentials, loads and decrypts user credentials from Excel files. |
| decrypt_msg                | src/utils/credentials_utils.py            | Decrypts an encrypted message using a key. |
| inti_desiered_credentials  | src/utils/credentials_utils.py            | Loads and sets the desired credentials from the Excel file. |
| start_logging              | src/utils/fmw_utils.py                    | Initializes logging to file and/or console with custom formatting. |
| Config (class)             | src/utils/fmw_utils.py                    | Loads and builds configuration from JSONC files, manages config paths. |
| build_config               | src/utils/fmw_utils.py                    | Builds and returns the full configuration dictionary. |
| read_config                | src/utils/fmw_utils.py                    | Reads the main config file and returns it as a dictionary. |
| get_config_tag_keys        | src/utils/fmw_utils.py                    | Recursively collects tag keys from config dictionaries. |
| build_absolute_config_paths| src/utils/fmw_utils.py                    | Converts relative config paths to absolute paths. |
| read_json                  | src/utils/fmw_utils.py                    | Reads a JSON file and returns its contents. |
| read_jsonc                 | src/utils/fmw_utils.py                    | Reads a JSONC (JSON with comments) file and returns its contents. |
| save_json_file             | src/utils/fmw_utils.py                    | Saves a dictionary as a JSON file. |
| delete_folder              | src/utils/fmw_utils.py                    | Deletes a folder and its contents. |
| create_folder              | src/utils/fmw_utils.py                    | Creates a folder if it does not exist. |
| save_excel_file            | src/utils/fmw_utils.py                    | Saves a pandas DataFrame to an Excel file with formatting. |
| kill_processes             | src/utils/fmw_utils.py                    | Kills a list of processes by name using PowerShell. |
| add_dt_offset              | src/utils/fmw_utils.py                    | Adds a time offset to a datetime object. |
| last_day_in_month          | src/utils/fmw_utils.py                    | Returns the last day of the month for a given datetime. |
| obtain_months              | src/utils/fmw_utils.py                    | Obtains the months from a JSON file. |
| dt_to_spanish              | src/utils/fmw_utils.py                    | Converts a datetime to its Spanish month or day name. |
| log_worktray_metadata      | src/utils/fmw_utils.py                    | Logs worktray metadata, including status counts and file existence. |
| get_total_states           | src/utils/fmw_utils.py                    | Gets the total number of states defined in main.py. |
| mask_number                | src/utils/fmw_utils.py                    | Masks a number, showing only the last digits and decimals. |
| get_size                   | src/utils/fmw_utils.py                    | Gets the size of a file in the specified unit. |
| get_last_log_file          | src/utils/fmw_utils.py                    | Gets the most recently modified log file in the log folder. |
| build_execution_summary_table | src/utils/fmw_utils.py                | Builds and saves an execution summary table as a DataFrame and JSON file. |
| remove_path_until_tag      | src/utils/fmw_utils.py                    | Shortens a given path, removing its first part until a specific folder/tag. |
| save_txt_file              | src/utils/fmw_utils.py                    | Saves a string as a text file. |
| read_txt                   | src/utils/fmw_utils.py                    | Reads a text file and returns its contents. |
| remove_accents             | src/utils/fmw_utils.py                    | Removes accents from a string. |
| number_to_currency         | src/utils/fmw_utils.py                    | Converts a number to Chilean currency format. |
| delete_old_folders         | src/utils/fmw_utils.py                    | Deletes old folders according to a month offset and date format. |
| create_backup              | src/utils/fmw_utils.py                    | Copies a file to a backup folder, avoiding overwrites by renaming duplicates. |
| build_execution_summary_table_eb | src/utils/fmw_utils.py              | Builds and saves a minimal execution summary table for EB processes. |
| check_files_exist          | src/utils/fmw_utils.py                    | Checks if all required files exist. Raises FileNotFoundError if any are missing. |
| write_process_status       | src/utils/fmw_utils.py                    | Appends the process status and timestamp to a JSON file in the process_data folder. |
| BusinessException (class)  | src/utils/fmw_utils.py                    | Custom exception for business logic errors. |
| SeleniumUtils (class)      | src/utils/selenium_utils.py               | Utility class for automating web browsers with Selenium, including driver setup and common actions. |
| init_edge_driver           | src/utils/selenium_utils.py               | Initializes the Edge web driver with custom options. |
| open_website               | src/utils/selenium_utils.py               | Opens a website in the browser. |
| close_website              | src/utils/selenium_utils.py               | Closes a specific website tab. |
| close_all_websites         | src/utils/selenium_utils.py               | Closes all open browser tabs. |
| switch_to_tab              | src/utils/selenium_utils.py               | Switches to a browser tab by URL or index. |
| element_exists             | src/utils/selenium_utils.py               | Checks if a web element exists on the page. |
| click_element              | src/utils/selenium_utils.py               | Clicks a web element, with optional hover. |
| populate_field             | src/utils/selenium_utils.py               | Fills a form field with text. |
| send_keys                  | src/utils/selenium_utils.py               | Sends keyboard input to an element. |
| switch_frame               | src/utils/selenium_utils.py               | Switches to a specific iframe on the page. |
| close_driver               | src/utils/selenium_utils.py               | Closes the Selenium web driver. |
| check_unfinished_downloads | src/utils/selenium_utils.py               | Checks for unfinished downloads in the download folder. |
| wait_for_element_visibility| src/utils/selenium_utils.py               | Waits for an element to be visible on the page. |
| to_element                 | src/utils/selenium_utils.py               | Scrolls to a specific element on the page. |
| check_exist                | src/utils/selenium_utils.py               | Checks if an element exists using find_element (no wait). |
| get_text                   | src/utils/selenium_utils.py               | Gets the text of a web element. |
| wait_for_page_load         | src/utils/selenium_utils.py               | Waits for the page to load completely. |
| find_elements              | src/utils/selenium_utils.py               | Finds all elements matching a selector. |
| find_element               | src/utils/selenium_utils.py               | Finds a single element matching a selector. |
| hover_element              | src/utils/selenium_utils.py               | Hovers the mouse over a web element. |
| execute_script             | src/utils/selenium_utils.py               | Executes a JavaScript script in the browser. |
| scroll_to_element          | src/utils/selenium_utils.py               | Scrolls the page to a specific element. |
| screenshot                 | src/utils/selenium_utils.py               | Takes a screenshot of the current page. |
| wait_for_element           | src/utils/selenium_utils.py               | Waits for an element to be present and visible. Returns the element or raises TimeoutException. |
| switch_to_default_content  | src/utils/selenium_utils.py               | Switches the Selenium driver context to the default content (main document). |
| scroll_to_bottom           | src/utils/selenium_utils.py               | Scrolls to the bottom of the page. |
| scroll_down_with_mouse     | src/utils/selenium_utils.py               | Simulates mouse scroll down by sending PAGE_DOWN key. |
| scroll_up_with_mouse       | src/utils/selenium_utils.py               | Simulates mouse scroll up by sending ARROW_UP key. |
| scroll_to_end_with_mouse   | src/utils/selenium_utils.py               | Simulates mouse scroll to the bottom by sending END key. |
| list_all_frames            | src/utils/selenium_utils.py               | Logs all iframe and frame elements on the current page. |
| get_current_url            | src/utils/selenium_utils.py               | Returns the current URL of the Selenium driver. |
| wait_for_download_completion | src/utils/selenium_utils.py             | Waits for file download completion in a directory. |
| is_file_download_complete  | src/utils/selenium_utils.py               | Checks if file download is complete by monitoring file size stability. |
| check_file_downloaded      | src/utils/selenium_utils.py               | Checks if a file matching the pattern exists and is fully downloaded. |
| keep_session_active        | src/utils/selenium_utils.py               | Keeps the browser session active by performing a minimal action. |
| get_all_links              | src/utils/selenium_utils.py               | Retrieve all hyperlinks from the current page as a list of URLs. |
| take_screenshot             | src/utils/selenium_utils.py               | Take a screenshot of the current page, with an optional filename prefix. |
| XLWingsUtils (class)       | src/utils/xlwings_utils.py                | Comprehensive utility class for Excel automation using xlwings. |
| start_app                  | src/utils/xlwings_utils.py                | Starts Excel application with configured settings. |
| quit_app                   | src/utils/xlwings_utils.py                | Quits Excel application and cleanup. |
| open_workbook              | src/utils/xlwings_utils.py                | Opens Excel workbook with error handling. |
| read_recipients_file       | src/utils/send_email_utils.py             | Reads an Excel file and returns recipient lists for email (to, cc, bcc) based on environment and type. |
| df2html                    | src/utils/send_email_utils.py             | Converts a pandas DataFrame to an HTML table for email. |
| send_email                 | src/utils/send_email_utils.py             | Sends an email with subject, recipients, body, and attachments using Outlook. |
| ExceptionEmails (class)    | src/utils/send_exceptions_emails.py       | Handles sending exception-related emails (system, user, business exceptions). |
| send_user_system_exception | src/utils/send_exceptions_emails.py       | Sends a user system exception email. |
| send_system_exception      | src/utils/send_exceptions_emails.py       | Sends a system exception email with error details. |
| send_business_exception    | src/utils/send_exceptions_emails.py       | Sends a business exception email with custom info. |

**Configuration variables are managed in `config.jsonc` at the project root. If present, use `src/utils/constants.py` for project-wide constants.**

Files excluded: monitoring.py, robot_date.py, base_workflow.py
