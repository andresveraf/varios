# Email Filtering by Country/Sheet - Implementation Summary

## Overview
Updated the email functions to filter recipients by detected country/sheet. Now emails are sent to country-specific managers based on the report filename.

## Changes Made

### 1. **Updated `_get_manager_emails()` Function**
   - **Parameter**: Now accepts optional `sheet_name` parameter
   - **Logic**: 
     - If `sheet_name` is provided (Brasil, Chile, Colombia, Argentina, Uruguay), reads from country-specific email column
     - Maps sheet names to email columns:
       - Brasil → `brazil_manager_email`
       - Chile → `chile_manager_email`
       - Colombia → `colombia_manager_email`
       - Argentina → `argentina_manager_email`
       - Uruguay → `uruguay_manager_email`
     - Falls back to default `Manager_email` column if country-specific column doesn't exist
   - **Logging**: Detailed logging showing which column is being used

### 2. **Updated `_send_single_resume_email()` Function**
   - **Change**: Now passes `detected_sheet_name` to `_get_manager_emails()`
   - **Result**: Resume emails are sent only to managers of the detected country
   - **Example**:
     ```python
     # File: "Reporte PII - Brasil - 123.xlsx"
     # → Detects: Brasil
     # → Calls: _get_manager_emails(sheet_name='Brazil')
     # → Reads from: brazil_manager_email column
     ```

### 3. **Updated `_get_responsible_email()` Function**
   - **Parameter**: Now accepts optional `sheet_name` parameter
   - **Logic**:
     - Uses country-specific email column if `sheet_name` provided
     - Maps sheet names to email columns (same as manager function)
     - Falls back to default `Responsible_email` column if needed
   - **Matching**: Still matches folder name, but now filters by country

### 4. **Updated `_send_folder_email()` Function**
   - **Change 1**: Automatically detects country/sheet from folder name
   - **Change 2**: Passes detected sheet to `_get_responsible_email()`
   - **Result**: Folder emails are sent only to responsible person for that country
   - **Example**:
     ```python
     # Folder: "Brasil - 123.1-Gestión mandatos"
     # → Detects: Brasil (sheet='Brazil')
     # → Calls: _get_responsible_email(folder_name, sheet_name='Brazil')
     # → Reads from: brazil_responsible_email column
     ```

## Email Column Structure

The `Listado encargados Chile.xlsx` file should have columns:

```
| Folder/Document | Manager_email | brazil_manager_email | chile_manager_email | ...
| Responsible_email | brazil_responsible_email | chile_responsible_email | ...
```

## Backward Compatibility

✅ **Fully backward compatible**:
- If country-specific columns don't exist → falls back to default columns
- If `sheet_name` parameter not provided → uses default columns
- Existing code continues to work without modifications

## Flow Diagrams

### Resume Email Flow
```
Resume File: "Reporte PII - Brasil - 123.1-Gestión mandatos.xlsx"
      ↓
_send_single_resume_email()
      ↓
Detect sheet: detector.get_sheet_name() → "Brazil"
      ↓
_get_manager_emails(sheet_name="Brazil")
      ↓
Read from "brazil_manager_email" column
      ↓
Send to [email1@brasil, email2@brasil]
```

### Folder Email Flow
```
Folder: "Reporte PII - Chile - 456.2-Análisis"
      ↓
_send_folder_email(folder_name, ...)
      ↓
Detect sheet: detector.get_sheet_name() → "Chile"
      ↓
_get_responsible_email(folder_name, sheet_name="Chile")
      ↓
Match folder name + Read from "chile_responsible_email" column
      ↓
Send to manager@chile.cl
```

## Test Output

```
Test: Resume email for Brazil report
Filename: Reporte PII - Brasil - 123.1-Gestión mandatos físicos PAC
  Detected Country: Brasil
  Detected Sheet: Brazil
  Email Column to Use: brazil_responsible_email

  ACTION: Call _get_manager_emails(sheet_name='Brazil')
  → Will read from 'brazil_manager_email' column
```

## Benefits

1. **Country-specific email routing**: Each country's managers only receive their country's reports
2. **Automatic detection**: No manual configuration needed - detected from filename
3. **Flexible**: Supports both generic and country-specific email columns
4. **Robust**: Falls back gracefully if country-specific columns missing
5. **Maintainable**: Centralized country detection logic

## Implementation Details

### Country Detection
- Uses `CountrySheetDetector` class (already implemented)
- Detects: Brasil/Brazil, Chile, Colombia, Argentina, Uruguay
- Case-insensitive, works with various filename formats

### Sheet Mapping
```python
'Brasil' → 'Brazil' (sheet name)
'Chile' → 'Chile'
'Colombia' → 'Colombia'
'Argentina' → 'Argentina'
'Uruguay' → 'Uruguay'
```

### Email Column Mapping
```python
Manager emails:
'Brasil' → 'brazil_manager_email'
'Chile' → 'chile_manager_email'
...

Responsible emails:
'Brasil' → 'brazil_responsible_email'
'Chile' → 'chile_responsible_email'
...
```

## Next Steps (Optional)

1. Add country-specific email columns to `Listado encargados Chile.xlsx`:
   - `brazil_manager_email`
   - `chile_manager_email`
   - `colombia_manager_email`
   - `argentina_manager_email`
   - `uruguay_manager_email`
   - Similar columns for responsible emails

2. Populate these columns with country-specific manager contact information

3. Test email routing with actual reports from each country

## Testing

Run the demonstration:
```bash
cd c:\RPA\repositorio\OPS\OP01_ocr_pii
python test_email_filtering.py
```

This shows:
- How filenames are mapped to countries
- Which email columns will be used
- The calling functions and their parameters
- Fallback behavior

## Summary

✅ **Email filtering by country successfully implemented**
- Automatic detection from filename
- Country-specific email column filtering
- Backward compatible with existing code
- Robust error handling and logging
- Ready for production use
