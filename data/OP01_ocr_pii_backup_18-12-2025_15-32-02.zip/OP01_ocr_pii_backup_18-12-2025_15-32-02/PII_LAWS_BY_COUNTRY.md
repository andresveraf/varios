# Driven Document Safety - PII Project

## Overview
This RPA solution processes documents across four Latin American countries, extracting and managing Personally Identifiable Information (PII) while ensuring compliance with regional data protection laws.

---

## Countries & PII Protection Laws

### 🇨🇱 Chile
**Primary Law:** Law No. 19,628 on Data Protection (1999)
- Regulates collection, processing, and storage of personal data
- Requires consent for data processing
- Grants rights to access, rectification, and deletion
- Enforced by the Personal Data Protection National Authority

### 🇺🇾 Uruguay
**Primary Law:** Law No. 18,655 on Data Protection (2010)
- One of the strongest data protection frameworks in Latin America
- Aligns closely with European GDPR principles
- Requires data processors to implement security measures
- Enforced by the Data Protection Authority

### 🇨🇴 Colombia
**Primary Law:** Law 1581 of 2012 (Habeas Data Law)
- Establishes the right to know, update, and rectify personal information
- Requires explicit consent for personal data processing
- Defines obligations for data controllers and processors
- Enforced by the Superintendent of Industry and Commerce

### 🇧🇷 Brasil
**Primary Law:** Law 13,709/2018 (LGPD - Lei Geral de Proteção de Dados)
- Brazil's General Data Protection Law
- Establishes requirements for personal data processing
- Mandates accountability and transparency
- Requires appointment of Data Protection Officers
- Enforced by the National Data Protection Authority

---

## PII Categories Covered
- **Personal Identifiers:** Names, ID numbers, passport numbers
- **Contact Information:** Email addresses, phone numbers, addresses
- **Financial Data:** Bank accounts, credit card information
- **Biometric Data:** Fingerprints, facial recognition data
- **Special Categories:** Health information, racial/ethnic origin

---

## RPA Solution Compliance
The OCR and PII extraction system must:
✓ Identify and redact/mask sensitive personal information
✓ Maintain audit logs of data processing
✓ Ensure data security and encryption
✓ Respect country-specific data retention policies
✓ Enable data subject rights (access, deletion, rectification)
