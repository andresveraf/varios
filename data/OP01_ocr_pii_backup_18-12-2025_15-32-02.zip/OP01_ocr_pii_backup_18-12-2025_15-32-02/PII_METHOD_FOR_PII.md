# PII Detection Methodology - Hybrid Approach

## Executive Overview
This project implements a **Hybrid PII Detection Solution** combining rule-based patterns (Regex) with Machine Learning models to accurately identify and extract sensitive information from documents across multiple Latin American countries.

---

## Technical Architecture

### 1. Document Processing Pipeline
```mermaid
graph TD
    A[Input Documents<br/>PDF/DOCX/Images] --> B[OCR Extraction<br/>Tesseract/Azure Vision]
    B --> C[Text Normalization<br/>& Cleaning]
    C --> D[Hybrid PII Detection<br/>Regex + ML Models]
    D --> E[Data Validation<br/>& Consolidation]
    E --> F[Output Reports<br/>& Dashboards]
```

### 2. Hybrid Detection Methods

#### **A. Regex Pattern Matching (Rule-Based)**
- **Strengths:** Fast, deterministic, high precision for structured patterns
- **Use Cases:** ID numbers, phone formats, email addresses, credit cards
- **Languages:** Python `re` module with localized patterns per country

#### **B. Machine Learning Models (NER - Named Entity Recognition)**
- **Technology:** Transformer-based models (XLM-RoBERTa, BERT-based NER)
- **Approach:** Token-level classification using pre-trained models
- **Strengths:** Context-aware detection, handles variations, identifies implicit PII
- **Models Used:**
  - `xlm-roberta-large-ner-spanish`
  - `distiluse-base-multilingual-cased-v2`
  - Country-specific fine-tuned models

#### **C. Hybrid Decision Logic**
```mermaid
graph TD
    A[Extracted Text<br/>from Document] --> B{Apply Regex<br/>Patterns}
    B -->|High Confidence Match| C[FLAGGED<br/>as PII]
    B -->|No/Low Match| D[Run NER<br/>ML Models]
    D -->|Entity Classified<br/>as PII| E[FLAGGED<br/>as PII]
    D -->|Not PII| F[NOT PII]
    C --> G[Confidence<br/>Scoring]
    E --> G
    G --> H[Final Decision<br/>& Classification]
```

---

## PII Types by Country

### Country Detection Flow
```mermaid
graph LR
    A[Document<br/>Detected] --> B{Identify<br/>Country}
    B -->|Chile| C[Load Chile<br/>Patterns]
    B -->|Uruguay| D[Load Uruguay<br/>Patterns]
    B -->|Colombia| E[Load Colombia<br/>Patterns]
    B -->|Brasil| F[Load Brasil<br/>Patterns]
    C --> G[Extract PII<br/>with Country Rules]
    D --> G
    E --> G
    F --> G
    G --> H[Country-Specific<br/>Report]
```

### 🇨🇱 **CHILE**
| PII Type | Example Format | Detection Method |
|----------|---|---|
| **RUT (ID Number)** | XX.XXX.XXX-X (8-9 digits + check digit) | Regex + Validation Algorithm |
| **Names** | Juan García Pérez | NER (Person entities) |
| **Phone** | +56 9 XXXX XXXX | Regex pattern |
| **Email** | usuario@empresa.cl | Regex pattern |
| **Passport** | NumeroPasaporte | Regex + Keywords |

### 🇺🇾 **URUGUAY**
| PII Type | Example Format | Detection Method |
|----------|---|---|
| **CI (Cédula Identity)** | X.XXX.XXX-X (7-8 digits) | Regex + Validation |
| **Names** | Carlos Rodríguez López | NER (Person entities) |
| **Phone** | +598 9 XXXX XXXX | Regex pattern |
| **Email** | correo@empresa.uy | Regex pattern |
| **Financial Accounts** | Cuenta/Tarjeta XXXX | NER + Keywords |

### 🇨🇴 **COLOMBIA**
| PII Type | Example Format | Detection Method |
|----------|---|---|
| **CC (Cédula Ciudadanía)** | X.XXX.XXX-X (8-10 digits) | Regex + Validation |
| **Names** | María González Flores | NER (Person entities) |
| **Phone** | +57 1 XXXX XXXX | Regex pattern |
| **Email** | info@empresa.com.co | Regex pattern |
| **NIT (Business ID)** | XXX.XXX.XXX-X | Regex pattern |

### 🇧🇷 **BRASIL**
| PII Type | Example Format | Detection Method |
|----------|---|---|
| **CPF (Taxpayer ID)** | XXX.XXX.XXX-XX (11 digits) | Regex + Validation Algorithm |
| **CNPJ (Business ID)** | XX.XXX.XXX/XXXX-XX (14 digits) | Regex + Validation |
| **Names** | João Silva Santos | NER (Person entities) |
| **Phone** | +55 11 XXXX-XXXX | Regex pattern |
| **Email** | contato@empresa.br | Regex pattern |

---

## Implementation Benefits

✅ **Accuracy:** Combines precision of rules with flexibility of ML
✅ **Speed:** Regex handles 80% of cases; ML processes complex cases
✅ **Scalability:** Handles multiple languages and document formats
✅ **Adaptability:** Easy to add new patterns or fine-tune models
✅ **Compliance:** Country-specific detection ensures regional compliance

---

## Key Technologies
- **Language:** Python 3.13
- **OCR:** Tesseract, Azure Vision API
- **Document Processing:** PyPDF2, python-docx, Pillow
- **ML Models:** Hugging Face Transformers, spaCy
- **Data Pipeline:** Pandas, NumPy
- **Output:** Excel reports, JSON structured data

