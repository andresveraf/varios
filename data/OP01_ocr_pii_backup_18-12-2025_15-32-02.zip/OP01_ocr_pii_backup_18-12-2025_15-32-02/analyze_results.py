#!/usr/bin/env python3
"""
PII Detection Results Analysis Script

This script analyzes the output from PII detection processes, providing comprehensive
statistics and insights about detected entities, patterns, and quality metrics.


How to use : run the script with the path to the Excel file as an argument, e.g.:
python analyze_results.py "C:\RPA\repositorio\OPS\OP01_ocr_pii\output\OCR_PII_Analysis_HYBRID_20250912_113208.xlsx"

Author: Analysis Script
Date: 2025-09-12
"""

import pandas as pd
import numpy as np
from collections import Counter, defaultdict
import json
import os
import sys
from typing import Dict, List, Any, Optional, Tuple
import warnings
from datetime import datetime
import re

# Import visualization libraries
import matplotlib.pyplot as plt
import seaborn as sns

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Set up plotting style
plt.style.use('default')
sns.set_palette("husl")
VISUALIZATION_AVAILABLE = True

print("📊 Visualization libraries loaded successfully")

class PIIResultsAnalyzer:
    """Comprehensive analyzer for PII detection results"""
    
    def __init__(self, excel_file_path: str):
        """
        Initialize the analyzer with the Excel file path.
        
        Args:
            excel_file_path (str): Path to the Excel file containing PII results
        """
        self.excel_file_path = excel_file_path
        self.df = None
        self.analysis_results = {}
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create output directory for images
        self.output_dir = os.path.join(os.path.dirname(excel_file_path), "images")
        os.makedirs(self.output_dir, exist_ok=True)
        
    def load_data(self) -> bool:
        """
        Load and validate the Excel data.
        
        Returns:
            bool: True if data loaded successfully, False otherwise
        """
        try:
            if not os.path.exists(self.excel_file_path):
                print(f"❌ ERROR: File not found: {self.excel_file_path}")
                return False
            
            print(f"📊 Loading data from: {self.excel_file_path}")
            
            # Read the Combined_PII_Results sheet
            self.df = pd.read_excel(self.excel_file_path, sheet_name='Combined_PII_Results')
            
            print(f"✅ Data loaded successfully!")
            print(f"   📋 Total records: {len(self.df):,}")
            print(f"   📋 Columns: {list(self.df.columns)}")
            
            # Basic data validation
            if self.df.empty:
                print("❌ ERROR: Dataset is empty")
                return False
                
            return True
            
        except Exception as e:
            print(f"❌ ERROR loading data: {e}")
            return False
    
    def basic_overview(self) -> Dict[str, Any]:
        """
        Generate basic overview statistics.
        
        Returns:
            Dict[str, Any]: Basic statistics and overview metrics
        """
        print("\n" + "="*60)
        print("📈 BASIC OVERVIEW ANALYSIS")
        print("="*60)
        
        overview = {
            'total_records': len(self.df),
            'total_columns': len(self.df.columns),
            'columns': list(self.df.columns),
            'data_types': self.df.dtypes.to_dict(),
            'memory_usage': self.df.memory_usage(deep=True).sum(),
            'null_counts': self.df.isnull().sum().to_dict()
        }
        
        print(f"📊 Dataset Shape: {self.df.shape}")
        print(f"💾 Memory Usage: {overview['memory_usage']:,} bytes")
        
        # Null value analysis
        null_counts = self.df.isnull().sum()
        if null_counts.sum() > 0:
            print("\n🔍 NULL VALUES DETECTED:")
            for col, count in null_counts.items():
                if count > 0:
                    percentage = (count / len(self.df)) * 100
                    print(f"   {col}: {count:,} ({percentage:.1f}%)")
        else:
            print("✅ No null values detected")
        
        self.analysis_results['overview'] = overview
        return overview
    
    def analyze_pii_types(self) -> Dict[str, Any]:
        """
        Analyze PII_Type distribution and patterns.
        
        Returns:
            Dict[str, Any]: PII type analysis results
        """
        print("\n" + "="*60)
        print("🔍 PII TYPE ANALYSIS")
        print("="*60)
        
        if 'PII_Type' not in self.df.columns:
            print("❌ PII_Type column not found")
            return {}
        
        pii_type_counts = self.df['PII_Type'].value_counts()
        pii_type_percentages = self.df['PII_Type'].value_counts(normalize=True) * 100
        
        analysis = {
            'unique_types': len(pii_type_counts),
            'type_counts': pii_type_counts.to_dict(),
            'type_percentages': pii_type_percentages.to_dict(),
            'most_common': pii_type_counts.head(10).to_dict(),
            'least_common': pii_type_counts.tail(5).to_dict()
        }
        
        print(f"🏷️  Unique PII Types: {analysis['unique_types']}")
        print(f"📊 Most Common Types:")
        for pii_type, count in analysis['most_common'].items():
            percentage = analysis['type_percentages'][pii_type]
            print(f"   {pii_type}: {count:,} ({percentage:.1f}%)")
        
        # Create visualization
        try:
            plt.figure(figsize=(12, 8))
            top_10_types = pii_type_counts.head(10)
            
            plt.subplot(2, 1, 1)
            bars = plt.bar(range(len(top_10_types)), top_10_types.values)
            plt.title('Top 10 PII Types Distribution', fontsize=14, fontweight='bold')
            plt.xlabel('PII Type')
            plt.ylabel('Count')
            plt.xticks(range(len(top_10_types)), top_10_types.index, rotation=45, ha='right')
            
            # Add value labels on bars
            for i, bar in enumerate(bars):
                height = bar.get_height()
                plt.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                        f'{int(height):,}', ha='center', va='bottom', fontsize=9)
            
            plt.tight_layout()
            chart_path = os.path.join(self.output_dir, f'pii_types_analysis_{self.timestamp}.png')
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.show()
            print(f"📊 Chart saved: {chart_path}")
        except Exception as e:
            print(f"⚠️  Could not create visualization: {e}")
        
        self.analysis_results['pii_types'] = analysis
        return analysis
    
    def analyze_sources(self) -> Dict[str, Any]:
        """
        Analyze Source distribution (regex, ML, hybrid).
        
        Returns:
            Dict[str, Any]: Source analysis results
        """
        print("\n" + "="*60)
        print("🔧 SOURCE ANALYSIS")
        print("="*60)
        
        source_analysis = {}
        
        # Analyze Source column if it exists
        if 'Source' in self.df.columns:
            source_counts = self.df['Source'].value_counts()
            source_percentages = self.df['Source'].value_counts(normalize=True) * 100
            
            source_analysis['source_distribution'] = {
                'counts': source_counts.to_dict(),
                'percentages': source_percentages.to_dict()
            }
            
            print("📊 Source Distribution:")
            for source, count in source_counts.items():
                percentage = source_percentages[source]
                print(f"   {source}: {count:,} ({percentage:.1f}%)")
        
        # Analyze Source_Type column if it exists
        if 'Source_Type' in self.df.columns:
            source_type_counts = self.df['Source_Type'].value_counts()
            source_type_percentages = self.df['Source_Type'].value_counts(normalize=True) * 100
            
            source_analysis['source_type_distribution'] = {
                'counts': source_type_counts.to_dict(),
                'percentages': source_type_percentages.to_dict()
            }
            
            print("\n📊 Source Type Distribution:")
            for source_type, count in source_type_counts.items():
                percentage = source_type_percentages[source_type]
                print(f"   {source_type}: {count:,} ({percentage:.1f}%)")
        
        # Cross-analysis: PII Type by Source
        if 'Source' in self.df.columns and 'PII_Type' in self.df.columns:
            cross_analysis = pd.crosstab(self.df['PII_Type'], self.df['Source'])
            source_analysis['pii_type_by_source'] = cross_analysis.to_dict()
            
            print("\n🔄 Top PII Types by Source:")
            for source in cross_analysis.columns:
                top_types = cross_analysis[source].nlargest(5)
                print(f"   {source}:")
                for pii_type, count in top_types.items():
                    if count > 0:
                        print(f"     {pii_type}: {count:,}")
        
        self.analysis_results['sources'] = source_analysis
        return source_analysis
    
    def analyze_length_patterns(self) -> Dict[str, Any]:
        """
        Analyze PII_Length distribution and patterns.
        
        Returns:
            Dict[str, Any]: Length analysis results
        """
        print("\n" + "="*60)
        print("📏 LENGTH PATTERN ANALYSIS")
        print("="*60)
        
        if 'PII_Length' not in self.df.columns:
            print("❌ PII_Length column not found")
            return {}
        
        # Convert to numeric, handling any string values
        pii_lengths = pd.to_numeric(self.df['PII_Length'], errors='coerce')
        valid_lengths = pii_lengths.dropna()
        
        length_analysis = {
            'total_records': len(self.df),
            'valid_length_records': len(valid_lengths),
            'invalid_length_records': len(pii_lengths) - len(valid_lengths),
            'min_length': int(valid_lengths.min()) if len(valid_lengths) > 0 else None,
            'max_length': int(valid_lengths.max()) if len(valid_lengths) > 0 else None,
            'mean_length': round(valid_lengths.mean(), 2) if len(valid_lengths) > 0 else None,
            'median_length': int(valid_lengths.median()) if len(valid_lengths) > 0 else None,
            'std_length': round(valid_lengths.std(), 2) if len(valid_lengths) > 0 else None
        }
        
        print(f"📊 Length Statistics:")
        print(f"   Valid records: {length_analysis['valid_length_records']:,}")
        print(f"   Min length: {length_analysis['min_length']}")
        print(f"   Max length: {length_analysis['max_length']}")
        print(f"   Mean length: {length_analysis['mean_length']}")
        print(f"   Median length: {length_analysis['median_length']}")
        
        # Length distribution by PII Type
        if 'PII_Type' in self.df.columns:
            length_by_type = {}
            for pii_type in self.df['PII_Type'].unique():
                type_lengths = self.df[self.df['PII_Type'] == pii_type]['PII_Length']
                type_lengths = pd.to_numeric(type_lengths, errors='coerce').dropna()
                if len(type_lengths) > 0:
                    length_by_type[pii_type] = {
                        'mean': round(type_lengths.mean(), 2),
                        'median': int(type_lengths.median()),
                        'min': int(type_lengths.min()),
                        'max': int(type_lengths.max()),
                        'count': len(type_lengths)
                    }
            
            length_analysis['length_by_type'] = length_by_type
            
            print(f"\n📊 Average Length by PII Type (Top 10):")
            sorted_types = sorted(length_by_type.items(), 
                                key=lambda x: x[1]['mean'], reverse=True)[:10]
            for pii_type, stats in sorted_types:
                print(f"   {pii_type}: {stats['mean']:.1f} chars (median: {stats['median']})")
        
        # Create length distribution visualization
        if len(valid_lengths) > 0:
            try:
                plt.figure(figsize=(15, 10))
                
                # Overall length distribution
                plt.subplot(2, 2, 1)
                plt.hist(valid_lengths, bins=50, alpha=0.7, edgecolor='black')
                plt.title('PII Length Distribution', fontweight='bold')
                plt.xlabel('Length (characters)')
                plt.ylabel('Frequency')
                
                # Box plot by PII Type (top 10 types)
                if 'PII_Type' in self.df.columns:
                    plt.subplot(2, 2, 2)
                    top_types = self.df['PII_Type'].value_counts().head(10).index
                    plot_data = []
                    plot_labels = []
                    for pii_type in top_types:
                        type_lengths = self.df[self.df['PII_Type'] == pii_type]['PII_Length']
                        type_lengths = pd.to_numeric(type_lengths, errors='coerce').dropna()
                        if len(type_lengths) > 0:
                            plot_data.append(type_lengths)
                            plot_labels.append(pii_type)
                    
                    if plot_data:
                        plt.boxplot(plot_data, labels=plot_labels)
                        plt.title('Length Distribution by PII Type (Top 10)', fontweight='bold')
                        plt.xlabel('PII Type')
                        plt.ylabel('Length (characters)')
                        plt.xticks(rotation=45, ha='right')
                
                plt.tight_layout()
                chart_path = os.path.join(self.output_dir, f'length_analysis_{self.timestamp}.png')
                plt.savefig(chart_path, dpi=300, bbox_inches='tight')
                plt.show()
                print(f"📊 Chart saved: {chart_path}")
            except Exception as e:
                print(f"⚠️  Could not create length visualization: {e}")
        else:
            print("📊 No valid length data for visualization")
        
        self.analysis_results['length_patterns'] = length_analysis
        return length_analysis
    
    def analyze_page_distribution(self) -> Dict[str, Any]:
        """
        Analyze Page distribution and patterns.
        
        Returns:
            Dict[str, Any]: Page analysis results
        """
        print("\n" + "="*60)
        print("📄 PAGE DISTRIBUTION ANALYSIS")
        print("="*60)
        
        if 'Page' not in self.df.columns:
            print("❌ Page column not found")
            return {}
        
        page_counts = self.df['Page'].value_counts().sort_index()
        page_analysis = {
            'total_pages': len(page_counts),
            'page_counts': page_counts.to_dict(),
            'entities_per_page_stats': {
                'min': int(page_counts.min()),
                'max': int(page_counts.max()),
                'mean': round(page_counts.mean(), 2),
                'median': int(page_counts.median())
            }
        }
        
        print(f"📊 Page Statistics:")
        print(f"   Total pages with PII: {page_analysis['total_pages']}")
        print(f"   Min entities per page: {page_analysis['entities_per_page_stats']['min']}")
        print(f"   Max entities per page: {page_analysis['entities_per_page_stats']['max']}")
        print(f"   Mean entities per page: {page_analysis['entities_per_page_stats']['mean']}")
        
        # Top pages with most PII
        top_pages = page_counts.nlargest(10)
        print(f"\n📊 Top 10 Pages with Most PII:")
        for page, count in top_pages.items():
            print(f"   Page {page}: {count:,} entities")
        
        # PII Type distribution by page (for top pages)
        if 'PII_Type' in self.df.columns:
            print(f"\n📊 PII Types on Top 5 Pages:")
            for page in top_pages.head(5).index:
                page_data = self.df[self.df['Page'] == page]
                page_types = page_data['PII_Type'].value_counts().head(5)
                print(f"   Page {page} ({top_pages[page]} total entities):")
                for pii_type, count in page_types.items():
                    print(f"     {pii_type}: {count}")
        
        # Create page distribution visualization
        try:
            plt.figure(figsize=(15, 6))
            
            plt.subplot(1, 2, 1)
            plt.plot(page_counts.index, page_counts.values, marker='o', linewidth=2, markersize=4)
            plt.title('PII Entities per Page', fontweight='bold')
            plt.xlabel('Page Number')
            plt.ylabel('Number of PII Entities')
            plt.grid(True, alpha=0.3)
            
            plt.subplot(1, 2, 2)
            plt.hist(page_counts.values, bins=20, alpha=0.7, edgecolor='black')
            plt.title('Distribution of PII Entities per Page', fontweight='bold')
            plt.xlabel('Number of PII Entities')
            plt.ylabel('Number of Pages')
            
            plt.tight_layout()
            chart_path = os.path.join(self.output_dir, f'page_analysis_{self.timestamp}.png')
            plt.savefig(chart_path, dpi=300, bbox_inches='tight')
            plt.show()
            print(f"📊 Chart saved: {chart_path}")
        except Exception as e:
            print(f"⚠️  Could not create page visualization: {e}")
        
        self.analysis_results['page_distribution'] = page_analysis
        return page_analysis
    
    def analyze_labels(self) -> Dict[str, Any]:
        """
        Analyze Label distribution and patterns.
        
        Returns:
            Dict[str, Any]: Label analysis results
        """
        print("\n" + "="*60)
        print("🏷️ LABEL ANALYSIS")
        print("="*60)
        
        if 'Label' not in self.df.columns:
            print("❌ Label column not found")
            return {}
        
        label_counts = self.df['Label'].value_counts()
        label_percentages = self.df['Label'].value_counts(normalize=True) * 100
        
        label_analysis = {
            'unique_labels': len(label_counts),
            'label_counts': label_counts.to_dict(),
            'label_percentages': label_percentages.to_dict()
        }
        
        print(f"🏷️  Unique Labels: {label_analysis['unique_labels']}")
        print(f"📊 Label Distribution:")
        for label, count in label_counts.items():
            percentage = label_percentages[label]
            print(f"   {label}: {count:,} ({percentage:.1f}%)")
        
        # Label vs PII_Type relationship
        if 'PII_Type' in self.df.columns:
            label_type_cross = pd.crosstab(self.df['Label'], self.df['PII_Type'])
            label_analysis['label_vs_pii_type'] = label_type_cross.to_dict()
            
            print(f"\n🔄 Label vs PII_Type Relationship:")
            for label in label_counts.head(5).index:
                label_data = self.df[self.df['Label'] == label]
                types = label_data['PII_Type'].value_counts().head(3)
                print(f"   {label}:")
                for pii_type, count in types.items():
                    print(f"     {pii_type}: {count}")
        
        self.analysis_results['labels'] = label_analysis
        return label_analysis
    
    def analyze_sensitivity_levels(self) -> Dict[str, Any]:
        """
        Analyze Sensitivity_Level distribution and patterns.
        
        Returns:
            Dict[str, Any]: Sensitivity level analysis results
        """
        print("\n" + "="*60)
        print("🔒 SENSITIVITY LEVEL ANALYSIS")
        print("="*60)
        
        if 'Sensitivity_Level' not in self.df.columns:
            print("❌ Sensitivity_Level column not found")
            return {}
        
        sensitivity_counts = self.df['Sensitivity_Level'].value_counts()
        sensitivity_percentages = self.df['Sensitivity_Level'].value_counts(normalize=True) * 100
        
        sensitivity_analysis = {
            'unique_levels': len(sensitivity_counts),
            'level_counts': sensitivity_counts.to_dict(),
            'level_percentages': sensitivity_percentages.to_dict()
        }
        
        print(f"🔒 Unique Sensitivity Levels: {sensitivity_analysis['unique_levels']}")
        print(f"📊 Sensitivity Distribution:")
        for level, count in sensitivity_counts.items():
            percentage = sensitivity_percentages[level]
            print(f"   {level}: {count:,} ({percentage:.1f}%)")
        
        # Sensitivity vs PII_Type relationship
        if 'PII_Type' in self.df.columns:
            sensitivity_type_cross = pd.crosstab(self.df['Sensitivity_Level'], self.df['PII_Type'])
            sensitivity_analysis['sensitivity_vs_pii_type'] = sensitivity_type_cross.to_dict()
            
            print(f"\n🔄 Sensitivity Level by PII Type:")
            for sensitivity in sensitivity_counts.index:
                sensitivity_data = self.df[self.df['Sensitivity_Level'] == sensitivity]
                types = sensitivity_data['PII_Type'].value_counts().head(5)
                print(f"   {sensitivity} ({sensitivity_counts[sensitivity]} total):")
                for pii_type, count in types.items():
                    print(f"     {pii_type}: {count}")
        
        # Detection accuracy by sensitivity level
        if 'PII_RESULTS' in self.df.columns:
            detection_by_sensitivity = {}
            for level in sensitivity_counts.index:
                level_data = self.df[self.df['Sensitivity_Level'] == level]
                level_results = level_data['PII_RESULTS'].astype(str).str.lower()
                level_detected = level_results.isin(['true', '1', '1.0', 'yes']).sum()
                level_total = len(level_data)
                
                detection_by_sensitivity[level] = {
                    'total': level_total,
                    'detected': level_detected,
                    'detection_rate': round((level_detected / level_total) * 100, 2) if level_total > 0 else 0
                }
            
            sensitivity_analysis['detection_by_sensitivity'] = detection_by_sensitivity
            
            print(f"\n📊 Detection Rate by Sensitivity Level:")
            for level, stats in detection_by_sensitivity.items():
                print(f"   {level}: {stats['detected']}/{stats['total']} ({stats['detection_rate']}%)")
        
        self.analysis_results['sensitivity_levels'] = sensitivity_analysis
        return sensitivity_analysis
    
    def analyze_detection_accuracy(self) -> Dict[str, Any]:
        """
        Analyze PII_RESULTS (true/false detection indicators) for accuracy assessment.
        
        Returns:
            Dict[str, Any]: Detection accuracy analysis results
        """
        print("\n" + "="*60)
        print("🎯 DETECTION ACCURACY ANALYSIS")
        print("="*60)
        
        if 'PII_RESULTS' not in self.df.columns:
            print("❌ PII_RESULTS column not found - cannot analyze detection accuracy")
            return {}
        
        # Convert PII_RESULTS to boolean for analysis
        pii_results = self.df['PII_RESULTS'].astype(str).str.lower()
        detected_count = pii_results.isin(['true', '1', '1.0', 'yes']).sum()
        not_detected_count = pii_results.isin(['false', '0', '0.0', 'no']).sum()
        total_records = len(self.df)
        
        accuracy_analysis = {
            'total_records': total_records,
            'detected_pii': detected_count,
            'not_detected_pii': not_detected_count,
            'detection_rate': round((detected_count / total_records) * 100, 2),
            'non_detection_rate': round((not_detected_count / total_records) * 100, 2)
        }
        
        print(f"📊 Detection Results Summary:")
        print(f"   Total records: {total_records:,}")
        print(f"   PII Detected: {detected_count:,} ({accuracy_analysis['detection_rate']}%)")
        print(f"   No PII Detected: {not_detected_count:,} ({accuracy_analysis['non_detection_rate']}%)")
        
        # Analyze detection by PII Type
        if 'PII_Type' in self.df.columns:
            detection_by_type = {}
            for pii_type in self.df['PII_Type'].unique():
                type_data = self.df[self.df['PII_Type'] == pii_type]
                type_results = type_data['PII_RESULTS'].astype(str).str.lower()
                type_detected = type_results.isin(['true', '1', '1.0', 'yes']).sum()
                type_total = len(type_data)
                
                detection_by_type[pii_type] = {
                    'total': type_total,
                    'detected': type_detected,
                    'detection_rate': round((type_detected / type_total) * 100, 2) if type_total > 0 else 0
                }
            
            accuracy_analysis['detection_by_type'] = detection_by_type
            
            print(f"\n📊 Detection Rate by PII Type:")
            sorted_types = sorted(detection_by_type.items(), 
                                key=lambda x: x[1]['detection_rate'], reverse=True)
            for pii_type, stats in sorted_types[:10]:
                print(f"   {pii_type}: {stats['detected']}/{stats['total']} ({stats['detection_rate']}%)")
        
        self.analysis_results['detection_accuracy'] = accuracy_analysis
        return accuracy_analysis
    
    def analyze_pii_values(self) -> Dict[str, Any]:
        """
        Analyze PII_RESULTS (actual detected values) for patterns and quality.
        
        Returns:
            Dict[str, Any]: PII values analysis results
        """
        print("\n" + "="*60)
        print("🔍 PII VALUES ANALYSIS")
        print("="*60)
        
        # Check for actual PII values column - prioritize PII_Value over PII_RESULTS
        pii_column = None
        for col in ['PII_Value', 'PII_VALUES', 'PII_RESULTS']:
            if col in self.df.columns:
                pii_column = col
                break
        
        if not pii_column:
            print("❌ PII values column not found (looked for: PII_Value, PII_VALUES, PII_RESULTS)")
            return {}
        
        print(f"📊 Using column '{pii_column}' for PII values analysis")
        
        # Special handling for PII_RESULTS column (detection flags)
        if pii_column == 'PII_RESULTS':
            unique_vals = self.df[pii_column].unique()
            if len(unique_vals) <= 5 and all(str(v) in ['0', '1', '0.0', '1.0', 'True', 'False', 'nan'] for v in unique_vals):
                print("⚠️  PII_RESULTS appears to be detection flags (0/1), not actual PII content!")
                print("   Analyzing as detection indicators...")
                
                detection_counts = self.df[pii_column].value_counts()
                print(f"📊 Detection Results:")
                for val, count in detection_counts.items():
                    status = "DETECTED" if str(val) in ['1', '1.0', 'True'] else "NOT DETECTED"
                    print(f"   {status}: {count:,} cases")
                
                # Try to use PII_Value instead if available
                if 'PII_Value' in self.df.columns:
                    print("   🔄 Switching to PII_Value column for content analysis...")
                    pii_column = 'PII_Value'
                else:
                    print("   ⚠️  No PII_Value column found - limited analysis possible")
        
        pii_values = self.df[pii_column].dropna()
        
        pii_analysis = {
            'total_values': len(pii_values),
            'unique_values': len(pii_values.unique()),
            'duplicate_rate': round((len(pii_values) - len(pii_values.unique())) / len(pii_values) * 100, 2),
            'avg_value_length': round(pii_values.astype(str).str.len().mean(), 2),
            'value_length_stats': {
                'min': int(pii_values.astype(str).str.len().min()),
                'max': int(pii_values.astype(str).str.len().max()),
                'median': int(pii_values.astype(str).str.len().median())
            }
        }
        
        print(f"📊 PII Values Statistics:")
        print(f"   Total values: {pii_analysis['total_values']:,}")
        print(f"   Unique values: {pii_analysis['unique_values']:,}")
        print(f"   Duplicate rate: {pii_analysis['duplicate_rate']}%")
        print(f"   Average length: {pii_analysis['avg_value_length']} characters")
        
        # Most common values (potential false positives)
        most_common = pii_values.value_counts().head(10)
        pii_analysis['most_common_values'] = most_common.to_dict()
        
        print(f"\n🔄 Most Common Values (potential false positives):")
        for value, count in most_common.items():
            if count > 1:  # Only show duplicates
                print(f"   '{value}': {count} times")
        
        # Pattern analysis by PII Type
        if 'PII_Type' in self.df.columns:
            pattern_analysis = {}
            for pii_type in self.df['PII_Type'].unique():
                type_values = self.df[self.df['PII_Type'] == pii_type][pii_column].dropna()
                if len(type_values) > 0:
                    pattern_analysis[pii_type] = {
                        'count': len(type_values),
                        'unique_count': len(type_values.unique()),
                        'avg_length': round(type_values.astype(str).str.len().mean(), 2),
                        'sample_values': type_values.head(3).tolist()
                    }
                    
                    # Look for suspicious patterns
                    suspicious_patterns = []
                    type_values_str = type_values.astype(str)
                    
                    # Check for single words that might be false positives
                    single_words = type_values_str[~type_values_str.str.contains(' ', na=False)]
                    if len(single_words) > 0 and pii_type in ['Person', 'ChileanFullName']:
                        suspicious_patterns.append(f"Single words: {len(single_words)} cases")
                    
                    # Check for very short values
                    short_values = type_values_str[type_values_str.str.len() < 3]
                    if len(short_values) > 0:
                        suspicious_patterns.append(f"Very short values: {len(short_values)} cases")
                    
                    if suspicious_patterns:
                        pattern_analysis[pii_type]['suspicious_patterns'] = suspicious_patterns
            
            pii_analysis['pattern_by_type'] = pattern_analysis
            
            print(f"\n📊 Pattern Analysis by PII Type:")
            for pii_type, stats in pattern_analysis.items():
                print(f"   {pii_type}: {stats['count']} values, {stats['unique_count']} unique")
                if 'suspicious_patterns' in stats:
                    for pattern in stats['suspicious_patterns']:
                        print(f"     ⚠️  {pattern}")
        
        self.analysis_results['pii_values'] = pii_analysis
        return pii_analysis
    
    def detect_quality_issues(self) -> Dict[str, Any]:
        """
        Detect potential quality issues and false positives.
        
        Returns:
            Dict[str, Any]: Quality issues analysis
        """
        print("\n" + "="*60)
        print("⚠️ QUALITY ISSUES DETECTION")
        print("="*60)
        
        quality_issues = {
            'total_issues': 0,
            'issues_found': []
        }
        
        # Find PII values column - prioritize actual content over flags
        pii_column = None
        for col in ['PII_Value', 'PII_VALUES', 'PII_RESULTS']:
            if col in self.df.columns:
                pii_column = col
                break
        
        if pii_column and 'PII_Type' in self.df.columns:
            
            # Issue 1: Single words detected as Person names
            person_single_words = self.df[
                (self.df['PII_Type'].isin(['Person', 'ChileanFullName'])) &
                (~self.df[pii_column].astype(str).str.contains(' ', na=False))
            ]
            
            if len(person_single_words) > 0:
                issue = {
                    'type': 'Single words as names',
                    'count': len(person_single_words),
                    'severity': 'HIGH',
                    'description': 'Names should typically have multiple words',
                    'examples': person_single_words[pii_column].head(5).tolist()
                }
                quality_issues['issues_found'].append(issue)
                quality_issues['total_issues'] += len(person_single_words)
                
                print(f"🔴 CRITICAL: {len(person_single_words)} single words detected as names:")
                for example in issue['examples']:
                    print(f"   '{example}'")
            
            # Issue 2: Very short PII values (< 3 characters)
            short_values = self.df[self.df[pii_column].astype(str).str.len() < 3]
            if len(short_values) > 0:
                issue = {
                    'type': 'Very short PII values',
                    'count': len(short_values),
                    'severity': 'MEDIUM',
                    'description': 'PII values with less than 3 characters might be false positives',
                    'examples': short_values[pii_column].head(5).tolist()
                }
                quality_issues['issues_found'].append(issue)
                
                print(f"🟡 WARNING: {len(short_values)} very short PII values:")
                for example in issue['examples']:
                    print(f"   '{example}'")
            
            # Issue 3: Highly repeated values (potential false positives)
            value_counts = self.df[pii_column].value_counts()
            highly_repeated = value_counts[value_counts > 10]  # Appears more than 10 times
            
            if len(highly_repeated) > 0:
                issue = {
                    'type': 'Highly repeated values',
                    'count': len(highly_repeated),
                    'severity': 'MEDIUM',
                    'description': 'Values that appear many times might be false positives',
                    'examples': highly_repeated.head(5).to_dict()
                }
                quality_issues['issues_found'].append(issue)
                
                print(f"🟡 WARNING: {len(highly_repeated)} highly repeated values:")
                for value, count in list(highly_repeated.head(5).items()):
                    print(f"   '{value}': {count} times")
            
            # Issue 4: Suspicious business terms detected as names
            business_terms = [
                'administracion', 'poliza', 'polizas', 'creacion', 'emision',
                'posteriormente', 'anteriormente', 'administrador', 'beneficiarios'
            ]
            
            business_term_matches = self.df[
                self.df[pii_column].astype(str).str.lower().str.contains('|'.join(business_terms), na=False)
            ]
            
            if len(business_term_matches) > 0:
                issue = {
                    'type': 'Business terms as PII',
                    'count': len(business_term_matches),
                    'severity': 'HIGH',
                    'description': 'Business/technical terms incorrectly detected as PII',
                    'examples': business_term_matches[pii_column].head(5).tolist()
                }
                quality_issues['issues_found'].append(issue)
                quality_issues['total_issues'] += len(business_term_matches)
                
                print(f"🔴 CRITICAL: {len(business_term_matches)} business terms detected as PII:")
                for example in issue['examples']:
                    print(f"   '{example}'")
        
        if quality_issues['total_issues'] == 0:
            print("✅ No major quality issues detected!")
        else:
            print(f"\n📊 SUMMARY: {quality_issues['total_issues']} potential quality issues found")
        
        self.analysis_results['quality_issues'] = quality_issues
        return quality_issues
    
    def generate_executive_report(self) -> str:
        """
        Generate a professional executive report with embedded visualizations.
        
        Returns:
            str: Path to the generated executive report file
        """
        print("\n" + "="*60)
        print("📋 GENERATING EXECUTIVE REPORT WITH VISUALIZATIONS")
        print("="*60)
        
        report_content = []
        
        # Report Header
        report_content.extend([
            "# 📊 PII Detection Analysis - Executive Report",
            "",
            f"**Analysis Date:** {datetime.now().strftime('%B %d, %Y at %H:%M:%S')}  ",
            f"**Source File:** `{os.path.basename(self.excel_file_path)}`  ",
            f"**Report ID:** `{self.timestamp}`",
            "",
            "---",
            ""
        ])
        
        # Executive Summary
        if 'overview' in self.analysis_results and 'detection_accuracy' in self.analysis_results:
            overview = self.analysis_results['overview']
            accuracy = self.analysis_results['detection_accuracy']
            
            report_content.extend([
                "## 🎯 Executive Summary",
                "",
                "### Key Metrics",
                "",
                f"| Metric | Value |",
                f"|--------|--------|",
                f"| **Total Records Analyzed** | {overview['total_records']:,} |",
                f"| **PII Detection Rate** | {accuracy['detection_rate']}% |",
                f"| **Records with PII Detected** | {accuracy['detected_pii']:,} |",
                f"| **Records with No PII** | {accuracy['not_detected_pii']:,} |",
                f"| **Unique PII Types Found** | {self.analysis_results.get('pii_types', {}).get('unique_types', 'N/A')} |",
                f"| **Pages Analyzed** | {self.analysis_results.get('page_distribution', {}).get('total_pages', 'N/A')} |",
                "",
            ])
            
        # Quality Assessment Summary
        if 'quality_issues' in self.analysis_results:
            quality = self.analysis_results['quality_issues']
            report_content.extend([
                "### 🚨 Quality Assessment",
                "",
                f"**Total Quality Issues Identified:** {quality['total_issues']}",
                "",
            ])
            
            for issue in quality['issues_found']:
                severity_icon = "🔴" if issue['severity'] == 'HIGH' else "🟡" if issue['severity'] == 'MEDIUM' else "🟢"
                report_content.append(f"- {severity_icon} **{issue['type']}**: {issue['count']} cases ({issue['severity']} priority)")
            
            report_content.extend(["", "---", ""])
        
        # Visual Analysis Section
        report_content.extend([
            "## 📈 Visual Analysis",
            "",
            "### PII Type Distribution",
            "",
            f"![PII Types Analysis](images/pii_types_analysis_{self.timestamp}.png)",
            "",
            "*Distribution of detected PII types showing the most common categories and their frequencies.*",
            "",
            "### Length Pattern Analysis", 
            "",
            f"![Length Analysis](images/length_analysis_{self.timestamp}.png)",
            "",
            "*Analysis of PII entity lengths showing distribution patterns and anomalies.*",
            "",
            "### Page Distribution Analysis",
            "",
            f"![Page Analysis](images/page_analysis_{self.timestamp}.png)",
            "",
            "*Distribution of PII entities across document pages showing concentration patterns.*",
            "",
            "---",
            ""
        ])
        
        # Detailed Analysis by Dimension
        report_content.extend([
            "## 🔍 Detailed Analysis",
            ""
        ])
        
        # PII Types Analysis
        if 'pii_types' in self.analysis_results:
            pii_types = self.analysis_results['pii_types']
            report_content.extend([
                "### PII Type Performance",
                "",
                f"**Total Unique Types:** {pii_types['unique_types']}",
                "",
                "**Top 10 Most Common Types:**",
                "",
            ])
            
            for i, (pii_type, count) in enumerate(list(pii_types['most_common'].items())[:10], 1):
                percentage = pii_types['type_percentages'][pii_type]
                report_content.append(f"{i}. **{pii_type}**: {count:,} occurrences ({percentage:.1f}%)")
            
            report_content.extend(["", ""])
        
        # Source Analysis
        if 'sources' in self.analysis_results:
            sources = self.analysis_results['sources']
            if 'source_distribution' in sources:
                report_content.extend([
                    "### Detection Source Performance",
                    "",
                    "| Source | Count | Percentage |",
                    "|--------|--------|------------|",
                ])
                
                for source, count in sources['source_distribution']['counts'].items():
                    percentage = sources['source_distribution']['percentages'][source]
                    report_content.append(f"| **{source}** | {count:,} | {percentage:.1f}% |")
                
                report_content.extend(["", ""])
        
        # Detection Accuracy by Type
        if 'detection_accuracy' in self.analysis_results and 'detection_by_type' in self.analysis_results['detection_accuracy']:
            detection_by_type = self.analysis_results['detection_accuracy']['detection_by_type']
            report_content.extend([
                "### Detection Accuracy by PII Type",
                "",
                "| PII Type | Detected | Total | Accuracy Rate |",
                "|----------|----------|-------|---------------|",
            ])
            
            # Sort by detection rate descending
            sorted_types = sorted(detection_by_type.items(), key=lambda x: x[1]['detection_rate'], reverse=True)
            for pii_type, stats in sorted_types[:15]:  # Top 15
                report_content.append(f"| **{pii_type}** | {stats['detected']:,} | {stats['total']:,} | {stats['detection_rate']}% |")
            
            report_content.extend(["", ""])
        
        # Sensitivity Level Analysis
        if 'sensitivity_levels' in self.analysis_results:
            sensitivity = self.analysis_results['sensitivity_levels']
            report_content.extend([
                "### Sensitivity Level Distribution",
                "",
                "| Sensitivity Level | Count | Percentage | Detection Rate |",
                "|-------------------|-------|------------|----------------|",
            ])
            
            if 'detection_by_sensitivity' in sensitivity:
                for level, count in sensitivity['level_counts'].items():
                    percentage = sensitivity['level_percentages'][level]
                    detection_stats = sensitivity['detection_by_sensitivity'].get(level, {})
                    detection_rate = detection_stats.get('detection_rate', 'N/A')
                    report_content.append(f"| **{level}** | {count:,} | {percentage:.1f}% | {detection_rate}% |")
            
            report_content.extend(["", ""])
        
        # Quality Issues Section
        if 'quality_issues' in self.analysis_results:
            quality = self.analysis_results['quality_issues']
            report_content.extend([
                "## ⚠️ Quality Issues & Recommendations",
                "",
            ])
            
            for issue in quality['issues_found']:
                severity_icon = "🔴" if issue['severity'] == 'HIGH' else "🟡" if issue['severity'] == 'MEDIUM' else "🟢"
                report_content.extend([
                    f"### {severity_icon} {issue['type']} ({issue['severity']} Priority)",
                    "",
                    f"**Count:** {issue['count']} cases  ",
                    f"**Description:** {issue['description']}",
                    "",
                    "**Examples:**",
                    ""
                ])
                
                # Add examples
                examples = issue.get('examples', [])
                if isinstance(examples, dict):
                    # Handle dictionary examples (for repeated values)
                    for value, count in list(examples.items())[:5]:
                        report_content.append(f"- `{value}` (appears {count} times)")
                else:
                    # Handle list examples
                    for example in examples[:5]:
                        report_content.append(f"- `{example}`")
                
                report_content.extend(["", ""])
        
        # Recommendations Section
        report_content.extend([
            "## 🎯 Action Items & Recommendations",
            "",
            "### Immediate Actions (High Priority)",
            "",
            "1. **Review Business Term Classifications**",
            "   - Investigate business/technical terms being detected as PII",
            "   - Update exclusion lists and validation rules",
            "   - Target: Reduce false positive rate by 80%",
            "",
            "2. **Implement Length Validation**",
            "   - Add minimum length thresholds for PII detection",
            "   - Review single-character and very short detections",
            "   - Recommended minimum: 3 characters for most PII types",
            "",
            "3. **Enhance Low Sensitivity Detection**",
            "   - Investigate poor performance on low sensitivity items",
            "   - Review and refine detection patterns",
            "   - Target: Improve detection rate from current level to >80%",
            "",
            "### Medium-Term Improvements",
            "",
            "1. **Source Optimization**",
            "   - Fine-tune confidence thresholds for each detection source",
            "   - Implement ensemble methods for better accuracy",
            "   - Add post-processing validation layers",
            "",
            "2. **Pattern Refinement**",
            "   - Reduce MISC classifications through better categorization",
            "   - Implement context-aware validation",
            "   - Add domain-specific pattern libraries",
            "",
            "3. **Quality Monitoring**",
            "   - Implement automated quality checks",
            "   - Set up regular accuracy monitoring",
            "   - Create feedback loops for continuous improvement",
            "",
            "---",
            ""
        ])
        
        # Technical Appendix
        report_content.extend([
            "## 📋 Technical Appendix",
            "",
            "### Analysis Configuration",
            "",
            f"- **Analysis Timestamp:** {self.timestamp}",
            f"- **Source File:** {self.excel_file_path}",
            f"- **Total Records:** {self.analysis_results.get('overview', {}).get('total_records', 'N/A'):,}",
            f"- **Analysis Methods:** Detection Accuracy, PII Types, Sources, Length Patterns, Page Distribution, Labels, Sensitivity Levels, Quality Assessment",
            "",
            "### Data Quality Metrics",
            "",
        ])
        
        if 'overview' in self.analysis_results:
            overview = self.analysis_results['overview']
            null_counts = overview.get('null_counts', {})
            total_records = overview.get('total_records', 1)
            
            report_content.extend([
                "| Column | Null Count | Null Percentage |",
                "|--------|------------|-----------------|",
            ])
            
            for col, null_count in null_counts.items():
                if null_count > 0:
                    null_percentage = (null_count / total_records) * 100
                    report_content.append(f"| {col} | {null_count:,} | {null_percentage:.1f}% |")
        
        report_content.extend([
            "",
            "### Report Generation Details",
            "",
            f"- **Generated By:** PII Results Analyzer v2.0",
            f"- **Analysis Duration:** Complete dataset analysis",
            f"- **Visualizations Created:** 3 charts (PII Types, Length Patterns, Page Distribution)",
            f"- **Quality Checks:** {len(self.analysis_results.get('quality_issues', {}).get('issues_found', []))} issue types analyzed",
            "",
            "---",
            "",
            "*This report was automatically generated using the enhanced PII Analysis system. For questions or additional analysis, please contact the data analysis team.*"
        ])
        
        # Save executive report
        report_filename = f"PII_Executive_Report_{self.timestamp}.md"
        report_path = os.path.join(os.path.dirname(self.excel_file_path), report_filename)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_content))
        
        print(f"📋 Executive Report saved to: {report_path}")
        print(f"🎨 Report includes embedded visualizations and professional formatting")
        return report_path

    def generate_comprehensive_report(self) -> str:
        """
        Generate a comprehensive analysis report.
        
        Returns:
            str: Path to the generated report file
        """
        print("\n" + "="*60)
        print("📋 GENERATING COMPREHENSIVE REPORT")
        print("="*60)
        
        report_content = []
        report_content.append("# PII Detection Results Analysis Report")
        report_content.append(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_content.append(f"Source file: {os.path.basename(self.excel_file_path)}\n")
        
        # Add all analysis results to report
        for analysis_type, results in self.analysis_results.items():
            report_content.append(f"## {analysis_type.replace('_', ' ').title()}")
            report_content.append(json.dumps(results, indent=2, default=str))
            report_content.append("")
        
        # Save report
        report_filename = f"pii_analysis_report_{self.timestamp}.md"
        report_path = os.path.join(os.path.dirname(self.excel_file_path), report_filename)
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(report_content))
        
        print(f"📋 Report saved to: {report_path}")
        return report_path
    
    def run_complete_analysis(self) -> bool:
        """
        Run all analysis methods in sequence.
        
        Returns:
            bool: True if analysis completed successfully
        """
        print("🚀 Starting Comprehensive PII Results Analysis")
        print("="*80)
        
        try:
            # Load data
            if not self.load_data():
                return False
            
            # Run all analyses
            self.basic_overview()
            self.analyze_detection_accuracy()  # New method for PII_RESULTS analysis
            self.analyze_pii_types()
            self.analyze_sources()
            self.analyze_length_patterns()
            self.analyze_page_distribution()
            self.analyze_labels()
            self.analyze_sensitivity_levels()  # New method for Sensitivity_Level analysis
            self.analyze_pii_values()
            self.detect_quality_issues()
            
            # Generate reports
            self.generate_comprehensive_report()
            self.generate_executive_report()  # New executive report with visualizations
            
            print("\n" + "="*80)
            print("✅ ANALYSIS COMPLETED SUCCESSFULLY!")
            print("="*80)
            
            return True
            
        except Exception as e:
            print(f"❌ ERROR during analysis: {e}")
            return False


def main():
    """Main execution function"""
    
    # Default file path
    default_file = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output\OCR_PII_Analysis_HYBRID_20250912_113208.xlsx"
    
    # Check if file path provided as argument
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = default_file
    
    print(f"🎯 Target file: {file_path}")
    
    # Initialize analyzer
    analyzer = PIIResultsAnalyzer(file_path)
    
    # Run complete analysis
    success = analyzer.run_complete_analysis()
    
    if success:
        print(f"\n🎉 Analysis completed! Check the generated files:")
        print(f"   📊 Charts: {os.path.join(os.path.dirname(file_path), 'images')}\\pii_*_analysis_*.png")
        print(f"   📋 Technical Report: {os.path.dirname(file_path)}\\pii_analysis_report_*.md")
        print(f"   📋 Executive Report: {os.path.dirname(file_path)}\\PII_Executive_Report_*.md")
        print(f"\n💡 The Executive Report includes embedded visualizations and is ready for sharing!")
    else:
        print(f"\n❌ Analysis failed. Please check the error messages above.")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())
