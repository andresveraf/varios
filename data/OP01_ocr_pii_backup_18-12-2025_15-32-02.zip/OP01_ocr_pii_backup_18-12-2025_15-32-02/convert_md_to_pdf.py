#!/usr/bin/env python3
"""
Convert Markdown file to PDF with mermaid diagram rendering.
Supports Spanish and English documentation.
"""

import os
import sys
import time
import base64
import logging
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)-15s [%(levelname)-5.5s] %(message)s'
)

class MarkdownToPDFConverter:
    """Convert Markdown files to PDF with mermaid diagram support."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def markdown_to_html(self, md_path):
        """Convert Markdown to HTML using basic rendering."""
        self.logger.info(f"📖 Reading markdown file: {md_path}")
        
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Basic HTML template with professional styling
        html_template = """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentación del Flujo OP01 OCR PII</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fff;
            padding: 40px;
        }}
        
        h1 {{
            color: #2c3e50;
            border-bottom: 4px solid #3498db;
            padding-bottom: 15px;
            margin-bottom: 30px;
            font-size: 2.5em;
        }}
        
        h2 {{
            color: #34495e;
            border-bottom: 2px solid #ecf0f1;
            padding-bottom: 10px;
            margin-top: 40px;
            margin-bottom: 20px;
            font-size: 1.8em;
        }}
        
        h3 {{
            color: #2c3e50;
            margin-top: 30px;
            margin-bottom: 15px;
            font-size: 1.4em;
        }}
        
        h4 {{
            color: #34495e;
            margin-top: 20px;
            margin-bottom: 10px;
            font-size: 1.1em;
        }}
        
        p {{
            margin-bottom: 15px;
            text-align: justify;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            font-size: 0.9em;
            table-layout: auto;
        }}
        
        th {{
            background-color: #3498db;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
            border: 1px solid #2980b9;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }}
        
        td {{
            padding: 10px 12px;
            border: 1px solid #bdc3c7;
            word-wrap: break-word;
            overflow-wrap: break-word;
            word-break: break-word;
        }}
        
        tr:nth-child(even) {{
            background-color: #ecf0f1;
        }}
        
        tr:hover {{
            background-color: #e8f4f8;
        }}
        
        code {{
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
        }}
        
        pre {{
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            overflow-x: auto;
            margin: 15px 0;
            font-size: 0.85em;
            white-space: pre-wrap;
            word-wrap: break-word;
            line-height: 1.4;
        }}
        
        pre code {{
            background: none;
            padding: 0;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: 'Courier New', Courier, monospace;
        }}
        
        code.language-flowchart {{
            display: block;
            white-space: pre-wrap;
            word-wrap: break-word;
        }}
        
        blockquote {{
            border-left: 4px solid #3498db;
            padding-left: 20px;
            margin-left: 0;
            margin-bottom: 15px;
            color: #555;
        }}
        
        .mermaid {{
            margin: 30px 0;
            text-align: center;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 4px;
            page-break-inside: avoid;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 200px;
            width: 100%;
            overflow-x: visible;
        }}
        
        .mermaid svg {{
            max-width: 100% !important;
            width: auto !important;
            height: auto !important;
            min-width: 800px;
            font-size: 14px !important;
        }}
        
        .mermaid .node rect,
        .mermaid .node circle,
        .mermaid .node ellipse,
        .mermaid .node polygon {{
            font-size: 14px !important;
        }}
        
        .mermaid .edgeLabel {{
            font-size: 12px !important;
        }}
        
        ul, ol {{
            margin-left: 20px;
            margin-bottom: 15px;
        }}
        
        li {{
            margin-bottom: 8px;
        }}
        
        a {{
            color: #3498db;
            text-decoration: none;
        }}
        
        a:hover {{
            text-decoration: underline;
        }}
        
        img {{
            max-width: 100%;
            height: auto;
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }}
        
        .warning {{
            background-color: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }}
        
        .info {{
            background-color: #e8f4fd;
            border-left: 4px solid #3498db;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }}
        
        .success {{
            background-color: #d4edda;
            border-left: 4px solid #28a745;
            padding: 15px;
            margin: 15px 0;
            border-radius: 4px;
        }}
        
        hr {{
            border: none;
            border-top: 2px solid #ecf0f1;
            margin: 40px 0;
        }}
        
        em {{
            color: #555;
            font-style: italic;
        }}
        
        strong {{
            color: #2c3e50;
            font-weight: 600;
        }}
        
        .toc {{
            background-color: #ecf0f1;
            border: 1px solid #bdc3c7;
            border-radius: 4px;
            padding: 15px;
            margin: 20px 0;
        }}
        
        .toc h3 {{
            margin-top: 0;
        }}
        
        .toc ul {{
            margin-bottom: 0;
        }}
    </style>
</head>
<body>
{content}
    <script>
        window.mermaidConfig = {{
            startOnLoad: true,
            theme: 'default',
            securityLevel: 'loose',
            logLevel: 'warn',
            flowchart: {{
                useMaxWidth: false,
                htmlLabels: true,
                curve: 'basis',
                padding: 15,
                nodeSpacing: 80,
                rankSpacing: 80
            }},
            sequence: {{
                useMaxWidth: false
            }},
            gantt: {{
                useMaxWidth: false
            }}
        }};
        
        document.addEventListener('DOMContentLoaded', function() {{
            if (typeof mermaid !== 'undefined') {{
                mermaid.initialize(window.mermaidConfig);
                setTimeout(() => {{
                    try {{
                        mermaid.run();
                    }} catch(e) {{
                        console.warn('Mermaid rendering warning:', e);
                    }}
                }}, 1000);
            }}
        }});
        
        // Fallback rendering if mermaid doesn't load
        window.addEventListener('load', function() {{
            if (typeof mermaid !== 'undefined') {{
                try {{
                    mermaid.run();
                }} catch(e) {{
                    console.warn('Mermaid late rendering warning:', e);
                }}
            }}
        }});
    </script>
</body>
</html>
"""
        
        # Convert markdown to HTML (simple conversion)
        html_content = self._markdown_to_html_simple(content)
        return html_template.format(content=html_content)
    
    def _markdown_to_html_simple(self, markdown_text):
        """Simple markdown to HTML converter."""
        import re
        import html as html_module
        
        html = markdown_text
        
        # Convert mermaid blocks FIRST (before generic code blocks)
        html = re.sub(
            r'```mermaid\n(.*?)\n```',
            r'<div class="mermaid">\1</div>',
            html,
            flags=re.DOTALL
        )
        
        # Convert flowchart blocks (special handling for flowchart diagrams)
        html = re.sub(
            r'```flowchart\n(.*?)\n```',
            r'<div class="mermaid">\1</div>',
            html,
            flags=re.DOTALL
        )
        
        # Convert other code blocks with language highlighting
        def convert_code_block(match):
            lang = match.group(1) or 'text'
            code = match.group(2)
            # Escape HTML in code
            code = html_module.escape(code)
            # Preserve whitespace and formatting
            return f'<pre><code class="language-{lang}">{code}</code></pre>'
        
        html = re.sub(
            r'```(\w+)?\n(.*?)\n```',
            convert_code_block,
            html,
            flags=re.DOTALL
        )
        
        # Convert headers (order matters: h4, h3, h2, h1)
        html = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        
        # Convert horizontal rules
        html = re.sub(r'^---+$', '<hr>', html, flags=re.MULTILINE)
        
        # Convert inline code
        html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
        
        # Convert bold and italic
        html = re.sub(r'\*\*\*(.+?)\*\*\*', r'<strong><em>\1</em></strong>', html)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        html = re.sub(r'__(.+?)__', r'<strong>\1</strong>', html)
        html = re.sub(r'_(.+?)_', r'<em>\1</em>', html)
        
        # Convert images
        html = re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'<img src="\2" alt="\1">', html)
        
        # Convert links
        html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
        
        # Convert lists (simple approach)
        lines = html.split('\n')
        result = []
        in_ul = False
        in_ol = False
        
        for line in lines:
            if re.match(r'^\s*[-*]\s+', line):
                if not in_ul:
                    result.append('<ul>')
                    in_ul = True
                    in_ol = False
                item = re.sub(r'^\s*[-*]\s+', '', line)
                result.append(f'<li>{item}</li>')
            elif re.match(r'^\s*\d+\.\s+', line):
                if not in_ol:
                    result.append('</ul>' if in_ul else '')
                    result.append('<ol>')
                    in_ol = True
                    in_ul = False
                item = re.sub(r'^\s*\d+\.\s+', '', line)
                result.append(f'<li>{item}</li>')
            else:
                if in_ul:
                    result.append('</ul>')
                    in_ul = False
                if in_ol:
                    result.append('</ol>')
                    in_ol = False
                result.append(line)
        
        if in_ul:
            result.append('</ul>')
        if in_ol:
            result.append('</ol>')
        
        html = '\n'.join(result)
        
        # Wrap paragraphs
        paragraphs = html.split('\n\n')
        wrapped = []
        for para in paragraphs:
            if (para.strip() and 
                not para.strip().startswith('<') and 
                not para.strip().startswith('|')):
                wrapped.append(f'<p>{para.strip()}</p>')
            else:
                wrapped.append(para)
        
        html = '\n'.join(wrapped)
        
        # Convert markdown tables with improved pattern
        # Match tables more reliably: lines with | and separator with |---|
        table_pattern = r'\|[^\n]+\|\n\|[-:\s|]+\|\n((?:\|[^\n]+\|\n?)*)'
        def convert_table(match):
            full_match = match.group(0)
            lines = full_match.strip().split('\n')
            
            if len(lines) < 2:
                return full_match
            
            # Parse header (first line)
            header_cells = [cell.strip() for cell in lines[0].split('|')[1:-1]]
            
            html_table = '<table>\n<thead>\n<tr>\n'
            for cell in header_cells:
                html_table += f'<th>{cell}</th>\n'
            html_table += '</tr>\n</thead>\n<tbody>\n'
            
            # Parse data rows (skip separator line at index 1)
            for line in lines[2:]:
                if line.strip() and line.startswith('|'):
                    cells = [cell.strip() for cell in line.split('|')[1:-1]]
                    if len(cells) == len(header_cells):  # Only include if same column count
                        html_table += '<tr>\n'
                        for cell in cells:
                            html_table += f'<td>{cell}</td>\n'
                        html_table += '</tr>\n'
            
            html_table += '</tbody>\n</table>'
            return html_table
        
        html = re.sub(table_pattern, convert_table, html, flags=re.MULTILINE)
        
        return html
    
    def convert_to_pdf(self, md_path, pdf_path=None):
        """Convert markdown file to PDF."""
        
        if pdf_path is None:
            pdf_path = str(Path(md_path).with_suffix('.pdf'))
        
        self.logger.info(f"🚀 Starting conversion: {md_path}")
        self.logger.info(f"📄 Output PDF: {pdf_path}")
        
        # Create output directory if needed
        Path(pdf_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Convert markdown to HTML
        html_content = self.markdown_to_html(md_path)
        
        # Save HTML temporarily
        temp_html = Path(pdf_path).with_suffix('.html')
        self.logger.info(f"💾 Saving temporary HTML: {temp_html}")
        
        with open(temp_html, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # Convert HTML to PDF using Selenium
        self.logger.info(f"🔄 Converting HTML to PDF...")
        success = self._html_to_pdf(str(temp_html), pdf_path)
        
        if success:
            # Clean up temporary HTML
            try:
                temp_html.unlink()
                self.logger.info(f"🧹 Cleaned up temporary HTML file")
            except Exception as e:
                self.logger.warning(f"⚠️ Could not delete temporary HTML: {e}")
            
            self.logger.info(f"✅ PDF conversion completed successfully!")
            self.logger.info(f"📑 Final PDF: {pdf_path}")
            return True
        else:
            self.logger.error(f"❌ PDF conversion failed")
            return False
    
    def _html_to_pdf(self, html_path, pdf_path):
        """Convert HTML file to PDF using Selenium with improved connection handling."""
        
        options = Options()
        options.add_argument('--headless=new')
        options.add_argument('--disable-gpu')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-plugins')
        options.add_argument('--start-maximized')
        options.add_argument('--window-size=1920,1080')
        options.add_argument('--disable-blink-features=AutomationControlled')
        
        driver = None
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            driver = None
            try:
                self.logger.info(f"🌐 Initializing Chrome driver (attempt {retry_count + 1}/{max_retries})...")
                driver = webdriver.Chrome(options=options)
                
                # Set timeouts
                driver.set_page_load_timeout(60)
                driver.set_script_timeout(60)
                
                # Convert file path to URL
                file_url = 'file:///' + os.path.abspath(html_path).replace('\\', '/')
                self.logger.info(f"📂 Loading: {file_url}")
                
                driver.get(file_url)
                
                # Wait for page load
                time.sleep(3)
                
                # Wait for mermaid diagrams to render
                self.logger.info(f"⏳ Waiting for mermaid diagrams to render...")
                
                mermaid_count = driver.execute_script(
                    "return document.querySelectorAll('.mermaid').length;"
                )
                
                if mermaid_count > 0:
                    self.logger.info(f"📊 Found {mermaid_count} mermaid diagrams")
                    
                    # Wait for SVG rendering with longer timeout
                    start_time = time.time()
                    while time.time() - start_time < 60:
                        try:
                            svg_count = driver.execute_script(
                                "return document.querySelectorAll('.mermaid svg').length;"
                            )
                            if svg_count >= mermaid_count:
                                self.logger.info(f"✅ All {svg_count} diagrams rendered")
                                break
                        except:
                            pass
                        time.sleep(0.5)
                    else:
                        self.logger.warning(f"⚠️ Some diagrams may not have rendered properly")
                
                # Extra stabilization
                time.sleep(3)
                
                # Calculate page height
                content_height = driver.execute_script(
                    "return Math.max("
                    "document.body.scrollHeight, "
                    "document.documentElement.scrollHeight, "
                    "document.documentElement.clientHeight"
                    ");"
                )
                
                height_inches = max(11.0, (content_height / 96.0) + 1.0)
                self.logger.info(f"📐 Page dimensions: 8.3\" x {height_inches:.1f}\"")
                
                # Generate PDF with wider page width for diagrams
                self.logger.info(f"📑 Generating PDF...")
                
                result = driver.execute_cdp_cmd("Page.printToPDF", {
                    "paperWidth": 13.0,  # Increased to 13" for wider diagrams
                    "paperHeight": float(height_inches),
                    "printBackground": True,
                    "marginTop": 0.3,
                    "marginBottom": 0.3,
                    "marginLeft": 0.25,
                    "marginRight": 0.25,
                    "scale": 0.88,  # Reduced scale to fit wider content
                    "displayHeaderFooter": False
                })
                
                # Save PDF
                pdf_data = base64.b64decode(result['data'])
                with open(pdf_path, 'wb') as f:
                    f.write(pdf_data)
                
                self.logger.info(f"✅ PDF saved: {pdf_path}")
                return True
                
            except Exception as e:
                retry_count += 1
                self.logger.warning(f"⚠️ Attempt {retry_count} failed: {e}")
                
                if retry_count >= max_retries:
                    self.logger.error(f"❌ Failed to convert after {max_retries} attempts")
                    return False
                
                self.logger.info(f"🔄 Retrying in 2 seconds...")
                time.sleep(2)
            
            finally:
                if driver:
                    try:
                        driver.quit()
                        time.sleep(1)
                    except:
                        pass

def main():
    """Main execution function."""
    
    # File paths
    md_file = r"c:\RPA\repositorio\OPS\OP01_ocr_pii\docs\06-Workflows\op01_ocr_pii_workflow_es.md"
    pdf_file = r"c:\RPA\repositorio\OPS\OP01_ocr_pii\op01_ocr_pii_workflow_es.pdf"
    
    # Create converter and convert
    converter = MarkdownToPDFConverter()
    success = converter.convert_to_pdf(md_file, pdf_file)
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
