"""
Convert OP01 OCR PII Workflow Documentation to PDF
Uses Selenium + Chrome DevTools for reliable mermaid diagram rendering
"""

import os
import sys
import time
import base64
import logging
import re
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)


class MarkdownToPDFConverter:
    """Convert Markdown files to PDF with mermaid diagram support."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def markdown_to_html(self, md_path):
        """Convert Markdown to HTML with proper formatting and mermaid support."""
        self.logger.info(f"📖 Reading markdown file: {md_path}")
        
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Professional HTML template with comprehensive styling
        html_template = """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documentación del Flujo OP01 OCR PII</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #fff;
            padding: 40px;
        }}
        h1 {{ color: #2c3e50; border-bottom: 4px solid #3498db; padding-bottom: 15px; margin-bottom: 30px; }}
        h2 {{ color: #34495e; border-bottom: 2px solid #ecf0f1; padding-bottom: 10px; margin-top: 40px; }}
        h3 {{ color: #2c3e50; margin-top: 30px; }}
        h4 {{ color: #34495e; margin-top: 25px; }}
        p {{ margin-bottom: 15px; text-align: justify; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: #fff;
            font-size: 0.9em;
            table-layout: auto;
        }}
        th {{
            background-color: #3498db;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: bold;
            border: 1px solid #2980b9;
            word-wrap: break-word;
            overflow-wrap: break-word;
        }}
        td {{
            padding: 10px 12px;
            border: 1px solid #bdc3c7;
            word-wrap: break-word;
            overflow-wrap: break-word;
            word-break: break-word;
        }}
        tr:nth-child(even) {{ background-color: #ecf0f1; }}
        code {{
            background-color: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', Courier, monospace;
            font-size: 0.9em;
        }}
        pre {{
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            overflow-x: auto;
            margin: 15px 0;
            font-size: 0.85em;
            white-space: pre-wrap;
            word-wrap: break-word;
        }}
        pre code {{
            background: none;
            padding: 0;
        }}
        .mermaid {{
            margin: 30px 0;
            text-align: center;
            border: 1px solid #ddd;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 4px;
            page-break-inside: avoid;
            display: flex;
            justify-content: center;
            align-items: center;
        }}
        .mermaid svg {{
            max-width: 100% !important;
            width: auto !important;
            min-width: 800px;
            font-size: 14px !important;
        }}
        .mermaid .node rect,
        .mermaid .edgeLabel {{
            font-size: 14px !important;
        }}
        img {{ max-width: 100%; height: auto; margin: 20px 0; border: 1px solid #ddd; }}
        hr {{ border: 0; border-top: 2px solid #ecf0f1; margin: 30px 0; }}
        ul, ol {{ margin: 15px 0; padding-left: 30px; }}
        li {{ margin-bottom: 8px; }}
        strong {{ color: #2c3e50; }}
        em {{ color: #7f8c8d; }}
    </style>
</head>
<body>
{content}
    <script>
        window.mermaidConfig = {{
            startOnLoad: true,
            theme: 'default',
            securityLevel: 'loose',
            logLevel: 'warn',
            flowchart: {{
                useMaxWidth: false,
                htmlLabels: true,
                curve: 'basis',
                padding: 15,
                nodeSpacing: 80,
                rankSpacing: 80
            }},
            sequence: {{ useMaxWidth: true }},
            gantt: {{ useMaxWidth: true }}
        }};
        
        document.addEventListener('DOMContentLoaded', function() {{
            if (typeof mermaid !== 'undefined') {{
                mermaid.initialize(window.mermaidConfig);
                setTimeout(() => {{
                    try {{
                        mermaid.run();
                    }} catch(e) {{
                        console.warn('Mermaid rendering warning:', e);
                    }}
                }}, 1000);
            }}
        }});
        
        window.addEventListener('load', function() {{
            if (typeof mermaid !== 'undefined') {{
                try {{
                    mermaid.run();
                }} catch(e) {{
                    console.warn('Mermaid late rendering warning:', e);
                }}
            }}
        }});
    </script>
</body>
</html>
"""
        
        html_content = self._markdown_to_html_simple(content)
        return html_template.format(content=html_content)
    
    def _markdown_to_html_simple(self, markdown_text):
        """Convert markdown to HTML with proper mermaid and code block handling."""
        import html as html_module
        
        html = markdown_text
        
        # CRITICAL: Convert mermaid blocks FIRST with special marker to prevent paragraph wrapping
        mermaid_placeholder = "___MERMAID_PLACEHOLDER_{}___"
        mermaid_blocks = []
        
        def store_mermaid(match):
            idx = len(mermaid_blocks)
            mermaid_blocks.append(f'<div class="mermaid">{match.group(1)}</div>')
            return mermaid_placeholder.format(idx)
        
        html = re.sub(
            r'```mermaid\n(.*?)\n```',
            store_mermaid,
            html,
            flags=re.DOTALL
        )
        
        html = re.sub(
            r'```flowchart\n(.*?)\n```',
            store_mermaid,
            html,
            flags=re.DOTALL
        )
        
        # Convert other code blocks with proper escaping
        def convert_code_block(match):
            lang = match.group(1) or 'text'
            code = match.group(2)
            code = html_module.escape(code)
            return f'<pre><code class="language-{lang}">{code}</code></pre>'
        
        html = re.sub(
            r'```(\w+)?\n(.*?)\n```',
            convert_code_block,
            html,
            flags=re.DOTALL
        )
        
        # Convert headers
        html = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        
        # Convert tables
        def convert_table(match):
            table_text = match.group(0)
            lines = [line.strip() for line in table_text.split('\n') if line.strip()]
            
            if len(lines) < 2:
                return table_text
            
            # Extract header
            header_cells = [cell.strip() for cell in lines[0].split('|') if cell.strip()]
            
            # Skip separator line
            data_lines = lines[2:]
            
            # Build HTML table
            table_html = '<table>\n<thead>\n<tr>\n'
            for cell in header_cells:
                table_html += f'<th>{cell}</th>\n'
            table_html += '</tr>\n</thead>\n<tbody>\n'
            
            for line in data_lines:
                cells = [cell.strip() for cell in line.split('|') if cell.strip()]
                if len(cells) == len(header_cells):
                    table_html += '<tr>\n'
                    for cell in cells:
                        table_html += f'<td>{cell}</td>\n'
                    table_html += '</tr>\n'
            
            table_html += '</tbody>\n</table>'
            return table_html
        
        html = re.sub(
            r'\|[^\n]+\|\n\|[-:\s|]+\|\n((?:\|[^\n]+\|\n?)*)',
            convert_table,
            html
        )
        
        # Convert horizontal rules
        html = re.sub(r'^---$', r'<hr>', html, flags=re.MULTILINE)
        
        # Convert inline formatting
        html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        
        # Convert lists
        html = re.sub(r'^\- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'(<li>.*?</li>\n?)+', r'<ul>\n\g<0></ul>\n', html)
        
        # Convert paragraphs
        lines = html.split('\n')
        in_paragraph = False
        result_lines = []
        
        for line in lines:
            stripped = line.strip()
            # Skip mermaid placeholders and HTML tags
            if not stripped or stripped.startswith('<') or '___MERMAID_PLACEHOLDER_' in stripped:
                if in_paragraph:
                    result_lines.append('</p>')
                    in_paragraph = False
                result_lines.append(line)
            else:
                if not in_paragraph:
                    result_lines.append('<p>')
                    in_paragraph = True
                result_lines.append(line)
        
        if in_paragraph:
            result_lines.append('</p>')
        
        html = '\n'.join(result_lines)
        
        # CRITICAL: Restore mermaid blocks AFTER paragraph processing
        for idx, mermaid_block in enumerate(mermaid_blocks):
            html = html.replace(mermaid_placeholder.format(idx), mermaid_block)
        
        return html
    
    def html_to_pdf(self, html_path, pdf_path):
        """Convert HTML to PDF with improved connection handling and longer mermaid wait time."""
        
        options = Options()
        options.add_argument('--headless=new')
        options.add_argument('--disable-gpu')
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-extensions')
        options.add_argument('--disable-plugins')
        options.add_argument('--start-maximized')
        options.add_argument('--window-size=1920,1080')
        
        driver = None
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            driver = None
            try:
                self.logger.info(f"🌐 Initializing Chrome driver (attempt {retry_count + 1}/{max_retries})...")
                driver = webdriver.Chrome(options=options)
                driver.set_page_load_timeout(60)
                driver.set_script_timeout(60)
                
                file_url = 'file:///' + os.path.abspath(html_path).replace('\\', '/')
                self.logger.info(f"📂 Loading: {file_url}")
                driver.get(file_url)
                
                time.sleep(3)
                
                # Wait for mermaid diagrams with LONGER timeout
                self.logger.info(f"⏳ Waiting for mermaid diagrams to render...")
                
                mermaid_count = driver.execute_script(
                    "return document.querySelectorAll('.mermaid').length;"
                )
                
                if mermaid_count > 0:
                    self.logger.info(f"📊 Found {mermaid_count} mermaid diagrams")
                    
                    # CRITICAL: Wait up to 60 seconds for SVG rendering
                    start_time = time.time()
                    while time.time() - start_time < 60:
                        try:
                            svg_count = driver.execute_script(
                                "return document.querySelectorAll('.mermaid svg').length;"
                            )
                            if svg_count >= mermaid_count:
                                self.logger.info(f"✅ All {svg_count} diagrams rendered")
                                break
                        except:
                            pass
                        time.sleep(0.5)
                    else:
                        self.logger.warning(f"⚠️ Some diagrams may not have rendered properly")
                
                time.sleep(3)
                
                # Calculate dynamic page height
                content_height = driver.execute_script(
                    "return Math.max("
                    "document.body.scrollHeight, "
                    "document.documentElement.scrollHeight, "
                    "document.documentElement.clientHeight"
                    ");"
                )
                
                # Use wider page width for diagrams (13.0" instead of 8.27")
                page_width = 13.0
                height_inches = max(11.0, (content_height / 96.0) + 1.0)
                self.logger.info(f"📐 Page dimensions: {page_width}\" x {height_inches:.1f}\"")
                
                # Generate PDF
                self.logger.info(f"📑 Generating PDF...")
                
                result = driver.execute_cdp_cmd("Page.printToPDF", {
                    "paperWidth": page_width,
                    "paperHeight": float(height_inches),
                    "printBackground": True,
                    "marginTop": 0.25,
                    "marginBottom": 0.25,
                    "marginLeft": 0.25,
                    "marginRight": 0.25,
                    "scale": 0.88,
                    "displayHeaderFooter": False
                })
                
                # Save PDF
                pdf_data = base64.b64decode(result['data'])
                with open(pdf_path, 'wb') as f:
                    f.write(pdf_data)
                
                self.logger.info(f"✅ PDF saved: {pdf_path}")
                return True
                
            except Exception as e:
                retry_count += 1
                self.logger.warning(f"⚠️ Attempt {retry_count} failed: {e}")
                
                if retry_count >= max_retries:
                    self.logger.error(f"❌ Failed to convert after {max_retries} attempts")
                    return False
                
                self.logger.info(f"🔄 Retrying in 2 seconds...")
                time.sleep(2)
            
            finally:
                if driver:
                    try:
                        driver.quit()
                        time.sleep(1)
                    except:
                        pass
        
        return False
    
    def convert(self, md_path, pdf_path):
        """Main conversion method."""
        try:
            # Convert markdown to HTML
            html_content = self.markdown_to_html(md_path)
            
            # Save temporary HTML file
            html_path = pdf_path.replace('.pdf', '.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            self.logger.info(f"✅ HTML created: {html_path}")
            
            # Convert HTML to PDF
            success = self.html_to_pdf(html_path, pdf_path)
            
            if success:
                self.logger.info(f"🎉 Conversion completed successfully!")
                self.logger.info(f"📄 Markdown: {md_path}")
                self.logger.info(f"📑 PDF: {pdf_path}")
                return True
            else:
                self.logger.error(f"❌ PDF conversion failed")
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Conversion error: {e}")
            import traceback
            traceback.print_exc()
            return False


def main():
    """Main execution function."""
    # Define paths
    md_file = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\docs\06-Workflows\op01_ocr_pii_workflow_es.md"
    pdf_file = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\docs\06-Workflows\op01_ocr_pii_workflow_es.pdf"
    
    # Check if markdown file exists
    if not os.path.exists(md_file):
        print(f"❌ Markdown file not found: {md_file}")
        return False
    
    # Create converter and execute
    converter = MarkdownToPDFConverter()
    success = converter.convert(md_file, pdf_file)
    
    return success


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
