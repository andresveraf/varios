#!/usr/bin/env python3
"""
Final detailed check of version control data distribution
"""

import pandas as pd
import os

def detailed_version_control_check():
    """Detailed check of version control data in Excel reports"""
    
    output_dir = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output"
    
    # Check summary report - Consolidado PII sheet
    summary_files = [f for f in os.listdir(output_dir) if f.startswith("Resumen_Archivos_PII_") and f.endswith(".xlsx")]
    if summary_files:
        summary_files.sort(reverse=True)
        latest_summary_file = os.path.join(output_dir, summary_files[0])
        
        print(f"🔍 Detailed check: {summary_files[0]}")
        
        try:
            # Read Consolidado PII sheet specifically
            df = pd.read_excel(latest_summary_file, sheet_name='Consolidado PII')
            
            print(f"\n📊 Consolidado PII sheet analysis:")
            print(f"   - Total rows: {len(df)}")
            print(f"   - Available columns: {list(df.columns)}")
            
            # Check if both columns exist
            has_version_col = 'Control de version' in df.columns
            has_archivo_col = 'Archivo' in df.columns
            print(f"   - Has 'Control de version' column: {has_version_col}")
            print(f"   - Has 'Archivo' column: {has_archivo_col}")
            
            if has_version_col and has_archivo_col:
                # Group by file to see version control distribution
                def count_unique_versions(x):
                    return x.dropna().nunique()
                
                def get_unique_versions(x):
                    return list(x.dropna().unique())
                
                file_version_summary = df.groupby('Archivo')['Control de version'].agg(['count', count_unique_versions, get_unique_versions])
                file_version_summary.columns = ['Total_Entries', 'Unique_Versions', 'Version_Values']
                
                print(f"\n📋 Version control by file:")
                for archivo, data in file_version_summary.iterrows():
                    print(f"   📁 {archivo}:")
                    print(f"      - Total entries: {data['Total_Entries']}")
                    print(f"      - Unique versions: {data['Unique_Versions']}")
                    print(f"      - Version values: {data['Version_Values']}")
                
                # Overall version control stats
                total_with_version = df['Control de version'].dropna().count()
                total_entries = len(df)
                unique_versions = df['Control de version'].dropna().unique()
                
                print(f"\n📈 Overall statistics:")
                print(f"   - Total entries: {total_entries}")
                print(f"   - Entries with version control: {total_with_version}")
                print(f"   - Entries without version control: {total_entries - total_with_version}")
                print(f"   - Unique version values: {list(unique_versions)}")
                print(f"   - Coverage: {(total_with_version/total_entries)*100:.1f}%")
                
            else:
                print("   ❌ Required columns not found for analysis")
                
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    print("=" * 70)
    print("🔍 DETAILED VERSION CONTROL DISTRIBUTION CHECK")
    print("=" * 70)
    
    detailed_version_control_check()
    
    print("\n" + "=" * 70)
    print("✅ Detailed check complete!")
    print("=" * 70)