# Proyecto de Detección PII con OCR - Diagrama de Flujo

## 📋 Descripción General del Proyecto

Este proyecto detecta automáticamente **Información Identificable Personalmente (PII)** en documentos utilizando OCR (Reconocimiento Óptico de Caracteres) y Aprendizaje Automático.

---

## 🔄 Flujo de Trabajo Principal (Versión Simplificada)

```
┌─────────────────────┐
│ Inicio del Proceso  │
└──────────┬──────────┘
           │
           ▼
┌──────────────────────────────────────────────────────────────┐
│ Inspeccionar Carpetas de SharePoints Parametrizados por País │
│ • Busca carpetas de entrada para cada país                   │
│ • Valida acceso y disponibilidad de metadatos               │
│ • Verifica estructura de carpetas                            │
└──────────┬────────────────────────────┬────────────────────┬──┘
           │                            │                    │
           ▼                            ▼                    ▼
    ┌──────────────┐          ┌──────────────┐      ┌──────────────┐
    │   Chile      │          │  Colombia    │      │   Uruguay    │
    └──────┬───────┘          └──────┬───────┘      └──────┬───────┘
           │                         │                     │
           └──────────────┬──────────┴──────────┬──────────┘
                          │                     │
                          ▼                     ▼
           ┌─────────────────────────────────────────────────┐
           │  Validación de Metadatos (files_metadata.xlsx)  │
           │  • Crea o actualiza información de archivos     │
           │  • Asigna responsables por carpeta/país         │
           │  • Identifica archivos nuevos vs. modificados    │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  Identificación de Archivos a Procesar          │
           │  • Detecta archivos nuevos o modificados        │
           │  • Filtra archivos ya procesados                │
           │  • Valida formatos (PDF, DOC, XLSX, IMG)        │
           │  • Ordena por prioridad                         │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  S1: Procesamiento OCR del Documento            │
           │  • Extrae texto de imágenes y PDFs              │
           │  • Procesa documentos Word/Excel                │
           │  • Genera carpetas extracted_text               │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  S2: Limpieza y Preparación de Texto            │
           │  • Elimina errores del OCR                      │
           │  • Normaliza formato de texto                   │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  S3: Detección de PII con Reglas Regulares      │
           │  Aplica Expresiones Regulares para Identificar: │
           │  • RUT, Nombres, Correos, Teléfonos            │
           │  • Direcciones, Cuentas, Tarjetas de Crédito    │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  Extracción de Datos:                           │
           │  RUTs, Nombres, Direcciones, etc.              │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  S4: Generación de Archivo Excel con Detalles   │
           │  • Consolida todos los PII detectados           │
           │  • Organiza por archivo y tipo de PII           │
           │  • Prepara datos para reportes                  │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────────────┐
           │  Envío de Reportes y Notificaciones por Email   │
           │  • Reporte por carpeta (Propietarios)           │
           │  • Resumen por país (Gerentes)                  │
           │  • Reportes ejecutivos (Dirección)              │
           └─────────────────────────────────────────────────┘
                          │
                          ▼
                  ┌───────────────────┐
                  │ Proceso Completado │
                  └───────────────────┘
```

---

## 📊 Diagrama de Flujo de Datos

```
Documentos de Entrada
      │
      ▼
┌─────────────────┐     ┌──────────────┐     ┌─────────────┐
│  S0: Metadatos  │────▶│  S1: Extrac  │────▶│  S2: Limpiar│
│      Datos      │     │  OCR de Texto│     │    Texto    │
└─────────────────┘     └──────────────┘     └─────────────┘
                                                    │
                                                    ▼
                                            ┌──────────────┐
                                            │  S3: Detectar│
                                            │     PII      │
                                            └──────┬───────┘
                                                   │
                                ┌──────────────┬───┼───┬──────────────┐
                                │              │       │              │
                                ▼              ▼       ▼              ▼
                        ┌──────────────┐  ┌───────────┐  ┌──────────────┐
                        │ Método Regex │  │ Método ML │  │ Fusión Híbrida│
                        └──────────────┘  └───────────┘  └──────┬───────┘
                                                                 │
                                                                 ▼
                                                         ┌──────────────┐
                                                         │  S4: Análisis │
                                                         │  y Filtrado   │
                                                         └──────┬───────┘
                                                                │
                                ┌───────────────┬──────────────┼────────┐
                                │               │              │        │
                                ▼               ▼              ▼        ▼
                        ┌──────────────┐ ┌──────────────┐  ┌──────┐ ┌────────┐
                        │ Excel Principal
                        │  (Todo PII)   │ │ Excel Carpeta│  │Correo│ │Resumen │
                        │               │ │ (Filtrado)   │  │Notif │ │País    │
                        └──────────────┘ └──────────────┘  └──┬───┘ └────┬───┘
                                                              │         │
                                        ┌─────────────────────┼─────────┘
                                        │                     │
                                        ▼                     ▼
                                ┌───────────────────────────────────┐
                                │  NOTIFICACIONES POR CORREO        │
                                │  • Correos por carpeta            │
                                │  • Correos resumen por país       │
                                └───────────────────────────────────┘
```

---

## 🎯 Pasos Clave de Procesamiento

### Paso 1️⃣: Preparación de Entrada (S0)
- **Entrada**: Documentos en carpeta `input/_file_input`
- **Acciones**: 
  - Escanea todos los documentos
  - Crea archivo de metadatos
  - Organiza por país/región
  - Asigna responsables por carpeta
- **Salida**: `files_metadata.xlsx`

### Paso 2️⃣: Extracción OCR (S1)
- **Entrada**: Documentos del Paso 1
- **Acciones**:
  - Convierte PDFs/Imágenes a texto
  - Extrae de documentos Word/Excel
  - Guarda archivos de texto por página
- **Salida**: Archivos de texto en carpetas `extracted_text`

### Paso 3️⃣: Limpieza de Texto (S2)
- **Entrada**: Texto extraído del Paso 2
- **Acciones**:
  - Elimina artefactos del OCR
  - Corrige problemas de formato
  - Normaliza el texto
- **Salida**: Texto limpio listo para detección

### Paso 4️⃣: Detección de PII (S3)
- **Entrada**: Texto limpio del Paso 3
- **Acciones**:
  - **Regex**: Coincidencia de patrones (rápido)
  - **ML**: Modelos de aprendizaje automático (completo)
  - **Híbrido**: Combina ambos métodos
- **Salida**: Detecciones de PII sin procesar

### Paso 5️⃣: Análisis y Filtrado (S4)
- **Entrada**: Detecciones de PII del Paso 4
- **Acciones**:
  - Fusiona y deduplica resultados
  - Elimina falsos positivos
  - Filtra empleados
  - Aplica reglas de negocio
  - Extrae información de control de versiones
  - Genera reportes por carpeta y país
- **Salida**: 
  - Reportes Excel limpios
  - Notificaciones por correo
  - Actualizaciones de metadatos

---

## 📧 Distribución de Correos Electrónicos

```
Tres niveles de reportes:

┌─────────────────────────────────────────┐
│ CORREOS A NIVEL DE CARPETA              │
├─────────────────────────────────────────┤
│ • Uno por carpeta de documento          │
│ • Para: Propietario del documento       │
│ • Contenido: Únicamente PII crítico     │
│ • Alertas: Codificadas por color        │
│ • Adjunto: Reporte Excel filtrado       │
└─────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────┐
│ RESÚMENES A NIVEL DE PAÍS                │
├──────────────────────────────────────────┤
│ • Uno por país (Chile, Brasil, etc.)    │
│ • Para: Gerente/Responsable del país    │
│ • Contenido: Resumen ejecutivo          │
│ • Análisis: Evaluación de riesgo        │
│ • Recomendaciones: Medidas preventivas  │
│ • Adjunto: Todos los reportes Excel     │
└──────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────┐
│ REPORTES DE GESTIÓN/DIRECCIÓN            │
├──────────────────────────────────────────┤
│ • Consolidado de todos los países       │
│ • Para: Liderazgo/Dirección              │
│ • Contenido: Visión estratégica          │
│ • Análisis: Tendencias y patrones       │
│ • Métricas: KPIs y comparativos          │
└──────────────────────────────────────────┘
```

---

## ⚙️ Métodos de Detección

### 🔍 Detección con Regex
- **Velocidad**: ⚡⚡⚡ Muy rápida
- **Precisión**: ⭐⭐⭐ Buena (basada en patrones)
- **Ideal para**: 
  - Direcciones de correo electrónico
  - Números de teléfono
  - Números de ID/RUT
  - Tarjetas de crédito
  - Patrones predefinidos

### 🧠 Detección con ML
- **Velocidad**: ⚡ Más lenta
- **Precisión**: ⭐⭐⭐⭐ Excelente (consciente del contexto)
- **Ideal para**:
  - Nombres de personas
  - Locaciones/Ubicaciones
  - Organizaciones
  - PII específico del contexto
  - Información no estructurada

### 🔄 Método Híbrido (Recomendado)
- **Combina ambos métodos**
- **Filtra falsos positivos automáticamente**
- **Mejor precisión general**
- **Resultados más completos y confiables**

---

## 📁 Estructura de Carpetas

```
C:\RPA\repositorio\OPS\OP01_ocr_pii\
├── input/
│   ├── _file_input/              # Documentos a procesar
│   ├── employees.xlsx             # Lista de empleados (para filtrado)
│   ├── exclusiones.xlsx           # Reglas de exclusión de negocio
│   ├── Listado encargados Chile.xlsx  # Destinatarios de correo
│   └── glosa_lobs.xlsx            # Enrutamiento por LOB
├── output/
│   ├── OCR_PII_Analysis_HYBRID_*.xlsx    # Reporte principal
│   ├── PII_Report_*.xlsx                 # Reportes por carpeta
│   ├── Resumen_Archivos_PII_*.xlsx       # Resúmenes por país
│   └── _others/
│       └── files_metadata.xlsx    # Metadatos actualizados
├── src/
│   ├── process_scripts/
│   │   ├── S0_*.py               # Preparación de archivos
│   │   ├── S1_*.py               # Extracción OCR
│   │   ├── S2_*.py               # Limpieza de texto
│   │   ├── S3_*.py               # Detección de PII
│   │   └── S4_*.py               # Análisis y salida
│   └── utils/                    # Funciones auxiliares
└── docs/
    └── 06-Workflows/             # Documentación
```

---

## 🎛️ Configuración del Proyecto

El proyecto se controla mediante archivos de configuración:

```
config.jsonc (o config.json)
├── ENVIRONMENT
│   ├── DETECTION_METHOD: "hybrid" | "regex" | "ml"
│   ├── INPUT_PATH: "input/_file_input"
│   ├── OUTPUT_PATH: "output"
│   ├── ENABLE_PARALLEL_DETECTION: true/false
│   └── HYBRID_MERGE_STRATEGY: "union" | "intersection" | "ml_priority"
├── TRANSFORMER_CONFIG
│   └── enabled: true/false
└── DATABASE_CONFIG
    └── Configuración de conexión para logging opcional
```

---

## ✅ Aseguramiento de Calidad

```
VALIDACIÓN DE ENTRADA
    ↓
DETECCIÓN DE DUPLICADOS
    ↓
ELIMINACIÓN DE FALSOS POSITIVOS
    ↓
FILTRADO DE EMPLEADOS
    ↓
APLICACIÓN DE REGLAS DE NEGOCIO
    ↓
ASIGNACIÓN DE NIVEL DE SENSIBILIDAD
    ↓
VERIFICACIONES FINALES DE CALIDAD
    ↓
EXPORTACIÓN A EXCEL Y CORREO
```

---

## 📊 Niveles de Riesgo

El sistema evalúa automáticamente el riesgo basado en la exposición de PII:

```
RIESGO MÍNIMO (Verde)
    Sin PII detectado
    ✓ Sin acción requerida

RIESGO BAJO (Azul)
    < 10% archivos con PII
    ≤ 5 detecciones por archivo
    ⚠ Revisión preventiva recomendada

RIESGO MODERADO (Amarillo)
    10-25% archivos con PII
    Densidad de detección media
    ⚠ Atención inmediata necesaria
    
RIESGO ALTO (Rojo)
    > 25% archivos con PII
    Alta densidad de detección
    🚨 Intervención ejecutiva requerida
```

---

## 🎯 Tipos de PII Detectados

### Identificación Personal
- Nombres de personas
- Números RUT/Cédula de identidad
- Números de pasaporte
- Fechas de nacimiento
- Información de ciudadanía

### Contacto
- Correos electrónicos
- Números de teléfono
- Direcciones residenciales
- Números de apartamento/casa

### Financiero
- Números de tarjeta de crédito
- Números de cuenta bancaria
- Códigos de banco
- Números de transferencia
- Montos y transacciones

### Laboral
- Títulos de puesto
- Número de empleado
- Centro de costo
- Línea de negocio (LOB)
- Departamento

### Médico/Sensible
- Información de salud
- Diagnósticos
- Tratamientos
- Números de póliza

---

## 🚀 Guía de Inicio

### 1. Preparar Documentos
- Coloque todos los documentos en `input/_file_input/`
- Organícelos por país si es posible (ej: "Chile - documento.pdf")

### 2. Configurar Ajustes
- Edite `config.jsonc` con el método de detección deseado
- Ajuste umbrales de sensibilidad
- Configure destinatarios de correo

### 3. Ejecutar el Pipeline
- Ejecute el script principal (S0, S1, S2, S3, S4 en secuencia)
- Monitoree los logs para errores
- Verifique archivos de salida

### 4. Revisar Resultados
- Verifique archivos Excel de salida
- Revise notificaciones por correo
- Monitoree actualizaciones de metadatos

### 5. Tomar Acciones
- Direccione detecciones de PII de alto riesgo
- Implemente controles recomendados
- Actualice políticas de seguridad según sea necesario

---

## 📞 Soporte y Solución de Problemas

### Verificación de Errores
- Revise los logs en la carpeta de salida
- Examine archivos de texto extraídos para contexto
- Compare detecciones entre métodos (Regex vs ML)
- Valide contra documentos originales

### Archivos de Depuración
- Logs detallados en `output/_logs/`
- Archivos de texto extraídos en `extracted_text/`
- Metadatos en `output/_others/files_metadata.xlsx`

### Validación de Calidad
- Ejecute reportes de análisis híbrido
- Verifique falsos positivos
- Ajuste listas de exclusión si es necesario
- Reejecutar si hay cambios en configuración

---

## 🔐 Aspectos de Privacidad y Seguridad

### Tratamiento de PII Detectado
- **Ningún envío externo**: Los datos de PII se mantienen internamente
- **Reportes filtrados**: Solo información crítica se envía por correo
- **Auditoría completa**: Se mantiene un registro de todas las detecciones
- **Control de acceso**: Reportes limitados a destinatarios autorizados

### Exclusiones de Negocio
- Empleados internos: Nombres filtrados automáticamente
- Información pública: Se pueden excluir tipos específicos
- Valores estándar: Centros de costo, cuentas especiales
- Tipos sensibles: Configurables por política

---

## 📈 Métricas y KPIs

El sistema proporciona:
- Total de archivos analizados
- Cantidad de detecciones de PII
- Distribución por tipo de PII
- Archivos con mayor riesgo
- Tendencias por país/región
- Eficacia de cada método de detección

---

## 🔄 Integración y Automatización

### Monitoreo Automático
- El sistema puede ejecutarse en horario programado
- Procesamiento incremental de nuevos archivos
- Notificaciones automáticas por correo
- Generación automática de reportes

### Mejora Continua
- Aprendizaje de patrones nuevos
- Ajuste de exclusiones basado en feedback
- Optimización de umbrales de detección
- Refinamiento de métodos de fusión

---

**Última Actualización**: 9 de Diciembre de 2024  
**Proyecto**: Pipeline de Detección PII con OCR  
**Versión**: 4.0 (Detección Híbrida con Notificaciones por Correo)  
**Idioma**: Español
