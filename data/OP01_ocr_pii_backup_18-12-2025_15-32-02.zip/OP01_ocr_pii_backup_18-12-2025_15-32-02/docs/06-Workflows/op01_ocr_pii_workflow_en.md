# OP01 OCR PII Workflow Documentation

*Last Updated: November 27, 2025*
*Version: 2.2 - Updated State-Based Execution Pattern Documentation*

---

## Executive Summary

### Business Overview

This project automates the extraction and analysis of Personally Identifiable Information (PII) from documents using advanced OCR and multiple machine learning detection methods. It is structured as a modular pipeline with **four main execution states** (S00→S1→S2→S4) orchestrated through a state-based execution pattern in `main.py`.

**Key Characteristics:**

- **Multi-Method Detection**: Hybrid approach combining regex patterns, spaCy NER models, HuggingFace transformers, and sentence embedding-based semantic analysis
- **Enhanced Validation**: Dual-layer validation system preventing single-word false positives and context-aware entity classification
- **State-Based Architecture**: Linear state progression (state_idx = 1→2→3→4) with automatic error recovery and retry mechanisms
- **Comprehensive Compliance**: Detailed logging, audit trails, and stakeholder notifications via SMTP email

### Technical Architecture

The solution leverages:

- **Core Orchestration**: `main.py` with `MainProcess` class implementing state-based execution pattern
- **Detection Engines**:
  - Regex patterns (`S3_regex_pii.py`) for structured data (RUT numbers, phone numbers, emails)
  - spaCy NER models (`S3_ml_ner.py`) for contextual entity recognition
  - Transformer ensemble (`S2_transformer_pii.py`) using multilingual models for robust PII detection
  - Sentence Transformers for semantic context analysis and table structure detection
- **Supporting Infrastructure**:
  - Tesseract OCR for text extraction from images
  - Configuration management via `config.jsonc` with JSONC comment support
  - Modular utilities for logging, email notifications, and credential management
  - Excel and JSON reporting with detailed PII analysis

### Operational Importance

- **Regulatory Compliance**: Ensures GDPR, CCPA, and local data protection law adherence
- **Risk Mitigation**: Identifies and classifies sensitive data to prevent breaches
- **Operational Efficiency**: Automates manual document review processes
- **Business Impact**: Protects organization reputation and avoids regulatory fines

---

## Technical Architecture Overview

### System Dependencies

| Component | Type | Details | Business Purpose |
|-----------|------|---------|------------------|
| Trigger Script | Automation | `S00_change_detector_backup.py` | Detects changes and creates backups; emits canonical metadata |
| Input Folder | Data Source | `input/_file_input/` | Source documents for processing |
| Email Templates | Notification | `input/email_files/` | Stakeholder notification content |
| Model Directory | ML Models | `model_spacy/`, `models/` | NER and OCR models |
| Config File | Settings | `config.jsonc` | Pipeline configuration |
| Output Folder | Results | `output/_others/`, `output/_logs/` | Reports and logs |
| Process Data | Temp Data | `process_data/` | Intermediate files |

### File Processing Patterns

| Process | Input Pattern | Output Pattern | Example |
|---------|---------------|----------------|---------|
| S0: Change Detector & Backup | Only DOCX/PDF files in configured SharePoint sync paths | Log in `output/_logs/` | Detects changes, backs up to Regional Hub, emits metadata |
| S1: File Organization | DOCX/PDF files from S0 | Images in `input/_file_input/{doc_name}/images/` | `SOP_Emision_20250825.docx` → `SOP_Emision/images/` |
| S2: Image Preprocessing | Images from S1 | Enhanced images in `input/_file_input/{doc_name}/enhanced/` | `img_001.png` → `enhanced/img_001.png` |
| S3: OCR & PII Detection | Enhanced images | Excel/JSON in `output/_others/`, logs in `output/_logs/` | `OCR_PII_Analysis_{doc}_{date}_{time}.xlsx` |

### External System Details

- **Email**: Uses templates in `input/email_files/` and sends via SMTP (details in config)
- **Models**: spaCy models in `model_spacy/`, HuggingFace models in `models/`
- **Config**: All paths and settings managed via `config.jsonc` and loaded by `Config()` utility

---

## Process Inventory Table

| Process | Business Purpose | Critical Level | Technical Complexity | Documentation Gap | Systems Involved |
|---------|------------------|----------------|---------------------|-------------------|------------------|
| S0: Trigger & Scheduling | Initiate pipeline, detect files, create metadata | High | Medium | Minimal | Python, Scheduler |
| S1: File Organization | Organize and extract images from documents | High | Medium | Minimal | Local FS, Python |
| S2: Image Preprocessing | Enhance image quality for optimal OCR | High | Medium | Minimal | Python, ML libs |
| S4: OCR & PII Detection | Extract text and detect PII, generate reports | Critical | High | Moderate | Python, spaCy, HF |
| Master Pipeline Coordination | Orchestrate all states, error recovery, reporting | Critical | High | Moderate | Python, Email |
| Email Notification/Reporting | Notify stakeholders of process status | High | Medium | Moderate | Email, Python |

---

## Detailed Workflow Documentation

### State 1: S00_ChangeDetectorBackup - File Detection & Metadata Emission

**Business Purpose**: Detect new or modified DOCX/PDF files in configured SharePoint sync locations, create regional hub backups, and emit standardized metadata for downstream processing.

**Execution Frequency**: Manual or scheduled (typically every 5-60 minutes).

**Business Owner**: Compliance/Operations
**Technical Owner**: Automation Team

**Critical Level**: HIGH
**Recovery Impact**: If S00 fails, no files are detected and entire pipeline is blocked.

#### Complete Technical Story

- **What it does**: Scans configured SharePoint-synced input folders, filters for DOCX/PDF files, computes file hashes for change detection, creates backups in Regional Hub, copies OCR-compatible files to processing location, and generates standardized metadata (JSON + Excel)
- **How it works**: 
  - Uses `S00_change_detector_backup.py` class with `run_flow()` method
  - Detects file lifecycle: `nuevo_archivo`, `modificado`, `file_eliminated`
  - Computes MD5 hash for each file for change tracking
  - Backs up changed files to Regional Hub following country-based folder structure
  - Copies OCR-compatible files to `input/_file_input/` for downstream processing
  - Emits canonical metadata in `output/_others/files_metadata.json` and `.xlsx`
- **Where data comes from**: SharePoint-synced local folders configured in `config.jsonc` under `SHAREPOINT_SITES`
- **Where results go**: 
  - Metadata: `output/_others/files_metadata.json` (primary) and `output/_others/files_metadata.xlsx` (for human review)
  - Backups: `REGIONAL_HUB/<Country>/<Folder>/` as configured
  - OCR copies: `input/_file_input/` for immediate downstream processing
  - Logs: `output/_logs/S00_*.log`
- **When it runs**: On schedule or manual trigger
- **Who it affects**: All downstream stages and compliance teams

#### Process Flow Diagram

```mermaid
flowchart TD
    A[Trigger: Manual or Scheduled] --> B[Scan SharePoint-synced Folders]
    B --> C[Filter DOCX/PDF Files Only]
    C --> D[Compute MD5 Hash for Change Detection]
    D --> E{File Changed?}
    E -->|Yes - New| F[Register as nuevo_archivo]
    E -->|Yes - Modified| G[Register as modificado]
    E -->|No| H[Skip File]
    F --> I[Create Regional Hub Backup]
    G --> I
    I --> J[Copy to input/_file_input/]
    J --> K[Generate Metadata JSON/Excel]
    K --> L[Log Results]
    L --> M[Ready for S1]
    H --> L
```

#### Technical Implementation

| Step | Script | Technical Action | Input | Output | Configuration |
|------|--------|------------------|-------|--------|---------------|
| 1 | S00_change_detector_backup.py | Scan configured folders | Local folder paths | File list + metadata | SHAREPOINT_SITES in config.jsonc |
| 2 | S00_change_detector_backup.py | Compute file hashes | File list | Hash dictionary | Hash algorithm (MD5) |
| 3 | S00_change_detector_backup.py | Create backups in Regional Hub | Changed files | Backup copies | REGIONAL_HUB path in config |
| 4 | S00_change_detector_backup.py | Copy OCR-compatible files | File list | Files in input/_file_input/ | OCR file extensions (.pdf, .docx) |
| 5 | S00_change_detector_backup.py | Emit canonical metadata | File list | files_metadata.json + .xlsx | output/_others/ |
| 6 | S00_change_detector_backup.py | Log execution | Process status | Log file | output/_logs/ |

#### File Naming and Path Conventions

- **Input**: Only DOCX/PDF files in configured SharePoint-synced folders
- **Output Metadata**: 
  - `output/_others/files_metadata.json` (programmatic interface)
  - `output/_others/files_metadata.xlsx` (human review)
- **Backups**: `REGIONAL_HUB/<Country>/<Folder>/<filename>` structure
- **OCR Copies**: `input/_file_input/<filename>` (flat or organized as needed)
- **Logs**: `output/_logs/S00_change_detector_backup_{date}_{time}.log`

#### Canonical Metadata Contract

All downstream stages use metadata produced by S00. Minimum required fields per entry:

```json
{
  "file_id": "abc123def456",
  "original_filename": "SOP_Emision_20250825.docx",
  "source_region": "Chile",
  "source_folder": "/Operaciones/Documentos/",
  "source_full_path": "C:/SharePoint_Sync/Operaciones/Documentos/SOP_Emision_20250825.docx",
  "destination_full_path": "REGIONAL_HUB/Chile/Operaciones/SOP_Emision_20250825.docx",
  "file_extension": ".docx",
  "file_type": "document",
  "lifecycle_status": "nuevo_archivo",
  "workflow_stage": "detection",
  "processing_status": "pending",
  "file_hash": "a1b2c3d4e5f6g7h8i9j0",
  "detection_timestamp": "2025-10-28T14:30:00Z",
  "backup_success": true
}
```

#### Recovery Procedures

- **Path validation error**: Check `config.jsonc` SHAREPOINT_SITES entries; verify local sync paths exist
- **Files backed up but not copied to OCR folder**: Verify file extensions in `_is_ocr_compatible_file` mapping
- **Metadata generation failure**: Manually create metadata.json following canonical schema and retry S1
- **Partial failures**: Re-run S00 for specific sites; inspect `backup_reports/` for detailed error logs

#### Security and Compliance

- Only authorized users/systems can trigger S00
- All file changes audited in metadata and backup reports
- Regional Hub backups provide recovery capability
- File hashes enable tamper detection

---

### State 2: S1_FileOrganizer - File Organization & Image Extraction

**Business Purpose**: Normalize filenames, organize files into per-run working folders, and extract images from Word/PDF documents for downstream OCR processing.

**Execution Frequency**: Triggered after S00 completes (typically immediately in same pipeline run).

**Business Owner**: Compliance/Operations
**Technical Owner**: Automation Team

**Critical Level**: HIGH
**Recovery Impact**: If S1 fails, images cannot be extracted and OCR pipeline is blocked.

#### Complete Technical Story

- **What it does**: Reads metadata from S00, normalizes document filenames, moves files to organized working folders, extracts images using document conversion libraries, and updates metadata with workflow stage
- **How it works**:
  - Reads `output/_others/files_metadata.json` produced by S00
  - Creates organized folder structure: `process_data/current_run/<file_id>/`
  - Normalizes filenames (removes special characters, standardizes case)
  - Extracts images from DOCX (uses docx library) or PDF (uses pdf2image)
  - Saves images to `<working_folder>/images/` with sequential naming
  - Updates metadata: `workflow_stage = "organizer"`, `processing_status = "completed"`
- **Where data comes from**: Files in `input/_file_input/` + metadata from `output/_others/files_metadata.json`
- **Where results go**: 
  - Organized files: `process_data/current_run/<file_id>/`
  - Extracted images: `process_data/current_run/<file_id>/images/`
  - Updated metadata: `output/_others/files_metadata.json`
  - Logs: `output/_logs/S1_*.log`
- **When it runs**: After S00 completion
- **Who it affects**: S2 (preprocessing), compliance teams

#### Process Flow Diagram

```mermaid
flowchart TD
    A[Read files_metadata.json from S00] --> B[For Each File Entry]
    B --> C[Normalize Filename]
    C --> D[Create Working Folder]
    D --> E{File Type?}
    E -->|DOCX| F[Extract Images from DOCX]
    E -->|PDF| G[Extract Images from PDF]
    F --> H[Save Images to images/]
    G --> H
    H --> I[Generate Image Metadata]
    I --> J[Update files_metadata.json]
    J --> K[Update workflow_stage = organizer]
    K --> L[Log Results]
    L --> M[Ready for S2]
```

#### Technical Implementation

| Step | Script | Technical Action | Input | Output | Configuration |
|------|--------|------------------|-------|--------|---------------|
| 1 | S1_download_files_and_split.py | Read S00 metadata | files_metadata.json | File entries | config.jsonc |
| 2 | S1_download_files_and_split.py | Normalize filenames | Filenames | Normalized names | Name sanitization rules |
| 3 | S1_download_files_and_split.py | Extract images from DOCX | DOCX file | Image files | python-docx library |
| 4 | S1_download_files_and_split.py | Extract images from PDF | PDF file | Image files | pdf2image library |
| 5 | S1_download_files_and_split.py | Organize folder structure | File list | Working folders | process_data/current_run/ |
| 6 | S1_download_files_and_split.py | Update metadata | File entries | Updated metadata | output/_others/ |

#### File Naming and Path Conventions

- **Input**: Files in `input/_file_input/{filename}` + metadata from S00
- **Working Folder**: `process_data/current_run/<file_id>/`
- **Extracted Images**: `process_data/current_run/<file_id>/images/{image_id}.png` (sequential: img_001.png, img_002.png, etc.)
- **Logs**: `output/_logs/S1_{date}_{time}.log`

#### Recovery Procedures

- **File not found**: Verify file was copied by S00; check `input/_file_input/` folder
- **Image extraction failure**: Move file to `manual_review/` folder; inspect original for corruption
- **Metadata update failure**: Manually update `files_metadata.json` with `workflow_stage = "organizer"`
- **Partial extraction**: Retry S1 for affected files; check library versions (python-docx, pdf2image)

#### Security and Compliance

- Access restricted to service account
- Working folders created in secure `process_data/` directory
- All operations logged for audit trail
- Metadata updated to track workflow progress

---

### State 3: S2_ImagePreprocessor - Image Enhancement for OCR

**Business Purpose**: Enhance image quality using ML-based algorithms, normalize image format, and prepare images for optimal OCR text extraction.

**Execution Frequency**: After S1 completes (typically immediately in same pipeline run).

**Business Owner**: Compliance/Operations
**Technical Owner**: Automation Team

**Critical Level**: HIGH
**Recovery Impact**: Poor image quality leads to OCR errors and PII detection failures.

#### Complete Technical Story

- **What it does**: Loads extracted images, applies enhancement algorithms (denoising, binarization, upsampling), classifies image types, and saves enhanced versions for S3 OCR processing
- **How it works**:
  - Reads image files from `process_data/current_run/<file_id>/images/`
  - Applies preprocessing: noise reduction, contrast enhancement, rotation correction
  - Optionally applies super-resolution upsampling using ML models (EDSR, ESPCN, FSRCNN available in `SR_MODELS/`)
  - Classifies image quality and type (scanned document, digital image, table, form)
  - Saves enhanced images to `process_data/current_run/<file_id>/enhanced/`
  - Updates metadata: `workflow_stage = "preprocessed"`, `processing_status = "ready_for_ocr"`
- **Where data comes from**: Images from S1 in `process_data/current_run/<file_id>/images/`
- **Where results go**:
  - Enhanced images: `process_data/current_run/<file_id>/enhanced/`
  - Image metadata: Updated in `output/_others/files_metadata.json`
  - Logs: `output/_logs/S2_*.log`
- **When it runs**: After S1 completion
- **Who it affects**: S3 (OCR & PII detection)

#### Process Flow Diagram

```mermaid
flowchart TD
    A[Read Images from S1] --> B[Load Image File]
    B --> C[Apply Noise Reduction]
    C --> D[Apply Contrast Enhancement]
    D --> E[Apply Deskew/Rotation]
    E --> F{Apply Super-Resolution?}
    F -->|Yes| G[Upscale using EDSR/ESPCN/FSRCNN]
    F -->|No| H[Proceed with Enhanced Image]
    G --> H
    H --> I[Classify Image Type & Quality]
    I --> J[Save to enhanced/ Folder]
    J --> K[Update Metadata]
    K --> L[Log Results]
    L --> M[Ready for S3]
```

#### Technical Implementation

| Step | Script | Technical Action | Input | Output | Configuration |
|------|--------|------------------|-------|--------|---------------|
| 1 | S2_preprocessing_images.py | Load images | Image files | Image arrays | process_data/current_run/<file_id>/images/ |
| 2 | S2_preprocessing_images.py | Apply noise reduction | Raw image | Denoised image | Denoising algorithm settings |
| 3 | S2_preprocessing_images.py | Enhance contrast & brightness | Image | Enhanced image | Contrast/brightness parameters |
| 4 | S2_preprocessing_images.py | Apply deskew | Image | Straightened image | Rotation detection algorithm |
| 5 | S2_preprocessing_images.py | Apply super-resolution | Image | Upscaled image | SR_MODELS/ (EDSR/ESPCN/FSRCNN) |
| 6 | S2_preprocessing_images.py | Classify image | Image | Type & quality | Classification model |
| 7 | S2_preprocessing_images.py | Save enhanced images | Processed image | Enhanced PNG | enhanced/ folder |

#### File Naming and Path Conventions

- **Input**: `process_data/current_run/<file_id>/images/{image_id}.png`
- **Output Enhanced**: `process_data/current_run/<file_id>/enhanced/{image_id}_enhanced.png`
- **Logs**: `output/_logs/S2_{date}_{time}.log`

#### Recovery Procedures

- **Enhancement failure**: Skip image, log error, notify stakeholders
- **Super-resolution model missing**: Disable upsampling in config, retry with standard enhancement
- **Image quality too low**: Move to `manual_review/` folder for human assessment
- **Metadata update failure**: Manually update `files_metadata.json`

#### Security and Compliance

- All image processing logged
- Enhanced images stored with restricted access in `process_data/`
- No PII visible in preprocessing logs (only image filenames)

---

### State 4: S4_PIIOrchestrator - OCR Text Extraction & Multi-Method PII Detection

**Propósito de Negocio**: Extrae texto de imágenes mejoradas usando OCR Tesseract, aplica múltiples métodos de detección de PII (regex, spaCy NER, ensamble de transformers), valida resultados con protección de dos capas, y genera reportes de cumplimiento.

**Execution Frequency**: After S2 completes (typically immediately in same pipeline run).

**Business Owner**: Compliance/Risk
**Technical Owner**: Automation Team

**Last Updated**: November 27, 2025 - Correct State Index Documentation

**Critical Level**: CRITICAL
**Recovery Impact**: OCR/PII failures directly impact compliance reporting and data protection.

#### Complete Technical Story

- **What it does**: Executes Tesseract OCR on enhanced images, runs parallel PII detection using regex patterns + spaCy models + Transformer ensemble + semantic analysis, validates results with dual-layer protection to eliminate false positives, and generates comprehensive Excel/JSON reports with confidence scores and audit trails
- **How it works**:
  - Reads enhanced images from `process_data/current_run/<file_id>/enhanced/`
  - Extracts text using Tesseract OCR with language setting (Spanish "spa")
  - Runs parallel detection methods:
    - **Regex Detection** (`S3_regex_pii.py`): Finds structured PII (RUT, phone, email, URLs)
    - **spaCy NER Detection** (`S3_ml_ner.py`): Uses spaCy models for named entity recognition (Person, Organization, Location)
    - **Transformer Ensemble** (`S3_transformer_pii.py`): Uses multilingual BERT-based models for robust entity detection
    - **Semantic Analysis**: Sentence Transformers validate context appropriateness (e.g., name extraction from tables vs. body text)
  - Applies dual-layer validation:
    - **Regex Validation Layer**: Strict 2-4 word requirement, rejects single-word false positives, filters business terms
    - **ML Validation Layer**: Context-aware validation, checks confidence scores, semantic appropriateness
  - Merges results using configured strategy (union, intersection, ml_priority, regex_priority)
  - Deduplicates overlapping entities
  - Classifies entities by type and sensitivity level
  - Generates Excel report with detailed analysis
  - Creates JSON summary with statistics
- **Where data comes from**: Enhanced images from S2 in `process_data/current_run/<file_id>/enhanced/`
- **Where results go**:
  - Excel Report: `output/_others/OCR_PII_Analysis_HYBRID_{timestamp}.xlsx`
  - JSON Summary: `process_data/S3_hybrid_summary.json`
  - Updated Metadata: `output/_others/files_metadata.json` (workflow_stage = "completed")
  - Logs: `output/_logs/S4_*.log`
- **When it runs**: After S2 completion
- **Who it affects**: Compliance, audit, risk teams, executives

#### Multi-Method Detection Flow

```mermaid
flowchart TD
    A[Enhanced Images from S2] --> B[S4 PII Orchestrator]
    B --> C[Text Extraction with Tesseract OCR]
    C --> D[Parallel Detection Methods]
    
    D --> E["S3_regex_pii.py<br/>Pattern-Based Detection"]
    D --> F["S3_ml_ner.py<br/>spaCy NER Detection"]
    D --> G["S3_transformer_pii.py<br/>Transformer Ensemble"]
    
    E --> H["Regex Validation Layer<br/>_validate_enhanced_name"]
    F --> I["spaCy Validation Layer<br/>spacy_is_valid_person"]
    G --> J["Transformer Validation<br/>Semantic Context Analysis"]
    
    H -->|Valid| K["Regex Entities<br/>Confidence: 0.7-0.9"]
    I -->|Valid| L["spaCy Entities<br/>Confidence: 0.6-0.95"]
    J -->|Valid| M["Transformer Entities<br/>Confidence: 0.75+"]
    
    H -->|Invalid| N["Rejected<br/>Debug Logged"]
    I -->|Invalid| N
    J -->|Invalid| N
    
    K --> O["Hybrid Merge Process<br/>Union/Intersection/ML-Priority"]
    L --> O
    M --> O
    
    O --> P["Deduplication<br/>Remove Overlaps"]
    P --> Q["Entity Classification<br/>Person/RUT/Phone/Email/etc"]
    Q --> R["Excel Report<br/>OCR_PII_Analysis_HYBRID_*.xlsx"]
    R --> S["JSON Summary<br/>S3_hybrid_summary.json"]
    S --> T["Logging & Notifications"]
```

#### Detection Methods & Validation Deep Dive

**Regex Detection** (`S3_regex_pii.py`):
- Structured patterns: RUT numbers (12.345.678-9), phone numbers, email addresses, URLs
- Person name patterns: 2-4 words, capitalization rules, no business terms
- Strict validation: Rejects adverbs, organizational terms, single words
- Confidence: 0.7-0.9 (high precision, possible false negatives)

**spaCy NER Detection** (`S3_ml_ner.py`):
- Uses trained spaCy models from `model_spacy/`
- Entity types: PERSON, ORG, LOCATION, MISC
- Context-aware recognition of named entities
- Confidence: 0.6-0.95 (context-dependent)

**Transformer Ensemble** (`S3_transformer_pii.py`):

- Multilingual BERT models (`sentence-transformers/distiluse-base-multilingual-cased-v2`)
- Multi-model voting for robust predictions
- Weighted voting from multiple transformer architectures
- Semantic context analysis using embedding similarity
- Organization vs. Person classification reclassification
- Confidence: 0.75+ after ensemble voting

**Dual-Layer Validation**:
1. **Regex Validation** (`_validate_enhanced_name`):
   - Minimum 2 words, maximum 4 words
   - Each word 3+ characters (except connecting words: de, del, la, y, e, van, von)
   - Must contain 2+ valid name words
   - Filters 25+ problematic business/adverb terms
   - Checks name similarity to common Spanish names/surnames

2. **ML Validation** (`is_valid_person_name`):
   - Rejects single-word entities absolutely
   - Context-aware sentence embedding analysis
   - Table structure detection (names in tables vs. body text)
   - Semantic similarity scoring
   - Confidence thresholds applied

**Hybrid Merge Strategies**:
- **union**: All entities from both methods (maximum coverage, possible false positives)
- **intersection**: Only entities found by both methods (highest precision, possible false negatives)
- **ml_priority**: Prefer ML results, add regex discoveries (balanced, recommended)
- **regex_priority**: Prefer regex results, add ML discoveries (performance-focused)

#### Technical Implementation

| Step | Script/Method | Technical Action | Input | Output | Configuration |
|------|---------------|------------------|-------|--------|---------------|
| 1 | S4_pii_orchestrator.py | Initialize hybrid detection | Enhanced images | Detection setup | config.jsonc |
| 2 | Tesseract OCR | Text extraction | Image files | Text data | TESSERACT_CONFIG in config |
| 3 | S3_regex_pii.py | Pattern-based detection | Text data | Regex entities | PIIPatterns definitions |
| 4 | S3_ml_ner.py | spaCy NER detection | Text data | spaCy entities | model_spacy/ models |
| 5 | S3_transformer_pii.py | Transformer ensemble | Text data | Transformer entities | HF models in models/ |
| 6 | _validate_enhanced_name() | Regex validation layer | Name candidates | Validated regex entities | Validation rules |
| 7 | is_valid_person_name() | ML validation layer | Name candidates | Validated ML entities | Confidence thresholds |
| 8 | Semantic Analysis | Context validation | Entities + text | Context-valid entities | Sentence transformers |
| 9 | _merge_detection_results() | Hybrid merge | Both entity sets | Combined entities | HYBRID_MERGE_STRATEGY |
| 10 | Deduplication | Remove overlaps | Combined entities | Unique entities | Position-based matching |
| 11 | Classification | Entity type assignment | Entities | Classified entities | PII type mappings |
| 12 | Excel Generation | Report creation | All results | XLSX file | output/_others/ |
| 13 | JSON Summary | Statistics generation | All results | JSON summary | process_data/ |

#### File Naming and Path Conventions

- **Input Images**: `process_data/current_run/<file_id>/enhanced/{image_id}_enhanced.png`
- **Output Excel Report**: `output/_others/OCR_PII_Analysis_HYBRID_{timestamp}.xlsx`
- **Output JSON Summary**: `process_data/S3_hybrid_summary.json`
- **Updated Metadata**: `output/_others/files_metadata.json` (workflow_stage = "completed")
- **Logs**: `output/_logs/S4_{date}_{time}.log`

#### Excel Report Structure

The generated Excel file includes multiple sheets:

1. **Summary**: Overall statistics (total entities, by type, confidence distribution)
2. **All Entities**: Detailed list of detected PII with source, confidence, validation status
3. **Persons**: Person names with confidence, source method, validation status
4. **RUT Numbers**: Chilean RUT format with validation
5. **Contact Info**: Phone numbers and email addresses
6. **Metadata**: File information, processing timestamps, detection configuration
7. **Validation Log**: Entities rejected during validation with reasons

#### Configuration Settings (config.jsonc)

```jsonc
{
  "DETECTION_METHOD": "hybrid",  // Options: "regex", "ml", "hybrid"
  "HYBRID_MERGE_STRATEGY": "union",  // Options: "union", "intersection", "ml_priority", "regex_priority"
  "ENABLE_PARALLEL_DETECTION": false,  // Parallel execution in hybrid mode
  "TRANSFORMER_CONFIG": {
    "enabled": true,
    "models": [
      "xlm-roberta-base",  // Multilingual
      "distilbert-base-multilingual-cased",  // Fast multilingual
      "bert-base-multilingual-cased"  // Full multilingual BERT
    ],
    "voting_strategy": "weighted",
    "confidence_threshold": 0.75
  },
  "TESSERACT_CONFIG": "--oem 3 --psm 6",
  "OCR_LOW_CONF_THRESHOLD": 45,
  "PERSON_MIN_CONF": 0.75
}
```

#### Recovery Procedures

- **OCR failure**: Log error, skip image, notify stakeholders
- **Detection method failure**: Fall back to single method, log warning
- **Entity validation failure**: Log for manual review, escalate if critical
- **Report generation failure**: Save raw JSON output, investigate Excel library issues
- **Metadata update failure**: Manually update `files_metadata.json`

#### Performance Considerations

- **Parallel Detection**: Enable when processing large documents to speed up hybrid detection
- **Model Caching**: Transformer models cached in memory for batch processing
- **Memory Usage**: Plan for ~2-3GB RAM for loaded transformer models
- **Processing Time**: Typical document: 30-60 seconds for S3 complete execution

#### Security and Compliance

- All PII detection logged for audit trail
- Reports stored securely in `output/_others/` with restricted access
- Sensitive data never logged in plain text (hashed when necessary)
- Metadata includes detection method and confidence for traceability
- Email notifications masked sensitive data fields

---

## Process: Master Pipeline Coordination (main.py)

**Business Purpose**: Orchestrate all four states, manage state transitions, handle exceptions, and provide complete pipeline coordination.

**Execution Frequency**: Manual start or scheduled trigger.

**Business Owner**: Compliance/Operations
**Technical Owner**: Automation Team

**Critical Level**: CRITICAL

#### State-Based Execution Architecture

The `MainProcess` class in `main.py` implements a state-machine pattern:

```python
if self.state_idx == 1:
    self.current_workflow = S00ChangeDetectorBackup(self._config)
    print(f'Primer State')
elif self.state_idx == 2:
    self.current_workflow = S1_FileOrganizer(self._config)
    print(f'Segundo State')
elif self.state_idx == 3:
    self.current_workflow = S2_ImagePreprocessor(self._config)
    print(f'Tercer State')
elif self.state_idx == 4:
    self.current_workflow = S4PIIOrchestrator(self._config)
    print(f'Cuarto State')
else:
    self._running = False
```

#### Pipeline Execution Flow Diagram

```mermaid
flowchart LR
  Runner[Runner / Scheduler] --> S00[S00_ChangeDetectorBackup<br/>detection + backup + metadata]
  S00 -->|if changes| S1[S1_FileOrganizer<br/>normalize & move]
  S00 -->|no changes| EndNoChange[End - no changes]
  S1 --> S2[S2_ImagePreprocessor<br/>ocr-ready artifacts]
  S2 --> S4[S4PIIOrchestrator<br/>OCR + NER/PII + reports]
  S4 --> Reports[Reports, JSON, Excel, Email]
  S4 --> Archive[Regional Hub archive]
```

#### Error Handling & Recovery

**Retry Mechanism**:
- Maximum retries: `MAX_TRIES` in config (default: 2)
- On failure: Increments `state_idx` counter, stays in same state
- After max retries: Logs failed state, sends exception email, marks pipeline status as "FAILED" or "WARNING"

**Exception Types**:
1. **BusinessException**: Expected business errors (file not found, validation failed)
   - Status: WARNING
   - Action: Send business exception email, exit pipeline
2. **SystemException**: Unexpected system errors (library failure, system resources)
   - Status: FAILED
   - Action: Send system exception email with traceback, attempt recovery

**Exception Notification**:
- Calls `notify_exception()` method
- Builds traceback dataframe with file/line/function information
- Sends detailed email using `ExceptionEmails` utility
- Includes configuration and environment details for debugging

#### Execution Time Tracking

- Pipeline start: `t1 = time.time()`
- Pipeline end: Logs total elapsed time as `datetime.timedelta`
- Per-state timing: Each state logs start/end messages for performance analysis

---

## Output Structure

### Excel Reports (OCR_PII_Analysis_HYBRID_*.xlsx)

**Multiple sheets with detailed PII analysis:**

- **Summary**: Total entities, by type, confidence distribution
- **All Entities**: Complete entity list with confidence scores
- **Persons**: Person names with validation status
- **RUT Numbers**: Chilean RUT format validation
- **Contact Info**: Phone numbers and emails
- **Metadata**: File info, processing times, configuration used
- **Validation Log**: Rejected entities with rejection reasons

### JSON Summaries

- **files_metadata.json**: Complete metadata for all files (primary interface for downstream systems)
- **S3_hybrid_summary.json**: PII detection statistics and method performance metrics
- **backup_reports/**: Per-site backup success/failure reports

### Logs

- **S0_change_detector_backup_*.log**: File detection and backup operations
- **S1_fileorganizer_*.log**: File organization and image extraction
- **S2_imagepreprocessor_*.log**: Image enhancement operations
- **S3_orchestrator_*.log**: OCR and PII detection details
- **OP01_*.log**: Master pipeline execution log

### Email Notifications

Automated stakeholder updates using templates in `input/email_files/`:
- Execution start notification
- Success summary with entity counts
- Failure alerts with error details
- Escalation notifications for critical errors

---

## Risk Assessment & Mitigation

| Process | Risk Level | Impact of Failure | Current Mitigation | Recommended Action |
|---------|-----------|-------------------|-------------------|-------------------|
| S00: File Detection | Medium | Files not detected, pipeline blocked | Logging, manual review, retry logic | Monitor SharePoint sync status regularly |
| S1: File Organization | Medium | Images not extracted, S2-S3 blocked | Error logging, notification | Validate image extraction in testing |
| S2: Image Preprocessing | Medium | Poor OCR quality, PII detection fails | Logging, skip on error | Tuning enhancement algorithms |
| S4: OCR & PII Detection | High | Missed PII, compliance breach | Multi-method detection, dual validation | Add manual review for high-value docs |
| Master Coordination | High | Complete pipeline failure | Exception handling, email alerts | Implement automated recovery scripts |
| Email Notification | Medium | Stakeholders uninformed | Retry logic, logging | Monitor SMTP connectivity |

---

## Operational Tuning Tips

- **Schedule S00** at cadence balancing latency vs. scan cost (typical: every 5-60 minutes)
- **Disable hashing in S00** if environment has many large files to reduce CPU
- **Parallelize S4** processing per file_id using thread/process pool
- **Cache transformer models** across batch processing to reduce memory usage
- **Monitor OCR confidence** threshold; adjust based on false positive/negative rates
- **Tune validation thresholds** in hybrid merge strategy based on your data

---

## Quick Verification Checklist After Pipeline Run

- [ ] `output/_others/files_metadata.json` exists and contains entries for changed files
- [ ] `output/backup_reports/backup_summary_*.json` shows successful backups per site
- [ ] `input/_file_input/` contains expected OCR-compatible file copies
- [ ] `process_data/current_run/` contains organized folders with images and enhanced versions
- [ ] `output/_others/OCR_PII_Analysis_HYBRID_*.xlsx` contains final PII report
- [ ] `output/_logs/` contains logs for all four states
- [ ] Email notifications sent successfully to configured recipients
- [ ] `process_data/S3_hybrid_summary.json` contains detection statistics

---

## Appendix: Model & Resource Information

### Transformer Models Available

- **distiluse-base-multilingual-cased-v2**: Spanish+multilingual support, fast inference
- **xlm-roberta-base**: Robust multilingual, good for Spanish
- **distilbert-base-multilingual-cased**: Fast BERT variant, multilingual

### Super-Resolution Models

Located in `SR_MODELS/`:
- **EDSR**: High-quality upsampling (×2, ×3, ×4)
- **ESPCN**: Efficient sub-pixel convolution
- **FSRCNN**: Fast super-resolution CNN

### OCR Engine

- **Tesseract**: Industry-standard open-source OCR
- **Config**: `--oem 3 --psm 6` (default for document pages)
- **Language**: Spanish ("spa") configured in config.jsonc

---

## Support & Troubleshooting

For issues or questions, refer to:
- Detailed logs in `output/_logs/`
- Configuration reference: `config.jsonc` comments
- Utility documentation: `.github/instructions/utils_index.md`
- Process script docstrings for detailed method information

