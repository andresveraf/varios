# Documentación del Flujo OP01 OCR PII

*Última actualización: 27 de Noviembre de 2025*
*Versión: 2.2 - Documentación Actualizada del Patrón de Ejecución Basado en Estados*

---

## Resumen Ejecutivo

### Visión de Negocio

Este proyecto automatiza la extracción y análisis de Información Personal Identificable (PII) en documentos utilizando OCR avanzado y múltiples métodos de aprendizaje automático. Está estructurado como un pipeline modular con **cuatro estados principales de ejecución** (S00→S1→S2→S4) orquestados a través de un patrón de ejecución basado en estados en `main.py`.

**Características Clave:**

- **Detección Multi-Método**: Enfoque híbrido combinando patrones regex, modelos spaCy NER, transformers de HuggingFace y análisis semántico basado en embeddings
- **Validación Mejorada**: Sistema de validación en dos capas que previene falsos positivos de una sola palabra y clasificación de entidades consciente del contexto
- **Arquitectura Basada en Estados**: Progresión lineal de estados (state_idx = 1→2→3→4) con mecanismos automáticos de recuperación de errores
- **Cumplimiento Integral**: Registro detallado, auditoría completa y notificaciones a interesados vía correo SMTP

### Arquitectura Técnica

La solución aprovecha:

- **Orquestación Central**: `main.py` con clase `MainProcess` implementando patrón de ejecución basado en estados
- **Motores de Detección**:
  - Patrones regex (`S3_regex_pii.py`) para datos estructurados (RUT, teléfono, email)
  - Modelos spaCy NER (`S3_ml_ner.py`) para reconocimiento contextual de entidades
  - Ensamble de transformers (`S2_transformer_pii.py`) usando modelos multilingües para detección robusta de PII
  - Sentence Transformers para análisis semántico del contexto y detección de estructuras de tablas
- **Infraestructura de Soporte**:
  - OCR Tesseract para extracción de texto de imágenes
  - Gestión de configuración vía `config.jsonc` con soporte para comentarios JSONC
  - Utilidades modulares para registro, notificaciones por correo y gestión de credenciales
  - Reportes en Excel y JSON con análisis detallado de PII

### Importancia Operacional

- **Cumplimiento Regulatorio**: Asegura adherencia a GDPR, CCPA y leyes locales de protección de datos
- **Mitigación de Riesgos**: Identifica y clasifica datos sensibles para prevenir filtraciones
- **Eficiencia Operacional**: Automatiza procesos manuales de revisión de documentos
- **Impacto de Negocio**: Protege reputación organizacional y evita multas regulatorias

---

## Arquitectura Técnica General

### Dependencias del Sistema

| Componente | Tipo | Detalles | Propósito de Negocio |
|-----------|------|---------|---------------------|
| Script de Disparo | Automatización | `S00_change_detector_backup.py` | Detecta cambios y crea respaldos; emite metadata canónica |
| Carpeta de Entrada | Fuente de Datos | `input/_file_input/` | Documentos fuente para procesar |
| Plantillas de Email | Notificación | `input/email_files/` | Contenido de notificaciones a interesados |
| Directorio de Modelos | Modelos ML | `model_spacy/`, `models/` | Modelos NER y OCR |
| Archivo de Configuración | Configuración | `config.jsonc` | Configuración del pipeline |
| Carpeta de Salida | Resultados | `output/_others/`, `output/_logs/` | Reportes y logs |
| Datos de Proceso | Datos Temporales | `process_data/` | Archivos intermedios |

### Patrones de Procesamiento de Archivos

| Proceso | Patrón de Entrada | Patrón de Salida | Ejemplo |
|---------|-------------------|------------------|---------|
| S0: Detector de Cambios | Archivos en carpetas sincronizadas de SharePoint | Log en `output/_logs/` | `S00_change_detector_backup.py` detecta cambios, respalda y emite metadata |
| S1: Organización | Archivos DOCX/PDF en `input/_file_input/` | Imágenes en `input/_file_input/{doc}/images/` | `SOP_Emision_20250825.docx` → `SOP_Emision/images/` |
| S2: Preprocesamiento | Imágenes de S1 | Mejoradas en `input/_file_input/{doc}/enhanced/` | `img_001.png` → `enhanced/img_001.png` |
| S3: OCR y PII | Imágenes mejoradas | Excel/JSON en `output/_others/`, logs en `output/_logs/` | `OCR_PII_Analysis_{doc}_{fecha}_{hora}.xlsx` |

### Detalles de Sistemas Externos

- **Email**: Usa plantillas en `input/email_files/` y envía por SMTP (detalles en config)
- **Modelos**: Modelos spaCy en `model_spacy/`, HuggingFace en `models/`
- **Config**: Todas las rutas y parámetros gestionados por `config.jsonc` y la utilidad `Config()`

---

## Tabla de Inventario de Procesos

| Proceso | Propósito de Negocio | Nivel Crítico | Complejidad Técnica | Brecha Documental | Sistemas Involucrados |
|---------|---------------------|---------------|---------------------|-------------------|----------------------|
| S0: Disparo e Inicio | Inicia pipeline, detecta archivos, crea metadata | Alto | Medio | Mínima | Python, Scheduler |
| S1: Organización de Archivos | Organiza y extrae imágenes de documentos | Alto | Medio | Mínima | FS local, Python |
| S2: Preprocesamiento de Imágenes | Mejora calidad de imagen para OCR óptimo | Alto | Medio | Mínima | Python, librerías ML |
| S4: OCR y Detección de PII | Extrae texto y detecta PII, genera reportes | Crítico | Alto | Moderada | Python, spaCy, HF |
| Coordinación del Pipeline | Orquesta etapas, recuperación de errores | Crítico | Alto | Moderada | Python, Email |
| Notificación/Reporte por Email | Notifica estado de proceso a interesados | Alto | Medio | Moderada | Email, Python |

---

## Documentación Detallada del Flujo

### Estado 1: S00_ChangeDetectorBackup - Detección de Archivos & Emisión de Metadata

**Propósito de Negocio**: Detecta archivos DOCX/PDF nuevos o modificados en ubicaciones SharePoint sincronizadas, crea respaldos en el Regional Hub, y emite metadata estandarizada para procesamiento posterior.

**Frecuencia de Ejecución**: Manual o programada (típicamente cada 5-60 minutos).

**Dueño de Negocio**: Cumplimiento/Operaciones
**Dueño Técnico**: Equipo de Automatización

**Nivel Crítico**: ALTO
**Impacto de Recuperación**: Si S00 falla, ningún archivo es detectado y el pipeline completo se bloquea.

#### Historia Técnica Completa

- **Qué hace**: Escanea carpetas sincronizadas de SharePoint configuradas, filtra archivos DOCX/PDF, calcula hashes MD5 para detección de cambios, crea respaldos en Regional Hub, copia archivos compatibles con OCR a ubicación de procesamiento, y genera metadata estandarizada (JSON + Excel)
- **Cómo funciona**:
  - Usa clase `S00_change_detector_backup.py` con método `run_flow()`
  - Detecta ciclo de vida del archivo: `nuevo_archivo`, `modificado`, `file_eliminated`
  - Calcula hash MD5 de cada archivo para rastrear cambios
  - Respalda archivos modificados en Regional Hub según estructura por país
  - Copia archivos compatibles con OCR a `input/_file_input/` para procesamiento posterior
  - Emite metadata canónica en `output/_others/files_metadata.json` y `.xlsx`
- **De dónde vienen los datos**: Carpetas locales sincronizadas de SharePoint configuradas en `config.jsonc` bajo `SHAREPOINT_SITES`
- **A dónde van los resultados**:
  - Metadata: `output/_others/files_metadata.json` (principal) y `output/_others/files_metadata.xlsx` (revisión humana)
  - Respaldos: `REGIONAL_HUB/<País>/<Carpeta>/` según configuración
  - Copias OCR: `input/_file_input/` para procesamiento posterior inmediato
  - Logs: `output/_logs/S00_*.log`
- **Cuándo corre**: Según programación o disparo manual
- **A quién afecta**: Todas las etapas posteriores y equipos de cumplimiento

#### Diagrama de Flujo de Proceso

```mermaid
flowchart TD
    A[Disparo Manual o Programado] --> B[Escanear Carpetas Sincronizadas]
    B --> C[Filtrar Archivos DOCX PDF Solamente]
    C --> D[Calcular Hash MD5 para Detección de Cambios]
    D --> E{Archivo Cambió}
    E -->|Sí Nuevo| F[Registrar como nuevo_archivo]
    E -->|Sí Modificado| G[Registrar como modificado]
    E -->|No| H[Saltar Archivo]
    F --> I[Crear Respaldo en Regional Hub]
    G --> I
    I --> J[Copiar a input file_input]
    J --> K[Generar Metadata JSON Excel]
    K --> L[Registrar Resultados]
    L --> M[Listo para S1]
    H --> L
```

#### Implementación Técnica

| Paso | Script | Acción Técnica | Entrada | Salida | Configuración |
|------|--------|----------------|---------|--------|---------------|
| 1 | S00_change_detector_backup.py | Escanear carpetas configuradas | Rutas de carpetas locales | Lista de archivos + metadata | SHAREPOINT_SITES en config.jsonc |
| 2 | S00_change_detector_backup.py | Calcular hashes de archivos | Lista de archivos | Diccionario de hashes | Algoritmo hash (MD5) |
| 3 | S00_change_detector_backup.py | Crear respaldos en Regional Hub | Archivos modificados | Copias de respaldo | Ruta REGIONAL_HUB en config |
| 4 | S00_change_detector_backup.py | Copiar archivos compatibles con OCR | Lista de archivos | Archivos en input/_file_input/ | Extensiones OCR (.pdf, .docx) |
| 5 | S00_change_detector_backup.py | Emitir metadata canónica | Lista de archivos | files_metadata.json + .xlsx | output/_others/ |
| 6 | S00_change_detector_backup.py | Registrar ejecución | Estado del proceso | Archivo de log | output/_logs/ |

#### Convenciones de Nombres y Rutas

- **Entrada**: Solo archivos DOCX/PDF en carpetas SharePoint sincronizadas configuradas
- **Metadata de Salida**:
  - `output/_others/files_metadata.json` (interfaz programática)
  - `output/_others/files_metadata.xlsx` (revisión humana)
- **Respaldos**: Estructura `REGIONAL_HUB/<País>/<Carpeta>/<nombre_archivo>`
- **Copias OCR**: `input/_file_input/<nombre_archivo>` (plano u organizado según necesidad)
- **Logs**: `output/_logs/S00_change_detector_backup_{fecha}_{hora}.log`

#### Contrato de Metadata Canónica

Todas las etapas posteriores utilizan metadata producida por S00. Campos mínimos requeridos por entrada:

```json
{
  "file_id": "abc123def456",
  "original_filename": "SOP_Emision_20250825.docx",
  "source_region": "Chile",
  "source_folder": "/Operaciones/Documentos/",
  "source_full_path": "C:/SharePoint_Sync/Operaciones/Documentos/SOP_Emision_20250825.docx",
  "destination_full_path": "REGIONAL_HUB/Chile/Operaciones/SOP_Emision_20250825.docx",
  "file_extension": ".docx",
  "file_type": "document",
  "lifecycle_status": "nuevo_archivo",
  "workflow_stage": "detection",
  "processing_status": "pending",
  "file_hash": "a1b2c3d4e5f6g7h8i9j0",
  "detection_timestamp": "2025-10-28T14:30:00Z",
  "backup_success": true
}
```

#### Procedimientos de Recuperación

- **Error de validación de ruta**: Verificar SHAREPOINT_SITES en `config.jsonc`; confirmar que rutas locales existen
- **Archivos respaldados pero no copiados a carpeta OCR**: Verificar mapeo de extensiones en `_is_ocr_compatible_file`
- **Falla en generación de metadata**: Crear manualmente metadata.json siguiendo esquema canónico e intentar S1
- **Fallos parciales**: Re-ejecutar S00 para sitios específicos; inspeccionar logs en `backup_reports/`

#### Seguridad y Cumplimiento

- Solo usuarios/sistemas autorizados pueden disparar S00
- Todos los cambios de archivos auditados en metadata y reportes de respaldo
- Respaldos en Regional Hub proporcionan capacidad de recuperación
- Hashes de archivos permiten detección de manipulación

---

### Estado 2: S1_FileOrganizer - Organización de Archivos & Extracción de Imágenes

**Propósito de Negocio**: Normaliza nombres de archivos, organiza archivos en carpetas de trabajo por ejecución, y extrae imágenes de documentos Word/PDF para procesamiento OCR posterior.

**Frecuencia de Ejecución**: Disparado después de que S00 completa (típicamente inmediatamente en misma ejecución del pipeline).

**Dueño de Negocio**: Cumplimiento/Operaciones
**Dueño Técnico**: Equipo de Automatización

**Nivel Crítico**: ALTO
**Impacto de Recuperación**: Si S1 falla, las imágenes no se extraen y el pipeline OCR se bloquea.

#### Historia Técnica Completa

- **Qué hace**: Lee metadata de S00, normaliza nombres de documentos, mueve archivos a carpetas organizadas de trabajo, extrae imágenes usando librerías de conversión de documentos, y actualiza metadata con etapa de flujo
- **Cómo funciona**:
  - Lee `output/_others/files_metadata.json` producido por S00
  - Crea estructura de carpetas organizada: `process_data/current_run/<file_id>/`
  - Normaliza nombres de archivos (elimina caracteres especiales, estandariza caso)
  - Extrae imágenes desde DOCX (usa librería docx) o PDF (usa pdf2image)
  - Guarda imágenes en `<carpeta_trabajo>/images/` con nombres secuenciales
  - Actualiza metadata: `workflow_stage = "organizer"`, `processing_status = "completed"`
- **De dónde vienen los datos**: Archivos en `input/_file_input/` + metadata de `output/_others/files_metadata.json`
- **A dónde van los resultados**:
  - Archivos organizados: `process_data/current_run/<file_id>/`
  - Imágenes extraídas: `process_data/current_run/<file_id>/images/`
  - Metadata actualizada: `output/_others/files_metadata.json`
  - Logs: `output/_logs/S1_*.log`
- **Cuándo corre**: Después de finalizar S00
- **A quién afecta**: S2 (preprocesamiento), equipos de cumplimiento

#### Diagrama de Flujo

```mermaid
flowchart TD
    A[Leer files_metadata.json de S00] --> B[Para Cada Entrada de Archivo]
    B --> C[Normalizar Nombre de Archivo]
    C --> D[Crear Carpeta de Trabajo]
    D --> E{Tipo de Archivo}
    E -->|DOCX| F[Extraer Imágenes de DOCX]
    E -->|PDF| G[Extraer Imágenes de PDF]
    F --> H[Guardar Imágenes en images]
    G --> H
    H --> I[Generar Metadata de Imágenes]
    I --> J[Actualizar files_metadata.json]
    J --> K[Actualizar workflow_stage organizer]
    K --> L[Registrar Resultados]
    L --> M[Listo para S2]
```

#### Implementación Técnica

| Paso | Script | Acción Técnica | Entrada | Salida | Configuración |
|------|--------|----------------|---------|--------|---------------|
| 1 | S1_download_files_and_split.py | Leer metadata de S00 | files_metadata.json | Entradas de archivo | config.jsonc |
| 2 | S1_download_files_and_split.py | Normalizar nombres | Nombres de archivos | Nombres normalizados | Reglas de sanitización |
| 3 | S1_download_files_and_split.py | Extraer imágenes de DOCX | Archivo DOCX | Archivos de imagen | Librería python-docx |
| 4 | S1_download_files_and_split.py | Extraer imágenes de PDF | Archivo PDF | Archivos de imagen | Librería pdf2image |
| 5 | S1_download_files_and_split.py | Organizar estructura carpetas | Lista de archivos | Carpetas de trabajo | process_data/current_run/ |
| 6 | S1_download_files_and_split.py | Actualizar metadata | Entradas de archivo | Metadata actualizada | output/_others/ |

#### Convenciones de Nombres y Rutas

- **Entrada**: Archivos en `input/_file_input/{nombre_archivo}` + metadata de S00
- **Carpeta de Trabajo**: `process_data/current_run/<file_id>/`
- **Imágenes Extraídas**: `process_data/current_run/<file_id>/images/{image_id}.png` (secuencial: img_001.png, img_002.png, etc.)
- **Logs**: `output/_logs/S1_{fecha}_{hora}.log`

#### Procedimientos de Recuperación

- **Archivo no encontrado**: Verificar que archivo fue copiado por S00; revisar carpeta `input/_file_input/`
- **Falla en extracción de imágenes**: Mover archivo a carpeta `manual_review/`; inspeccionar original para corrupción
- **Falla en actualización de metadata**: Actualizar manualmente `files_metadata.json` con `workflow_stage = "organizer"`
- **Extracción parcial**: Reintentar S1 para archivos afectados; verificar versiones de librerías

#### Seguridad y Cumplimiento

- Acceso restringido a cuenta de servicio
- Carpetas de trabajo creadas en directorio seguro `process_data/`
- Todas las operaciones registradas para auditoría
- Metadata actualizada para rastrear progreso del flujo

---

### Estado 3: S2_ImagePreprocessor - Mejora de Imágenes para OCR

**Propósito de Negocio**: Mejora la calidad de imagen utilizando algoritmos basados en ML, normaliza formato de imagen, y prepara imágenes para extracción óptima de texto con OCR.

**Frecuencia de Ejecución**: Después de que S1 completa (típicamente inmediatamente en misma ejecución del pipeline).

**Dueño de Negocio**: Cumplimiento/Operaciones
**Dueño Técnico**: Equipo de Automatización

**Nivel Crítico**: ALTO
**Impacto de Recuperación**: Baja calidad de imagen causa errores de OCR y fallos en detección de PII.

#### Historia Técnica Completa

- **Qué hace**: Carga imágenes extraídas, aplica algoritmos de mejora (reducción de ruido, binarización, remuestreo), clasifica tipos de imagen, y guarda versiones mejoradas para procesamiento OCR de S3
- **Cómo funciona**:
  - Lee archivos de imagen de `process_data/current_run/<file_id>/images/`
  - Aplica preprocesamiento: reducción de ruido, mejora de contraste, corrección de rotación
  - Opcionalmente aplica remuestreo super-resolución usando modelos ML (EDSR, ESPCN, FSRCNN disponibles en `SR_MODELS/`)
  - Clasifica calidad y tipo de imagen (documento escaneado, imagen digital, tabla, formulario)
  - Guarda imágenes mejoradas en `process_data/current_run/<file_id>/enhanced/`
  - Actualiza metadata: `workflow_stage = "preprocessed"`, `processing_status = "ready_for_ocr"`
- **De dónde vienen los datos**: Imágenes de S1 en `process_data/current_run/<file_id>/images/`
- **A dónde van los resultados**:
  - Imágenes mejoradas: `process_data/current_run/<file_id>/enhanced/`
  - Metadata de imagen: Actualizada en `output/_others/files_metadata.json`
  - Logs: `output/_logs/S2_*.log`
- **Cuándo corre**: Después de finalizar S1
- **A quién afecta**: S3 (OCR y detección de PII)

#### Diagrama de Flujo

```mermaid
flowchart TD
    A[Leer Imágenes de S1] --> B[Cargar Archivo de Imagen]
    B --> C[Aplicar Reducción de Ruido]
    C --> D[Aplicar Mejora de Contraste]
    D --> E[Aplicar Deskew Rotación]
    E --> F{Aplicar Super-Resolución}
    F -->|Sí| G[Remuestrear usando EDSR ESPCN FSRCNN]
    F -->|No| H[Proceder con Imagen Mejorada]
    G --> H
    H --> I[Clasificar Tipo y Calidad de Imagen]
    I --> J[Guardar en Carpeta enhanced]
    J --> K[Actualizar Metadata]
    K --> L[Registrar Resultados]
    L --> M[Listo para S3]
```

#### Implementación Técnica

| Paso | Script | Acción Técnica | Entrada | Salida | Configuración |
|------|--------|----------------|---------|--------|---------------|
| 1 | S2_preprocessing_images.py | Cargar imágenes | Archivos de imagen | Arrays de imagen | process_data/current_run/<file_id>/images/ |
| 2 | S2_preprocessing_images.py | Aplicar reducción de ruido | Imagen cruda | Imagen sin ruido | Configuración de algoritmo |
| 3 | S2_preprocessing_images.py | Mejorar contraste y brillo | Imagen | Imagen mejorada | Parámetros de contraste/brillo |
| 4 | S2_preprocessing_images.py | Aplicar deskew | Imagen | Imagen enderezada | Algoritmo de detección de rotación |
| 5 | S2_preprocessing_images.py | Aplicar super-resolución | Imagen | Imagen remuestreada | SR_MODELS/ (EDSR/ESPCN/FSRCNN) |
| 6 | S2_preprocessing_images.py | Clasificar imagen | Imagen | Tipo y calidad | Modelo de clasificación |
| 7 | S2_preprocessing_images.py | Guardar imágenes mejoradas | Imagen procesada | PNG mejorado | Carpeta enhanced/ |

#### Convenciones de Nombres y Rutas

- **Entrada**: `process_data/current_run/<file_id>/images/{image_id}.png`
- **Salida Mejorada**: `process_data/current_run/<file_id>/enhanced/{image_id}_enhanced.png`
- **Logs**: `output/_logs/S2_{fecha}_{hora}.log`

#### Procedimientos de Recuperación

- **Falla en mejora**: Saltar imagen, registrar error, notificar interesados
- **Modelo super-resolución faltante**: Desactivar remuestreo en config, reintentar con mejora estándar
- **Calidad de imagen demasiado baja**: Mover a carpeta `manual_review/` para evaluación humana
- **Falla en actualización de metadata**: Actualizar manualmente `files_metadata.json`

#### Seguridad y Cumplimiento

- Todo procesamiento de imagen registrado
- Imágenes mejoradas almacenadas con acceso restringido en `process_data/`
- No hay PII visible en logs de preprocesamiento (solo nombres de archivos)

---

### Estado 4: S4_PIIOrchestrator - Extracción de Texto OCR & Detección Multi-Método de PII

**Propósito de Negocio**: Extrae texto de imágenes mejoradas usando OCR Tesseract, aplica múltiples métodos de detección de PII (regex, spaCy NER, ensamble de transformers), valida resultados con protección de dos capas, y genera reportes de cumplimiento.

**Frecuencia de Ejecución**: Después de que S2 completa (típicamente inmediatamente en misma ejecución del pipeline).

**Dueño de Negocio**: Cumplimiento/Riesgos
**Dueño Técnico**: Equipo de Automatización

**Última Actualización**: 27 de Noviembre de 2025 - Documentación Correcta del Índice de Estado

**Nivel Crítico**: CRÍTICO
**Impacto de Recuperación**: Fallos en OCR/PII afectan directamente reportes de cumplimiento y protección de datos.

#### Historia Técnica Completa

- **Qué hace**: Ejecuta Tesseract OCR en imágenes mejoradas, ejecuta detección de PII en paralelo usando patrones regex + modelos spaCy + ensamble de Transformers + análisis semántico, valida resultados con protección de dos capas para eliminar falsos positivos, y genera reportes Excel/JSON integrales con puntuaciones de confianza y auditoría completa
- **Cómo funciona**:
  - Lee imágenes mejoradas de `process_data/current_run/<file_id>/enhanced/`
  - Extrae texto usando Tesseract OCR con configuración de idioma (español "spa")
  - Ejecuta métodos de detección en paralelo:
    - **Detección Regex** (`S3_regex_pii.py`): Encuentra PII estructurado (RUT, teléfono, email, URLs)
    - **Detección spaCy NER** (`S3_ml_ner.py`): Usa modelos spaCy para reconocimiento de entidades nombradas (Persona, Organización, Ubicación)
    - **Ensamble de Transformers** (`S3_transformer_pii.py`): Usa modelos multilingües basados en BERT para detección robusta de entidades
    - **Análisis Semántico**: Sentence Transformers validan adecuación contextual (p.ej., extracción de nombre de tablas vs. cuerpo de texto)
  - Aplica validación de dos capas:
    - **Capa Validación Regex**: Requisito estricto 2-4 palabras, rechaza falsos positivos de palabra única, filtra términos empresariales
    - **Capa Validación ML**: Validación consciente del contexto, verifica puntuaciones de confianza, adecuación semántica
  - Fusiona resultados usando estrategia configurada (union, intersection, ml_priority, regex_priority)
  - Desduplica entidades superpuestas
  - Clasifica entidades por tipo y nivel de sensibilidad
  - Genera reporte Excel con análisis detallado
  - Crea resumen JSON con estadísticas
- **De dónde vienen los datos**: Imágenes mejoradas de S2 en `process_data/current_run/<file_id>/enhanced/`
- **A dónde van los resultados**:
  - Reporte Excel: `output/_others/OCR_PII_Analysis_HYBRID_{timestamp}.xlsx`
  - Resumen JSON: `process_data/S3_hybrid_summary.json`
  - Metadata Actualizada: `output/_others/files_metadata.json` (workflow_stage = "completed")
  - Logs: `output/_logs/S4_*.log`
- **Cuándo corre**: Después de finalizar S2
- **A quién afecta**: Cumplimiento, auditoría, riesgos, ejecutivos

#### Flujo de Detección Multi-Método

```mermaid
flowchart TD
    A[Imágenes Mejoradas de S2] --> B[S4 PII Orchestrator]
    B --> C[Extracción de Texto con Tesseract OCR]
    C --> D[Métodos de Detección en Paralelo]
    
    D --> E[S3_regex_pii Detección Basada en Patrones]
    D --> F[S3_ml_ner Detección spaCy NER]
    D --> G[S3_transformer_pii Ensamble de Transformers]
    
    E --> H[Capa Validación Regex validate_enhanced_name]
    F --> I[Capa Validación spaCy spacy_is_valid_person]
    G --> J[Validación Transformers Análisis Semántico del Contexto]
    
    H -->|Válido| K[Entidades Regex Confianza 0.7-0.9]
    I -->|Válido| L[Entidades spaCy Confianza 0.6-0.95]
    J -->|Válido| M[Entidades Transformers Confianza 0.75+]
    
    H -->|Inválido| N[Rechazado Debug Registrado]
    I -->|Inválido| N
    J -->|Inválido| N
    
    K --> O[Proceso Fusión Híbrida Union Intersection ML-Priority]
    L --> O
    M --> O
    
    O --> P[Deduplicación Eliminar Superposiciones]
    P --> Q[Clasificación de Entidades Persona RUT Teléfono Email etc]
    Q --> R[Reporte Excel OCR_PII_Analysis_HYBRID]
    R --> S[Resumen JSON S3_hybrid_summary.json]
    S --> T[Registro y Notificaciones]
```

#### Métodos de Detección & Validación Profunda

**Detección Regex** (`S3_regex_pii.py`):
- Patrones estructurados: Números RUT (12.345.678-9), teléfonos, direcciones email, URLs
- Patrones nombres: 2-4 palabras, reglas de capitalización, sin términos empresariales
- Validación estricta: Rechaza adverbios, términos organizacionales, palabras únicas
- Confianza: 0.7-0.9 (precisión alta, posibles falsos negativos)

**Detección spaCy NER** (`S3_ml_ner.py`):
- Usa modelos spaCy entrenados de `model_spacy/`
- Tipos de entidades: PERSON, ORG, LOCATION, MISC
- Reconocimiento de entidades nombradas consciente del contexto
- Confianza: 0.6-0.95 (dependiente del contexto)

**Ensamble de Transformers** (`S3_transformer_pii.py`):

- Modelos multilingües BERT (`sentence-transformers/distiluse-base-multilingual-cased-v2`)
- Votación multi-modelo para predicciones robustas
- Votación ponderada de múltiples arquitecturas de transformers
- Análisis semántico del contexto usando similitud de embeddings
- Reclasificación de Organización vs. Persona
- Confianza: 0.75+ después de votación del ensamble

**Validación de Dos Capas**:
1. **Validación Regex** (`_validate_enhanced_name`):
   - Mínimo 2 palabras, máximo 4 palabras
   - Cada palabra 3+ caracteres (excepto conectores: de, del, la, y, e, van, von)
   - Debe contener 2+ palabras de nombre válidas
   - Filtra 25+ términos empresariales/adverbios problemáticos
   - Verifica similitud del nombre a nombres/apellidos españoles comunes

2. **Validación ML** (`is_valid_person_name`):
   - Rechaza absolutamente entidades de palabra única
   - Análisis de embedding de frase consciente del contexto
   - Detección de estructura de tablas (nombres en tablas vs. cuerpo de texto)
   - Puntuación de similitud semántica
   - Umbrales de confianza aplicados

**Estrategias de Fusión Híbrida**:
- **union**: Todas las entidades de ambos métodos (cobertura máxima, posibles falsos positivos)
- **intersection**: Solo entidades encontradas por ambos métodos (precisión máxima, posibles falsos negativos)
- **ml_priority**: Prefiere resultados ML, agrega descubrimientos regex (equilibrado, recomendado)
- **regex_priority**: Prefiere resultados regex, agrega descubrimientos ML (enfocado en rendimiento)

#### Implementación Técnica

| Paso | Script/Método | Acción Técnica | Entrada | Salida | Configuración |
|------|---------------|----------------|---------|--------|---------------|
| 1 | S4_pii_orchestrator.py | Inicializar detección híbrida | Imágenes mejoradas | Configuración de detección | config.jsonc |
| 2 | Tesseract OCR | Extracción de texto | Archivos de imagen | Datos de texto | TESSERACT_CONFIG en config |
| 3 | S3_regex_pii.py | Detección basada en patrones | Datos de texto | Entidades regex | Definiciones PIIPatterns |
| 4 | S3_ml_ner.py | Detección spaCy NER | Datos de texto | Entidades spaCy | Modelos en model_spacy/ |
| 5 | S3_transformer_pii.py | Ensamble de transformers | Datos de texto | Entidades de transformers | Modelos HF en models/ |
| 6 | _validate_enhanced_name() | Capa validación regex | Candidatos de nombre | Entidades regex validadas | Reglas de validación |
| 7 | is_valid_person_name() | Capa validación ML | Candidatos de nombre | Entidades ML validadas | Umbrales de confianza |
| 8 | Análisis Semántico | Validación de contexto | Entidades + texto | Entidades contexto-válidas | Sentence transformers |
| 9 | _merge_detection_results() | Fusión híbrida | Ambos conjuntos de entidades | Entidades combinadas | HYBRID_MERGE_STRATEGY |
| 10 | Deduplicación | Eliminar superposiciones | Entidades combinadas | Entidades únicas | Emparejamiento basado en posición |
| 11 | Clasificación | Asignación de tipo de entidad | Entidades | Entidades clasificadas | Mapeos de tipo PII |
| 12 | Generación Excel | Creación de reporte | Todos los resultados | Archivo XLSX | output/_others/ |
| 13 | Resumen JSON | Generación de estadísticas | Todos los resultados | Resumen JSON | process_data/ |

#### Convenciones de Nombres y Rutas

- **Imágenes de Entrada**: `process_data/current_run/<file_id>/enhanced/{image_id}_enhanced.png`
- **Reporte Excel de Salida**: `output/_others/OCR_PII_Analysis_HYBRID_{timestamp}.xlsx`
- **Resumen JSON de Salida**: `process_data/S3_hybrid_summary.json`
- **Metadata Actualizada**: `output/_others/files_metadata.json` (workflow_stage = "completed")
- **Logs**: `output/_logs/S4_{fecha}_{hora}.log`

#### Estructura de Reporte Excel

El archivo Excel generado incluye múltiples hojas:

1. **Resumen**: Estadísticas generales (total entidades, por tipo, distribución confianza)
2. **Todas las Entidades**: Lista detallada de PII detectado con fuente, confianza, estado validación
3. **Personas**: Nombres de personas con confianza, método fuente, estado validación
4. **Números RUT**: Formato RUT chileno con validación
5. **Información de Contacto**: Teléfonos y direcciones email
6. **Metadata**: Información de archivo, marcas de tiempo procesamiento, configuración detección
7. **Log Validación**: Entidades rechazadas durante validación con razones

#### Configuración (config.jsonc)

```jsonc
{
  "DETECTION_METHOD": "hybrid",
  "HYBRID_MERGE_STRATEGY": "union",
  "ENABLE_PARALLEL_DETECTION": false,
  "TRANSFORMER_CONFIG": {
    "enabled": true,
    "models": [
      "xlm-roberta-base",
      "distilbert-base-multilingual-cased",
      "bert-base-multilingual-cased"
    ],
    "voting_strategy": "weighted",
    "confidence_threshold": 0.75
  },
  "TESSERACT_CONFIG": "--oem 3 --psm 6",
  "OCR_LOW_CONF_THRESHOLD": 45,
  "PERSON_MIN_CONF": 0.75
}
```

#### Procedimientos de Recuperación

- **Falla en OCR**: Registrar error, saltar imagen, notificar interesados
- **Falla en método de detección**: Retroceder a método único, registrar advertencia
- **Falla en validación de entidad**: Registrar para revisión manual, escalar si es crítico
- **Falla en generación de reporte**: Guardar salida JSON bruta, investigar problemas de librería Excel
- **Falla en actualización de metadata**: Actualizar manualmente `files_metadata.json`

#### Consideraciones de Rendimiento

- **Detección en Paralelo**: Habilitar cuando se procesan documentos grandes para acelerar detección híbrida
- **Caché de Modelos**: Modelos de transformers cacheados en memoria para procesamiento por lotes
- **Uso de Memoria**: Planificar ~2-3GB RAM para modelos de transformers cargados
- **Tiempo de Procesamiento**: Documento típico: 30-60 segundos para ejecución S3 completa

#### Seguridad y Cumplimiento

- Todo detecting de PII registrado para auditoría
- Reportes almacenados de forma segura en `output/_others/` con acceso restringido
- Datos sensibles nunca registrados en texto plano (hasheados cuando sea necesario)
- Metadata incluye método detección y confianza para trazabilidad
- Notificaciones email enmascaran campos de datos sensibles

---

## Proceso: Coordinación del Pipeline Maestro (main.py)

**Propósito de Negocio**: Orquesta los cuatro estados, gestiona transiciones de estado, maneja excepciones y proporciona coordinación integral del pipeline.

**Frecuencia de Ejecución**: Disparo manual o activación programada.

**Dueño de Negocio**: Cumplimiento/Operaciones
**Dueño Técnico**: Equipo de Automatización

**Nivel Crítico**: CRÍTICO

#### Arquitectura de Ejecución Basada en Estados

La clase `MainProcess` en `main.py` implementa un patrón de máquina de estados:

```python
if self.state_idx == 1:
    self.current_workflow = S00ChangeDetectorBackup(self._config)
    print(f'Primer State')
elif self.state_idx == 2:
    self.current_workflow = S1_FileOrganizer(self._config)
    print(f'Segundo State')
elif self.state_idx == 3:
    self.current_workflow = S2_ImagePreprocessor(self._config)
    print(f'Tercer State')
elif self.state_idx == 4:
    self.current_workflow = S4PIIOrchestrator(self._config)
    print(f'Cuarto State')
else:
    self._running = False
```

#### Diagrama de Flujo de Ejecución del Pipeline

```mermaid
flowchart LR
  Runner[Runner Scheduler] --> S00[S00_ChangeDetectorBackup detección respaldo metadata]
  S00 -->|si hay cambios o nuevo archivo| S1[S1_FileOrganizer normalizar mover]
  S00 -->|sin cambios| EndNoChange[Fin sin cambios]
  S1 --> S2[S2_ImagePreprocessor artefactos listos para OCR]
  S2 --> S4[S4PIIOrchestrator OCR NER PII reportes]
  S4 --> Reports[Reportes JSON Excel Email]
  S4 --> Archive[Archivado Regional Hub]
```

#### Manejo de Errores & Recuperación

**Mecanismo de Reintentos**:
- Máximo de reintentos: `MAX_TRIES` en config (predeterminado: 2)
- En falla: Incrementa contador `state_idx`, permanece en mismo estado
- Después máximo reintentos: Registra estado fallido, envía email excepción, marca estado pipeline como "FAILED" o "WARNING"

**Tipos de Excepción**:
1. **BusinessException**: Errores de negocio esperados (archivo no encontrado, validación falló)
   - Estado: WARNING
   - Acción: Enviar email excepción negocio, salir del pipeline
2. **SystemException**: Errores inesperados del sistema (falla librería, recursos del sistema)
   - Estado: FAILED
   - Acción: Enviar email excepción del sistema con traceback, intentar recuperación

**Notificación de Excepción**:
- Llama método `notify_exception()`
- Construye dataframe de traceback con información archivo/línea/función
- Envía email detallado usando utilidad `ExceptionEmails`
- Incluye detalles de configuración y entorno para depuración

#### Rastreo de Tiempo de Ejecución

- Inicio del pipeline: `t1 = time.time()`
- Fin del pipeline: Registra tiempo transcurrido total como `datetime.timedelta`
- Tiempo por estado: Cada estado registra mensajes inicio/fin para análisis de rendimiento

---

## Estructura de Salida

### Reportes Excel (OCR_PII_Analysis_HYBRID_*.xlsx)

**Múltiples hojas con análisis detallado de PII:**

- **Resumen**: Total entidades, por tipo, distribución confianza
- **Todas las Entidades**: Lista completa de entidades con puntuaciones confianza
- **Personas**: Nombres de personas con estado validación
- **Números RUT**: Validación formato RUT chileno
- **Información de Contacto**: Teléfonos y correos electrónicos
- **Metadata**: Info archivo, tiempos procesamiento, configuración usada
- **Log Validación**: Entidades rechazadas con razones

### Resúmenes JSON

- **files_metadata.json**: Metadata completa para todos archivos (interfaz primaria para sistemas posteriores)
- **S3_hybrid_summary.json**: Estadísticas detección PII y métricas rendimiento del método
- **backup_reports/**: Reportes de éxito/falla de respaldo por sitio

### Logs

- **S0_change_detector_backup_*.log**: Operaciones detección de archivos y respaldo
- **S1_fileorganizer_*.log**: Organización de archivos y extracción de imágenes
- **S2_imagepreprocessor_*.log**: Operaciones mejora de imágenes
- **S3_orchestrator_*.log**: Detalles OCR y detección de PII
- **OP01_*.log**: Log ejecución del pipeline maestro

### Notificaciones por Email

Actualizaciones automáticas de interesados usando plantillas en `input/email_files/`:
- Notificación inicio ejecución
- Resumen éxito con conteos de entidades
- Alertas falla con detalles error
- Notificaciones escalación para errores críticos

---

## Evaluación de Riesgos & Mitigación

| Proceso | Nivel de Riesgo | Impacto de Falla | Mitigación Actual | Acción Recomendada |
|---------|-----------------|------------------|------------------|--------------------|
| S00: Detección Archivos | Medio | Archivos no detectados, pipeline bloqueado | Logging, revisión manual, lógica reintentos | Monitorear estado sincronización SharePoint regularmente |
| S1: Organización Archivos | Medio | Imágenes no extraídas, S2-S3 bloqueados | Logging de error, notificación | Validar extracción de imágenes en pruebas |
| S2: Preprocesamiento Imágenes | Medio | Baja calidad OCR, falla detección PII | Logging, saltar en error | Ajuste algoritmos mejora |
| S4: OCR y Detección PII | Alto | PII perdido, incumplimiento normativo | Detección multi-método, validación dual | Agregar revisión manual para documentos alto-valor |
| Coordinación Maestro | Alto | Falla pipeline completo | Manejo excepciones, alertas email | Implementar scripts recuperación automática |
| Notificación Email | Medio | Interesados desinformados | Lógica reintentos, logging | Monitorear conectividad SMTP |

---

## Consejos de Ajuste Operacional

- **Programar S00** con cadencia equilibrando latencia vs. costo de escaneo (típico: cada 5-60 minutos)
- **Desactivar hashing en S00** si entorno tiene muchos archivos grandes para reducir CPU
- **Paralelizar procesamiento S4** por file_id usando pool de hilos/procesos
- **Cachear modelos de transformers** a través del procesamiento por lotes para reducir memoria
- **Monitorear confianza OCR**; ajustar umbral basado en tasas falso positivo/negativo
- **Ajustar umbrales validación** en estrategia fusión híbrida basado en sus datos

---

## Lista Rápida de Verificación Después de Ejecución del Pipeline

- [ ] `output/_others/files_metadata.json` existe y contiene entradas para archivos modificados
- [ ] `output/backup_reports/backup_summary_*.json` muestra respaldos exitosos por sitio
- [ ] `input/_file_input/` contiene copias esperadas de archivos compatibles con OCR
- [ ] `process_data/current_run/` contiene carpetas organizadas con imágenes y versiones mejoradas
- [ ] `output/_others/OCR_PII_Analysis_HYBRID_*.xlsx` contiene reporte final de PII
- [ ] `output/_logs/` contiene logs para los cuatro estados
- [ ] Notificaciones email enviadas exitosamente a destinatarios configurados
- [ ] `process_data/S3_hybrid_summary.json` contiene estadísticas detección

---

## Apéndice: Información de Modelos & Recursos

### Modelos de Transformers Disponibles

- **distiluse-base-multilingual-cased-v2**: Soporte español+multilingüe, inferencia rápida
- **xlm-roberta-base**: Multilingüe robusto, bueno para español
- **distilbert-base-multilingual-cased**: Variante BERT rápida, multilingüe

### Modelos Super-Resolución

Ubicados en `SR_MODELS/`:
- **EDSR**: Remuestreo alta calidad (×2, ×3, ×4)
- **ESPCN**: Convolución eficiente de píxeles sub
- **FSRCNN**: CNN super-resolución rápida

### Motor de OCR

- **Tesseract**: OCR de código abierto estándar industria
- **Config**: `--oem 3 --psm 6` (predeterminado para páginas documento)
- **Idioma**: Español ("spa") configurado en config.jsonc

---

## Soporte & Solución de Problemas

Para problemas o preguntas, consulte:
- Logs detallados en `output/_logs/`
- Referencia configuración: comentarios en `config.jsonc`
- Documentación utilidades: `.github/instructions/utils_index.md`
- Docstrings scripts proceso para información método detallada

