#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3 PII Detection Orchestrator

Coordinates multiple PII detection methods: regex-based, ML-based, or hybrid approach.
Provides flexible detection strategies based on performance requirements.
"""

import os
import sys
import logging
import datetime as dt
import argparse
import pandas as pd
import glob
from datetime import datetime
from openpyxl.utils import get_column_letter
from typing import Dict, Any, List, Optional
from src.utils.send_email_utils import send_email, df2html
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 


from src.utils.fmw_utils import read_config, save_json_file, start_logging


class EmailTemplateManager:
    """Manages HTML email templates for PII reports"""
    
    def __init__(self, template_dir: str = None):
        self.template_dir = template_dir or os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            "input", "email_files"
        )
        
        # Load template configuration
        self.config_path = os.path.join(self.template_dir, "template_config.json")
        self.template_config = self._load_template_config()
        
        logging.info(f"EmailTemplateManager initialized | template_dir={self.template_dir}")
        
    def _load_template_config(self) -> dict:
        """Load template configuration from JSON file"""
        try:
            if os.path.exists(self.config_path):
                import json
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                logging.warning(f"Template config not found: {self.config_path}, using defaults")
                return self._get_default_config()
        except Exception as e:
            logging.error(f"Error loading template config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> dict:
        """Default template configuration if file is missing"""
        return {
            "email_templates": {
                "resume_email": {"template_file": "resume_email_template.html", "css_file": "email_styles.css"},
                "folder_email": {"template_file": "folder_email_template.html", "css_file": "email_styles.css"}
            },
            "risk_level_configs": {
                "RIESGO ALTO": {"css_class": "risk-high", "description": "Alto riesgo PII detectado"},
                "RIESGO MODERADO": {"css_class": "risk-medium", "description": "Riesgo moderado PII"},
                "RIESGO BAJO": {"css_class": "risk-low", "description": "Bajo riesgo PII"}
            }
        }
    
    def load_template(self, template_name: str) -> str:
        """Load HTML template from file"""
        template_config = self.template_config.get("email_templates", {}).get(template_name, {})
        template_file = template_config.get("template_file", f"{template_name}.html")
        template_path = os.path.join(self.template_dir, template_file)
        
        if not os.path.exists(template_path):
            logging.warning(f"Template not found: {template_path}, using fallback")
            return self._get_fallback_template(template_name)
        
        try:
            with open(template_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logging.error(f"Error loading template {template_name}: {e}")
            return self._get_fallback_template(template_name)
    
    def load_css_styles(self) -> str:
        """Load CSS styles from file and escape curly braces for email format compatibility"""
        css_path = os.path.join(self.template_dir, "email_styles.css")
        
        if not os.path.exists(css_path):
            logging.warning(f"CSS file not found: {css_path}, using default styles")
            return self._get_default_css()
        
        try:
            with open(css_path, 'r', encoding='utf-8') as f:
                css_content = f.read()
                # Escape curly braces to prevent issues with .format() in send_email
                css_content = css_content.replace('{', '{{').replace('}', '}}')
                return css_content
        except Exception as e:
            logging.error(f"Error loading CSS styles: {e}")
            return self._get_default_css()
    
    def render_template(self, template_name: str, **kwargs) -> str:
        """Render template with variables using simple string replacement"""
        try:
            # Load template content
            template_content = self.load_template(template_name)
            
            # Load and inject CSS styles
            css_styles = self.load_css_styles()
            template_content = template_content.replace("{{css_styles}}", css_styles)
            
            # Replace all template variables
            for key, value in kwargs.items():
                placeholder = f"{{{{{key}}}}}"
                template_content = template_content.replace(placeholder, str(value))
            
            return template_content
            
        except Exception as e:
            logging.error(f"Error rendering template {template_name}: {e}")
            return self._get_fallback_html(**kwargs)
    
    def get_risk_config(self, risk_level: str) -> dict:
        """Get risk level configuration"""
        return self.template_config.get("risk_level_configs", {}).get(risk_level, {
            "css_class": "risk-medium",
            "description": "Nivel de riesgo no definido",
            "recommendations": []
        })
    
    def generate_recommendations_html(self, risk_level: str) -> str:
        """Generate strategic recommendations HTML based on risk level"""
        risk_config = self.get_risk_config(risk_level)
        recommendations = risk_config.get("recommendations", [])
        
        if not recommendations:
            return ""
        
        recommendation_items = "".join([f"<li>{rec}</li>" for rec in recommendations])
        timeframe = risk_config.get("timeframe", "A determinar")
        priority = risk_config.get("priority", "normal")
        
        return f"""
        <div class="recommendations-section">
            <h3>📋 Recomendaciones Estratégicas</h3>
            <ul class="recommendation-list">
                {recommendation_items}
            </ul>
            <p class="recommendation-meta">
                <strong>Prioridad:</strong> {priority} | 
                <strong>Plazo sugerido:</strong> {timeframe}
            </p>
        </div>
        """
    
    def _get_fallback_template(self, template_name: str) -> str:
        """Simple fallback template if file loading fails"""
        if template_name == "resume_email":
            return self._get_simple_resume_template()
        elif template_name == "folder_email":
            return self._get_simple_folder_template()
        else:
            return self._get_simple_resume_template()
    
    def _get_simple_resume_template(self) -> str:
        """Simple fallback resume template"""
        return """
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
            <h1>🛡️ INFORME EJECUTIVO DE RIESGOS PII</h1>
            <p><strong>Fecha:</strong> {{timestamp}}</p>
            <p><strong>Archivos analizados:</strong> {{total_files}}</p>
            <p><strong>Archivos con PII:</strong> {{files_with_pii}}</p>
            <p><strong>Total detecciones:</strong> {{total_detections}}</p>
            <p><strong>Nivel de riesgo:</strong> {{risk_level_label}}</p>
            <div>{{strategic_recommendations}}</div>
        </body>
        </html>
        """
    
    def _get_simple_folder_template(self) -> str:
        """Simple fallback folder template"""
        return """
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
            <h1>📁 REPORTE PII POR CARPETA</h1>
            <p><strong>Carpeta:</strong> {{folder_name}}</p>
            <p><strong>Archivos en carpeta:</strong> {{folder_total_files}}</p>
            <p><strong>Con PII:</strong> {{folder_files_with_pii}}</p>
        </body>
        </html>
        """
    
    def _get_default_css(self) -> str:
        """Basic default CSS if file loading fails - with escaped braces for email compatibility"""
        return """
        body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; }}
        .header {{ background: #1e3c72; color: white; padding: 20px; text-align: center; }}
        .kpi-table {{ width: 100%; margin: 20px 0; }}
        .kpi-value {{ font-size: 24px; font-weight: bold; }}
        .risk-high {{ color: #721c24; }}
        .risk-medium {{ color: #856404; }}
        .risk-low {{ color: #155724; }}
        """
    
    def _get_fallback_html(self, **kwargs) -> str:
        """Emergency fallback HTML if everything fails"""
        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
            <h1>Error en Template</h1>
            <p>No se pudo cargar la plantilla correctamente.</p>
            <h3>Datos del reporte:</h3>
            <ul>
                {"".join([f"<li><strong>{k}:</strong> {v}</li>" for k, v in kwargs.items()])}
            </ul>
        </body>
        </html>
        """


class S3PIIOrchestrator:
    """
    Orchestrates PII detection using different methods:
    - 'regex': Fast regex-only detection 
    - 'ml': Comprehensive ML-based detection (spaCy + transformers)
    - 'hybrid': Run both methods and compare/merge results
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config = config or read_config()
        self.config_env = self.config.get("ENVIRONMENT", {})
        
        # Detection method configuration
        self.detection_method = self.config_env.get("DETECTION_METHOD", "hybrid").lower()
        
        # Performance settings
        self.enable_parallel = bool(self.config_env.get("ENABLE_PARALLEL_DETECTION", False))
        self.hybrid_merge_strategy = self.config_env.get("HYBRID_MERGE_STRATEGY", "union")  # union, intersection, ml_priority
        
        # Email configuration - hardcoded defaults, no config.jsonc dependency
        self.send_email_on_completion = True  # Set to True to enable email functionality
        self.email_recipients_file = "input/_recipients.xlsx"
        
        # PII filtering for email reports - exclude sensitive/low-value PII types
        self.email_excluded_pii_types = {
            "MISC", "LOC", "ORG", "ContextualPersonName", 
            "Address_Keywords", "Sex", "Health"
        }
        
        # Directories
        self.input_dir = self.config_env.get("INPUT_PATH", "input/_file_input")
        self.output_dir = self.config_env.get("OUTPUT_PATH", "output")
        self.process_data_dir = self.config_env.get("PROCESS_DATA_PATH", "process_data")
        
        # Initialize detector instances
        self._regex_detector = None
        self._ml_detector = None
        
        # Initialize template manager
        self.template_manager = EmailTemplateManager()
        
        logging.info(
            f"S3PIIOrchestrator initialized | "
            f"method={self.detection_method} | "
            f"hybrid_strategy={self.hybrid_merge_strategy} | "
            f"parallel={self.enable_parallel} | "
            f"email_enabled={self.send_email_on_completion}"
        )

    def _get_regex_detector(self):
        """Lazy initialization of regex detector"""
        if self._regex_detector is None:
            from src.process_scripts.S3_regex_pii import S3_RegexPII
            self._regex_detector = S3_RegexPII(config=self.config)
        return self._regex_detector

    def _get_ml_detector(self):
        """Lazy initialization of ML detector"""  
        if self._ml_detector is None:
            from src.process_scripts.S3_ml_ner import S3_MachineLearningNER
            self._ml_detector = S3_MachineLearningNER(config=self.config)
        return self._ml_detector

    def _estimate_data_volume(self) -> Dict[str, Any]:
        """Estimate the volume of data to be processed"""
        stats = {
            "total_files": 0,
            "total_size_mb": 0.0,
            "image_files": 0,
            "text_files": 0,
            "pdf_files": 0,
            "folders": 0
        }
        
        try:
            input_path = os.path.abspath(self.input_dir)
            if not os.path.exists(input_path):
                logging.warning(f"Input directory not found: {input_path}")
                return stats
            
            for root, dirs, files in os.walk(input_path):
                # Count folders
                stats["folders"] += len(dirs)
                
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        file_size = os.path.getsize(file_path)
                        stats["total_size_mb"] += file_size / (1024 * 1024)
                        stats["total_files"] += 1
                        
                        # Categorize by extension
                        ext = os.path.splitext(file)[1].lower()
                        if ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                            stats["image_files"] += 1
                        elif ext in ['.txt', '.md', '.log']:
                            stats["text_files"] += 1
                        elif ext == '.pdf':
                            stats["pdf_files"] += 1
                            
                    except (OSError, IOError) as e:
                        logging.warning(f"Could not get size for {file_path}: {e}")
                        
        except Exception as e:
            logging.error(f"Error estimating data volume: {e}")
            
        return stats

    def _merge_detection_results(self, regex_results: List[Dict[str, Any]], 
                                ml_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Merge results from regex and ML detectors based on strategy"""
        
        if self.hybrid_merge_strategy == "union":
            # Simple union of all results
            from src.utils.pii_utils import EntityUtils
            all_results = regex_results + ml_results
            return EntityUtils.dedupe_entities(all_results)
        
        elif self.hybrid_merge_strategy == "intersection":
            # Only include entities found by both methods
            from src.utils.pii_utils import EntityUtils
            
            regex_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in regex_results}
            ml_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in ml_results}
            common_values = regex_values & ml_values
            
            results = []
            for result in regex_results + ml_results:
                norm_value = EntityUtils._norm_value_for_key(result.get("PII_Value", ""))
                if norm_value in common_values:
                    results.append(result)
            
            return EntityUtils.dedupe_entities(results)
        
        elif self.hybrid_merge_strategy == "ml_priority":
            # Prefer ML results, supplement with regex-only findings
            from src.utils.pii_utils import EntityUtils
            
            ml_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in ml_results}
            
            results = list(ml_results)  # Start with all ML results
            
            # Add regex results that weren't found by ML
            for result in regex_results:
                norm_value = EntityUtils._norm_value_for_key(result.get("PII_Value", ""))
                if norm_value not in ml_values:
                    results.append(result)
            
            return EntityUtils.dedupe_entities(results)
        
        else:
            logging.warning(f"Unknown merge strategy: {self.hybrid_merge_strategy}, using union")
            return self._merge_detection_results(regex_results, ml_results)

    def _run_single_method(self, method: str) -> bool:
        """Run a single detection method"""
        try:
            if method == "regex":
                detector = self._get_regex_detector()
                logging.info("Running regex-based PII detection...")
                success = detector.run_flow()
                
                if success and self.send_email_on_completion:
                    # Find the generated Excel file
                    excel_files = [f for f in os.listdir(self.output_dir) 
                                 if f.startswith("OCR_PII_Analysis_REGEX") and f.endswith(".xlsx")]
                    if excel_files:
                        excel_path = os.path.join(self.output_dir, sorted(excel_files)[-1])
                        self._create_user_email_report(excel_path)
                
                return success
                
            elif method == "ml":
                detector = self._get_ml_detector()
                logging.info("Running ML-based PII detection...")
                success = detector.run_flow()
                
                if success and self.send_email_on_completion:
                    # Find the generated Excel file
                    excel_files = [f for f in os.listdir(self.output_dir) 
                                 if f.startswith("OCR_PII_Analysis_ML") and f.endswith(".xlsx")]
                    if excel_files:
                        excel_path = os.path.join(self.output_dir, sorted(excel_files)[-1])
                        self._create_user_email_report(excel_path)
                
                return success
                
            else:
                logging.error(f"Unknown detection method: {method}")
                return False
                
        except Exception as e:
            logging.error(f"Error running {method} detection: {e}")
            return False

    def _run_hybrid_method(self) -> bool:
        """Run both detection methods and merge results"""
        try:
            logging.info("Running hybrid PII detection (regex + ML)...")
            
            if self.enable_parallel:
                # TODO: Implement parallel execution
                logging.warning("Parallel execution not yet implemented, running sequentially")
            
            # Collect results from regex detection without generating Excel
            regex_detector = self._get_regex_detector()
            logging.info("Phase 1/2: Collecting regex detection results...")
            regex_results = regex_detector.collect_pii_results("regex")
            
            if not regex_results:
                logging.warning("No results from regex detection")
            else:
                logging.info(f"Regex detection found {len(regex_results)} PII entities")
            
            # Collect results from ML detection without generating Excel
            ml_detector = self._get_ml_detector()
            logging.info("Phase 2/2: Collecting ML detection results...")
            ml_results = ml_detector.collect_pii_results("ml")
            
            if not ml_results:
                logging.warning("No results from ML detection")
            else:
                logging.info(f"ML detection found {len(ml_results)} PII entities")
            
            # If neither method found anything, return False
            if not regex_results and not ml_results:
                logging.error("No PII entities found by either detection method")
                return False
            
            # Merge results according to configured strategy
            logging.info(f"Merging results using strategy: {self.hybrid_merge_strategy}")
            combined_results = self._merge_detection_results(regex_results, ml_results)
            logging.info(f"Combined results: {len(combined_results)} PII entities after {self.hybrid_merge_strategy} merge")
            
            # Generate single Excel report with combined results
            logging.info("Generating hybrid Excel report...")
            excel_path = self.create_hybrid_excel_report(
                regex_results, ml_results, combined_results, self.hybrid_merge_strategy
            )
            
            if not excel_path:
                logging.error("Failed to generate hybrid Excel report")
                return False
            
            # Generate hybrid summary JSON
            self._generate_hybrid_summary_json(regex_results, ml_results, combined_results)
            
            # Send user email with simplified report
            if self.send_email_on_completion:
                email_success = self._create_user_email_report(excel_path)
                if not email_success:
                    logging.warning("Main report generated successfully but email sending failed")
            
            # Send resume email with files_metadata.xlsx integration
            resume_email_success = self._send_resume_email()
            if not resume_email_success:
                logging.warning("Resume email sending failed, but main process completed successfully")
            
            logging.info("Hybrid detection completed successfully - single combined report generated")
            return True
            
        except Exception as e:
            logging.error(f"Error running hybrid detection: {e}")
            return False

    def _generate_hybrid_summary_json(self, regex_results: List[Dict[str, Any]], 
                                       ml_results: List[Dict[str, Any]], 
                                       combined_results: List[Dict[str, Any]]) -> None:
        """Generate a summary JSON comparing both detection methods with actual results"""
        try:
            # Analyze results by detection method
            regex_count = len(regex_results)
            ml_count = len(ml_results)
            combined_count = len(combined_results)
            
            # Count unique entities (entities that appear in both methods)
            regex_values = {f"{r.get('PII_Type', '')}_{r.get('PII_Value', '')}" for r in regex_results}
            ml_values = {f"{m.get('PII_Type', '')}_{m.get('PII_Value', '')}" for m in ml_results}
            common_entities = len(regex_values & ml_values)
            
            # Count by PII type
            regex_types = {}
            ml_types = {}
            combined_types = {}
            
            for result in regex_results:
                pii_type = result.get('PII_Type', 'Unknown')
                regex_types[pii_type] = regex_types.get(pii_type, 0) + 1
            
            for result in ml_results:
                pii_type = result.get('PII_Type', 'Unknown')
                ml_types[pii_type] = ml_types.get(pii_type, 0) + 1
                
            for result in combined_results:
                pii_type = result.get('PII_Type', 'Unknown')
                combined_types[pii_type] = combined_types.get(pii_type, 0) + 1
            
            summary = {
                "orchestrator": "S3PIIOrchestrator",
                "detection_mode": "hybrid",
                "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "merge_strategy": self.hybrid_merge_strategy,
                "results_summary": {
                    "regex_entities_found": regex_count,
                    "ml_entities_found": ml_count,
                    "combined_entities_final": combined_count,
                    "common_entities_both_methods": common_entities,
                    "regex_only_entities": regex_count - common_entities if common_entities <= regex_count else 0,
                    "ml_only_entities": ml_count - common_entities if common_entities <= ml_count else 0
                },
                "pii_type_breakdown": {
                    "regex_types": regex_types,
                    "ml_types": ml_types,
                    "combined_types": combined_types
                },
                "detection_methods": {
                    "regex_detection": {
                        "completed": True,
                        "method": "pattern_matching",
                        "entities_found": regex_count
                    },
                    "ml_detection": {
                        "completed": True,
                        "method": "machine_learning",
                        "entities_found": ml_count
                    }
                },
                "data_volume": self._estimate_data_volume(),
                "output_directory": self.output_dir,
                "excel_report_generated": True,
                "excel_report_type": "single_hybrid_file"
            }
            
            # Save hybrid summary
            summary_path = os.path.join(self.process_data_dir, "S3_hybrid_summary.json")
            save_json_file(summary, summary_path)
            logging.info(f"Hybrid detection summary saved to: {summary_path}")
            logging.info(f"Summary: Regex={regex_count}, ML={ml_count}, Combined={combined_count}, Common={common_entities}")
            
        except Exception as e:
            logging.error(f"Error generating hybrid summary JSON: {e}")

    def _generate_hybrid_summary(self, regex_detector, ml_detector) -> None:
        """Legacy method - kept for compatibility"""
        logging.warning("Using legacy _generate_hybrid_summary method - this should be replaced with _generate_hybrid_summary_json")

    def create_hybrid_excel_report(self, regex_results: List[Dict[str, Any]], 
                                   ml_results: List[Dict[str, Any]], 
                                   combined_results: List[Dict[str, Any]], 
                                   merge_strategy: str) -> str:
        """Generate hybrid Excel report with combined results from both detection methods"""
        import pandas as pd
        import datetime as dt
        from src.utils.pii_utils import extract_page_number, get_sensitivity_level
        
        def extract_status_from_folder(folder_name: str) -> str:
            """Extract status from folder name by splitting on '__'"""
            try:
                if not folder_name or folder_name.strip() == "":
                    return "unknown"
                
                # Split by '__' and get the last part
                parts = folder_name.split('__')
                if len(parts) > 1:
                    status = parts[-1].strip()
                    # Clean up common suffixes and normalize
                    if status.lower() in ['modificado', 'nuevo_archivo']:
                        return status.lower()
                    return status
                else:
                    return "sin_cambios"  # No suffix found
            except Exception as e:
                logging.warning(f"Error extracting status from folder '{folder_name}': {e}")
                return "unknown"
            
        def clean_folder_name(folder_name: str) -> str:
            """Clean folder name by removing suffix after '__'"""
            try:
                if not folder_name or folder_name.strip() == "":
                    return folder_name
                
                # Split by '__' and get the first part (clean name)
                parts = folder_name.split('__')
                return parts[0].strip()
                
            except Exception as e:
                logging.warning(f"Error cleaning folder name '{folder_name}': {e}")
                return folder_name
            
        
        try:
            if not combined_results:
                logging.warning("No PII entities to report in hybrid mode")
                return None
            
            # Create Excel rows from combined entities
            pii_rows = []
            for pii_entity in combined_results:
                # Get page number from filename
                filename = pii_entity.get("File_Name", "unknown")
                page_number = extract_page_number(filename)
                sensitivity_level = get_sensitivity_level(pii_entity["PII_Type"])
                
                # Extract status from folder name
                folder_name_raw = pii_entity.get("Folder", "")
                status_file = extract_status_from_folder(folder_name_raw)
                folder_name_clean = clean_folder_name(folder_name_raw)
                
                pii_rows.append({
                    "Report_Generated": dt.datetime.now().strftime("%d-%m-%Y"),  ## New field for report generation date
                    "File": filename,
                    "Folder": folder_name_clean,
                    "Status_file": status_file,
                    "Source_Type": pii_entity.get("Source_Type", "").replace("_", " ").title(),
                    "Page": page_number,
                    "PII_Type": pii_entity["PII_Type"],
                    "PII_Value": pii_entity["PII_Value"],
                    "PII_Length": len(pii_entity["PII_Value"]),
                    "Confidence_Score": pii_entity.get("Confidence", "N/A"),
                    "Detection_Method": pii_entity.get("Detection_Method", "unknown"),
                    "Source": pii_entity.get("Source", ""),
                    "Start_Position": pii_entity.get("start_pos", ""),
                    "End_Position": pii_entity.get("end_pos", ""),
                    "Sensitivity_Level": sensitivity_level,
                    "Pattern": pii_entity.get("pattern", ""),
                    "Label": pii_entity.get("Label", ""),
                    "Original_Text": pii_entity.get("Original_Text", "")[:100] + "..." if len(pii_entity.get("Original_Text", "")) > 100 else pii_entity.get("Original_Text", ""),
                    "Extraction_Confidence": pii_entity.get("Extraction_Confidence", "N/A")
                })
            
            # Create DataFrames
            pii_df = pd.DataFrame(pii_rows)
            
            # Generate summary statistics for hybrid mode
            hybrid_summary = self._generate_hybrid_summary_stats(pii_df, merge_strategy, regex_results, ml_results)
            summary_df = pd.DataFrame([hybrid_summary])
            
            # Generate output filename
            import os
            os.makedirs(self.output_dir, exist_ok=True)
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(self.output_dir, f"OCR_PII_Analysis_HYBRID_{timestamp}.xlsx")
            
            # Create Excel file
            with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
                summary_df.to_excel(writer, sheet_name="Hybrid_Summary", index=False)
                pii_df.to_excel(writer, sheet_name="Combined_PII_Results", index=False)
                
                # Create method breakdown sheets if we have multiple methods
                detection_methods = pii_df["Detection_Method"].unique()
                if len(detection_methods) > 1:
                    for method in detection_methods:
                        method_df = pii_df[pii_df["Detection_Method"] == method]
                        sheet_name = f"{method.upper()}_Results"[:31]  # Excel sheet name limit
                        method_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Format the sheets
                self._format_hybrid_excel_sheets(writer, pii_df, summary_df)
            
            logging.info(f"Hybrid Excel report created: {output_file}")
            logging.info(f"Report contains: {len(pii_df)} PII entities from {len(detection_methods)} detection method(s)")
            logging.info(f"Merge strategy used: {merge_strategy}")
            
            # Log status distribution for debugging
            status_counts = pii_df["Status_file"].value_counts().to_dict()
            logging.info(f"File status distribution: {status_counts}")
            
            return output_file
            
        except Exception as e:
            logging.error(f"Error creating hybrid Excel report: {e}")
            return None

    def _generate_hybrid_summary_stats(self, pii_df, merge_strategy: str, 
                                       regex_results: List[Dict], ml_results: List[Dict]) -> Dict[str, Any]:
        """Generate summary statistics for hybrid mode Excel report"""
        try:
            import datetime as dt
            
            # Count entities by detection method
            method_counts = pii_df["Detection_Method"].value_counts().to_dict()
            
            # Count by PII type
            pii_type_counts = pii_df["PII_Type"].value_counts().to_dict()
            
            # Count by source type
            source_type_counts = pii_df["Source_Type"].value_counts().to_dict()
            
            stats = {
                "Report_Generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Report_Type": "Hybrid Detection Analysis",
                "Merge_Strategy": merge_strategy,
                "Total_PII_Entities": len(pii_df),
                "Unique_Files_Processed": pii_df["File"].nunique(),
                "Detection_Methods_Used": ", ".join(method_counts.keys()),
                "Regex_Entities": len(regex_results),
                "ML_Entities": len(ml_results),
                "Combined_Entities": len(pii_df),
                "Most_Common_PII_Type": max(pii_type_counts.items(), key=lambda x: x[1])[0] if pii_type_counts else "None",
                "Image_OCR_Entities": source_type_counts.get("Image Ocr", 0),
                "Text_File_Entities": source_type_counts.get("Text File", 0),
                "Average_PII_Length": float(pii_df["PII_Length"].mean()) if not pii_df.empty else 0.0,
            }
            
            return stats
            
        except Exception as e:
            logging.error(f"Error generating hybrid summary stats: {e}")
            return {"Error": str(e)}

    def _format_hybrid_excel_sheets(self, writer, pii_df, summary_df):
        """Format the hybrid Excel report sheets"""
        try:
            from openpyxl.styles import Font, PatternFill, Alignment
            
            # Format PII Results sheet
            if "PII_Results" in writer.sheets:
                pii_ws = writer.sheets["PII_Results"]
                
                # Set column widths
                column_widths = {'A': 15, 'B': 20, 'C': 15, 'D': 15, 'E': 15, 'F': 30, 'G': 8, 'H': 15}
                for col, width in column_widths.items():
                    pii_ws.column_dimensions[col].width = width
                
                # Auto-size columns based on content (header + cell max length)
                # Cap widths for readability: min 8, max 50
                if isinstance(pii_df, pd.DataFrame) and not pii_df.empty:
                    for idx, col in enumerate(pii_df.columns, start=1):
                        try:
                            max_cell = max((len(str(v)) for v in pii_df[col].fillna('')), default=0)
                        except Exception:
                            max_cell = 0
                        header_len = len(str(col))
                        calculated = max(header_len, max_cell) + 2  # padding
                        width = max(8, min(50, calculated))
                        col_letter = get_column_letter(idx)
                        pii_ws.column_dimensions[col_letter].width = width
                else:
                    # Fallback sensible defaults if dataframe empty
                    for i, col_letter in enumerate(list("ABCDEFGH"), start=1):
                        pii_ws.column_dimensions[col_letter].width = 15
                
                # Format headers
                # Use dark-blue headers for consistency with folder summary screenshots
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                for cell in pii_ws[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = header_fill_dark_blue
                    cell.alignment = Alignment(horizontal="center")
                
                # Color code by file status (priority) and detection method (secondary)
                status_colors = {
                    "modificado": PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid"),      # Light yellow
                    "nuevo_archivo": PatternFill(start_color="D5E8D4", end_color="D5E8D4", fill_type="solid"),  # Light green
                    "sin_cambios": PatternFill(start_color="F8CECC", end_color="F8CECC", fill_type="solid"),    # Light red
                }
                
                # Apply status coloring if Status_file column exists
                if 'Status_file' in pii_df.columns:
                    status_col_idx = list(pii_df.columns).index('Status_file') + 1  # Excel is 1-indexed
                    
                    for row_idx, row in enumerate(pii_ws.iter_rows(min_row=2, max_row=len(pii_df) + 1), 2):
                        if len(row) > status_col_idx - 1:
                            status_value = str(row[status_col_idx - 1].value).lower() if row[status_col_idx - 1].value else ""
                            fill_color = status_colors.get(status_value)
                            if fill_color:
                                for cell in row:
                                    cell.fill = fill_color
            
            # Format Summary Analysis sheet
            if "Summary_Analysis" in writer.sheets:
                summary_ws = writer.sheets["Summary_Analysis"]
                
                # Set column widths
                summary_ws.column_dimensions['A'].width = 25  # Category
                summary_ws.column_dimensions['B'].width = 30  # Metric
                summary_ws.column_dimensions['C'].width = 15  # Count
                summary_ws.column_dimensions['D'].width = 15  # Percentage
                
                # Format headers
                # Use dark-blue main header and a soft blue for section/category rows
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                category_fill_light = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
                for cell in summary_ws[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = header_fill_dark_blue
                    cell.alignment = Alignment(horizontal="center")
                
                # Format category headers (section rows)
                category_fill = category_fill_light
                for row in summary_ws.iter_rows(min_row=2):
                    if row[0].value and row[0].value.isupper() and not row[1].value:
                        for cell in row:
                            cell.font = Font(bold=True)
                            cell.fill = category_fill
                        for cell in row:
                            cell.font = Font(bold=True)
                            cell.fill = category_fill
                        
        except Exception as e:
            logging.error(f"Error formatting hybrid Excel sheets: {e}")

    def _create_user_email_report(self, excel_file_path: str) -> bool:
        """
        Create and send simplified email reports for end users.
        Sends one email per folder with only files from that folder.
        
        Args:
            excel_file_path (str): Path to the main Excel report file
            
        Returns:
            bool: True if all emails sent successfully, False otherwise
        """
        try:
            logging.info(f"Email functionality called - enabled: {self.send_email_on_completion}")
            if not self.send_email_on_completion:
                logging.info("Email sending is disabled in configuration")
                return True
                
            if not os.path.exists(excel_file_path):
                logging.error(f"Excel file not found: {excel_file_path}")
                return False
            
            # Read the Combined_PII_Results sheet from Excel
            logging.info("Reading Excel file for email report...")
            try:
                pii_df = pd.read_excel(excel_file_path, sheet_name="Combined_PII_Results")
                logging.info(f"Loaded {len(pii_df)} PII entities from Excel")
            except Exception as e:
                logging.error(f"Error reading Excel file: {e}")
                return False
            
            # Filter out excluded PII types for user report
            original_count = len(pii_df)
            filtered_df = pii_df[~pii_df["PII_Type"].isin(self.email_excluded_pii_types)] ## Exclude pii for user report - configurable
            filtered_count = len(filtered_df)
            excluded_count = original_count - filtered_count
            
            logging.info(f"Email filtering: {excluded_count} entities excluded, {filtered_count} included")
            
            if filtered_df.empty:
                logging.warning("No PII entities remain after filtering for email")
                return False
            
            # Get unique folders
            unique_folders = filtered_df['Folder'].unique()
            logging.info(f"Found {len(unique_folders)} unique folders/files to process for emails")
            
            all_emails_sent = True
            
            # Process each folder separately
            for folder_name in unique_folders:
                try:
                    logging.info(f"Processing email for folder: {folder_name}")
                    
                    # Filter data for this specific folder
                    folder_df = filtered_df[filtered_df['Folder'] == folder_name].copy()
                    folder_entity_count = len(folder_df)
                    
                    if folder_df.empty:
                        logging.warning(f"No entities found for folder: {folder_name}")
                        continue
                    
                    # Create folder-specific Excel report
                    folder_excel_path = self._create_folder_specific_excel_report(
                        folder_df, folder_name, excel_file_path
                    )
                    
                    if not folder_excel_path:
                        logging.error(f"Failed to create Excel report for folder: {folder_name}")
                        all_emails_sent = False
                        continue
                    
                    # Generate folder-specific summary statistics
                    folder_summary_stats = self._generate_folder_summary_stats(folder_df, folder_name)
                    
                    # Create summary HTML table for email body
                    summary_html = df2html(folder_summary_stats)
                    
                    # Prepare email content with folder name
                    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    email_filename = os.path.basename(folder_excel_path)
                    
                    # Email subject and body in Spanish with folder name
                    subject = f"Reporte PII - Archivo: '{folder_name}' - {folder_entity_count} Entidades detectadas"
                    

                    body = f"""
                    <html>
                    <body style="font-family: Arial, sans-serif; margin:20px;">
                        <h1>Resumen de Análisis de Detección PII</h1>
                        <p>El análisis de detección de información personal (PII) ha sido completado para el archivo "{folder_name}". A continuación se presenta un resumen de los hallazgos:</p>
                        {summary_html}
                    </body>
                    </html>
                    """
                    
                    # Send folder-specific email
                    folder_email_sent = self._send_folder_email(
                        subject, body, folder_excel_path, folder_name
                    )
                    
                    if folder_email_sent:
                        logging.info(f"Email sent successfully for folder '{folder_name}' - {folder_entity_count} entities")
                    else:
                        logging.error(f"Failed to send email for folder '{folder_name}'")
                        all_emails_sent = False
                        
                except Exception as folder_error:
                    logging.error(f"Error processing folder '{folder_name}': {folder_error}")
                    all_emails_sent = False
                    continue
            
            # Log final results
            if all_emails_sent:
                logging.info(f"All folder emails sent successfully - {len(unique_folders)} folders processed")
            else:
                logging.warning(f"Some folder emails failed - {len(unique_folders)} folders attempted")
            
            return all_emails_sent
                
        except Exception as e:
            logging.error(f"Error creating user email reports: {e}")
            return False

    def _create_filtered_excel_report(self, filtered_df: pd.DataFrame, original_excel_path: str) -> str:
        """
        Create a simplified 2-sheet Excel report for email distribution.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data
            original_excel_path (str): Path to original Excel file
            
        Returns:
            str: Path to created email Excel file
        """
        try:
            # Create user-friendly columns (remove technical fields)
            user_columns = [
                "Report_Generated", "File", "Folder", "Status_file", 
                "PII_Type", "PII_Value", "Page", "Source_Type"
            ]
            
            # Filter to only user-relevant columns that exist
            available_columns = [col for col in user_columns if col in filtered_df.columns]
            user_df = filtered_df[available_columns].copy()
            
            # Create summary analysis sheet
            summary_df = self._create_summary_analysis_sheet(filtered_df)
            
            # Generate email-specific filename
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            email_filename = f"PII_User_Report_{timestamp}.xlsx"
            email_excel_path = os.path.join(self.output_dir, email_filename)
            
            # Create 2-sheet Excel file
            with pd.ExcelWriter(email_excel_path, engine="openpyxl") as writer:
                # Sheet 1: Filtered PII Results
                user_df.to_excel(writer, sheet_name="PII_Results", index=False)
                
                # Sheet 2: Summary Analysis
                summary_df.to_excel(writer, sheet_name="Summary_Analysis", index=False)
                
                # Format sheets for better readability
                self._format_user_excel_sheets(writer, user_df, summary_df)
            
            logging.info(f"User Excel report created: {email_excel_path}")
            return email_excel_path
            
        except Exception as e:
            logging.error(f"Error creating filtered Excel report: {e}")
            return None

    def _create_folder_specific_excel_report(self, folder_df: pd.DataFrame, 
                                           folder_name: str, original_excel_path: str) -> str:
        """
        Create a folder-specific 2-sheet Excel report for email distribution.
        
        Args:
            folder_df (pd.DataFrame): Filtered PII data for specific folder
            folder_name (str): Name of the folder
            original_excel_path (str): Path to original Excel file
            
        Returns:
            str: Path to created folder-specific Excel file
        """
        try:
            # Create user-friendly columns (remove technical fields)
            user_columns = [
                "Report_Generated", "File","Page", "Folder", "Status_file", 
                "PII_Type", "PII_Value", "Label",   ] # "Source_Type"
            
            ########################################################################################
            # Filter to only user-relevant columns that exist
            available_columns = [col for col in user_columns if col in folder_df.columns]
            user_df = folder_df[available_columns].copy()
            
            # Rename columns for end users (English -> Spanish) — only rename existing cols
            rename_map = {
                "Report_Generated": "Fecha de reporte",
                "File": "Archivo",
                "Page": "Pagina",
                "Folder": "Documento",
                "Status_file": "Estatus documento",
                "PII_Type": "Tipo de PII",
                "PII_Value": "PII detectado",
                "Label": "Tag PII"
            }
            rename_map = {k: v for k, v in rename_map.items() if k in user_df.columns}
            if rename_map:
                user_df = user_df.rename(columns=rename_map)
            ########################################################################################
            # Standardize PII_Type values to Spanish equivalents using comprehensive mapping
            mapping = {
                # Primary mappings for common PII types
                "CUSTOMER_NAME": "Nombre de cliente",
                "SEQ_NUMBER": "Secuencia numerica", 
                "DATE": "Fecha",
                "AMOUNT": "Monto",
                "Amount": "Monto",
                "PHONE_NUMBER": "Telefono",
                "PHONE": "Telefono", 
                "Phone": "Telefono",
                "NumberSequence": "Secuencia numerica",
                "NUMBERSEQUENCE": "Secuencia numerica",
                "Person": "Nombre de cliente",
                "PERSON": "Nombre de cliente",
                "RUT": "RUT",
                
                # Additional comprehensive mappings
                "EMAIL": "Correo electronico",
                "Email": "Correo electronico",
                "DOCUMENT": "Documento",
                "Document": "Documento",
                "ID": "Identificacion",
                "IDENTIFICATION": "Identificacion",
                "ADDRESS": "Direccion",
                "Address": "Direccion",
                "NAME": "Nombre",
                "Name": "Nombre",
                "CREDIT_CARD": "Tarjeta de credito",
                "CreditCard": "Tarjeta de credito",
                "ACCOUNT": "Cuenta",
                "Account": "Cuenta",
                "BANK": "Banco",
                "Bank": "Banco"
            }
            # for col_name in ("PII_Type", "Tipo de PII"):
                # if col_name in df.columns:
            if "Tipo de PII" in user_df.columns:
                user_df['Tipo de PII'] = user_df['Tipo de PII'].map(mapping).fillna(user_df['Tipo de PII'])

            ########################################################################################
            mapping_tag = {'TextData': 'Datos Texto', 'SequenceNumber': 'Datos numericos'}
            if "Tag PII" in user_df.columns:
                user_df['Tag PII'] = user_df['Tag PII'].map(mapping_tag).fillna(user_df['Tag PII'])

            ########################################################################################
            # Create folder-specific summary analysis sheet using translated data
            # Use _create_summary_analysis_sheet which works with already-translated columns
            summary_df = self._create_summary_analysis_sheet(user_df)  # Uses Spanish columns from user_df
            
            # Generate folder-specific filename
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_folder_name = "".join(c for c in folder_name if c.isalnum() or c in (' ', '_', '-')).strip()
            safe_folder_name = safe_folder_name.replace(' ', '_')[:20]  # Limit length for filename
            
            email_filename = f"PII_Report_{safe_folder_name}_{timestamp}.xlsx"
            email_excel_path = os.path.join(self.output_dir, email_filename)
            
            # Create 2-sheet Excel file
            with pd.ExcelWriter(email_excel_path, engine="openpyxl") as writer:
                # Sheet 1: Filtered PII Results for this folder
                user_df.to_excel(writer, sheet_name="PII_Results", index=False)
                
                
                # Sheet 2: Folder-Specific Summary Analysis
                summary_df.to_excel(writer, sheet_name="Summary_Analysis", index=False)
                
                # Format sheets for better readability
                self._format_user_excel_sheets(writer, user_df, summary_df)
            
            logging.info(f"Folder Excel report created: {email_excel_path}")
            return email_excel_path
            
        except Exception as e:
            logging.error(f"Error creating folder-specific Excel report for '{folder_name}': {e}")
            return None

    def _generate_folder_summary_stats(self, folder_df: pd.DataFrame, folder_name: str) -> pd.DataFrame:
        """
        Generate folder-specific summary statistics.
        
        Args:
            folder_df (pd.DataFrame): Filtered PII data for specific folder
            folder_name (str): Name of the folder
            
        Returns:
            pd.DataFrame: Summary statistics for folder email
        """
        try:
            # Basic statistics for this folder
            total_entities = len(folder_df)
            unique_files = folder_df['File'].nunique() if 'File' in folder_df.columns else 0
            
            # Top PII types in this folder
            if 'PII_Type' in folder_df.columns:
                top_pii_types = folder_df['PII_Type'].value_counts().head(3)
                most_common_pii = top_pii_types.index[0] if len(top_pii_types) > 0 else "None"
                most_common_count = top_pii_types.iloc[0] if len(top_pii_types) > 0 else 0
            else:
                most_common_pii = "Unknown"
                most_common_count = 0
            
            # File status distribution for this folder - COUNT UNIQUE FILES, not entities
            if 'Status_file' in folder_df.columns:
                # Get unique files by status within this folder
                modified_files = folder_df[folder_df['Status_file'] == 'modificado']['File'].nunique() if 'File' in folder_df.columns else 0
                new_files = folder_df[folder_df['Status_file'] == 'nuevo_archivo']['File'].nunique() if 'File' in folder_df.columns else 0
            else:
                modified_files = new_files = 0
            
            summary_data = {
                "Métrica": [
                    "Archivo Analizado",
                    "Tipo de Detección",
                    "Total de Entidades PII en Carpeta",
                    "Archivos con PII en esta Carpeta", 
                    "Tipo de PII Más Común en Carpeta",
                    # "Archivos Modificados con PII",
                    # "Archivos Nuevos con PII",
                    "Reporte Generado"
                ],
                "Valor": [
                    folder_name,
                    folder_df['Status_file'].mode()[0] if 'Status_file' in folder_df.columns and not folder_df['Status_file'].empty else "Desconocido",
                    total_entities,
                    unique_files,
                    f"{most_common_pii} : {most_common_count} ocurrencias",
                    # modified_files,
                    # new_files,
                    dt.datetime.now().strftime("%Y-%m-%d %H:%M")
                ]
            }
            
            return pd.DataFrame(summary_data)
            
        except Exception as e:
            logging.error(f"Error generating folder summary stats for '{folder_name}': {e}")
            return pd.DataFrame({"Métrica": ["Error"], "Valor": [str(e)]})

    def _create_folder_summary_analysis_sheet(self, folder_df: pd.DataFrame, folder_name: str) -> pd.DataFrame:
        """
        Create folder-specific summary analysis sheet with breakdowns.
        
        Args:
            folder_df (pd.DataFrame): Filtered PII data for specific folder
            folder_name (str): Name of the folder
            
        Returns:
            pd.DataFrame: Folder-specific summary analysis data
        """
        try:
            # Safe guards
            if folder_df is None or folder_df.empty:
                return pd.DataFrame([
                    {"Categoría": "RESUMEN EJECUTIVO", "Métrica": folder_name, "Cantidad": "", "Porcentaje": ""},
                    {"Categoría": "", "Métrica": "No se encontraron entidades PII en esta carpeta", "Cantidad": "", "Porcentaje": ""}
                ])
            
            total_entities = len(folder_df)
            unique_files = int(folder_df['File'].nunique()) if 'File' in folder_df.columns else 0
            # number of unique files in this folder that contain at least one PII entity
            files_with_pii = unique_files
            
            # Build rows
            rows = []
            
            # Header / summary (kept as normal rows; top merged decorative header is applied in formatter)
            # rows.append({"Categoría": "RESUMEN EJECUTIVO", "Métrica": "Carpeta Analizada", "Cantidad": folder_name, "Porcentaje": ""})
            rows.append({"Categoría": "RESUMEN EJECUTIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            rows.append({"Categoría": "", "Métrica": "Total de Entidades PII (filas)", "Cantidad": total_entities, "Porcentaje": "100%"})
            rows.append({"Categoría": "", "Métrica": "Archivos Afectados (únicos)", "Cantidad": unique_files, "Porcentaje": ""})
            rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})  # separator
            
            # PII type breakdown (sorted by count) - show top N (configurable)
            if 'PII_Type' in folder_df.columns and not folder_df['PII_Type'].empty:
                pii_type_counts = folder_df['PII_Type'].value_counts()
                rows.append({"Categoría": "DESGLOSE POR TIPO DE PII", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                top_n = min(8, len(pii_type_counts))  # show up to 8 most common types for compactness
                for pii_type, count in pii_type_counts.head(top_n).items():
                    pct = (count / total_entities) * 100 if total_entities > 0 else 0.0
                    rows.append({
                        "Categoría": "",
                        "Métrica": str(pii_type),
                        "Cantidad": int(count),
                        "Porcentaje": f"{pct:.1f}%"
                    })
                rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # File status section removed - status is now displayed in the top merged header row
            # "Estado de archivo: Modificado" instead of a separate section
            
            # Source type breakdown (sorted)
            if 'Source_Type' in folder_df.columns and not folder_df['Source_Type'].empty:
                source_counts = folder_df['Source_Type'].value_counts()
                rows.append({"Categoría": "TIPOS DE FUENTE", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for source, count in source_counts.items():
                    pct = (count / total_entities) * 100 if total_entities > 0 else 0.0
                    rows.append({
                        "Categoría": "",
                        "Métrica": str(source),
                        "Cantidad": int(count),
                        "Porcentaje": f"{pct:.1f}%"
                    })
                rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # Additional useful detail: most common PII and sample files (limit examples)
            try:
                most_common_pii = folder_df['PII_Type'].mode()[0] if 'PII_Type' in folder_df.columns and not folder_df['PII_Type'].empty else None
                if most_common_pii:
                    # increase examples to max 5 for more context
                    sample_files = folder_df[folder_df['PII_Type'] == most_common_pii]['File'].unique()[:3].tolist()
                    rows.append({"Categoría": "DETALLE ADICIONAL", "Métrica": "Tipo PII Más Común", "Cantidad": most_common_pii, "Porcentaje": ""})
                    rows.append({"Categoría": "", "Métrica": "Ejemplos de Archivos con este PII (máx 3)", "Cantidad": ", ".join(sample_files), "Porcentaje": ""})
                    rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            except Exception:
                # ignore optional detail if something fails
                pass
            
            # Footer / generation timestamp
            rows.append({"Categoría": "", "Métrica": "Reporte Generado", "Cantidad": dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "Porcentaje": ""})
            
            return pd.DataFrame(rows, columns=["Categoría", "Métrica", "Cantidad", "Porcentaje"])
            
        except Exception as e:
            logging.error(f"Error creating folder summary analysis for '{folder_name}': {e}")
            return pd.DataFrame([{"Categoría": "Error", "Métrica": "Análisis Falló", "Cantidad": str(e), "Porcentaje": ""}])


    def _send_folder_email(self, subject: str, body: str, excel_path: str, folder_name: str) -> bool:
        """
        Send email for a specific folder.
        
        Args:
            subject (str): Email subject
            body (str): Email body HTML
            excel_path (str): Path to Excel attachment
            folder_name (str): Name of the folder
            
        Returns:
            bool: True if email sent successfully, False otherwise
        """
        try:
            # Convert to absolute path to fix Outlook issues
            excel_path = os.path.abspath(excel_path)
            logging.info(f"Folder '{folder_name}' Excel absolute path: {excel_path}")
            
            # Verify file exists with absolute path
            if not os.path.exists(excel_path):
                logging.error(f"Folder Excel file not found at absolute path: {excel_path}")
                return False
            
            # Create temporary HTML files for email in output directory
            os.makedirs(self.output_dir, exist_ok=True)
            safe_folder_name = "".join(c for c in folder_name if c.isalnum() or c in ('_', '-'))
            temp_body_file = os.path.join(self.output_dir, f"temp_email_body_{safe_folder_name}.html")
            temp_wrapper_file = os.path.join(self.output_dir, f"temp_email_wrapper_{safe_folder_name}.html")
            
            try:
                # Create body file
                with open(temp_body_file, 'w', encoding='utf-8') as f:
                    f.write(body)
                
                # Create wrapper file with body content
                wrapper_html = f"""
                    {body}
                """
                with open(temp_wrapper_file, 'w', encoding='utf-8') as f:
                    f.write(wrapper_html)
                
                logging.info(f"Sending email for folder '{folder_name}' - Subject: {subject}")
                
                # Send email using framework's send_email function
                email_sent = send_email(
                    subject=subject,
                    to=['andres.n.vera@provida.cl'], # 'nicolas.pinto@metlife.cl','jorge.e.torres@metlife.cl'
                    body_file=temp_body_file,
                    wrapper_file=temp_wrapper_file,
                    environment="dev",
                    attachments=[excel_path]
                )
                
                return email_sent
                
            finally:
                # Clean up temporary files
                for temp_file in [temp_body_file, temp_wrapper_file]:
                    try:
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                            logging.debug(f"Cleaned up temp file: {temp_file}")
                    except Exception as cleanup_error:
                        logging.warning(f"Failed to clean up temp file {temp_file}: {cleanup_error}")
            
        except Exception as e:
            logging.error(f"Error sending folder email for '{folder_name}': {e}")
            return False

    def _generate_user_summary_stats(self, filtered_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate user-friendly summary statistics.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data
            
        Returns:
            pd.DataFrame: Summary statistics for email
        """
        try:
            # Basic statistics
            total_entities = len(filtered_df)
            unique_files = filtered_df['File'].nunique() if 'File' in filtered_df.columns else 0
            unique_folders = filtered_df['Folder'].nunique() if 'Folder' in filtered_df.columns else 0
            
            # Top PII types
            if 'PII_Type' in filtered_df.columns:
                top_pii_types = filtered_df['PII_Type'].value_counts().head(3)
                most_common_pii = top_pii_types.index[0] if len(top_pii_types) > 0 else "None"
                most_common_count = top_pii_types.iloc[0] if len(top_pii_types) > 0 else 0
            else:
                most_common_pii = "Unknown"
                most_common_count = 0
            
            # File status distribution - COUNT UNIQUE FILES, not entities
            if 'Status_file' in filtered_df.columns:
                # Get unique files by status
                modified_files = filtered_df[filtered_df['Status_file'] == 'modificado']['File'].nunique() if 'File' in filtered_df.columns else 0
                new_files = filtered_df[filtered_df['Status_file'] == 'nuevo_archivo']['File'].nunique() if 'File' in filtered_df.columns else 0
            else:
                modified_files = new_files = 0
            
            summary_data = {
                "Métrica": [
                    "Total de Entidades PII Encontradas",
                    "Archivos que Contienen PII (imagenes/texto)", 
                    "Carpetas Procesadas",
                    "Tipo de PII Más Común",
                    # "Archivos Modificados con PII",
                    # "Archivos Nuevos con PII",
                    "Reporte Generado"
                ],
                "Valor": [
                    total_entities,
                    unique_files,
                    unique_folders,
                    f"{most_common_pii} ({most_common_count})",
                    # modified_files,
                    # new_files,
                    dt.datetime.now().strftime("%Y-%m-%d %H:%M")
                ]
            }
            
            return pd.DataFrame(summary_data)
            
        except Exception as e:
            logging.error(f"Error generating user summary stats: {e}")
            return pd.DataFrame({"Metric": ["Error"], "Value": [str(e)]})

    def _create_summary_analysis_sheet(self, filtered_df: pd.DataFrame) -> pd.DataFrame:
        """
        Create dynamic summary analysis sheet with breakdowns.
        Uses already-translated data from PII_Results for consistency.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data (should have Spanish columns if from PII_Results)
            
        Returns:
            pd.DataFrame: Summary analysis data
        """
        try:
            summary_rows = []
            
            # Detect if we have Spanish or English columns (use Spanish if available)
            pii_type_col = "Tipo de PII" if "Tipo de PII" in filtered_df.columns else "PII_Type"
            status_col = "Estatus documento" if "Estatus documento" in filtered_df.columns else "Status_file"
            file_col = "Archivo" if "Archivo" in filtered_df.columns else "File"
            folder_col = "Documento" if "Documento" in filtered_df.columns else "Folder"
            source_col = "Source_Type"  # This column doesn't get translated in PII_Results currently
            
            # Header section
            summary_rows.extend([
                {"Categoría": "RESUMEN EJECUTIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""},
                {"Categoría": "", "Métrica": "Total de Entidades PII", "Cantidad": len(filtered_df), "Porcentaje": "100%"},
                {"Categoría": "", "Métrica": "Archivos imagenes/texto Afectados", "Cantidad": filtered_df[file_col].nunique() if file_col in filtered_df.columns else 0, "Porcentaje": ""},
                {"Categoría": "", "Métrica": "Archivos unicos analizados", "Cantidad": filtered_df[folder_col].nunique() if folder_col in filtered_df.columns else 0, "Porcentaje": ""},
                {"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""},
            ])
            
            # PII Type breakdown - use already translated values
            if pii_type_col in filtered_df.columns and not filtered_df.empty:
                pii_type_counts = filtered_df[pii_type_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR TIPO DE PII", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for pii_type, count in pii_type_counts.head(10).items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # No need for translation - already translated in PII_Results
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": str(pii_type),  # Already in Spanish if from PII_Results
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
                
                summary_rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # File Status breakdown - use already translated values  
            if status_col in filtered_df.columns and not filtered_df.empty:
                status_counts = filtered_df[status_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR ESTADO DE ARCHIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for status, count in status_counts.items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # If using Spanish column, no translation needed. If English, apply minimal cleanup
                    if status_col == "Estatus documento":
                        status_display = str(status)  # Already in Spanish
                    else:
                        status_display = str(status).replace("_", " ").title()  # Clean up English version
                    
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": status_display,
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
                
                summary_rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # Source Type breakdown
            if source_col in filtered_df.columns and not filtered_df.empty:
                source_counts = filtered_df[source_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR TIPO DE FUENTE", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for source, count in source_counts.items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # Apply minimal cleanup for source types
                    source_display = str(source).replace("_", " ").title()
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": source_display,
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
            
            return pd.DataFrame(summary_rows)
            
        except Exception as e:
            logging.error(f"Error creating summary analysis sheet: {e}")
            return pd.DataFrame([{"Categoría": "Error", "Métrica": "Análisis Falló", "Cantidad": str(e), "Porcentaje": ""}])

    def _format_user_excel_sheets(self, writer, pii_df: pd.DataFrame, summary_df: pd.DataFrame) -> None:
        """
        Format the user Excel sheets with clean, professional styling.
        
        Args:
            writer: Excel writer object
            pii_df (pd.DataFrame): PII results dataframe
            summary_df (pd.DataFrame): Summary dataframe
        """
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
            
            # Format PII Results sheet
            if "PII_Results" in writer.sheets:
                pii_ws = writer.sheets["PII_Results"]
                
                # Set column widths
                column_widths = {'A': 15, 'B': 20, 'C': 15, 'D': 15, 'E': 15, 'F': 30, 'G': 8, 'H': 15}
                for col, width in column_widths.items():
                    pii_ws.column_dimensions[col].width = width
                
                # Auto-size columns based on content (header + cell max length)
                # Cap widths for readability: min 8, max 50
                if isinstance(pii_df, pd.DataFrame) and not pii_df.empty:
                    for idx, col in enumerate(pii_df.columns, start=1):
                        try:
                            max_cell = max((len(str(v)) for v in pii_df[col].fillna('')), default=0)
                        except Exception:
                            max_cell = 0
                        header_len = len(str(col))
                        calculated = max(header_len, max_cell) + 2  # padding
                        width = max(8, min(50, calculated))
                        col_letter = get_column_letter(idx)
                        pii_ws.column_dimensions[col_letter].width = width
                else:
                    # Fallback sensible defaults if dataframe empty
                    for i, col_letter in enumerate(list("ABCDEFGH"), start=1):
                        pii_ws.column_dimensions[col_letter].width = 15
                
                # Format headers
                # Use dark-blue headers for consistency with folder summary screenshots
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                for cell in pii_ws[1]:
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = header_fill_dark_blue
                    cell.alignment = Alignment(horizontal="center")
                
                # Color code by file status (priority) and detection method (secondary)
                status_colors = {
                    "modificado": PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid"),      # Light yellow
                    "nuevo_archivo": PatternFill(start_color="D5E8D4", end_color="D5E8D4", fill_type="solid"),  # Light green
                    "sin_cambios": PatternFill(start_color="F8CECC", end_color="F8CECC", fill_type="solid"),    # Light red
                }
                
                # Apply status coloring if Status_file column exists
                if 'Status_file' in pii_df.columns:
                    status_col_idx = list(pii_df.columns).index('Status_file') + 1  # Excel is 1-indexed
                    
                    for row_idx, row in enumerate(pii_ws.iter_rows(min_row=2, max_row=len(pii_df) + 1), 2):
                        if len(row) > status_col_idx - 1:
                            status_value = str(row[status_col_idx - 1].value).lower() if row[status_col_idx - 1].value else ""
                            fill_color = status_colors.get(status_value)
                            if fill_color:
                                for cell in row:
                                    cell.fill = fill_color
            
            # Format Summary Analysis sheet
            if "Summary_Analysis" in writer.sheets:
                summary_ws = writer.sheets["Summary_Analysis"]
                
                # Set column widths
                summary_ws.column_dimensions['A'].width = 25  # Category
                summary_ws.column_dimensions['B'].width = 30  # Metric
                summary_ws.column_dimensions['C'].width = 15  # Count
                summary_ws.column_dimensions['D'].width = 15  # Percentage
                
                # Format headers
                # Prepare fills & fonts
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                category_fill_light = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
                header_font = Font(bold=True, color="FFFFFF")
                section_font = Font(bold=True, color="000000")
                
                # Insert a decorative merged header row above the dataframe header (pandas header will be shifted down)
                try:
                    # Insert a blank row at top so we can add a merged title row
                    summary_ws.insert_rows(1)
                except Exception:
                    # If insertion fails (rare), continue and attempt to format existing header
                    pass
                
                # Try to extract folder name and status from the summary_df (these are present when folder-specific)
                folder_display = ""
                status_display = ""
                
                try:
                    if isinstance(summary_df, pd.DataFrame):
                        # Get folder name from the folder_name parameter passed to the sheet creation
                        # Since we removed "Carpeta Analizada" row, we need to get it from the data
                        if isinstance(pii_df, pd.DataFrame) and 'Folder' in pii_df.columns and not pii_df['Folder'].empty:
                            # Get the most common folder name (should be consistent within folder-specific reports)
                            folder_display = pii_df['Folder'].mode()[0] if not pii_df['Folder'].empty else ""
                        else:
                            folder_display = ""
                        
                        # Get status from the pii_df if available (most common status)
                        try:
                            if isinstance(pii_df, pd.DataFrame) and 'Estatus documento' in pii_df.columns and not pii_df['Estatus documento'].empty:
                                # Use the Spanish column name and get the most common status
                                status_display = pii_df['Estatus documento'].mode()[0]
                            elif isinstance(pii_df, pd.DataFrame) and 'Status_file' in pii_df.columns and not pii_df['Status_file'].empty:
                                # Fallback to English column with proper translation
                                status_raw = pii_df['Status_file'].mode()[0]
                                # Translate to Spanish
                                status_mapping = {
                                    'modificado': 'Modificado',
                                    'nuevo_archivo': 'Nuevo Archivo', 
                                    'sin_cambios': 'Sin Cambios'
                                }
                                status_display = status_mapping.get(status_raw, status_raw.replace("_", " ").title())
                            else:
                                status_display = "Desconocido"
                        except Exception:
                            status_display = "Desconocido"
                except Exception:
                    folder_display = folder_display or ""
                    status_display = status_display or ""
                
                # Write merged top header and style it
                try:
                    merged_text = f"Carpeta Analizada: {folder_display}    |    Estado de archivo: {status_display}"
                    summary_ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
                    top_cell = summary_ws.cell(row=1, column=1)
                    top_cell.value = merged_text
                    top_cell.font = header_font
                    top_cell.fill = header_fill_dark_blue
                    top_cell.alignment = Alignment(horizontal="center", vertical="center")
                except Exception:
                    # ignore merge/write errors and continue formatting rest
                    pass
                
                # The DataFrame header row is now at excel row 2 (after insertion). Format it bold/centered and give it the dark-blue fill.
                header_row_idx = 2
                try:
                    for cell in summary_ws[header_row_idx]:
                        cell.font = header_font
                        cell.fill = header_fill_dark_blue
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                except Exception:
                    # If iterating row fails, try per-column approach
                    for col_idx in range(1, 5):
                        cell = summary_ws.cell(row=header_row_idx, column=col_idx)
                        cell.font = header_font
                        cell.fill = header_fill_dark_blue
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                
                # Freeze panes so header row stays visible. Freeze above row 3 (so rows 1-2 remain visible).
                try:
                    summary_ws.freeze_panes = summary_ws['A3']
                except Exception:
                    # Fallback textual form
                    try:
                        summary_ws.freeze_panes = "A3"
                    except Exception:
                        pass
                
                # Format category/section header rows (soft blue) - start from row 3 to skip the decorative header + df header
                for row in summary_ws.iter_rows(min_row=3, max_row=summary_ws.max_row):
                    try:
                        first_cell = row[0]
                        second_cell = row[1] if len(row) > 1 else None
                        
                        # Detect section title rows:
                        # 1. Standard rule: first cell is ALL UPPER and second cell is empty (e.g., "DESGLOSE POR TIPO DE PII")
                        # 2. Special case: "DETALLE ADICIONAL" row should be formatted even if it has content in following cells
                        is_section_title = False
                        if first_cell.value and isinstance(first_cell.value, str):
                            cell_value = first_cell.value.strip()
                            # Check if it's a standard section header (all caps + empty second cell)
                            if cell_value == cell_value.upper() and (not second_cell or not second_cell.value):
                                is_section_title = True
                            # Special case for "DETALLE ADICIONAL" - always format regardless of following cells
                            elif cell_value.upper() == "DETALLE ADICIONAL":
                                is_section_title = True
                        
                        if is_section_title:
                            # Apply section header formatting to entire row
                            for cell in row:
                                cell.font = section_font
                                cell.fill = category_fill_light
                                # Keep left alignment for category column, center for numbers
                                if cell.col_idx in (3, 4):
                                    cell.alignment = Alignment(horizontal="center")
                                else:
                                    cell.alignment = Alignment(horizontal="left")
                    except Exception:
                        continue
                
                # Ensure numeric columns alignment and simple formatting for the rest of rows
                for row in summary_ws.iter_rows(min_row=3, max_row=summary_ws.max_row):
                    try:
                        # Align quantity and percentage
                        qty_cell = summary_ws.cell(row=row[0].row, column=3)
                        pct_cell = summary_ws.cell(row=row[0].row, column=4)
                        qty_cell.alignment = Alignment(horizontal="right")
                        pct_cell.alignment = Alignment(horizontal="right")
                    except Exception:
                        continue
                            
        except Exception as e:
            logging.error(f"Error formatting user Excel sheets: {e}")

    def run_detection(self) -> bool:
        """Main orchestration method"""
        try:
            logging.info(f"Starting S3 PII Detection Orchestrator")
            logging.info(f"Configured method: {self.detection_method}")
            
            # Validate method
            valid_methods = ["regex", "ml", "hybrid"]
            if self.detection_method not in valid_methods:
                logging.error(f"Invalid detection method: {self.detection_method}. Valid options: {valid_methods}")
                return False
            
            # Execute detection
            if self.detection_method == "hybrid":
                return self._run_hybrid_method()
            else:
                return self._run_single_method(self.detection_method)
                
        except Exception as e:
            logging.error(f"Orchestration failed: {e}")
            return False

    def run_flow(self) -> bool:
        """
        Main workflow method - follows the same pattern as S0, S1, S2, S3 scripts
        Required by MainProcess in main.py
        """
        return self.run_detection()

    def _send_resume_email(self) -> bool:
        """
        Envía email de resumen integrando files_metadata.xlsx con detecciones PII.
        
        Returns:
            bool: True si el email se envió exitosamente, False en caso contrario
        """
        try:
            logging.info("Iniciando generación y envío de email de resumen")
            
            # Buscar files_metadata.xlsx en input/ y output/
            input_dir = self.config.get("paths", {}).get("input", "input")
            if not os.path.isabs(input_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                input_dir = os.path.join(project_root, input_dir)
            
            # Buscar en input/ y también en output/_others/
            metadata_search_paths = [
                os.path.join(input_dir, "**/files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "_others", "files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "files_metadata.xlsx")
            ]
            
            metadata_files = []
            for search_path in metadata_search_paths:
                metadata_files.extend(glob.glob(search_path, recursive=True))
                            
            if not metadata_files:
                logging.warning("No se encontró files_metadata.xlsx en las rutas de búsqueda. No se enviará email de resumen.")
                return False
            
            files_metadata_path = metadata_files[0]
            logging.info(f"Encontrado files_metadata.xlsx en: {files_metadata_path}")
            
            # Buscar el último archivo de análisis PII
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            pii_files = glob.glob(os.path.join(output_dir, "OCR_PII_Analysis_HYBRID_*.xlsx"))
            
            if not pii_files:
                logging.warning("No se encontraron archivos de análisis PII. No se enviará email de resumen.")
                return False
            
            # Obtener el archivo más reciente
            latest_pii_file = max(pii_files, key=os.path.getmtime)
            logging.info(f"Usando archivo PII más reciente: {latest_pii_file}")
            
            # Crear archivo Excel de resumen
            resume_excel_path = self._create_resume_excel_report(files_metadata_path, latest_pii_file)
            
            if not resume_excel_path:
                logging.error("No se pudo crear el archivo Excel de resumen")
                return False
            
            # Generar contenido del email
            return self._send_single_resume_email(resume_excel_path, files_metadata_path, latest_pii_file)
            
        except Exception as e:
            logging.error(f"Error enviando email de resumen: {e}")
            return False

    def _create_resume_excel_report(self, files_metadata_path: str, pii_analysis_path: str) -> Optional[str]:
        """
        Crea archivo Excel de resumen integrando metadata y análisis PII.
        
        Args:
            files_metadata_path: Ruta al archivo files_metadata.xlsx
            pii_analysis_path: Ruta al archivo de análisis PII más reciente
            
        Returns:
            str: Ruta al archivo Excel generado, None si hay error
        """
        try:
            # Leer files_metadata.xlsx
            metadata_df = pd.read_excel(files_metadata_path)
            logging.info(f"Metadata load: {len(metadata_df)} files - shape: {metadata_df.shape}")
            logging.info(f"Metadata columns: {metadata_df.columns.tolist()}")
            
            # Leer análisis PII (hoja "Combined_PII_Results")
            pii_df = pd.read_excel(pii_analysis_path, sheet_name="Combined_PII_Results")
            logging.info(f"Analysis PII load: {len(pii_df)} detections - shape: {pii_df.shape}")
            
            # APLICAR EL MISMO FILTRO QUE EN USER EMAIL REPORTS PARA CONSISTENCIA
            original_count = len(pii_df)
            filtered_df = pii_df[~pii_df["PII_Type"].isin(self.email_excluded_pii_types)]
            filtered_count = len(filtered_df)
            excluded_count = original_count - filtered_count
            
            logging.info(f"Resume email filtering: {excluded_count} entities excluded, {filtered_count} included")
            logging.info(f"Excluded PII types for resume: {list(self.email_excluded_pii_types)}")
            
            if filtered_df.empty:
                logging.warning("No PII entities remain after filtering for resume email")
                # Still create the report but with zero detections
                filtered_df = pii_df.head(0)  # Empty DataFrame with same columns
            
            # DEBUG: Verify FILTERED PII data
            logging.info("=== DEBUG PII DATA PROCESSING (FILTERED) ===")
            logging.info(f"PII DataFrame shape: {filtered_df.shape}")
            logging.info(f"PII DataFrame columns: {filtered_df.columns.tolist()}")
            if 'Folder' in filtered_df.columns:
                logging.info(f"Sample Folder values: {filtered_df['Folder'].head().tolist()}")
                logging.info(f"Unique folders count: {filtered_df['Folder'].nunique()}")
            logging.info("=== END DEBUG PII DATA PROCESSING (FILTERED) ===")
            
            # Helper function to clean filenames for matching
            def clean_filename_for_matching(filename):
                """Clean filename by removing automation suffixes and extension"""
                if pd.isna(filename) or not filename:
                    return ''
                
                # Convert to string and get basename
                clean_name = os.path.basename(str(filename))
                
                # Remove anything after the first double-underscore "__" (most robust rule)
                if "__" in clean_name:
                    clean_name = clean_name.split("__", 1)[0]
                else:
                    # Fallback: remove a set of common automation suffixes if present
                    suffixes_to_remove = [
                        '_vfinal__modificado',
                        '__modificado',
                        '__nuevo_archivo',
                        '_vfinal',
                        '__processed',
                        '__updated'
                    ]
                    for suffix in suffixes_to_remove:
                        if suffix in clean_name:
                            clean_name = clean_name.split(suffix, 1)[0]
                            break
                
                # Only remove extension if it's a real file extension (has common file extensions)
                # This prevents treating "2." as having an extension
                common_extensions = ['.docx', '.pdf', '.xlsx', '.txt', '.doc', '.ppt', '.pptx']
                for ext in common_extensions:
                    if clean_name.lower().endswith(ext):
                        clean_name = clean_name[:-len(ext)]
                        break
                
                return clean_name.strip()
            
            # Extract and clean filename from 'Folder' column for matching USING FILTERED_DF
            logging.info("=== DEBUG FILENAME CLEANING PROCESS (FILTERED DATA) ===")
            filtered_df['Archivo_Base'] = filtered_df['Folder'].apply(clean_filename_for_matching)
            
            # Debug filename cleaning results
            if len(filtered_df) > 0:
                logging.info("Sample filename cleaning results:")
                for i, (original, cleaned) in enumerate(zip(filtered_df['Folder'].head(), filtered_df['Archivo_Base'].head())):
                    logging.info(f"  {i+1}: '{original}' -> '{cleaned}'")
            
            # Contar detecciones por archivo usando el nombre base extraído DE DATOS FILTRADOS
            pii_counts = filtered_df.groupby('Archivo_Base')['PII_Type'].agg(['count', 'nunique']).reset_index()
            pii_counts.columns = ['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']
            
            logging.info(f"PII counts after groupby (FILTERED): {len(pii_counts)} unique files")
            logging.info(f"Sample pii_counts:\n{pii_counts.head()}")
            
            # Obtener tipos PII por archivo usando el nombre base DE DATOS FILTRADOS
            pii_types_by_file = filtered_df.groupby('Archivo_Base')['PII_Type'].apply(lambda x: ', '.join(x.unique())).reset_index()
            pii_types_by_file.columns = ['Archivo_Base', 'Tipos_PII_Detectados']
            
            # Translate PII types in comma-separated strings to Spanish
            def translate_pii_types_string(pii_types_string):
                """Translate comma-separated PII types string to Spanish"""
                if pd.isna(pii_types_string) or pii_types_string == 'Ninguno':
                    return pii_types_string
                
                # Translation mapping
                pii_translation_map = {
                    "CUSTOMER_NAME": "Nombre de cliente",
                    "SEQ_NUMBER": "Secuencia numerica", 
                    "DATE": "Fecha",
                    "AMOUNT": "Monto",
                    "Amount": "Monto",
                    "PHONE_NUMBER": "Telefono",
                    "PHONE": "Telefono", 
                    "Phone": "Telefono",
                    "NUMBERSEQUENCE": "Secuencia numerica",
                    "NumberSequence": "Secuencia numerica",
                    "PERSON": "Nombre de cliente",
                    "Person": "Nombre de cliente",
                    "RUT": "RUT",
                    "EMAIL": "Correo electronico",
                    "Address": "Direccion",
                    "ADDRESS": "Direccion",
                    "ID_NUMBER": "Numero de identificacion",
                    "CREDIT_CARD": "Tarjeta de credito",
                    "BANK_ACCOUNT": "Cuenta bancaria",
                    "SSN": "Numero de seguridad social",
                    "TAX_ID": "Numero tributario"
                }
                
                # Split by comma, translate each type, and join back
                try:
                    pii_types = [pii_type.strip() for pii_type in pii_types_string.split(',')]
                    translated_types = []
                    
                    for pii_type in pii_types:
                        translated = pii_translation_map.get(pii_type, pii_type)
                        translated_types.append(translated)
                    
                    return ', '.join(translated_types)
                except Exception as e:
                    logging.warning(f"Error translating PII types string '{pii_types_string}': {e}")
                    return pii_types_string
            
            # Apply translation to the PII types column
            pii_types_by_file['Tipos_PII_Detectados'] = pii_types_by_file['Tipos_PII_Detectados'].apply(translate_pii_types_string)
            
            logging.info(f"PII types by file (FILTERED & TRANSLATED): {len(pii_types_by_file)} entries")
            logging.info("=== END DEBUG FILENAME CLEANING PROCESS (FILTERED DATA) ===")
            
            # Preparar datos para merge
            # Crear columns compatibles con metadata actual - Files_metadata.xlsx

            metadata_df['file_name'] = metadata_df['name']  # Use 'name' column instead of 'destination_name'
            metadata_df['folder_name'] = metadata_df['path'].apply(lambda x: os.path.basename(os.path.dirname(x)) if pd.notna(x) else '')
            
            # Calculate file size in MB from file path
            def get_file_size_mb(file_path):
                try:
                    if pd.notna(file_path) and os.path.exists(file_path):
                        size_bytes = os.path.getsize(file_path)
                        return round(size_bytes / (1024 * 1024), 2)  # Convert to MB
                    return 0
                except:
                    return 0
            
            metadata_df['file_size_mb'] = metadata_df['path'].apply(get_file_size_mb)
            metadata_df['modification_date'] = metadata_df['last_modified'] if 'last_modified' in metadata_df.columns else ''
            
            # Crear claves para merge - extraer nombre base del archivo de metadata también
            metadata_df['Archivo_Base'] = metadata_df['file_name'].apply(clean_filename_for_matching)
            
            # DEBUG: Verify metadata processing
            logging.info("=== DEBUG METADATA PROCESSING ===")
            logging.info(f"Metadata DataFrame shape: {metadata_df.shape}")
            logging.info(f"Metadata columns: {metadata_df.columns.tolist()}")
            if len(metadata_df) > 0:
                logging.info("Sample metadata filename cleaning:")
                for i, (original, cleaned) in enumerate(zip(metadata_df['file_name'].head(), metadata_df['Archivo_Base'].head())):
                    logging.info(f"  {i+1}: '{original}' -> '{cleaned}'")
            logging.info("=== END DEBUG METADATA PROCESSING ===")
            
            # Agregar logging para debug del matching
            logging.info(f"Archivos únicos en metadata: {metadata_df['Archivo_Base'].nunique()}")
            logging.info(f"Archivos únicos en PII: {len(pii_counts)}")
            logging.info(f"Muestra de nombres base PII: {pii_counts['Archivo_Base'].head().tolist()}")
            logging.info(f"Muestra de nombres base metadata: {metadata_df['Archivo_Base'].head().tolist()}")

            # Hacer join usando la clave común 'Archivo_Base'
            logging.info("=== DEBUG MERGE PROCESS (FILTERED DATA) ===")
            logging.info(f"Before merge - metadata_df shape: {metadata_df.shape}")
            logging.info(f"Before merge - pii_counts (filtered) shape: {pii_counts.shape}")
            logging.info(f"Sample metadata Archivo_Base: {metadata_df['Archivo_Base'].head().tolist()}")
            logging.info(f"Sample pii_counts Archivo_Base: {pii_counts['Archivo_Base'].head().tolist()}")
            
            # First merge
            enriched_df = metadata_df.merge(pii_counts[['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']], 
                                          on='Archivo_Base', how='left')
            
            logging.info(f"After first merge - enriched_df shape: {enriched_df.shape}")
            logging.info(f"Total_Detecciones null count: {enriched_df['Total_Detecciones'].isna().sum()}")
            logging.info(f"Total_Detecciones > 0 count (before fillna): {(enriched_df['Total_Detecciones'] > 0).sum()}")
            
            # Check for successful matches
            successful_merges = enriched_df[enriched_df['Total_Detecciones'].notna()]
            if len(successful_merges) > 0:
                logging.info(f"Successful merges (FILTERED): {len(successful_merges)}")
                for idx, row in successful_merges.head(3).iterrows():
                    logging.info(f"  Match: '{row['Archivo_Base']}' -> {row['Total_Detecciones']} detections")
            else:
                logging.error("NO SUCCESSFUL MERGES! Checking key mismatches...")
                # Compare keys
                meta_keys = set(metadata_df['Archivo_Base'].tolist())
                pii_keys = set(pii_counts['Archivo_Base'].tolist())
                common_keys = meta_keys & pii_keys
                logging.error(f"Metadata unique keys: {len(meta_keys)}")
                logging.error(f"PII unique keys: {len(pii_keys)}")
                logging.error(f"Common keys: {len(common_keys)}")
                if common_keys:
                    logging.info(f"Sample common keys: {list(common_keys)[:5]}")
                else:
                    logging.error(f"Sample metadata keys: {list(meta_keys)[:5]}")
                    logging.error(f"Sample PII keys: {list(pii_keys)[:5]}")
            
            # Second merge
            enriched_df = enriched_df.merge(pii_types_by_file[['Archivo_Base', 'Tipos_PII_Detectados']], 
                                          on='Archivo_Base', how='left')
            
            logging.info(f"After second merge - enriched_df shape: {enriched_df.shape}")
            logging.info("=== END DEBUG MERGE PROCESS (FILTERED DATA) ===")
            
            # Llenar valores nulos
            enriched_df['Total_Detecciones'] = enriched_df['Total_Detecciones'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Unicos'] = enriched_df['Tipos_PII_Unicos'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Detectados'] = enriched_df['Tipos_PII_Detectados'].fillna('Ninguno')
            
            # Reordenar columnas
            columns_order = ['file_name', 'folder_name', 'file_size_mb', 'modification_date', 
                           'Total_Detecciones', 'Tipos_PII_Unicos', 'Tipos_PII_Detectados']
            
            # Agregar columnas faltantes si existen en el DataFrame
            available_columns = [col for col in columns_order if col in enriched_df.columns]
            final_df = enriched_df[available_columns]
            
            
            #################################################################################
            # Rename output columns for the resume Excel (adjust display names as needed)
            rename_map = {
                "file_name": "Archivo",          
                "folder_name": "Carpeta",
                "file_size_mb": "Tamaño MB",
                "modification_date": "Fecha Modificación",
                "Total_Detecciones": "Total Detecciones",
                "Tipos_PII_Unicos": "Tipos PII Únicos",
                "Tipos_PII_Detectados": "Tipos PII Detectados"
            }
            # Only rename columns that actually exist to avoid KeyErrors
            rename_map = {k: v for k, v in rename_map.items() if k in final_df.columns}
            if rename_map:
                final_df = final_df.rename(columns=rename_map)
            #################################################################################
            
            # Generar estadísticas de resumen
            summary_stats = self._generate_resume_summary_stats(enriched_df, pii_counts)
            
            # Crear archivo Excel con formato
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            resume_filename = f"Resumen_Archivos_PII_{timestamp}.xlsx"
            
            # Obtener ruta de output de forma segura
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                # Si es ruta relativa, hacerla absoluta desde el directorio del proyecto
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            # Asegurar que el directorio existe
            os.makedirs(output_dir, exist_ok=True)
            
            resume_path = os.path.join(output_dir, resume_filename)
            logging.info(f"Creando archivo Excel de resumen en: {resume_path}")
            
            with pd.ExcelWriter(resume_path, engine='openpyxl') as writer:
                # Hoja 1: Datos enriquecidos
                final_df.to_excel(writer, sheet_name='Resumen Archivos', index=False)
                
                # Hoja 2: Estadísticas
                summary_stats.to_excel(writer, sheet_name='Estadísticas Resumen', index=False)
                
                # Aplicar formato
                self._format_resume_excel_sheets(writer, final_df, summary_stats)
            
            logging.info(f"Resume Excel report created with FILTERED data: {resume_path}")
            logging.info(f"Filter applied - Original: {original_count}, Filtered: {filtered_count}, Excluded: {excluded_count}")
            return resume_path
            
        except Exception as e:
            logging.error(f"Error creando archivo Excel de resumen: {e}")
            return None

    def _generate_resume_summary_stats(self, enriched_df: pd.DataFrame, pii_counts: pd.DataFrame = None) -> pd.DataFrame:
        """
        Genera estadísticas de resumen para el email de resumen.
        
        Args:
            enriched_df: DataFrame con datos enriquecidos
            pii_counts: DataFrame con conteos de PII por archivo (opcional)
            
        Returns:
            pd.DataFrame: Estadísticas de resumen
        """
        try:
            stats_data = []
            
            # DEBUG: Input DataFrames analysis
            logging.info("=== DEBUG RESUME SUMMARY STATS GENERATION ===")
            logging.info(f"enriched_df shape: {enriched_df.shape}")
            logging.info(f"enriched_df columns: {enriched_df.columns.tolist()}")
            if 'Total_Detecciones' in enriched_df.columns:
                logging.info(f"Total_Detecciones column info:")
                logging.info(f"  - Type: {enriched_df['Total_Detecciones'].dtype}")
                logging.info(f"  - Null count: {enriched_df['Total_Detecciones'].isna().sum()}")
                logging.info(f"  - > 0 count: {(enriched_df['Total_Detecciones'] > 0).sum()}")
                logging.info(f"  - Sum: {enriched_df['Total_Detecciones'].sum()}")
                logging.info(f"  - Sample values: {enriched_df['Total_Detecciones'].head().tolist()}")
                logging.info(f"  - Max value: {enriched_df['Total_Detecciones'].max()}")
            
            if pii_counts is not None:
                logging.info(f"pii_counts provided: {len(pii_counts)} entries")
                logging.info(f"pii_counts sample:\n{pii_counts.head()}")
            else:
                logging.info("pii_counts is None")
            
            # Estadísticas generales
            # FIXED: Use enriched_df directly as the base for counting
            total_files = len(enriched_df)  # All files in the enriched metadata
            files_with_pii = len(enriched_df[enriched_df['Total_Detecciones'] > 0])
            files_without_pii = total_files - files_with_pii
            total_detections = int(enriched_df['Total_Detecciones'].sum())
            
            # DEBUG: Show calculation results
            logging.info(f"CALCULATIONS:")
            logging.info(f"  - total_files (len enriched_df): {total_files}")
            logging.info(f"  - files_with_pii (Total_Detecciones > 0): {files_with_pii}")
            logging.info(f"  - files_without_pii: {files_without_pii}")
            logging.info(f"  - total_detections (sum): {total_detections}")
            logging.info("=== END DEBUG RESUME SUMMARY STATS GENERATION ===")
            
            stats_data.extend([
                ['Total de Archivos Procesados', total_files],
                ['Archivos con PII Detectado', files_with_pii],
                ['Archivos sin PII', files_without_pii],
                ['Total de Detecciones PII', total_detections],
                ['Porcentaje de Archivos con PII', f"{(files_with_pii/total_files*100):.1f}%" if total_files > 0 else "0%"]
            ])
            
            # Estadísticas por carpeta
            if 'folder_name' in enriched_df.columns:
                folder_stats = enriched_df.groupby('folder_name').agg({
                    'file_name': 'count',
                    'Total_Detecciones': 'sum',
                    'Tipos_PII_Unicos': 'sum'
                }).reset_index()
                
                stats_data.append(['--- Estadísticas por Carpeta ---', ''])
                for _, row in folder_stats.iterrows():
                    stats_data.extend([
                        [f"Carpeta: {row['folder_name']}", ''],
                        [f"  - Archivos", row['file_name']],
                        [f"  - Detecciones PII", row['Total_Detecciones']],
                        [f"  - Tipos PII Únicos", row['Tipos_PII_Unicos']]
                    ])
            
            # Top 5 archivos con más detecciones
            top_files = enriched_df.nlargest(5, 'Total_Detecciones')[['file_name', 'Total_Detecciones']]
            if len(top_files) > 0:
                stats_data.append(['--- Top 5 Archivos con más PII ---', ''])
                for _, row in top_files.iterrows():
                    stats_data.append([row['file_name'], row['Total_Detecciones']])
            
            return pd.DataFrame(stats_data, columns=['Métrica', 'Valor'])
            
        except Exception as e:
            logging.error(f"Error generando estadísticas de resumen: {e}")
            return pd.DataFrame(columns=['Métrica', 'Valor'])

    def _format_resume_excel_sheets(self, writer, files_df: pd.DataFrame, summary_df: pd.DataFrame) -> None:
        """
        Aplica formato a las hojas del Excel de resumen.
        
        Args:
            writer: ExcelWriter object
            files_df: DataFrame con archivos enriquecidos
            summary_df: DataFrame con estadísticas de resumen
        """
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            
            # Formato para hoja de archivos
            ws_files = writer.sheets['Resumen Archivos']
            
            # Encabezados en negrita
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            
            for col_num, column_title in enumerate(files_df.columns, 1):
                cell = ws_files.cell(row=1, column=col_num)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
            
            # Auto-fit columns: calcular ancho según contenido (header + celdas)
            try:
                # Calcular ancho máximo por columna
                for idx, col in enumerate(files_df.columns, start=1):
                    col_letter = get_column_letter(idx)
                    # Longitud del encabezado
                    max_length = len(str(col)) if col is not None else 0
                    # Revisar cada celda en la columna
                    for cell in ws_files[col_letter]:
                        try:
                            value = cell.value
                            if value is None:
                                continue
                            # Convertir a cadena y medir longitud
                            cell_length = len(str(value))
                            if cell_length > max_length:
                                max_length = cell_length
                        except Exception:
                            continue
                    # Ajustar ancho con padding y límites razonables
                    adjusted_width = max(8, max_length + 2)
                    ws_files.column_dimensions[col_letter].width = adjusted_width
            except Exception as e:
                logging.warning(f"Auto-fit columns failed for 'Resumen Archivos': {e}")
                # Fallback sensible widths
                try:
                    ws_files.column_dimensions['A'].width = 25
                    ws_files.column_dimensions['B'].width = 20
                    ws_files.column_dimensions['C'].width = 15
                    ws_files.column_dimensions['D'].width = 20
                    ws_files.column_dimensions['E'].width = 18
                    ws_files.column_dimensions['F'].width = 18
                    ws_files.column_dimensions['G'].width = 40
                except Exception:
                    pass
            
            # Formato condicional para archivos con PII
            for row in range(2, len(files_df) + 2):
                pii_count = ws_files.cell(row=row, column=5).value or 0
                try:
                    if pii_count > 0:
                        for col in range(1, len(files_df.columns) + 1):
                            ws_files.cell(row=row, column=col).fill = PatternFill(
                                start_color="FFE6E6", end_color="FFE6E6", fill_type="solid"
                            )
                except Exception:
                    continue
            # Formato para hoja de estadísticas
            ws_stats = writer.sheets['Estadísticas Resumen']
            
            # Encabezados
            for col_num in range(1, 3):
                cell = ws_stats.cell(row=1, column=col_num)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
            
            # Ajustar ancho
            ws_stats.column_dimensions['A'].width = 35
            ws_stats.column_dimensions['B'].width = 20
            
            # Resaltar métricas importantes
            important_metrics = ['Total de Archivos Procesados', 'Archivos con PII Detectado', 'Total de Detecciones PII']
            for row in range(2, len(summary_df) + 2):
                metric = ws_stats.cell(row=row, column=1).value
                if metric in important_metrics:
                    ws_stats.cell(row=row, column=1).font = Font(bold=True)
                    ws_stats.cell(row=row, column=2).font = Font(bold=True, color="D32F2F")
                    
        except Exception as e:
            logging.error(f"Error aplicando formato al Excel de resumen: {e}")

    def _send_single_resume_email(self, resume_excel_path: str, metadata_path: str, pii_path: str) -> bool:
        """
        Envía el email ejecutivo de resumen con análisis estratégico de riesgos PII usando templates.
        
        Args:
            resume_excel_path: Ruta al archivo Excel de resumen
            metadata_path: Ruta al archivo de metadata
            pii_path: Ruta al archivo de análisis PII
            
        Returns:
            bool: True si el email se envió exitosamente
        """
        try:
            # Leer estadísticas del resumen
            summary_df = pd.read_excel(resume_excel_path, sheet_name='Estadísticas Resumen')
            files_df = pd.read_excel(resume_excel_path, sheet_name='Resumen Archivos')
            
            # DEBUG: Verificar contenido de los DataFrames
            logging.info("=== DEBUG RESUME EMAIL METRICS ===")
            logging.info(f"Summary DataFrame shape: {summary_df.shape}")
            logging.info(f"Summary DataFrame columns: {summary_df.columns.tolist()}")
            logging.info(f"Summary DataFrame content:\n{summary_df.to_string()}")
            
            logging.info(f"Files DataFrame shape: {files_df.shape}")
            logging.info(f"Files DataFrame columns: {files_df.columns.tolist()}")
            if 'Total_Detecciones' in files_df.columns:
                pii_summary = files_df['Total_Detecciones'].describe()
                logging.info(f"Total_Detecciones column summary:\n{pii_summary}")
                logging.info(f"Files with PII > 0: {(files_df['Total_Detecciones'] > 0).sum()}")
                logging.info(f"Total detections sum: {files_df['Total_Detecciones'].sum()}")
            
            # Extraer métricas clave
            metrics = dict(zip(summary_df['Métrica'], summary_df['Valor']))
            logging.info(f"Extracted metrics: {metrics}")
            
            total_files = metrics.get('Total de Archivos Procesados', 0)
            files_with_pii = metrics.get('Archivos con PII Detectado', 0)
            total_detections = metrics.get('Total de Detecciones PII', 0)
            percentage_with_pii = metrics.get('Porcentaje de Archivos con PII', '0%')
            
            # DEBUG: Verificar valores extraídos
            logging.info(f"EXTRACTED VALUES:")
            logging.info(f"  - total_files: {total_files}")
            logging.info(f"  - files_with_pii: {files_with_pii}")
            logging.info(f"  - total_detections: {total_detections}")
            logging.info(f"  - percentage_with_pii: {percentage_with_pii}")
            logging.info("=== END DEBUG RESUME EMAIL METRICS ===")
            
            # VERIFICATION: Calculate manually from files_df if available
            if 'Total_Detecciones' in files_df.columns:
                manual_files_with_pii = (files_df['Total_Detecciones'] > 0).sum()
                manual_total_detections = files_df['Total_Detecciones'].sum()
                manual_total_files = len(files_df)
                
                logging.info("=== MANUAL CALCULATION VERIFICATION ===")
                logging.info(f"Manual calc - total_files: {manual_total_files}")
                logging.info(f"Manual calc - files_with_pii: {manual_files_with_pii}")
                logging.info(f"Manual calc - total_detections: {manual_total_detections}")
                
                # Use manual calculations if summary metrics are 0 but manual shows data
                if total_files == 0 and manual_total_files > 0:
                    logging.warning("Using manual calculations as summary metrics are 0")
                    total_files = manual_total_files
                    files_with_pii = manual_files_with_pii
                    total_detections = int(manual_total_detections)
                    percentage_with_pii = f"{(manual_files_with_pii/manual_total_files*100):.1f}%" if manual_total_files > 0 else "0%"
                    
                    logging.info(f"CORRECTED VALUES:")
                    logging.info(f"  - total_files: {total_files}")
                    logging.info(f"  - files_with_pii: {files_with_pii}")
                    logging.info(f"  - total_detections: {total_detections}")
                    logging.info(f"  - percentage_with_pii: {percentage_with_pii}")
                logging.info("=== END MANUAL CALCULATION VERIFICATION ===")
            
            # Determinar nivel de riesgo y recomendaciones estratégicas
            risk_level = self._assess_pii_risk_level(files_with_pii, total_files, total_detections)
            
            # Generar asunto ejecutivo
            timestamp = datetime.now().strftime("%d/%m/%Y")
            subject = f"Informe Ejecutivo - Análisis de Riesgos PII - {risk_level['label']} - {timestamp}"
            
            # Generate strategic recommendations using template manager
            strategic_recommendations = self.template_manager.generate_recommendations_html(risk_level['label'])
            
            # Prepare template variables
            template_vars = {
                "subject": subject,
                "timestamp": timestamp,
                "total_files": total_files,
                "files_with_pii": files_with_pii,
                "total_detections": total_detections,
                "percentage_with_pii": percentage_with_pii,
                "risk_level_label": risk_level['label'],
                "risk_level_css_class": risk_level['css_class'],
                "risk_level_description": risk_level['description'],
                "strategic_recommendations": strategic_recommendations,
                "pii_filename": os.path.basename(pii_path),
                "resume_filename": os.path.basename(resume_excel_path),
                "analysis_timestamp": datetime.now().strftime('%d/%m/%Y %H:%M')
            }
            
            # Render email template
            logging.info("Rendering resume email template...")
            try:
                body_html = self.template_manager.render_template("resume_email", **template_vars)
                logging.info(f"Template rendered successfully. HTML length: {len(body_html)}")
            except Exception as e:
                logging.error(f"Template rendering failed: {e}")
                raise
            
            # Enviar email
            logging.info(f"Enviando email ejecutivo: {subject}")
            
            # Crear archivos temporales para el email
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            os.makedirs(output_dir, exist_ok=True)
            temp_body_file = os.path.join(output_dir, "temp_resume_email_body.html")
            temp_wrapper_file = os.path.join(output_dir, "temp_resume_email_wrapper.html")
            
            try:
                # Crear archivos temporales
                with open(temp_body_file, 'w', encoding='utf-8') as f:
                    f.write(body_html)
                
                with open(temp_wrapper_file, 'w', encoding='utf-8') as f:
                    # Use simple string concatenation instead of f-string to avoid formatting issues
                    wrapper_content = "\n" + body_html + "\n"
                    f.write(wrapper_content)
                
                # Enviar email usando la función del framework
                return send_email(
                    subject=subject,
                    to=["andres.n.vera@provida.cl",],  # Ajustar según configuración 'nicolas.pinto@metlife.cl'
                    cc=[],
                    bcc=[],
                    body_file=temp_body_file,
                    wrapper_file=temp_wrapper_file,
                    environment="dev",
                    attachments=[resume_excel_path]
                )
                
            finally:
                # Limpiar archivos temporales
                for temp_file in [temp_body_file, temp_wrapper_file]:
                    try:
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                    except Exception:
                        pass  # No es crítico si no se pueden eliminar los archivos temporales
            
        except Exception as e:
            logging.error(f"Error enviando email ejecutivo: {e}")
            return False

    def _assess_pii_risk_level(self, files_with_pii: int, total_files: int, total_detections: int) -> dict:
        """
        Evalúa el nivel de riesgo estratégico basado en métricas PII.
        
        Args:
            files_with_pii: Número de archivos con PII detectado
            total_files: Total de archivos procesados
            total_detections: Total de detecciones PII
            
        Returns:
            dict: Información del nivel de riesgo con etiqueta, descripción y CSS
        """
        if files_with_pii == 0:
            return {
                'label': 'RIESGO MÍNIMO',
                'description': 'No se detectaron exposiciones de información personal. La organización mantiene un control efectivo de datos sensibles.',
                'css_class': 'risk-low'
            }
        
        # Calcular porcentaje de exposición
        exposure_rate = (files_with_pii / total_files) * 100 if total_files > 0 else 0
        avg_detections_per_file = total_detections / files_with_pii if files_with_pii > 0 else 0
        
        if exposure_rate <= 10 and avg_detections_per_file <= 5:
            return {
                'label': 'RIESGO BAJO',
                'description': 'Exposición limitada de PII detectada. Se recomienda revisión preventiva y implementación de controles adicionales.',
                'css_class': 'risk-low'
            }
        elif exposure_rate <= 25 or avg_detections_per_file <= 15:
            return {
                'label': 'RIESGO MODERADO',
                'description': 'Nivel de exposición PII que requiere atención inmediata. Se sugiere auditoría de procesos y capacitación del personal.',
                'css_class': 'risk-medium'
            }
        else:
            return {
                'label': 'RIESGO ALTO',
                'description': 'Exposición significativa de información personal identificada. Requiere intervención ejecutiva inmediata y plan de remediación.',
                'css_class': 'risk-high'
            }

    def _generate_strategic_recommendations(self, risk_level: dict, files_with_pii: int, total_files: int) -> str:
        """
        Genera recomendaciones estratégicas basadas en el nivel de riesgo.
        
        Args:
            risk_level: Información del nivel de riesgo
            files_with_pii: Archivos con PII detectado
            total_files: Total de archivos
            
        Returns:
            str: HTML con recomendaciones estratégicas
        """
        recommendations_html = ""
        
        if 'MÍNIMO' in risk_level['label'] or 'BAJO' in risk_level['label']:
            recommendations_html += """
                
            """
        
        elif 'MODERADO' in risk_level['label']:
            recommendations_html += """
                
                
            """
        
        else:  # RIESGO ALTO
            recommendations_html += """
                
                
                
            """
        
        # Agregar recomendación general de monitoreo
        recommendations_html += """
        """
        
        return recommendations_html

    def get_available_methods(self) -> Dict[str, bool]:
        """Check availability of different detection methods"""
        available = {}
        
        # Check regex method (always available)
        available["regex"] = True
        
        # Check ML method dependencies
        try:
            import spacy
            import transformers
            available["ml"] = True
        except ImportError:
            available["ml"] = False
        
        # Hybrid available if ML is available
        available["hybrid"] = available["ml"]
        
        return available


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description="S3 PII Detection Orchestrator")
    parser.add_argument(
        "--method", 
        choices=["regex", "ml", "hybrid"],
        default="hybrid",
        help="Detection method to use (default: hybrid)"
    )
    parser.add_argument(
        "--config", 
        type=str,
        help="Path to configuration file"
    )
    parser.add_argument(
        "--log-level", 
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )
    parser.add_argument(
        "--check-methods",
        action="store_true", 
        help="Check availability of detection methods and exit"
    )
    
    args = parser.parse_args()
    
    # Initialize logging
    start_logging(logs_level=args.log_level, show_console_logs=True, save_logs=True)
    
    try:
        # Load configuration
        if args.config:
            # Custom config loading logic here if needed
            config = read_config()
        else:
            config = read_config()
        
        # Override method from command line
        if "ENVIRONMENT" not in config:
            config["ENVIRONMENT"] = {}
        config["ENVIRONMENT"]["DETECTION_METHOD"] = args.method
        
        # Initialize orchestrator
        orchestrator = S3PIIOrchestrator(config=config)
        
        # Check methods if requested
        if args.check_methods:
            available = orchestrator.get_available_methods()
            print("Available detection methods:")
            for method, is_available in available.items():
                status = "✓" if is_available else "✗"
                print(f"  {status} {method}")
            return 0
        
        # Run detection
        logging.info(f"Starting PII detection with method: {args.method}")
        success = orchestrator.run_detection()
        
        if success:
            logging.info("PII detection completed successfully")
            return 0
        else:
            logging.error("PII detection failed")
            return 1
            
    except KeyboardInterrupt:
        logging.info("Detection interrupted by user")
        return 1
    except Exception as e:
        logging.error(f"Orchestration error: {e}")
        return 1


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")
    state = S3PIIOrchestrator(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
