# S00 Change Detector & Regional Hub Backup — Detailed Process

This document explains the purpose, design, and step-by-step behavior of the S00 SharePoint Change Detector with Regional Hub Backup implemented in `src/process_scripts/S00_change_detector_backup.py`.

## High-level purpose

- Detects changes (new / modified / deleted) in SharePoint-synchronized folders.
- Backs up changed files to a Regional Hub structure.
- Copies OCR-compatible files to the OCR input folder (`input/_file_input`) when they need PII processing.
- Produces standardized metadata (JSON + Excel) and backup reports in `output/_others` and `output/backup_reports`.

## Main entrypoint

- `S00ChangeDetectorBackup.run_flow()` is the standard framework entrypoint. It initializes the environment, performs detection and backup cycles, saves snapshots and metadata, and returns a boolean success value.

## Initialization

- Loads configuration via `Config().build_config()`.
- Reads `SHAREPOINT_SITES` configuration block.
- Resolves and ensures required directories exist:
  - `process_data/backup_snapshots`
  - `output/backup_reports`
  - `input/_file_input`
  - `output/_others` (metadata storage)
- Sets behavior flags:
  - `enable_file_hashing` (MD5)
  - `file_types_allowed`
  - `max_file_size_mb`
  - `exclude_folders`

## Data models

- `FileChange` dataclass: represents a detected change — fields include `file_path`, `change_type`, `site_id`, `country`, `file_size`, timestamps, `file_hash`, and `backup_path`.
- `SiteSnapshot` dataclass: represents a snapshot of a site folder at a point in time, listing files and totals. Snapshots are saved as JSON files.

## Scan and snapshot generation

- `scan_folder()` walks the local synced folder tree, excludes configured folders, filters by allowed file types, and gathers `file_info` for each file including size, mtime, ctime, and optionally MD5 hash.
- `generate_site_snapshot(site_name)` builds a `SiteSnapshot` from current state and saves it.
- `_save_snapshot()` writes a snapshot JSON file under `process_data/backup_snapshots`.

## Change detection

- `_load_previous_snapshot(site_name)` loads the previous snapshot JSON when present.
- `detect_changes_and_backup(site_name, current_snapshot, previous_snapshot)` compares snapshots and determines:
  - New files (present in current, not in previous)
  - Modified files (present in both but hash or mtime changed)
  - Deleted files (present in previous, missing in current)
- For new/modified files, the flow creates a `FileChange` and calls backup routines.

## Backup logic

- `_backup_file_to_regional_hub()` computes the target path under `REGIONAL_HUB/country/...`, ensures folders exist, and copies the file with `shutil.copy2()`.
- `_generate_unique_backup_filename()` prevents overwriting by appending timestamp or counter for modified files.
- After backing up, metadata `FileChange.backup_path` is populated.

## OCR input decisions

- `_is_ocr_compatible_file()` checks extensions (`.docx`, `.doc`, `.pdf`) for OCR copying.
- `_clean_ocr_input_directory()` removes previous files from `input/_file_input` on run start.
- `_copy_to_ocr_input()` builds a destination filename prefixed with the country (e.g., `Chile - filename.docx`), ensures uniqueness, and copies the file to the OCR input folder.

## PII processing decision

- `_needs_pii_processing(file_path, relative_path)` decides whether the file needs PII processing or can be skipped:
  - If `files_metadata.xlsx` is missing, assumes processing is needed (safe default on first run).
  - Reads `files_metadata.xlsx` and attempts to match the file by `original_filename` or fuzzy matching.
  - If a metadata record exists and `pii_analysis_completed == True` with a `pii_analysis_timestamp` newer than the file's mtime, it skips processing.
  - Otherwise, it queues the file for OCR/PII processing.

## Metadata generation and saving

- `_create_standardized_metadata(change)` builds a dict for each `FileChange` with normalized fields including `file_id` (uuid), lifecycle status mapping (`new` -> `nuevo_archivo`), sizes, hashes, timestamps, and PII-related flags.
- `_generate_metadata_from_changes(all_changes)` and `_save_standardized_metadata()` append to `self.metadata_list` and save both JSON and Excel files in `output/_others`.

## Reporting & cleanup

- Per-site `backup_report.json` files are saved to `output/backup_reports` with lists of changes and stats.
- `_generate_backup_summary_report()` produces a consolidated summary of all sites processed.
- `_cleanup_old_snapshots()` removes snapshots older than retention_days to avoid disk growth.

## Utilities

- `_calculate_file_hash()` implements MD5 hashing in chunks (safe for large files).
- `_file_changed()` compares MD5 hashes when available or falls back to size and mtime.
- `_map_change_type_to_lifecycle()` maps change types to lifecycle statuses used in metadata.

## Troubleshooting and caveats

- Filename matching between actual files and `files_metadata.xlsx` must be consistent. If new prefixes/suffixes are added when copying to OCR input, matching may fail and files may be reprocessed.
- Timezone or format mismatches in `pii_analysis_timestamp` may cause incorrect skip decisions; ensure timestamps are normalized.
- MD5 hashing is default but can be disabled in config to save CPU on large runs.
- Excel files may be locked by users — reading/writing may fail; code falls back to safe defaults (process file) when metadata cannot be read.

## Suggested improvements (optional)

- Use `file_hash` matching as primary key for metadata matching when available.
- Add a configurable allowlist for country prefixes used in OCR filenames to make matching more robust.
- Write a small CLI or unit tests for `_needs_pii_processing()` to validate matching heuristics.

---

Detailed step-by-step folder status detection and email fix

The S3 email/status issue was caused because the per-folder "Tipo de Detección" was being determined from the PII analysis DataFrame instead of the authoritative `files_metadata.xlsx` file. The fix implemented in `src/process_scripts/S3_pii_orchestrator.py` does the following:

- Primary source of truth: read `output/_others/files_metadata.xlsx` for `lifecycle_status` (e.g., `nuevo_archivo`, `modificado`, `sin_cambios`).
- If found, translate those values using `status_mapping` to user-friendly Spanish labels (e.g., `Archivo Nuevo`).
- Matching strategies include filename containment checks and source_region matching to handle different naming conventions.
- Fallback: only if metadata isn't present or matching fails, use the PII DataFrame `Status_file` as a fallback source.

This ensures that files that are new in metadata (e.g., `nuevo_archivo`) show the correct "Archivo Nuevo" in email reports rather than incorrectly displaying "Sin Cambios".

## S1: Download Files and Split — Detailed Process

This section documents `src/process_scripts/S1_download_files_and_split.py` (class `S1_FileOrganizer`). It explains the purpose, detailed workflow, key functions, configuration hooks, outputs, common edge cases, and suggested improvements.

### Purpose / Summary

- Organize incoming documents (Word, PDF, ZIP) found in the configured download folder.
- Convert Word documents to PDF (Windows only via COM / Word installed).
- Extract images from PDFs, Word documents and ZIP archives into a per-file `images/` folder.
- Extract page-by-page text from PDFs and save individual page `.txt` files (and a transient combined text file which the script removes immediately).
- Produce a lightweight processing summary (`S1_summary.json`) in the process data folder for downstream steps.

### Contract (inputs / outputs / error modes)

- Inputs
  - Files in the configured download folder (config key: `DOWNLOAD_FOLDER`). Supported extensions: `.pdf`, `.docx`, `.doc`, `.zip`.
  - Optional: `pdfplumber` installed for improved PDF text extraction; otherwise PyMuPDF (`fitz`) is used.
  - On Windows: Microsoft Word must be installed for Word->PDF conversion and for the win32 image extraction path.

- Outputs
  - For each processed file a folder is created under the download folder named after the file (no extension). Inside:
    - `images/` — extracted images (PNG by convention)
    - `extracted_text/` — per-page `.txt` files; optionally a combined text file (temporary)
    - original file (moved into that folder)
  - `S1_summary.json` saved to the configured process data directory (`DOWNLOAD_FOLDER` by default in this script) containing counts and a per-folder summary.

- Error modes / failure behavior
  - The script continues processing other files if a single-file operation fails; errors are logged and do not stop the whole run.
  - Word conversion or COM failures return None and the flow proceeds without conversion for that file.
  - If no files are found the script returns False and logs a warning.

### High-level step-by-step flow

1. Initialization
   - The class extends the project's `ProcessBase` and reads configuration via `Config()` utilities.
   - Key runtime attributes: `input_dir` (DOWNLOAD_FOLDER), `output_dir` (OUTPUT_FOLDER), `process_data_dir` (DOWNLOAD_FOLDER). A text extraction option `save_individual_pages` is read from `text_extraction.save_individual_pages`.
   - Required folders are created if missing.

2. Discover files to process
   - `organize_files()` lists the `input_dir` and selects files with supported extensions.
   - If none found, the function logs and returns.

3. Per-file processing (`_process_single_file`)
   - Create a folder for the file (basename without extension).
   - Move the original file into that folder.
   - Dispatch by extension:
     - PDF: extract images (`_extract_images_from_pdf`) and extract page-by-page text (`_extract_text_from_pdf_page_by_page`).
     - DOC/DOCX: extract images via COM (`_extract_images_from_word_win32com`), convert to PDF (`_convert_word_to_pdf`) using Word COM, then run the PDF text extraction on the converted PDF.
     - ZIP: extract image files from the ZIP (`_extract_images_from_zip`).
   - The method returns True if either image extraction or text extraction succeeded.

4. PDF text extraction
   - `_extract_pages_from_pdf()` tries `pdfplumber` first (if available) for higher quality text extraction; falls back to PyMuPDF (`fitz`).
   - `_extract_text_from_pdf_page_by_page()` cleans extracted page text with `_clean_extracted_text()` and writes individual page `.txt` files when `save_individual_pages` is True.
   - The script also creates a combined text string (pages joined with " / ") and writes a combined `_all_pages.txt` file — but then it immediately removes that combined file (used transiently). Per-page files remain.

5. Image extraction
   - PDFs: `_extract_images_from_pdf()` iterates every page's image list using PyMuPDF, saves images as PNG to `images/` folder.
   - Word files: `_extract_images_from_word_win32com()` uses the Word COM API to iterate InlineShapes, copy each shape to the clipboard, then `ImageGrab.grabclipboard()` to obtain the image and save it. This is a Windows-only approach and is sensitive to clipboard state.
   - ZIPs: `_extract_images_from_zip()` extracts entries with image-like extensions and saves them to `images/`.

6. Summary and save
   - After processing files the run collects counts per processed folder via `get_processing_summary()` and writes `S1_summary.json` using `save_json_file()`.

### Key functions and responsibilities (map to code)

- `organize_files()` — orchestration: discover files, iterate and call `_process_single_file`.
- `_process_single_file(file_path)` — create folders, move file, dispatch to specific extract/convert methods.
- `_convert_word_to_pdf(word_path, output_folder)` — use win32com Word automation to export PDF. Requires MS Word and Windows.
- `_extract_pages_from_pdf(pdf_path)` — extract page text using `pdfplumber` (preferred) or `fitz` fallback.
- `_extract_text_from_pdf_page_by_page(pdf_path, output_folder)` — create per-page text files and combined transient file.
- `_extract_images_from_pdf`, `_extract_images_from_word_win32com`, `_extract_images_from_zip` — image extraction per-format.
- `_clean_extracted_text(text)` — sanitize and normalize text: control character removal, whitespace normalization, and trimming.
- `get_processing_summary()` — produce a structured dict summarizing processed folders and counts.
- `run_flow()` — top-level entrypoint executed by the runner; saves summary to `S1_summary.json` and ensures logging output.

### Configuration keys used (where to change behavior)

- `DOWNLOAD_FOLDER` (config env) — source folder where input files are discovered and where per-file folders are created.
- `OUTPUT_FOLDER` (config env) — general output folder (the script writes logs and may use this for other outputs; the primary per-file structure is created under `DOWNLOAD_FOLDER`).
- `text_extraction.save_individual_pages` (optional) — boolean to enable/disable writing individual page `.txt` files. Defaults to True in code.

### Files and artifacts produced

- Per-file folder structure under `DOWNLOAD_FOLDER/<basename>/` containing:
  - `<original_filename>` (moved file)
  - `images/` (extracted PNGs and other image files)
  - `extracted_text/` (individual `page_X_filename.txt` files and a transient `*_all_pages.txt` that is removed)
- `S1_summary.json` in `process_data_dir` (in this script points to the download folder) with a summary of counts used by the orchestrator or for debugging.

### Edge cases, caveats and operational notes

- Word COM dependencies: The Word->PDF conversion and Word image extraction rely on Microsoft Word via `win32com`. This makes the script Windows-only for those features and requires Word to be installed and accessible from the running user.
- Clipboard-based image extraction is fragile: other processes or user activity can interfere. It is preferable to extract image binary data directly from the Word document if possible (e.g., by unzipping `.docx` and extracting `word/media/*` or using python-docx utilities).
- `pdfplumber` is optional: when not installed the script falls back to `PyMuPDF` which may produce different extraction quality. Consider adding `pdfplumber` to `requirements.txt` if better extraction is required.
- Large PDFs and memory: PyMuPDF extracts pages in-memory; extremely large documents may need streaming or page-limited processing.
- Temporary combined text file is deleted by design. If you need the combined text persisted, remove the deletion step or add a config flag.
- File locking: Moving files from `DOWNLOAD_FOLDER` may fail if another process holds a handle; the script logs and continues.

### Troubleshooting tips

- If Word conversion fails with COM errors, verify:
  - Microsoft Word is installed and licensed for the account running the script.
  - The process has desktop/clipboard access (for image extraction) — running as a background service without interactive desktop may fail.
- If no text is extracted from PDFs, install `pdfplumber` (pip install pdfplumber) and retry; compare results between `pdfplumber` and `PyMuPDF`.
- If images from Word are missing or corrupted, stop other clipboard-using applications during a run, or replace the clipboard extraction method with direct `.docx` archive extraction.

### Suggested low-risk improvements (quick wins)

- Replace clipboard-based Word image extraction with extraction from the `.docx` zip container (look for `word/media/` files) to avoid clipboard fragility.
- Persist the combined `_all_pages.txt` behind a config flag instead of always deleting it.
- Add a small retry/backoff when moving files to handle transient file-locks.
- Add a `max_pages` config to avoid processing extremely large PDFs in one run.
- Add unit tests for `_clean_extracted_text()` and `_extract_pages_from_pdf()` using small test fixtures.

### How to run / quick commands (Windows PowerShell)

To run the S1 script directly (module contains a runnable `__main__`):

```powershell
# run the script file directly
py src\process_scripts\S1_download_files_and_split.py

# or run via the project runner (recommended if you use the project's runner)
py runner.py
```

---

What I did next

- I appended this S1 analysis to `docs/details_process.md`. If you'd like, I can now:
  - Add a short example unit test for `_clean_extracted_text()` and `_extract_pages_from_pdf()`.
  - Replace the Word clipboard image extraction with a helper that extracts `word/media/*` from `.docx` files (low-risk, reversible change).

Tell me which follow-up you'd prefer and I'll implement it.

## S2: Image Preprocessing and Enhancement — Detailed Process

This section documents `src/process_scripts/S2_preprocessing_images.py` (class `S2_ImagePreprocessor`). It explains the purpose, detailed workflow, key functions, configuration hooks, outputs, constraints, and suggested improvements.

### Purpose / Summary

- Enhance image quality for improved OCR results (denoise, sharpen, contrast, upscaling).
- Classify images (tabular/excel/document/ui) to apply specialized pipelines per type.
- Provide AI-super-resolution (when model files are available) with safe fallbacks to traditional upscaling.
- Produce a processing summary (`S2_summary.json`) for downstream monitoring.

### Contract (inputs / outputs / error modes)

- Inputs
  - Per-file `images/` folders created by S1 under the configured `DOWNLOAD_FOLDER`.
  - OpenCV (`cv2`) and NumPy installed; optional deep-learning super-resolution models placed under `SR_MODELS`.
  - Config environment keys (see section below). 

- Outputs
  - Enhanced images saved in-place (the script writes enhanced images back to the image path or saves enhanced copies depending on internal calls).
  - Metadata JSON files per enhanced image (`*_metadata.json`) describing original/enhanced sizes and applied steps.
  - `S2_summary.json` saved to the `process_data_dir` with counts per folder.

- Error modes / failure behavior
  - The script logs errors and continues processing other images/folders rather than failing the whole run.
  - Missing AI models or failures in super-resolution fall back to traditional interpolation upscaling.
  - If no folders or images are found the script returns False and logs a warning.

### High-level step-by-step flow

1. Initialization
   - The class extends `ProcessBase` and reads configuration via framework utilities.
   - Important attributes set: `input_dir` (DOWNLOAD_FOLDER), `output_dir` (OUTPUT_FOLDER), `process_data_dir` (DOWNLOAD_FOLDER). The code also references `self.enhancement_params` which is expected to be provided via config or initialized in `ProcessBase` (verify this in your config or initialization path).
   - Creates required folders if missing.

2. Discover folders with images
   - `process_all_folders()` walks `input_dir` and finds subfolders (excluding `_file_input`) that contain an `images/` folder.
   - Aggregates a list of folders to be processed.

3. Per-folder enhancement (`improve_images_in_folder`
   - Lists image files in `images/` with common extensions.
   - For each image calls one of the enhancement methods. By default the code calls `improve_image_quality_basic()` (the basic faster pipeline). Other available methods are:
     - `improve_image_quality_test()` — a multi-step proven pipeline with bilateral filtering, CLAHE, sharpening, multi-step upscaling, Laplacian edge enhancement.
     - `improve_image_quality()` — attempts AI Super-Resolution via OpenCV DNN super-resolution (`cv2.dnn_superres`) using models from `SR_MODELS`, with fallback to traditional resizing when model is missing or fails.
   - Tracks successes and logs progress per folder.

4. Image classification and per-type pipeline
   - `_classify_image_type()` analyzes geometry, Hough line detection, and orientation to classify images as `excel`, `table`, `document`, or `ui`.
   - `_apply_enhancement_pipeline()` applies a common noise reduction and then delegates to type-specific enhancers:
     - `_enhance_tabular_image()` — adaptive thresholding, morphological close to preserve table lines.
     - `_enhance_document_image()` — Gaussian blur + OTSU threshold to improve text contrast.
     - `_enhance_ui_image()` — CLAHE on LAB L-channel for UI screenshots.
   - Post-processing steps include contrast enhancement (`_enhance_contrast`) and sharpening (`_apply_sharpening`), plus optional resize based on `self.enhancement_params`.

5. Metadata and summary
   - `_enhance_single_image()` writes a metadata JSON next to the enhanced image describing original/enhanced sizes and applied operations.
   - After all folders are processed, `get_processing_summary()` collects counts and writes `S2_summary.json`.

### Key functions and responsibilities (map to code)

- `process_all_folders()` — find folders containing images and orchestrate folder processing.
- `improve_images_in_folder(folder_path)` — iterate images and call selected enhancement method(s).
- `improve_image_quality_basic(image_path)` — fast, deterministic pipeline using Gaussian blur, unsharp mask, and traditional upscaling.
- `improve_image_quality_test(image_path)` — higher-quality pipeline with bilateral filter, CLAHE, unsharp masking, progressive upscaling, and Laplacian-based edge enhancement.
- `improve_image_quality(image_path)` — tries AI Super-Resolution using OpenCV `dnn_superres` with models in `SR_MODELS`; falls back to standard resizing.
- `_classify_image_type(image)` — heuristic classifier using edge/line detection and orientation.
- `_apply_enhancement_pipeline(image, image_type)` — orchestrates type-specific transforms and shared post-processing.
- `_enhance_tabular_image`, `_enhance_document_image`, `_enhance_ui_image`, `_enhance_contrast`, `_apply_sharpening` — modular processing steps.
- `get_processing_summary()` — build a dict of processed folders and counts; used to save `S2_summary.json`.

### Configuration keys referenced / required

- `DOWNLOAD_FOLDER` — input root where S1 placed per-file folders with `images/`.
- `OUTPUT_FOLDER` — general output folder (used for logs/other outputs).
- `SR_MODELS` folder — AI super-resolution model files (the code uses an absolute path in the repo `SR_MODELS/` by default). Put supported `.pb` model files there if you want AI SR.
- `self.enhancement_params` — the code expects a dict-like structure containing keys such as `noise_reduction`, `contrast_enhancement`, `sharpening`, and `resize_factor`. Ensure this is present in `Config()` or initialized in `ProcessBase`.

If `self.enhancement_params` is not defined at runtime the pipeline will raise an AttributeError; confirm config or add defaults.

### Files and artifacts produced

- Enhanced images (saved in-place or as `*_enhanced.png` depending on the code path).
- Per-image metadata JSON files (`<name>_metadata.json`)
- `S2_summary.json` in `process_data_dir` with folder-level counts.

### Edge cases, caveats and operational notes

- CPU/GPU and memory: AI super-resolution models can be memory- and compute-heavy. Use smaller models or non-AI fallback for large batches or resource-constrained hosts.
- Model availability: The script expects model files in `SR_MODELS` (e.g., `EDSR_x2.pb`). The code currently hardcodes a repo path — consider making this a config value.
- `self.enhancement_params` must be defined in config; otherwise several pipeline steps assume keys that may not exist. Add safe defaults during initialization.
- Hough line detection is sensitive to noisy images; classifier heuristics may mislabel photos or mixed-content images. Consider adding a small ML classifier or threshold-based fallback.
- Writing images back to the same path overwrites originals; if you need originals preserved, change the save path to an `_enhanced` sibling filename (the code already sometimes writes `*_enhanced.png`).
- Windows vs Linux: This script uses only OpenCV and NumPy and is OS-agnostic for image processing. The AI SR model loading via `cv2.dnn_superres` is cross-platform but check library compatibility on non-Windows systems.

### Troubleshooting tips

- If `cv2.dnn_superres` raises errors: verify OpenCV was built with DNN SuperRes support. If model fails to load, check file path and model compatibility (correct `.pb` format).
- If `self.enhancement_params` missing: set defaults in your config or modify `S2_ImagePreprocessor.__init__` to assign a safe default dict, e.g.:

```python
self.enhancement_params = self.config.get('image_enhancement', {
    'noise_reduction': True,
    'contrast_enhancement': True,
    'sharpening': True,
    'resize_factor': 1.0
})
```

- If classification mislabels many images, temporarily skip `_classify_image_type()` and run a fixed pipeline to compare OCR performance.

### Suggested low-risk improvements (quick wins)

- Add default `self.enhancement_params` in `__init__` to avoid runtime AttributeErrors.
- Make the SR models folder path configurable via `config.jsonc` instead of using a hardcoded repo path.
- Add an option to write enhanced images to a separate folder (e.g., `images_enhanced/`) to preserve originals and enable safe rollbacks.
- Parallelize the per-image processing using a small thread/process pool with a configurable concurrency limit to speed up large batches.
- Add unit tests for `_classify_image_type()` using synthetic images (tables, photos, UI screenshots) and for the small enhancement functions using deterministic inputs.

### How to run / quick commands (Windows PowerShell)

```powershell
# run the S2 script directly
py src\process_scripts\S2_preprocessing_images.py

# or run via the project runner
py runner.py
```

---

Progress update

- Appended the S2 analysis to `docs/details_process.md` (done).

Next suggested action

- I can now implement a safe default for `self.enhancement_params` in `S2_preprocessing_images.py` and make the `SR_MODELS` path configurable; both are small, low-risk changes that prevent runtime errors and improve maintainability. Would you like me to make those changes and run a quick static check?


