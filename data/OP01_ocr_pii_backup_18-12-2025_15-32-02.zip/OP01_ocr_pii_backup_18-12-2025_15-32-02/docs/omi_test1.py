#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script template 1 for process validation
Compatible with Python 3.13.4
file_name: _base_process_class.py
modified_on: 2024-01-03 ; daniel.hermosilla.omi ; Template
"""

import os
import sys
import shutil
import logging
import datetime as dt
import pytesseract
import spacy
import cv2
import numpy as np
import pandas as pd
import zipfile
import re
import unicodedata
import fitz  # PyMuPDF
from src.utils.fmw_utils import *
from src.utils.selenium_utils import *
from src.utils.credentials_utils import *
from src.process_scripts.base_process import ProcessBase
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) )  # move to modules 

# Load Spanish NER model (install with: python -m spacy download es_core_news_sm)
try:
    nlp = spacy.load("es_core_news_lg") # es_core_news_md es_core_news_lg 
    NER_AVAILABLE = True
except OSError:
    print("Warning: Spanish NER model not found. Install with: python -m spacy download es_core_news_sm")
    print("Falling back to basic pattern matching for names.")
    NER_AVAILABLE = False


# Set the Tesseract-OCR data path
os.environ['TESSDATA_PREFIX']         = r"C:\Users\veraan\AppData\Local\Programs\Tesseract-OCR\tessdata"
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\veraan\AppData\Local\Programs\Tesseract-OCR\tesseract.exe"

class process_files_input(ProcessBase):
    def extract_pii_from_text(self, text: str) -> list:
        """
        Extracts PII entities from text using spaCy NER (if available) and custom regex patterns.
        Returns a list of dicts: {PII_Type, PII_Value, Confidence, Source}
        """
        results = []
        try:
            # Use global spaCy model if available
            if 'NER_AVAILABLE' in globals() and NER_AVAILABLE:
                try:
                    doc = nlp(text)
                    for ent in doc.ents:
                        if ent.label_ in ["PER", "ORG", "LOC", "MISC"]:
                            results.append({
                                "PII_Type": ent.label_,
                                "PII_Value": ent.text,
                                "Confidence": None,
                                "Source": "spaCy",
                                "start_pos": ent.start_char,
                                "end_pos": ent.end_char,
                                "pattern": None,
                                "label": ent.label_
                            })
                except Exception as e:
                    logging.warning(f"spaCy NER failed: {e}")
            # Custom regex for IDs, phones, emails, health, sex, etc.
            patterns = {
                # More flexible ID patterns for Brazil (CPF/RG)
                "RUT": r"\b\d{1,2}[.\s]?\d{3}[.\s]?\d{3}-[\dkK]\b",
                "CPF": r"\b\d{3}[.\s]?\d{3}[.\s]?\d{3}-\d{2}\b",
                "RG": r"\b\d{1,2}[.\s]?\d{3}[.\s]?\d{3}-?[\dX]\b",
                
                "SpanishName": r"\b([A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}){1,3})\b",
                
                # More flexible phone pattern for international formats
                "Phone": r"\(?\+?\d{1,3}\)?[\s.-]?\(?\d{2,4}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}\b",
                
                # Context-aware account number pattern to reduce false positives
                "Account": r"\b(?:cuenta|c[/\.]c|n[°º] de cuenta|account no|nro\.\s*cuenta)\s*:?\s*(\d{6,20})\b",
                
                "Email": r"\b[\w\.-]+@[\w\.-]+\.\w+\b",
                
                # Expanded keyword lists for better coverage
                "Health": r"\b(salud|m[eé]dico|cl[ií]nico|hospital|biometr[ií]a|enfermedad|diagn[oó]stico|tratamiento|paciente|doctor)\b",
                "Sex": r"\b(sexual|sexo|orientación sexual|g[eé]nero)\b",
                "Address": r"\b(calle|cll|avenida|av|direcci[oó]n|domicilio|residencial|ciudad|comuna|piso|depto)\b",
                
                # Improved date pattern to include named months
                "Date": r"\b(\d{1,2}[-/\s](?:ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic|enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|\d{1,2})[-/\s]\d{2,4})\b"
            }
            
            # Require 2-4 capitalized words, each at least 3 letters, not all-caps, and not in exclusion list
            SPANISH_NAME_EXCLUDE = set([
                "RELACIÓN", "SEXO", "INVALIDEZ", "FECHA", "NACIMIENTO", "RENTA", "CONYUGE", "HIJOS", "FEMENINO", "MASCULINO","COTIZADOR","ESTUDIO","PRODUCCION","OPERACION","COTIZACION","TRASPASO","VALIDACION",
                "CAMPOS","POLIZAS","BENEFICIARIOS", "CONTROL", "ARCHIVO", "AYUDA", "REGISTROS", "VENTANA", "CLIENTE", "CLIENTA","PRODUCCION", "SEGURO", "VEJEZ","CONSULTA", "IMPRIME","ADMINISTRADOR","NUMERO"
            ])
            
            for pii_type, pattern in patterns.items():
                if pii_type == "SpanishName":
                    # Custom post-filter for SpanishName to reduce false positives
                    for match in re.finditer(pattern, text):
                        value = match.group(1) if match.lastindex else match.group(0)
                        words = value.split()
                        # Exclude if any word is in exclusion list or if all words are uppercase (likely labels)
                        if any(w.upper() in SPANISH_NAME_EXCLUDE for w in words):
                            continue
                        if all(w.isupper() for w in words):
                            continue
                        # Only add if 2-4 words and at least one word longer than 3 letters
                        if 2 <= len(words) <= 4 and any(len(w) > 3 for w in words):
                            results.append({
                                "PII_Type": pii_type,
                                "PII_Value": value,
                                "Confidence": None,
                                "Source": "regex",
                                "start_pos": match.start(1) if match.lastindex else match.start(0),
                                "end_pos": match.end(1) if match.lastindex else match.end(0),
                                "pattern": pattern,
                                "label": pii_type
                            })
                else:
                    for match in re.finditer(pattern, text, re.IGNORECASE):
                        value = match.group(1) if match.lastindex else match.group(0)
                        results.append({
                            "PII_Type": pii_type,
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": match.start(1) if match.lastindex else match.start(0),
                            "end_pos": match.end(1) if match.lastindex else match.end(0),
                            "pattern": pattern,
                            "label": pii_type
                        })
        except Exception as e:
            logging.error(f"Error extracting PII: {e}")
        return results

    def clean_ocr_text(self, text: str) -> list:
        """
        Cleans OCR text for better NER/PII extraction with advanced normalization.
        - Unicode normalization (NFKC)
        - Fixes hyphenated word breaks
        - Removes weird symbols while preserving PII-relevant characters
        - Collapses multiple spaces
        - Splits by '|'
        - Removes stop words
        - Strips whitespace and normalizes text
        Returns a list of tuples: (cleaned_line, line_number).
        """
        try:
            # Step 1: Unicode normalization (NFKC) - handles accented chars and special Unicode
            text = unicodedata.normalize('NFKC', text)
            
            # Step 2: Fix hyphenated word breaks (e.g., "docu-\nmento" -> "documento")
            # Common OCR patterns: word-\n, word- \n, word-\r\n
            text = re.sub(r'(\w+)-\s*[\r\n]+\s*(\w+)', r'\1\2', text)
            text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)  # Handle "docu- mento"
            
            # Step 3: Remove weird symbols but preserve important characters for PII detection
            # DO NOT REMOVE '.' and '-' (for IDs), keep @/+()[] for emails/phones/IDs/addresses
            # Keep common punctuation: ,;:'"
            text = re.sub(r"[^\w\s@.\-/+()[\],;:'\"áéíóúüñÁÉÍÓÚÜÑ-]", ' ', text)
            
            # Step 4: Replace multiple spaces with single space
            text = re.sub(r'\s+', ' ', text)
            
            # Load Spanish stop words (spaCy or fallback)
            try:
                if 'NER_AVAILABLE' in globals() and NER_AVAILABLE:
                    stopwords = nlp.Defaults.stop_words
                else:
                    raise Exception("spaCy not available")
            except Exception:
                stopwords = set([
                    "de", "la", "que", "el", "en", "y", "a", "los", "del", "se", "las", "por", "un", "para", "con", "no", "una", "su", "al", "lo", "como", "más", "pero", "sus", 
                    "le", "ya", "o", "este", "sí", "porque", "esta", "entre", "cuando", "muy", "sin", "sobre", "también", "me",
                    "hasta", "hay", "donde", "quien", "desde", "todo", "nos", "durante", "todos",
                    "uno", "les", "ni", "contra", "otros", "ese", "eso", "ante", "ellos", "e", "esto", 
                    "mí", "antes", "algunos", "qué", "unos", "yo", "otro", "otras", "otra", "él", "tanto", "esa", "estos", 
                    "mucho", "quienes", "nada", "muchos", "cual", "poco", "ella", "estar", "estas",
                    "algunas", "algo", "nosotros", "mi", "mis", "tú", "te", "ti", "tu", "tus", "ellas",
                    "nosotras", "vosotros", "vosotras", "os", "mío", "mía", "míos", "mías", "tuyo", "tuya", "tuyos",
                    "tuyas", "suyo", "suya", "suyos", "suyas", "nuestro", "nuestra", "nuestros", "nuestras",
                    "vuestro", "vuestra", "vuestros", "vuestras", "esos", "esas", "estoy", "estás", "está",
                    "estamos", "estáis", "están", "esté", "estés", "estemos", "estéis", "estén", "estaré", 
                    "estarás", "estará", "estaremos", "estaréis", "estarán", "estaría", "estarías", 
                    "estaríamos", "estaríais", "estarían", "estaba", "estabas", "estábamos", "estabais",
                    "estaban", "estuve", "estuviste", "estuvo", "estuvimos", "estuvisteis", "estuvieron", "estuviera", 
                    "estuvieras", "estuviéramos", "estuvierais", "estuvieran", "estuviese", "estuvieses",
                    "estuviésemos", "estuvieseis", "estuviesen", "estando", "estado", "estada", "estados",
                    "estadas", "estad"
                ])
            
            # Step 5: Split by '|' and process each line
            lines = [line.strip() for line in text.split('|') if line.strip()]
            cleaned_lines = []
            
            for line_number, line in enumerate(lines, 1):
                # Convert to lowercase for stop word removal (but preserve original case for PII)
                line_lower = line.lower()
                
                # Remove stop words while preserving case and structure
                tokens = []
                words = line.split()
                for word in words:
                    # Keep word if it's not a stop word OR if it contains special chars (emails, IDs, etc.)
                    if (word.lower() not in stopwords or 
                        re.search(r'[@.\-+()]', word) or  # Keep emails, IDs, phones
                        re.search(r'\d', word)):  # Keep words with numbers
                        tokens.append(word)
                
                if tokens:
                    cleaned_lines.append((' '.join(tokens), line_number))
            
            return cleaned_lines
        except Exception as e:
            logging.error(f"Error cleaning OCR text: {e}")
            return []

    def extract_texts_to_excel_from_folder(self, folder_path: str, lang: str = 'spa', output_file: str = None) -> None:
        """
        Extracts text and confidence from all images in a folder using pytesseract OCR and saves results to an Excel file.
        Columns: Page, Image, Text, Confidence score
        Args:
            folder_path (str): Path to the folder containing images
            lang (str): Language for OCR (default 'spa')
            output_file (str): Path to save the Excel file (default: None, will save as 'extracted_texts.xlsx' in folder)
        Usage example:
            >>> self.extract_texts_to_excel_from_folder('path/to/images')
        """
        import pandas as pd
        if output_file is None:
            output_file = os.path.join(folder_path, 'extracted_texts.xlsx')
        images = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        results = []
        for img_file in images:
            img_path = os.path.join(folder_path, img_file)
            try:
                data = np.fromfile(img_path, dtype=np.uint8)
                image = cv2.imdecode(data, cv2.IMREAD_COLOR)
                if image is None:
                    logging.error(f"Failed to read image for OCR: {img_path}")
                    continue
                ocr_data = pytesseract.image_to_data(image, lang=lang, output_type=pytesseract.Output.DICT)
                words = [w for w in ocr_data['text'] if w.strip()]
                text = ' '.join(words)
                confidences = [float(c) for c in ocr_data['conf'] if c != '-1']
                confidence = round(np.mean(confidences), 2) if confidences else None
                match = re.search(r'(?:raw_)?page(\d+)_image(\d+)', img_file)
                if match:
                    page = int(match.group(1))
                    image_num = int(match.group(2))
                else:
                    nums = re.findall(r'(\d+)', img_file)
                    page = int(nums[0]) if len(nums) > 0 else None
                    image_num = int(nums[1]) if len(nums) > 1 else None
                # Clean OCR text before PII extraction
                cleaned_lines = self.clean_ocr_text(text)
                found_pii = False
                for cleaned_line, line_number in cleaned_lines:
                    pii_list = self.extract_pii_from_text(cleaned_line)
                    if not pii_list:
                        continue
                    found_pii = True
                    for pii in pii_list:
                        results.append({
                            'Page': page,
                            'Image': image_num,
                            'Line_Number': line_number,
                            'Text': cleaned_line,
                            'PII_Type': pii['PII_Type'],
                            'PII_Value': pii['PII_Value'],
                            'Confidence score': confidence,
                            'Source': pii.get('Source', '')
                        })
                # If no PII found in any cleaned line, add a row for the image
                if not found_pii:
                    results.append({
                        'Page': page,
                        'Image': image_num,
                        'Line_Number': '',
                        'Text': text,
                        'PII_Type': '',
                        'PII_Value': '',
                        'Confidence score': confidence,
                        'Source': ''
                    })
                logging.info(f"Text, confidence, and PII extracted from {img_file} (Page: {page}, Image: {image_num})")
            except Exception as e:
                logging.error(f"Error extracting text/PII from image {img_file}: {e}")
        
        # Save results to Excel
        df = pd.DataFrame(results, columns=['Page', 'Image', 'Line_Number', 'Text', 'PII_Type', 'PII_Value', 'Confidence score', 'Source'])
        df.to_excel(output_file, index=False)
        logging.info(f"Extracted texts, confidence, and PII saved to {output_file}")

    def extract_text_from_image(self, image_path: str, lang: str = 'spa') -> str:
        """
        Extracts text from an image using pytesseract OCR.
        Args:
            image_path (str): Path to the image file
            lang (str): Language for OCR (default 'spa')
        Returns:
            str: Extracted text from the image
        Raises:
            Exception: If image cannot be read or OCR fails
        Usage example:
            >>> text = self.extract_text_from_image('path/to/image.png')
            >>> print(text)
        """
        try:
            # Read image using np.fromfile to handle non-ASCII paths
            data = np.fromfile(image_path, dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if image is None:
                logging.error(f"Failed to read image for OCR: {image_path}")
                return ''
            # Extract text using pytesseract
            text = pytesseract.image_to_string(image, lang=lang)
            logging.info(f"Extracted text from {image_path}: {text[:100]}...")
            return text
        except Exception as e:
            logging.error(f"Error extracting text from image {image_path}: {e}")
            return ''

    def extract_texts_from_folder(self, folder_path: str, lang: str = 'spa', output_file: str = None) -> None:
        """
        Extracts text from all images in a folder using pytesseract OCR and saves results to a text file.
        Args:
            folder_path (str): Path to the folder containing images
            lang (str): Language for OCR (default 'spa')
            output_file (str): Path to save the extracted texts (default: None, will save as 'extracted_texts.txt' in folder)
        Usage example:
            >>> self.extract_texts_from_folder('path/to/images')
        """
        if output_file is None:
            output_file = os.path.join(folder_path, 'extracted_texts.txt')
        images = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
        with open(output_file, 'w', encoding='utf-8') as out:
            for img_file in images:
                img_path = os.path.join(folder_path, img_file)
                text = self.extract_text_from_image(img_path, lang=lang)
                out.write(f"--- {img_file} ---\n{text}\n\n")
                logging.info(f"Text from {img_file} written to output file.")
    # This is an example of how the funcions you create should look like
    # omi .bless
    def __init__(self, config:dict):
        ProcessBase.__init__(self, config=config) 
        self.state_name    = "Workflow"  # Change with the class name 
        self.now           = dt.datetime.now()
        self.template_parameter_1 = self.config_env["ENV_PARAM_1"]
        self.template_parameter_2 = self.config_global["GLOBAL_PARAM_1"]
        self.input_dir = self.config_env["DOWNLOAD_FOLDER"]
        self.output_dir = self.config_env["OUTPUT_FOLDER"]
        # USE IF YOU NEED DRIVER AND CREDS
        # self.driver        = SeleniumUtils(excecute_headless=False, download_folder=self.dev_data, max_timeout=300)
        # self.creds         = Credentials(config=config, cred_config_name='CREDENTIALS')
        # self.user          = self.creds.desiered_creds_dict['USER']
        # self.password      = self.creds.creds



    def organize_files(self):
        """
        Organizes Word and PDF files in the input directory by creating folders with the same name
        and moving the files into those folders.
        
        Raises:
            Exception: If there are errors during file operations
        """
        try:
            input_dir = self.input_dir
            logging.info(f"Starting file organization in directory: {input_dir}")
            
            # Check if input directory exists
            if not os.path.exists(input_dir):
                raise Exception(f"Input directory does not exist: {input_dir}")
            
            # Get all files in the input directory
            all_files = os.listdir(input_dir)
            document_files = []
            
            # Filter for Word and PDF files
            for file in all_files:
                file_path = os.path.join(input_dir, file)
                if os.path.isfile(file_path) and file.lower().endswith(('.doc', '.docx', '.pdf')):
                    document_files.append(file)
            
            logging.info(f"Found {len(document_files)} document files to process")
            
            if not document_files:
                logging.info("No document files found in the input directory")
                return
            
            # Process each document file
            for doc_file in document_files:
                try:
                    self._process_single_file(doc_file, input_dir)
                except Exception as e:
                    logging.error(f"Error processing file {doc_file}: {str(e)}")
                    raise BusinessException(f"Failed to process document file {doc_file}: {str(e)}")
            
            logging.info("File organization completed successfully")
            
        except Exception as e:
            logging.error(f"Error in organize_files: {str(e)}")
            raise
    
    def _process_single_file(self, doc_file, input_dir):
        """
        Processes a single document file (Word or PDF) by creating a folder and moving the file.
        
        Args:
            doc_file (str): Name of the document file
            input_dir (str): Path to the input directory
        """
        # Get filename without extension for folder name
        file_name_without_ext = os.path.splitext(doc_file)[0]
        
        # Create folder path
        folder_path = os.path.join(input_dir, file_name_without_ext)
        
        # Create the folder
        create_folder(folder_path)
        logging.info(f"Created folder: {folder_path}")
        
        # Source and destination paths
        source_file_path = os.path.join(input_dir, doc_file)
        destination_file_path = os.path.join(folder_path, doc_file)
        
        # Move the file
        shutil.move(source_file_path, destination_file_path)
        logging.info(f"Moved file {doc_file} to folder {file_name_without_ext}")
        
        # Extract images based on file type
        # if doc_file.lower().endswith(('.doc', '.docx')):
        #     self.extract_images_from_word_file(folder_path)
        if doc_file.lower().endswith(('.doc', '.docx')):
            self.extract_images_from_word_win32com(destination_file_path)
        elif doc_file.lower().endswith('.pdf'):
            self.extract_images_from_pdf(folder_path)
    
    def extract_images_from_word_file(self, word_file_path):
        """
        Extracts images from the Word file using zip extraction and saves them in an 'images' subfolder
        in the same folder as the Word file.
        Images are tagged with the page number and image number in page.
        Note: Due to limitations in the DOCX format, real pagination is not available; page number is assumed as 1.

        Args:
            word_file_path (str): Full path to the Word file.
        """
        import zipfile
        
        # Use the directory of the word file as the base folder
        folder_path = os.path.dirname(word_file_path)
        
        # Create a subfolder for images within the base folder
        images_folder = os.path.join(folder_path, 'images')
        create_folder(images_folder)
        logging.info(f"Created images folder: {images_folder}")
        
        try:
            with zipfile.ZipFile(word_file_path, 'r') as docx_zip:
                # Extract files from the word/media folder
                media_files = [f for f in docx_zip.namelist() if f.startswith('word/media/')]
                logging.info(f"Found {len(media_files)} media files in the Word file")
                for idx, media_file in enumerate(media_files, start=1):
                    # Heuristic: Assume 4 images per page
                    images_per_page = 4
                    page_number = (idx - 1) // images_per_page + 1
                    image_number = (idx - 1) % images_per_page + 1
                    ext = os.path.splitext(media_file)[1]  # get extension
                    temp_filename = f"temp_page{page_number}_image{image_number}{ext}"
                    temp_path = os.path.join(images_folder, temp_filename)
                    
                    # Extract image temporarily
                    with docx_zip.open(media_file) as source, open(temp_path, 'wb') as target:
                        target.write(source.read())
                    
                    # classification = self.classify_image_type(temp_path)  # For future use, classification logic can be added here
                    # Save image with a generic tag for further processing/classification
                    final_filename = f"page_{page_number}_image{image_number}{ext}"
                    final_path = os.path.join(images_folder, final_filename)
                    os.rename(temp_path, final_path)
                    logging.info(f"Extracted image saved as {final_filename}")
        except Exception as e:
            logging.error(f"Failed to extract images: {str(e)}")
            raise e

    def extract_images_from_pdf(self, folder_path):
        """
        Extracts images from the PDF file in the given folder and saves them in an 'images' subfolder.
        Images are saved with the naming convention: page{page_number}_image{image_index}.{ext}
        """
        # Find the PDF file in the folder
        pdf_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
        if not pdf_files:
            logging.warning(f"No PDF file found in folder: {folder_path}")
            return
        pdf_file = pdf_files[0]
        pdf_file_path = os.path.join(folder_path, pdf_file)

        images_folder = os.path.join(folder_path, 'images')
        create_folder(images_folder)
        logging.info(f"Created images folder: {images_folder}")

        try:
            doc = fitz.open(pdf_file_path)
            for page in doc:
                page_number = page.number + 1  # page numbers are zero-indexed
                image_list = page.get_images(full=True)
                logging.info(f"page_ {page_number}: Found {len(image_list)} images")
                for image_index, img in enumerate(image_list, start=1):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    ext = base_image["ext"]
                    
                    # Save image temporarily for classification
                    temp_filename = f"temp_page{page_number}_image{image_index}.{ext}"
                    temp_path = os.path.join(images_folder, temp_filename)
                    with open(temp_path, "wb") as image_file:
                        image_file.write(image_bytes)
                    
                    # classification = self.classify_image_type(temp_path)  # For future use, classification logic can be added here
                    # Save image with a generic tag for further processing/classification
                    final_filename = f"page_{page_number}_image{image_index}.{ext}"
                    final_path = os.path.join(images_folder, final_filename)
                    os.rename(temp_path, final_path)
                    logging.info(f"Extracted image saved as {final_filename}")
            doc.close()
        except Exception as e:
            logging.error(f"Failed to extract images from PDF: {str(e)}")
            raise e

    # def classify_image_type(self, image_path):
    #     """
    #     Classifies an image as either 'tabular' (Excel-like) or 'ui' (UI screenshot) based on visual characteristics.
        
    #     Args:
    #         image_path (str): Path to the image file
            
    #     Returns:
    #         str: 'tabular' for spreadsheet-like images, 'ui' for user interface screenshots
    #     """
    #     import cv2
    #     import numpy as np
        
    #     try:
    #         # Read image using np.fromfile to handle paths with non-ASCII characters
    #         data = np.fromfile(image_path, dtype=np.uint8)
    #         image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    #         if image is None:
    #             logging.warning(f"Could not read image for classification: {image_path}")
    #             return 'ui'  # Default to ui if can't read
            
    #         # Convert to grayscale for analysis
    #         gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
    #         # Feature 1: Detect horizontal and vertical lines (typical in tables)
    #         # Create kernels for line detection
    #         horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (40, 1))
    #         vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 40))
            
    #         # Detect lines
    #         horizontal_lines = cv2.morphologyEx(gray, cv2.MORPH_OPEN, horizontal_kernel)
    #         vertical_lines = cv2.morphologyEx(gray, cv2.MORPH_OPEN, vertical_kernel)
            
    #         # Count line pixels
    #         h_line_pixels = cv2.countNonZero(horizontal_lines)
    #         v_line_pixels = cv2.countNonZero(vertical_lines)
    #         total_pixels = gray.shape[0] * gray.shape[1]
            
    #         line_density = (h_line_pixels + v_line_pixels) / total_pixels
            
    #         # Feature 2: Check for grid-like patterns using Hough Line Transform
    #         edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    #         lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=50, maxLineGap=10)
            
    #         horizontal_lines_count = 0
    #         vertical_lines_count = 0
            
    #         if lines is not None:
    #             for line in lines:
    #                 x1, y1, x2, y2 = line[0]
    #                 angle = np.arctan2(y2 - y1, x2 - x1) * 180 / np.pi
                    
    #                 # Horizontal lines (angle close to 0 or 180)
    #                 if abs(angle) < 15 or abs(angle) > 165:
    #                     horizontal_lines_count += 1
    #                 # Vertical lines (angle close to 90 or -90)
    #                 elif abs(abs(angle) - 90) < 15:
    #                     vertical_lines_count += 1
            
    #         # Feature 3: Color analysis - tables often have more uniform colors
    #         # Calculate color variance
    #         color_variance = np.var(image.reshape(-1, 3), axis=0).mean()
            
    #         # Feature 4: Edge density - UI screenshots typically have more varied edges
    #         edge_density = cv2.countNonZero(edges) / total_pixels
            
    #         # Classification logic
    #         tabular_score = 0
            
    #         # High line density suggests tabular data
    #         if line_density > 0.02:  # 2% of image is lines
    #             tabular_score += 2
    #         elif line_density > 0.01:  # 1% of image is lines
    #             tabular_score += 1
            
    #         # Balanced horizontal and vertical lines suggest grid
    #         if horizontal_lines_count > 5 and vertical_lines_count > 5:
    #             tabular_score += 2
    #         elif horizontal_lines_count > 2 and vertical_lines_count > 2:
    #             tabular_score += 1
            
    #         # Lower color variance suggests tabular data (more uniform)
    #         if color_variance < 1000:
    #             tabular_score += 1
            
    #         # Moderate edge density suggests tabular data
    #         if 0.05 < edge_density < 0.15:
    #             tabular_score += 1
    #         elif edge_density > 0.2:  # Very high edge density suggests UI
    #             tabular_score -= 1
            
    #         # Decision threshold
    #         if tabular_score >= 3:
    #             classification = 'tabular'
    #         else:
    #             classification = 'ui'
            
    #         logging.info(f"Image classified as '{classification}' (score: {tabular_score}) - {image_path}")
    #         return classification
            
    #     except Exception as e:
    #         logging.error(f"Error in image classification: {e}")
    #         return 'ui'  # Default to ui on error
        
    # def classify_image_type(self, image_path: str):
    #     """
    #     Classifies an image as 'excel', 'tabular', or 'ui' using visual features.
    #     - Excel: Screenshots from Excel with colored headers, filter arrows, toolbars.
    #     - Tabular: Generic tables/grids.
    #     - UI: Application screens, forms, dashboards.

    #     Args:
    #         image_path (str): Path to the image file

    #     Returns:
    #         str: 'excel', 'tabular', or 'ui'
    #     """
    #     import cv2
    #     import numpy as np

    #     try:
    #         data = np.fromfile(image_path, dtype=np.uint8)
    #         image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    #         if image is None:
    #             logging.warning(f"Could not read image for classification: {image_path}")
    #             return 'ui'

    #         gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    #         thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
    #                                     cv2.THRESH_BINARY_INV, 15, 10)

    #         # Line detection
    #         horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 1))
    #         vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 15))
    #         horizontal_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel)
    #         vertical_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel)
    #         h_line_pixels = cv2.countNonZero(horizontal_lines)
    #         v_line_pixels = cv2.countNonZero(vertical_lines)
    #         total_pixels = gray.shape[0] * gray.shape[1]
    #         line_density = (h_line_pixels + v_line_pixels) / total_pixels

    #         # Contour detection for cell-like regions
    #         contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #         cell_like_contours = [cnt for cnt in contours if cv2.boundingRect(cnt)[2] > 30 and cv2.boundingRect(cnt)[3] > 10]
    #         cell_count = len(cell_like_contours)

    #         # Color block analysis
    #         pixels = image.reshape(-1, 3)
    #         colors, counts = np.unique(pixels, axis=0, return_counts=True)
    #         max_color_count = np.max(counts)
    #         repeated_color_ratio = max_color_count / pixels.shape[0]

    #         # Edge density
    #         edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    #         edge_density = cv2.countNonZero(edges) / total_pixels

    #         # Excel heuristics: colored header row, filter icons (small dark rectangles in header)
    #         h = image.shape[0]
    #         header_row = image[:int(h * 0.1), :, :]
    #         header_colors, header_counts = np.unique(header_row.reshape(-1, 3), axis=0, return_counts=True)
    #         header_max_color_ratio = np.max(header_counts) / header_row.size * 3
    #         has_colored_header = header_max_color_ratio > 0.25 or len(header_colors) < 10

    #         # Detect small dark rectangles (filter icons) in header
    #         header_gray = cv2.cvtColor(header_row, cv2.COLOR_BGR2GRAY)
    #         _, header_bin = cv2.threshold(header_gray, 50, 255, cv2.THRESH_BINARY_INV)
    #         filter_icon_contours, _ = cv2.findContours(header_bin, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #         filter_icons = [cnt for cnt in filter_icon_contours if 5 < cv2.boundingRect(cnt)[2] < 20 and 5 < cv2.boundingRect(cnt)[3] < 20]

    #         # Scoring
    #         excel_score = 0
    #         tabular_score = 0

    #         # Excel: colored header and filter icons
    #         if has_colored_header:
    #             excel_score += 2
    #         if len(filter_icons) > 2:
    #             excel_score += 2

    #         # Tabular: high line density, many cells, repeated color blocks
    #         if line_density > 0.008:
    #             tabular_score += 2
    #         elif line_density > 0.004:
    #             tabular_score += 1
    #         if cell_count > 10:
    #             tabular_score += 2
    #         elif cell_count > 3:
    #             tabular_score += 1
    #         if repeated_color_ratio > 0.12:
    #             tabular_score += 1
    #         if 0.04 < edge_density < 0.18:
    #             tabular_score += 1
    #         elif edge_density > 0.22:
    #             tabular_score -= 1

    #         # Decision logic
    #         if excel_score >= 3:
    #             classification = 'excel'
    #         elif tabular_score >= 3:
    #             classification = 'tabular'
    #         else:
    #             classification = 'ui'

    #         logging.info(f"Image classified as '{classification}' (excel_score: {excel_score}, tabular_score: {tabular_score}) - {image_path}")
    #         return classification

    #     except Exception as e:
    #         logging.error(f"Error in image classification: {e}")
    #         return 'ui'

    def classify_image_type(self, image_path: str) -> str:
        """
        Classifies an image as 'excel', 'tabular', or 'ui' using visual features and OCR (Tesseract).
        Uses OpenCV for visual features and Tesseract OCR to detect table-like text structure.

        Args:
            image_path (str): Path to the image file

        Returns:
            str: 'excel', 'tabular', or 'ui'

        Raises:
            Exception: If image cannot be read or processed

        Usage example:
            >>> result = self.classify_image_type("path/to/image.png")
            >>> print(result)
        """

        try:
            # Read image robustly
            data = np.fromfile(image_path, dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if image is None:
                logging.warning(f"Could not read image for classification: {image_path}")
                return 'ui'

            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                                        cv2.THRESH_BINARY_INV, 15, 10)

            # Visual features (as before)
            horizontal_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 1))
            vertical_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 15))
            horizontal_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, horizontal_kernel)
            vertical_lines = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, vertical_kernel)
            h_line_pixels = cv2.countNonZero(horizontal_lines)
            v_line_pixels = cv2.countNonZero(vertical_lines)
            total_pixels = gray.shape[0] * gray.shape[1]
            line_density = (h_line_pixels + v_line_pixels) / total_pixels

            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cell_like_contours = [cnt for cnt in contours if cv2.boundingRect(cnt)[2] > 30 and cv2.boundingRect(cnt)[3] > 10]
            cell_count = len(cell_like_contours)

            pixels = image.reshape(-1, 3)
            colors, counts = np.unique(pixels, axis=0, return_counts=True)
            max_color_count = np.max(counts)
            repeated_color_ratio = max_color_count / pixels.shape[0]

            edges = cv2.Canny(gray, 50, 150, apertureSize=3)
            edge_density = cv2.countNonZero(edges) / total_pixels

            h = image.shape[0]
            header_row = image[:int(h * 0.1), :, :]
            header_colors, header_counts = np.unique(header_row.reshape(-1, 3), axis=0, return_counts=True)
            header_max_color_ratio = np.max(header_counts) / header_row.size * 3
            has_colored_header = header_max_color_ratio > 0.25 or len(header_colors) < 10

            header_gray = cv2.cvtColor(header_row, cv2.COLOR_BGR2GRAY)
            _, header_bin = cv2.threshold(header_gray, 50, 255, cv2.THRESH_BINARY_INV)
            filter_icon_contours, _ = cv2.findContours(header_bin, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            filter_icons = [cnt for cnt in filter_icon_contours if 5 < cv2.boundingRect(cnt)[2] < 20 and 5 < cv2.boundingRect(cnt)[3] < 20]

            # --- Tesseract OCR analysis ---
            # Use OCR to detect table-like text structure (rows, columns, delimiters)
            custom_oem_psm_config = r'--oem 3 --psm 6'
            ocr_text = pytesseract.image_to_string(image, config=custom_oem_psm_config,lang='spa')
            # Heuristic: If OCR detects many lines with tabs or multiple columns, likely a table
            ocr_lines = ocr_text.split('\n')
            tabular_lines = [line for line in ocr_lines if ('\t' in line or ',' in line or ';' in line) and len(line.split()) > 2]
            ocr_table_score = len(tabular_lines)

            # Scoring
            excel_score = 0
            tabular_score = 0

            if has_colored_header:
                excel_score += 2
            if len(filter_icons) > 2:
                excel_score += 2

            if line_density > 0.008:
                tabular_score += 2
            elif line_density > 0.004:
                tabular_score += 1
            if cell_count > 10:
                tabular_score += 2
            elif cell_count > 3:
                tabular_score += 1
            if repeated_color_ratio > 0.12:
                tabular_score += 1
            if 0.04 < edge_density < 0.18:
                tabular_score += 1
            elif edge_density > 0.22:
                tabular_score -= 1

            # Add OCR table score to tabular_score
            if ocr_table_score > 2:
                tabular_score += 2
            elif ocr_table_score > 0:
                tabular_score += 1

            # Decision logic
            if excel_score >= 3:
                classification = 'excel'
            elif tabular_score >= 3:
                classification = 'tabular'
            else:
                classification = 'ui'

            logging.info(f"Image classified as '{classification}' (excel_score: {excel_score}, tabular_score: {tabular_score}, ocr_table_score: {ocr_table_score}) - {image_path}")
            return classification

        except Exception as e:
            logging.error(f"Error in image classification: {e}")
            return 'ui'

    def improve_image_quality(self, image_path):
        """Enhances the image quality using OpenCV techniques: sharpening and upscaling.
        
        Techniques and study references:
        - Gaussian Blur for noise reduction: https://docs.opencv.org/4.x/d4/d13/tutorial_py_filtering.html
        - Unsharp Mask for image sharpening: https://www.learnopencv.com/sharpening-an-image/
        - Cubic Interpolation for upscaling: https://docs.opencv.org/4.x/da/d54/group__imgproc__transform.html
        - General OpenCV image processing tutorials: https://www.pyimagesearch.com/category/opencv-tutorials/
        - Advanced image enhancement techniques: https://www.pyimagesearch.com/2020/09/28/opencv-image-enhancement/

        Apply: noise reduction, sharpening, AI super-resolution 3x (with fallback to traditional upscaling) 
        """
        
        # Read image using np.fromfile to handle paths with non-ASCII characters
        data = np.fromfile(image_path, dtype=np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if image is None:
            logging.error(f"Failed to read image: {image_path}")
            return
        
        # Apply Gaussian blur to reduce noise
        # Ref: https://docs.opencv.org/4.x/d4/d13/tutorial_py_filtering.html
        blurred = cv2.GaussianBlur(image, (0, 0), 3)
        
        # Use unsharp mask technique to enhance edges
        # Ref: https://www.learnopencv.com/sharpening-an-image/
        sharpened = cv2.addWeighted(image, 1.5, blurred, -0.5, 0)
        
        # Try AI Super-Resolution first, fallback to traditional upscaling with dynamic scale factor
        # Define model filename; change this value to select a different model (e.g., "EDSR_x2.pb" for 2x upscaling)
        model_filename = "EDSR_x2.pb"
        try:
            scale = int(model_filename.split('_x')[-1].split('.')[0])
        except Exception as e:
            logging.warning(f"Failed to extract scale factor from model filename {model_filename}: {e}. Defaulting to 3x.")
            scale = 3

        try:
            sr = cv2.dnn_superres.DnnSuperResImpl_create()
            model_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), model_filename)
            if os.path.exists(model_path):
                sr.readModel(model_path)
                sr.setModel("edsr", scale)  # Set model with dynamic scale factor
                upscaled = sr.upsample(sharpened)
                logging.info(f"Applied AI Super-Resolution ({scale}x) to image: {image_path}")
            else:
                logging.warning(f"AI model {model_path} not found, using traditional upscaling")
                height, width = sharpened.shape[:2]
                upscaled = cv2.resize(sharpened, (width * scale, height * scale), interpolation=cv2.INTER_CUBIC)
        except Exception as sr_error:
            logging.warning(f"AI Super-Resolution failed: {sr_error}, using traditional upscaling")
            height, width = sharpened.shape[:2]
            upscaled = cv2.resize(sharpened, (width * scale, height * scale), interpolation=cv2.INTER_CUBIC)
        
        # Save the improved image using imencode and tofile to handle non-ASCII characters
        ext = os.path.splitext(image_path)[1]
        result, encoded_img = cv2.imencode(ext, upscaled)
        if result:
            encoded_img.tofile(image_path)
            logging.info(f"Improved image quality saved: {image_path}")
        else:
            logging.error(f"Failed to encode image: {image_path}")

    def improve_image_quality_basic(self, image_path):
        """Enhances the image quality using basic OpenCV techniques: sharpening and traditional upscaling.
        
        This is a faster alternative to improve_image_quality that skips AI super-resolution.
        Uses only traditional image processing techniques for better performance.
        
        Techniques applied:
        - Gaussian Blur for noise reduction
        - Unsharp Mask for image sharpening  
        - Traditional 2x cubic interpolation upscaling (no AI)
        
        Args:
            image_path (str): Path to the image file to enhance
        """
        # Read image using np.fromfile to handle paths with non-ASCII characters
        data = np.fromfile(image_path, dtype=np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if image is None:
            logging.error(f"Failed to read image: {image_path}")
            return
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(image, (0, 0), 3)
        
        # Use unsharp mask technique to enhance edges
        sharpened = cv2.addWeighted(image, 1.3, blurred, -0.5, 0)
        
        # Traditional upscaling with 2x scale factor using cubic interpolation
        scale = 2
        height, width = sharpened.shape[:2]
        upscaled = cv2.resize(sharpened, (width * scale, height * scale), interpolation=cv2.INTER_CUBIC)
        
        # Save the improved image using imencode and tofile to handle non-ASCII characters
        ext = os.path.splitext(image_path)[1]
        result, encoded_img = cv2.imencode(ext, upscaled)
        if result:
            encoded_img.tofile(image_path)
            logging.info(f"Improved image quality (basic) saved: {image_path}")
        else:
            logging.error(f"Failed to encode image: {image_path}")
            
    def improve_image_quality_test(self, image_path):
        """Enhances the image quality using advanced OpenCV techniques for better results.
        
        This is a faster alternative to improve_image_quality that skips AI super-resolution.
        Provides significantly better quality than basic processing while maintaining reasonable speed (10-20 seconds).
        
        Techniques applied:
        - Bilateral filtering for edge-preserving noise reduction
        - CLAHE (Contrast Limited Adaptive Histogram Equalization) for better contrast
        - Custom sharpening kernel for enhanced edge definition
        - Multi-step upscaling for smoother results
        - Final edge enhancement using Laplacian filter
        
        Args:
            image_path (str): Path to the image file to enhance
        """
        # Read image using np.fromfile to handle paths with non-ASCII characters
        # This ensures compatibility with file paths containing non-standard characters
        data = np.fromfile(image_path, dtype=np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if image is None:
            logging.error(f"Failed to read image: {image_path}")
            return

        # Step 1: Bilateral filtering for edge-preserving noise reduction
        # Bilateral filter smooths the image while preserving edges, which is crucial for document clarity
        # Parameters: diameter=9, sigmaColor=75, sigmaSpace=75 (good balance for most document images)
        denoised = cv2.bilateralFilter(image, 9, 75, 75)

        # Step 2: Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
        # CLAHE enhances local contrast, making text and details more visible
        # LAB color space separates lightness (L) from color (A/B), so we only enhance L channel
        lab = cv2.cvtColor(denoised, cv2.COLOR_BGR2LAB)
        l_channel, a_channel, b_channel = cv2.split(lab)

        # Apply CLAHE to the L channel
        # clipLimit=2.0 prevents over-amplification, tileGridSize=(8,8) divides image for local enhancement
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l_channel = clahe.apply(l_channel)

        # Merge channels back and convert to BGR for further processing
        enhanced = cv2.merge([l_channel, a_channel, b_channel])
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)

        # Step 3: Custom sharpening using kernel convolution
        # This sharpening kernel emphasizes edges and fine details
        # The center value (9) boosts the intensity of the current pixel, while surrounding -1 values subtract neighbors
        sharpening_kernel = np.array([[-1, -1, -1],
                                     [-1,  9, -1],
                                     [-1, -1, -1]])
        sharpened = cv2.filter2D(enhanced, -1, sharpening_kernel)

        # Step 4: Additional unsharp mask for fine detail enhancement
        # Unsharp mask combines the sharpened image with a blurred version to further enhance edges
        # Weights (1.8, -0.8) provide strong sharpening without excessive noise
        gaussian_blur = cv2.GaussianBlur(sharpened, (0, 0), 1.5)
        unsharp_mask = cv2.addWeighted(sharpened, 1.8, gaussian_blur, -0.8, 0)

        # Step 5: Multi-step upscaling for smoother results
        # Instead of direct 2x upscaling, we first upscale to 1.4x (cubic interpolation)
        # This reduces artifacts and produces smoother results
        height, width = unsharp_mask.shape[:2]
        intermediate = cv2.resize(unsharp_mask, (int(width * 1.4), int(height * 1.4)), interpolation=cv2.INTER_CUBIC)

        # Then upscale to final 2x (Lanczos4 interpolation is higher quality than cubic)
        # final_scale = 2.0 / 1.4 ensures total scaling is exactly 2x
        final_scale = 2.0 / 1.4
        upscaled = cv2.resize(intermediate, (int(width * 2), int(height * 2)), interpolation=cv2.INTER_LANCZOS4)

        # Step 6: Final edge enhancement using Laplacian
        # Laplacian filter detects edges in the image, which we add back to the upscaled image for extra sharpness
        gray = cv2.cvtColor(upscaled, cv2.COLOR_BGR2GRAY)
        laplacian = cv2.Laplacian(gray, cv2.CV_64F)
        laplacian = np.uint8(np.absolute(laplacian))

        # Convert Laplacian back to 3-channel and blend with upscaled image
        # This adds subtle edge enhancement without making the image look unnatural
        laplacian_3ch = cv2.cvtColor(laplacian, cv2.COLOR_GRAY2BGR)
        final_result = cv2.addWeighted(upscaled, 0.85, laplacian_3ch, 0.15, 0)

        # Save the improved image using imencode and tofile to handle non-ASCII characters
        # This ensures compatibility with file paths containing non-standard characters
        ext = os.path.splitext(image_path)[1]
        result, encoded_img = cv2.imencode(ext, final_result)
        if result:
            encoded_img.tofile(image_path)
            logging.info(f"Improved image quality test saved: {image_path}")
        else:
            logging.error(f"Failed to encode image: {image_path}")

    def improve_images_in_folder(self, folder_path):
        """Iterates over images in the 'images' subfolder of the given folder and applies improve_image_quality to each image."""
        images_folder = os.path.join(folder_path, 'images')
        if not os.path.isdir(images_folder):
            logging.info(f"No images folder found in {folder_path}")
            return
        for file in os.listdir(images_folder):
            file_path = os.path.join(images_folder, file)
            if os.path.isfile(file_path) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
                logging.info(f"Improving image: {file_path}")
                # self.improve_image_quality(file_path) # deep learning-based denoising 
                # self.improve_image_quality_basic(file_path)  # Apply basic enhancement as well - quickly 
                self.improve_image_quality_test(file_path)  # Apply enhanced basic method

    def extract_images_from_word_win32com(self, word_file_path):
        """
        Extracts images from a Word file using win32com API.
        Iterates over the inline shapes in the document, copies each as a picture,
        retrieves the image from the clipboard, and saves it with a filename
        formatted as: page{page_number}_image{image_index}.png

        Args:
            word_file_path (str): The full path to the Word file.
        """
        import os
        import win32com.client as win32
        from PIL import ImageGrab

        # Determine base folder and create directory structure
        folder_path = os.path.dirname(word_file_path)
        images_folder = os.path.join(folder_path, "images")
        create_folder(images_folder)

        # Launch Word application via COM
        word_app = win32.Dispatch("Word.Application")
        word_app.Visible = False
        doc = word_app.Documents.Open(word_file_path)
        
        image_index = 0
        # Only process InlineShapes in the main story range (body text)
        main_story = doc.StoryRanges(1)  # 1 = wdMainTextStory
        for shape in main_story.InlineShapes:
            image_index += 1
            # Get the page number where the shape appears using Word constant 3 (wdActiveEndPageNumber)
            page_number = shape.Range.Information(3)
            
            # Select the shape and copy it as a picture
            shape.Select()
            word_app.Selection.CopyAsPicture()

            # Grab the image from clipboard
            img = ImageGrab.grabclipboard()
            if img is None:
                logging.warning(f"Failed to grab image from clipboard at index {image_index}")
                continue
            
            # Save the image temporarily
            temp_filename = f"temp_page{page_number}_image{image_index}.png"
            temp_path = os.path.join(images_folder, temp_filename)
            img.save(temp_path, "PNG")
            
            # classification = self.classify_image_type(temp_path)  # For future use, classification logic can be added here
            # Save image with a generic tag for further processing/classification
            final_filename = f"page_{page_number}_image{image_index}.png"
            final_path = os.path.join(images_folder, final_filename)
            os.rename(temp_path, final_path)
            logging.info(f"Extracted image saved as {final_filename}")

        doc.Close(False)
        word_app.Quit()



###importante para los que desarrollen run_flow corre en gran mededa todos los script y les agrega los logs
### CODEN EN script_function_1 O 2 COMO EJEMPLO      
    def run_flow(self):
        logging.info(f"----- Starting state: {self.state_name} -----")
        try:  # Add workflow in try block below
            self.organize_files()
            # After organizing files, apply image improvement for each folder
            for item in os.listdir(self.input_dir):
                folder = os.path.join(self.input_dir, item)
                if os.path.isdir(folder):
                    logging.info(f"Improving image quality for images in folder: {folder}")
                    self.improve_images_in_folder(folder)
                    # Extract text and confidence from all images in the folder after improvement
                    logging.info(f"Extracting text and confidence from images in folder: {folder}")
                    self.extract_texts_to_excel_from_folder(os.path.join(folder, 'images'), lang='spa')
        except Exception as error:
            logging.error(f"Exception: {str(error)}")
        logging.info(f"Finished state: {self.state_name}")

if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = process_files_input(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
