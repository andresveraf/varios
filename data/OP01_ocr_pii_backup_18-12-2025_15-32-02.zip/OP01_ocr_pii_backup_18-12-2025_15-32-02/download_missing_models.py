"""
Download missing transformer models from HuggingFace
Handles SSL certificate issues by disabling verification
"""
import os
import sys
from pathlib import Path

# Disable SSL verification for corporate proxies
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''
os.environ['SSL_CERT_FILE'] = ''

try:
    from huggingface_hub import snapshot_download
    print("✓ huggingface_hub is installed")
except ImportError:
    print("❌ huggingface_hub not found. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "huggingface-hub"])
    from huggingface_hub import snapshot_download

def download_model(model_id: str, local_dir: str):
    """Download a model from HuggingFace Hub"""
    print(f"\n{'='*70}")
    print(f"Downloading: {model_id}")
    print(f"To: {local_dir}")
    print(f"{'='*70}\n")
    
    try:
        # Create directory if it doesn't exist
        Path(local_dir).mkdir(parents=True, exist_ok=True)
        
        # Download model with SSL verification disabled
        snapshot_download(
            repo_id=model_id,
            local_dir=local_dir,
            local_dir_use_symlinks=False,
            resume_download=True,
            # Disable SSL verification for corporate proxies
            token=None
        )
        
        print(f"\n✅ SUCCESS: {model_id} downloaded to {local_dir}")
        return True
        
    except Exception as e:
        print(f"\n❌ FAILED: {model_id}")
        print(f"Error: {str(e)}")
        return False

def main():
    """Download all missing models"""
    
    base_dir = Path(__file__).parent / "models"
    
    models_to_download = [
        {
            "id": "PlanTL-GOB-ES/roberta-base-bne-capitel-ner",
            "path": base_dir / "PlanTL-GOB-ES" / "roberta-base-bne-capitel-ner"
        },
        # Uncomment if you want to re-download these:
        # {
        #     "id": "Davlan/xlm-roberta-base-ner-hrl",
        #     "path": base_dir / "Davlan" / "xlm-roberta-base-ner-hrl"
        # },
        # {
        #     "id": "dslim/bert-base-NER",
        #     "path": base_dir / "dslim" / "bert-base-NER"
        # }
    ]
    
    print("\n" + "="*70)
    print("DOWNLOADING MISSING TRANSFORMER MODELS")
    print("="*70)
    print(f"\nBase directory: {base_dir}")
    print(f"Models to download: {len(models_to_download)}")
    
    results = []
    for model_info in models_to_download:
        success = download_model(model_info["id"], str(model_info["path"]))
        results.append((model_info["id"], success))
    
    # Summary
    print("\n" + "="*70)
    print("DOWNLOAD SUMMARY")
    print("="*70)
    for model_id, success in results:
        status = "✅ SUCCESS" if success else "❌ FAILED"
        print(f"{status}: {model_id}")
    
    successful = sum(1 for _, success in results if success)
    print(f"\nCompleted: {successful}/{len(results)} models downloaded")
    
    if successful == len(results):
        print("\n🎉 All models downloaded successfully!")
        print("\nNext steps:")
        print("1. Update config.jsonc to use all 3 models")
        print("2. Set use_ensemble: true")
        print("3. Run: python test_orchestrator_integration.py")
    else:
        print("\n⚠️ Some models failed to download")
        print("This may be due to:")
        print("- Network/proxy issues")
        print("- SSL certificate problems")
        print("- HuggingFace Hub access restrictions")

if __name__ == "__main__":
    main()
