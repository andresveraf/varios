"""
Download spacy models with SSL verification disabled
Handles corporate proxy and certificate issues
"""
import os
import sys
import subprocess
from pathlib import Path

# Disable SSL verification for corporate proxies
os.environ['CURL_CA_BUNDLE'] = ''
os.environ['REQUESTS_CA_BUNDLE'] = ''
os.environ['SSL_CERT_FILE'] = ''

def download_spacy_model(model_name: str):
    """Download a spacy model using Python subprocess"""
    print(f"\n{'='*70}")
    print(f"Downloading spacy model: {model_name}")
    print(f"{'='*70}\n")
    
    try:
        # Method 1: Try direct download with PYTHONHTTPSVERIFY=0
        env = os.environ.copy()
        env['PYTHONHTTPSVERIFY'] = '0'
        
        result = subprocess.run(
            [sys.executable, "-m", "spacy", "download", model_name],
            env=env,
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print(f"✅ SUCCESS: {model_name} downloaded")
            print(result.stdout)
            return True
        else:
            print(f"⚠️ Method 1 failed, trying Method 2...")
            print(result.stderr)
    except Exception as e:
        print(f"⚠️ Method 1 error: {str(e)}")
    
    # Method 2: Try pip install with trusted hosts
    try:
        print(f"\nTrying pip install with trusted hosts...")
        
        result = subprocess.run(
            [
                sys.executable, "-m", "pip",
                "--trusted-host", "pypi.org",
                "--trusted-host", "files.pythonhosted.org",
                "install", model_name
            ],
            capture_output=True,
            text=True
        )
        
        if result.returncode == 0:
            print(f"✅ SUCCESS: {model_name} installed via pip")
            print(result.stdout)
            return True
        else:
            print(f"❌ pip install failed")
            print(result.stderr)
            return False
            
    except Exception as e:
        print(f"❌ Method 2 error: {str(e)}")
        return False

def main():
    """Download required spacy models"""
    
    models_to_download = [
        'en-core-web-sm',    # English model
        'es-core-news-md',   # Spanish model (medium, has pre-built wheels)
    ]
    
    print("\n" + "="*70)
    print("DOWNLOADING SPACY MODELS")
    print("="*70)
    print(f"\nModels to download: {models_to_download}")
    print("SSL verification disabled for corporate proxy compatibility\n")
    
    results = []
    for model in models_to_download:
        success = download_spacy_model(model)
        results.append((model, success))
    
    # Summary
    print("\n" + "="*70)
    print("DOWNLOAD SUMMARY")
    print("="*70)
    for model, success in results:
        status = "✅ SUCCESS" if success else "❌ FAILED"
        print(f"{status}: {model}")
    
    successful = sum(1 for _, success in results if success)
    print(f"\nCompleted: {successful}/{len(results)} models downloaded")
    
    if successful == len(results):
        print("\n🎉 All spacy models downloaded successfully!")
        print("\nYou can now use them in your code:")
        print("  import spacy")
        print("  en_nlp = spacy.load('en_core_web_sm')")
        print("  es_nlp = spacy.load('es_core_news_md')")
    else:
        print("\n⚠️ Some models failed to download")
        print("\nAlternative: Download manually from:")
        print("  https://github.com/explosion/spacy-models/releases")

if __name__ == "__main__":
    main()
