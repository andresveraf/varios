#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Find which exclusion is matching RAMIREZ VASQUEZ GUILLERMO
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.utils.pii_utils import ExclusionLists, TextProcessingUtils

name = "RAMIREZ VASQUEZ GUILLERMO"
normalized = TextProcessingUtils.strip_accents(name.lower())

print(f"Checking: {name}")
print(f"Normalized: {normalized}")
print("=" * 60)

# Check which Spanish name exclusion matches
print("\nChecking SPANISH_NAME_EXCLUDE matches:")
for exclusion in ExclusionLists._SPANISH_NAME_EXCLUDE_NORM:
    if exclusion and exclusion in normalized:
        print(f"  ✓ MATCH: '{exclusion}' found in '{normalized}'")

# Check multi-word exclusions
print("\nChecking MULTI_WORD_EXCLUSIONS matches:")
for exclusion in ExclusionLists._MULTI_WORD_EXCLUSIONS_NORM:
    if exclusion and exclusion in normalized:
        print(f"  ✓ MATCH: '{exclusion}' found in '{normalized}'")
