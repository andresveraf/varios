# Next steps

## Fix with python-docx the issue of Word that cant copy image

1. Review is better is python.docx or pdf to save the images


INFO:root:Creating folder C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\extracted_text
2025-11-14 14:12:53,250 [INFO ] Creating folder C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\extracted_text
INFO:root:Extracting images from Word document using win32com: C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\Chile - 1-. Procedimiento de Pago de Asegurados.docx
2025-11-14 14:12:53,312 [INFO ] Extracting images from Word document using win32com: C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\Chile - 1-. Procedimiento de Pago de Asegurados.docx
INFO:root:Creating folder C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\images
2025-11-14 14:12:53,315 [INFO ] Creating folder C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - 1-. Procedimiento de Pago de Asegurados\images
WARNING:root:Error processing shape: failed to open clipboard
2025-11-14 14:13:23,939 [WARNI] Error processing shape: failed to open clipboard
WARNING:root:Error processing shape: failed to open clipboard
2025-11-14 14:13:24,584 [WARNI] Error processing shape: failed to open clipboard
WARNING:root:Error processing shape: failed to open clipboard
2025-11-14 14:13:25,216 [WARNI] Error processing shape: failed to open clipboard
WARNING:root:Error processing shape: failed to open clipboard


Plan: ML Engineering Enhancements for PII Detection System
Comprehensive improvement plan for pii_utils.py and the PII detection pipeline based on ML engineering best practices. The system currently uses a hybrid approach combining regex patterns with transformer-based NER models (mrm8488/bert-spanish, xlm-roberta-large, dslim/bert-base-NER) to detect personally identifiable information across Latin American documents.

Steps
Fine-tune domain-specific transformer models on Chilean insurance/financial documents (500-1,000 labeled examples) to address domain mismatch from CoNLL-2003 news article training data. Update TransformerEnsemble class to support custom model paths and create training pipeline in new src/training/ module. Expected: +15-25% precision improvement.

Replace manual exclusion list with ML-based classification by training a binary classifier (name vs. non-name) on the 1,200+ exclusion terms in EXCLUSION_TERMS. Implement active learning loop in ExclusionLists.is_excluded() and add Platt scaling for confidence calibration. Expected: 30-50% false positive reduction.

Optimize long-document processing by implementing sliding window chunking (400-token windows, 50-token overlap) in _preprocess_text() to replace current 510-token truncation. Add entity span merging logic to consolidate predictions across windows. Expected: +10-15% recall on long documents.

Scale inference throughput by increasing batch size from 16→64 for GPU processing, implementing parallel regex+ML execution in S3_hybrid_pii.py, and adding LRU eviction policy to TransformerCache. Expected: 2-3x throughput improvement.

Implement automated performance monitoring by adding precision/recall/F1 metrics collection to S4_pii_orchestrator.py, creating benchmark test set (100+ labeled documents) in dev_data/benchmark/, and building A/B testing framework for method comparison. Export metrics via logging for regression detection.

Enhance multi-country support by adding Portuguese-specific model (neuralmind/bert-base-portuguese-cased) to ensemble with 25% weight, implementing CPF/CNPJ validation in PIIValidators, and expanding Brazilian training examples. Update config.jsonc country-specific configurations.

Further Considerations
Data labeling strategy: Should we use weak supervision (Snorkel) with heuristic labeling functions to generate training data, or invest in manual annotation for 500-1,000 examples? Weak supervision is faster but may introduce noise.

Model deployment: Keep all models local (current approach) or deploy fine-tuned models to cloud endpoints (Azure ML, AWS SageMaker) for centralized updates? Local is faster but harder to maintain across deployments.

Confidence threshold tuning: Run grid search on validation set for per-entity-type thresholds vs. current global 0.80, or implement uncertainty quantification (MC Dropout, ensembles) for adaptive thresholding?