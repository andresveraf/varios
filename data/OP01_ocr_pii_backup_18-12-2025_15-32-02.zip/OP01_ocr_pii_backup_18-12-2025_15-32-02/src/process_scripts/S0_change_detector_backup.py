#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S00 SharePoint Change Detector with Regional Hub Backup

Single responsibility: Detects changes in SharePoint folders and backs them up to Regional Hub.
This script operates independently from the main OCR PII flow and focuses solely on
creating backups of changed files in the regional hub structure.

Structure created: REGIONAL_HUB/country/sync_library/filename
"""

import os
import sys
import logging
import datetime as dt
import hashlib
import shutil
import uuid
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path

# Add src to path for imports (framework pattern)
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from utils.fmw_utils import start_logging, Config, save_json_file, read_json, create_folder, save_excel_file,read_config, BusinessException
# from utils.send_exceptions_emails import ExceptionEmails


@dataclass
class FileChange:
    """
    Represents a detected file change in SharePoint synchronized folders.
    """
    file_path: str
    change_type: str
    site_id: str
    country: str
    file_size: int
    last_modified: str
    detection_timestamp: str
    file_hash: Optional[str] = None
    relative_path: Optional[str] = None
    backup_path: Optional[str] = None  # Path where file was backed up
    creation_time: Optional[str] = None  # File creation time


@dataclass
class SiteSnapshot:
    """
    Snapshot of SharePoint synchronized folder state.
    """
    site_id: str
    country: str
    base_path: str
    snapshot_timestamp: str
    files: Dict[str, Dict]
    total_files: int
    total_size: int


class S00ChangeDetectorBackup:
    """
    SharePoint change detection with automatic Regional Hub backup.
    
    This class has a single responsibility: detect changes in SharePoint folders
    and immediately backup changed files to the Regional Hub. It operates
    independently from the main OCR PII processing flow.
    
    Key functionalities:
    - Detect changes in SharePoint synchronized folders
    - Automatically backup changed files to Regional Hub
    - Maintain backup history and reports
    - Simple structure: REGIONAL_HUB/country/library/filename
    
    Usage:
        detector = S00ChangeDetectorBackup()
        success = detector.run_flow()
    """

    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the SharePoint change detector with backup functionality.
        
        Args:
            config: Optional configuration dictionary. If not provided,
                   loads configuration from config.jsonc using framework Config class.
        
        Raises:
            BusinessException: If configuration is invalid or required paths don't exist
        """
        try:
            # Load configuration using framework Config class
            self.config = config or Config().build_config()
            
            # Initialize exception handler for error reporting
            # self.exception_handler = ExceptionEmails()
            
            # Extract SharePoint and backup configuration
            self.sharepoint_config = self.config.get("SHAREPOINT_SITES", {})
            backup_settings = self.sharepoint_config.get("backup_settings", {})
            
            # Get regional hub configuration
            self.regional_hub_path = self.sharepoint_config.get("regional_hub", {}).get("path")
            if not self.regional_hub_path:
                raise ValueError("Regional hub path not configured in SHAREPOINT_SITES")
            
            # Configuration settings from backup_settings
            self.enable_file_hashing = backup_settings.get("enable_file_hashing", True)
            self.file_types_allowed = backup_settings.get("file_types_allowed", [])  # Empty list means all types allowed
            self.max_file_size_mb = backup_settings.get("max_file_size_mb", 50)
            self.exclude_folders = backup_settings.get("exclude_folders", ["_private", "temp", ".git", "~$*"])
            
            # Setup directories using framework path structure
            framework_config = self.config.get("FRAMEWORK", {})
            process_data_path = framework_config.get("PROCESS_DATA", "../process_data")
            output_path = framework_config.get("OUTPUT", "../output")
            
            # Resolve relative paths to absolute paths
            if process_data_path.startswith("../"):
                process_data_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", process_data_path[3:]))
            if output_path.startswith("../"):
                output_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", output_path[3:]))
            
            self.snapshots_dir = os.path.join(process_data_path, "backup_snapshots")
            self.backup_reports_dir = os.path.join(output_path, "backup_reports")
            
            # OCR processing input directory
            self.ocr_input_dir = os.path.join(
                os.path.dirname(__file__), "..", "..", "input", "_file_input"
            )
            self.ocr_input_dir = os.path.abspath(self.ocr_input_dir)
            
            # Create required directories
            create_folder(self.snapshots_dir)
            create_folder(self.backup_reports_dir)
            create_folder(self.regional_hub_path)
            create_folder(self.ocr_input_dir)
            
            # Setup metadata output directories
            self.metadata_output_dir = os.path.join(output_path, "_others")
            self.metadata_json_path = os.path.join(self.metadata_output_dir, "files_metadata.json")
            self.metadata_excel_path = os.path.join(self.metadata_output_dir, "files_metadata.xlsx")
            create_folder(self.metadata_output_dir)
            
            # Initialize metadata tracking
            self.metadata_list = []
            
            # Processing statistics
            self.stats = {
                "files_detected": 0,
                "files_backed_up": 0,
                "files_skipped": 0,
                "backup_errors": 0,
                "ocr_files_copied": 0,
                "ocr_copy_errors": 0,
                "start_time": dt.datetime.now().isoformat(),
                "end_time": None
            }
            
            logging.info("S00ChangeDetectorBackup initialized successfully")
            logging.info(f"Regional Hub Path: {self.regional_hub_path}")
            
        except Exception as e:
            logging.error(f"Error initializing S00ChangeDetectorBackup: {e}")
            raise ValueError(f"Failed to initialize SharePoint change detector with backup: {e}")

    def validate_sharepoint_paths(self) -> bool:
        """
        Validate that all configured SharePoint paths exist and are accessible.
        
        Returns:
            bool: True if all paths are valid and accessible
            
        Raises:
            ValueError: If any configured path is invalid or inaccessible
        """
        try:
            source_sites = self.sharepoint_config.get("source_sites", [])
            
            if not source_sites:
                raise ValueError("No SharePoint source sites configured in SHAREPOINT_SITES")
            
            for site_config in source_sites:
                name = site_config.get("name")
                local_path = site_config.get("path")
                
                if not name:
                    raise ValueError("SharePoint site configuration missing name")
                
                if not local_path:
                    raise ValueError(f"No path configured for site: {name}")
                
                if not os.path.exists(local_path):
                    raise ValueError(f"SharePoint folder not found: {local_path} (site: {name})")
                
                if not os.path.isdir(local_path):
                    raise ValueError(f"Path is not a directory: {local_path} (site: {name})")
                
                if not os.access(local_path, os.R_OK):
                    raise ValueError(f"SharePoint folder is not readable: {local_path} (site: {name})")
                
                logging.info(f"Validated SharePoint path: {name} -> {local_path}")
            
            logging.info(f"All {len(source_sites)} SharePoint paths validated successfully")
            return True
            
        except ValueError:
            raise
        except Exception as e:
            logging.error(f"Error validating SharePoint paths: {e}")
            raise ValueError(f"SharePoint path validation failed: {e}")

    def scan_folder(self, folder_path: str, base_path: str) -> List[Dict[str, Any]]:
        """
        Recursively scan a folder for files, respecting exclude patterns and file filters.
        
        Args:
            folder_path: Current folder being scanned
            base_path: Base SharePoint folder path for calculating relative paths
            
        Returns:
            List[Dict[str, Any]]: List of file information dictionaries
            
        Raises:
            ValueError: If folder scanning fails critically
        """
        files = []
        
        try:
            for root, dirs, filenames in os.walk(folder_path):
                # Filter out excluded directories
                dirs[:] = [d for d in dirs if not self._is_folder_excluded(d)]
                
                for filename in filenames:
                    try:
                        file_path = os.path.join(root, filename)
                        
                        # Skip files that don't meet filtering criteria
                        if not self._is_file_allowed(file_path, filename):
                            continue
                        
                        # Get file statistics
                        stat = os.stat(file_path)
                        file_size = stat.st_size
                        
                        # Skip files that are too large
                        if file_size > (self.max_file_size_mb * 1024 * 1024):
                            logging.warning(f"Skipping large file: {file_path} ({file_size/1024/1024:.1f}MB)")
                            continue
                        
                        # Get both creation and modification times
                        last_modified = dt.datetime.fromtimestamp(stat.st_mtime).isoformat()
                        creation_time = dt.datetime.fromtimestamp(stat.st_ctime).isoformat()
                        
                        # Calculate relative path from base SharePoint folder
                        relative_path = os.path.relpath(file_path, base_path).replace("\\", "/")
                        
                        # Generate file hash if enabled
                        file_hash = None
                        if self.enable_file_hashing:
                            try:
                                file_hash = self._calculate_file_hash(file_path)
                            except Exception as hash_error:
                                logging.warning(f"Could not hash file {file_path}: {hash_error}")
                        
                        file_info = {
                            "name": filename,
                            "full_path": file_path,
                            "relative_path": relative_path,
                            "size": file_size,
                            "last_modified": last_modified,
                            "creation_time": creation_time,
                            "hash": file_hash,
                            "scan_timestamp": dt.datetime.now().isoformat()
                        }
                        
                        files.append(file_info)
                        
                        # Log each file found with details
                        size_mb = file_size / (1024 * 1024)
                        modified_date = last_modified[:10]
                        created_date = creation_time[:10]
                        logging.info(f"Found file: {relative_path} ({size_mb:.2f}MB) - Modified: {modified_date}, Created: {created_date}")
                        
                    except (OSError, PermissionError) as e:
                        logging.warning(f"Could not access file {file_path}: {e}")
                        continue
                    except Exception as e:
                        logging.error(f"Unexpected error processing file {file_path}: {e}")
                        continue
            
        except Exception as e:
            logging.error(f"Error scanning folder {folder_path}: {e}")
            raise ValueError(f"Failed to scan folder {folder_path}: {e}")
        
        logging.info(f"Folder scan completed: {folder_path} - Found {len(files)} files")
        return files

    def generate_site_snapshot(self, site_name: str) -> Optional[SiteSnapshot]:
        """
        Generate current snapshot for a SharePoint synchronized folder.
        
        Args:
            site_name: SharePoint site name
            
        Returns:
            Optional[SiteSnapshot]: Current site state snapshot or None if error
            
        Raises:
            ValueError: If snapshot generation fails critically
        """
        try:
            site_config = self._get_site_config(site_name)
            if not site_config:
                raise ValueError(f"No configuration found for site: {site_name}")
            
            local_path = site_config.get("path")
            country = site_config.get("name", "Unknown")
            
            if not os.path.exists(local_path):
                raise ValueError(f"SharePoint folder not found: {local_path}")
            
            logging.info(f"Generating snapshot for {site_name} ({country}) at {local_path}")
            
            snapshot_files = {}
            total_files = 0
            total_size = 0
            
            # Scan entire SharePoint folder
            files = self.scan_folder(local_path, local_path)
            
            for file_info in files:
                relative_path = file_info["relative_path"]
                snapshot_files[relative_path] = file_info
                total_files += 1
                total_size += file_info["size"]
            
            # Create snapshot object
            snapshot = SiteSnapshot(
                site_id=site_name,
                country=country,
                base_path=local_path,
                snapshot_timestamp=dt.datetime.now().isoformat(),
                files=snapshot_files,
                total_files=total_files,
                total_size=total_size
            )
            
            # Save snapshot using framework utility
            self._save_snapshot(snapshot)
            
            logging.info(f"Snapshot generated: {site_name} - {total_files} files, {total_size/1024/1024:.2f}MB")
            return snapshot
            
        except ValueError:
            raise
        except Exception as e:
            logging.error(f"Error generating snapshot for {site_name}: {e}")
            raise ValueError(f"Failed to generate snapshot for site {site_name}: {e}")

    def detect_changes_and_backup(self, site_name: str) -> List[FileChange]:
        """
        Detect changes and immediately backup changed files to Regional Hub.
        
        Args:
            site_name: SharePoint site name
            
        Returns:
            List[FileChange]: List of detected changes with backup information
            
        Raises:
            ValueError: If change detection or backup fails critically
        """
        try:
            # Generate current snapshot
            current_snapshot = self.generate_site_snapshot(site_name)
            if not current_snapshot:
                return []
            
            # Load previous snapshot
            previous_snapshot = self._load_previous_snapshot(site_name)
            if not previous_snapshot:
                # First run - backup all files as new
                logging.info(f"No previous snapshot found for {site_name}, backing up all files as new")
                return self._backup_all_as_new(current_snapshot)
            
            logging.info(f"Comparing snapshots for {site_name}")
            logging.info(f"Previous: {previous_snapshot.total_files} files")
            logging.info(f"Current: {current_snapshot.total_files} files")
            
            changes = []
            current_files = current_snapshot.files
            previous_files = previous_snapshot.files
            
            # Detect new and modified files - backup immediately
            for relative_path, current_info in current_files.items():
                if relative_path not in previous_files:
                    # New file detected - backup it
                    change = FileChange(
                        file_path=current_info["full_path"],
                        change_type="new",
                        site_id=site_name,
                        country=current_snapshot.country,
                        file_size=current_info["size"],
                        last_modified=current_info["last_modified"],
                        detection_timestamp=dt.datetime.now().isoformat(),
                        file_hash=current_info.get("hash"),
                        relative_path=relative_path,
                        creation_time=current_info.get("creation_time")
                    )
                    
                    # Backup the new file
                    backup_path = self._backup_file_to_regional_hub(change)
                    change.backup_path = backup_path
                    
                    # Copy to OCR input if it's a compatible file type
                    ocr_path = self._copy_to_ocr_input(
                        current_info["full_path"], 
                        relative_path, 
                        current_snapshot.country
                    )
                    
                    changes.append(change)
                    self.stats["files_detected"] += 1
                    
                    logging.info(f"New file detected and backed up: {relative_path}")
                    
                else:
                    # Check for modifications
                    previous_info = previous_files[relative_path]
                    if self._file_changed(current_info, previous_info):
                        change = FileChange(
                            file_path=current_info["full_path"],
                            change_type="modified",
                            site_id=site_name,
                            country=current_snapshot.country,
                            file_size=current_info["size"],
                            last_modified=current_info["last_modified"],
                            detection_timestamp=dt.datetime.now().isoformat(),
                            file_hash=current_info.get("hash"),
                            relative_path=relative_path,
                            creation_time=current_info.get("creation_time")
                        )
                        
                        # Backup the modified file
                        backup_path = self._backup_file_to_regional_hub(change)
                        change.backup_path = backup_path
                        
                        # Copy to OCR input if it's a compatible file type
                        ocr_path = self._copy_to_ocr_input(
                            current_info["full_path"], 
                            relative_path, 
                            current_snapshot.country
                        )
                        
                        changes.append(change)
                        self.stats["files_detected"] += 1
                        
                        logging.info(f"Modified file detected and backed up: {relative_path}")
            
            # Note: We don't backup deleted files, just log them
            for relative_path, previous_info in previous_files.items():
                if relative_path not in current_files:
                    change = FileChange(
                        file_path=previous_info["full_path"],
                        change_type="deleted",
                        site_id=site_name,
                        country=current_snapshot.country,
                        file_size=0,
                        last_modified="",
                        detection_timestamp=dt.datetime.now().isoformat(),
                        relative_path=relative_path,
                        backup_path=None  # No backup for deleted files
                    )
                    changes.append(change)
                    logging.info(f"Deleted file detected (no backup): {relative_path}")
            
            logging.info(f"Changes detected and processed for {site_name}: {len(changes)} total")
            logging.info(f"  New: {len([c for c in changes if c.change_type == 'new'])}")
            logging.info(f"  Modified: {len([c for c in changes if c.change_type == 'modified'])}")
            logging.info(f"  Deleted: {len([c for c in changes if c.change_type == 'deleted'])}")
            
            # Save backup report if any changes detected
            if changes:
                self._save_backup_report(site_name, changes)
            
            return changes
            
        except ValueError:
            raise
        except Exception as e:
            logging.error(f"Error detecting changes and backing up for {site_name}: {e}")
            raise ValueError(f"Failed to detect changes and backup for site {site_name}: {e}")

    def _backup_file_to_regional_hub(self, change: FileChange) -> Optional[str]:
        """
        Backup a single file to Regional Hub with proper structure.
        
        Args:
            change: FileChange object with file information
            
        Returns:
            Optional[str]: Path where file was backed up, or None if failed
        """
        try:
            source_file_path = change.file_path
            site_id = change.site_id
            country = change.country
            relative_path = change.relative_path
            change_type = change.change_type
            
            logging.info(f"Starting backup for {change_type} file: '{relative_path}'")
            
            # Validate source file exists
            if not os.path.exists(source_file_path):
                logging.warning(f"Source file not found for backup: '{source_file_path}'")
                self.stats["backup_errors"] += 1
                return None
            
            # Preserve full directory structure from relative path
            # Extract directory structure and filename
            dir_structure = os.path.dirname(relative_path) if os.path.dirname(relative_path) else "root"
            original_filename = os.path.basename(source_file_path)
            
            # Build target directory: REGIONAL_HUB/country/folder_structure/
            target_directory = os.path.join(self.regional_hub_path, country, dir_structure)
            create_folder(target_directory)
            
            # Handle filename conflicts for modified files
            target_filename = self._generate_unique_backup_filename(
                target_directory, 
                original_filename, 
                change_type
            )
            
            # Full target path
            backup_file_path = os.path.join(target_directory, target_filename)
            
            # Copy file to Regional Hub
            shutil.copy2(source_file_path, backup_file_path)
            self.stats["files_backed_up"] += 1
            
            logging.info(f"Backed up: {relative_path} -> {country}/{dir_structure}/{target_filename}")
            return backup_file_path
            
        except Exception as e:
            logging.error(f"Error backing up file {change.file_path}: {e}")
            self.stats["backup_errors"] += 1
            return None

    def _is_ocr_compatible_file(self, file_path: str) -> bool:
        """
        Check if a file is compatible with OCR processing (Word or PDF files).
        
        Args:
            file_path: Path to the file to check
            
        Returns:
            bool: True if file is Word (.docx, .doc) or PDF (.pdf)
        """
        if not os.path.exists(file_path):
            return False
            
        file_ext = os.path.splitext(file_path)[1].lower()
        return file_ext in ['.docx', '.doc', '.pdf']

    def _copy_to_ocr_input(self, file_path: str, relative_path: str, country: str) -> Optional[str]:
        """
        Copy Word/PDF files to OCR input directory for processing.
        Only copies files that actually need PII processing to avoid unnecessary work.
        
        Args:
            file_path: Full path to source file
            relative_path: Relative path from SharePoint base
            country: Country name for file naming
            
        Returns:
            Optional[str]: Path where file was copied, or None if failed or not needed
        """
        try:
            if not self._is_ocr_compatible_file(file_path):
                return None
                
            if not os.path.exists(file_path):
                logging.warning(f"Source file not found for OCR copy: {file_path}")
                self.stats["ocr_copy_errors"] += 1
                return None
            
            # Check if this file needs PII processing
            if not self._needs_pii_processing(file_path, relative_path):
                logging.info(f"File already processed for PII, skipping OCR copy: {relative_path}")
                return None
            
            # Generate unique filename with country prefix
            original_filename = os.path.basename(file_path)
            name_part, ext_part = os.path.splitext(original_filename)
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Create filename: COUNTRY_TIMESTAMP_originalname.ext
            ocr_filename = f"{country} - {name_part}{ext_part}"
            # ocr_filename = f"{country}_{timestamp}_{name_part}{ext_part}" # Avoid spaces in filename
            ocr_file_path = os.path.join(self.ocr_input_dir, ocr_filename)
            
            
            # Ensure unique filename in case of conflicts
            counter = 2
            while os.path.exists(ocr_file_path):
                ocr_filename = f"{country} - {name_part} ({counter}){ext_part}"
                # ocr_filename = f"{country}_{timestamp}_{name_part}_{counter}{ext_part}"
                ocr_file_path = os.path.join(self.ocr_input_dir, ocr_filename)
                counter += 1
            
            # Copy file to OCR input directory
            shutil.copy2(file_path, ocr_file_path)
            self.stats["ocr_files_copied"] += 1
            
            logging.info(f"Copied to OCR input for PII processing: {relative_path} -> {ocr_filename}")
            return ocr_file_path
            
        except Exception as e:
            logging.error(f"Error copying file to OCR input {file_path}: {e}")
            self.stats["ocr_copy_errors"] += 1
            return None
    
    def _needs_pii_processing(self, file_path: str, relative_path: str) -> bool:
        """
        Determine if a file needs PII processing by checking previous results.
        
        Args:
            file_path: Full path to the file
            relative_path: Relative path from SharePoint base
            
        Returns:
            bool: True if file needs PII processing, False if already processed
        """
        try:
            # Check if previous metadata exists
            if not os.path.exists(self.metadata_excel_path):
                logging.info(f"No previous metadata found, file needs processing: {relative_path}")
                return True
                
            # Read previous metadata
            try:
                metadata_df = pd.read_excel(self.metadata_excel_path)
                logging.info(f"Previous metadata loaded: {self.metadata_excel_path}")
            except Exception as e:
                logging.warning(f"Could not read metadata file, assuming file needs processing: {e}")
                return True
            
            # Get current file information
            try:
                file_stat = os.stat(file_path)
                current_hash = self._calculate_file_hash(file_path)
                current_mtime = dt.datetime.fromtimestamp(file_stat.st_mtime).isoformat()
            except Exception as e:
                logging.warning(f"Could not get file info for {file_path}: {e}")
                return True
            
            # Look for this file in previous metadata
            filename = os.path.basename(file_path)
            logging.info(f"Checking previous metadata for {filename}")

            # Try multiple matching strategies
            matching_records = metadata_df[
                (metadata_df['original_filename'] == filename) |
                (metadata_df['original_filename'].str.contains(os.path.splitext(filename)[0], na=False))
            ]
            
            
            if matching_records.empty:
                logging.info(f"File not found in previous metadata, needs processing: {relative_path}")
                return True
            
            # Check if any matching record has already been processed for PII
            for _, record in matching_records.iterrows():
                # Check if PII analysis was completed
                if record.get('pii_analysis_completed') == True:
                    # Check if file has changed since last PII analysis
                    last_processed = record.get('pii_analysis_timestamp')
                    if last_processed:
                        try:
                            last_processed_dt = pd.to_datetime(last_processed)
                            current_mtime_dt = pd.to_datetime(current_mtime)
                            
                            if current_mtime_dt <= last_processed_dt:
                                logging.info(f"File already processed and unchanged, skipping: {relative_path}")
                                return False
                            else:
                                logging.info(f"File was modified after last PII analysis, needs reprocessing: {relative_path}")
                                return True
                        except Exception as e:
                            logging.info(f"Could not compare timestamps, assuming needs processing: {e}")
                            return True
                    else:
                        logging.info(f"PII analysis timestamp missing, needs processing: {relative_path}")
                        return True
                else:
                    logging.info(f"PII analysis not completed for this file, needs processing: {relative_path}")
                    return True
            
            # Default: if we can't determine, process the file
            logging.info(f"Could not determine PII processing status, defaulting to process: {relative_path}")
            return True
            
        except Exception as e:
            logging.error(f"Error checking PII processing status for {file_path}: {e}")
            return True  # Default to processing on error
    
    def _clean_ocr_input_directory(self) -> None:
        """
        Clean the OCR input directory to ensure only files that need processing are present.
        This prevents processing of files from previous runs that shouldn't be reprocessed.
        Removes both files and folders (created by S1) from previous runs.
        """
        try:
            if not os.path.exists(self.ocr_input_dir):
                logging.info("OCR input directory doesn't exist, will be created during processing")
                return
            
            items_removed = 0
            folders_removed = 0
            files_removed = 0
            
            for item_name in os.listdir(self.ocr_input_dir):
                item_path = os.path.join(self.ocr_input_dir, item_name)
                
                try:
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                        files_removed += 1
                        logging.info(f"Removed previous file from OCR input: {item_name}")
                    elif os.path.isdir(item_path):
                        # Remove folders created by S1 (e.g., "Chile - filename/")
                        import shutil
                        shutil.rmtree(item_path)
                        folders_removed += 1
                        logging.info(f"Removed previous folder from OCR input: {item_name}")
                    
                    items_removed += 1
                    
                except Exception as e:
                    logging.warning(f"Could not remove {item_name} from OCR input: {e}")
            
            if items_removed > 0:
                logging.info(f"Cleaned OCR input directory: removed {files_removed} files and {folders_removed} folders from previous runs")
            else:
                logging.info("OCR input directory was already clean")
                
        except Exception as e:
            logging.error(f"Error cleaning OCR input directory: {e}")

    def _determine_library(self, relative_path: str, site_name: str) -> str:
        """
        Determine which SharePoint library a file belongs to based on its path.
        
        Args:
            relative_path: Relative path of the file from SharePoint base
            site_name: SharePoint site name
            
        Returns:
            str: Library name
        """
        try:
            # Get site configuration
            site_config = self._get_site_config(site_name)
            if not site_config:
                return "Unknown_Library"
            
            # Use the first part of the path as the library name
            path_parts = relative_path.replace("\\", "/").split("/")
            
            # If no specific library found, use first part of path or default
            if path_parts and path_parts[0] and path_parts[0] != ".":
                return path_parts[0]
            
            return "General"
            
        except Exception as e:
            logging.warning(f"Error determining library for {relative_path}: {e}")
            return "Unknown_Library"

    def _generate_unique_backup_filename(self, target_directory: str, original_filename: str, change_type: str) -> str:
        """
        Generate a unique filename for backup to avoid conflicts.
        
        Args:
            target_directory: Target directory path
            original_filename: Original filename
            change_type: Type of change (new, modified)
            
        Returns:
            str: Unique filename for backup
        """
        try:
            name_part, ext_part = os.path.splitext(original_filename)
            
            # For modified files, add timestamp prefix
            if change_type == "modified":
                timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
                candidate_filename = f"{timestamp}_{name_part}{ext_part}"
            else:
                candidate_filename = original_filename
            
            # Check for conflicts and add counter if needed
            target_path = os.path.join(target_directory, candidate_filename)
            counter = 1
            
            while os.path.exists(target_path):
                if change_type == "modified":
                    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
                    candidate_filename = f"{timestamp}_{name_part}_{counter}{ext_part}"
                else:
                    candidate_filename = f"{name_part}_{counter}{ext_part}"
                
                target_path = os.path.join(target_directory, candidate_filename)
                counter += 1
            logging.info(f"Generated unique backup filename: {candidate_filename}")
            return candidate_filename
            
        except Exception as e:
            logging.error(f"Error generating unique backup filename for {original_filename}: {e}")
            return original_filename

    def run_detection_and_backup_cycle(self) -> Dict[str, List[FileChange]]:
        """
        Run complete change detection and backup cycle for all configured SharePoint folders.
        
        Returns:
            Dict[str, List[FileChange]]: Dictionary mapping site_id to list of changes with backup info
            
        Raises:
            ValueError: If the detection and backup cycle fails critically
        """
        try:
            logging.info("Starting SharePoint change detection and backup cycle")
            
            # Validate all SharePoint paths first
            self.validate_sharepoint_paths()
            
            all_changes = {}
            source_sites = self.sharepoint_config.get("source_sites", [])
            
            # Process each configured SharePoint folder
            for site_config in source_sites:
                site_name = site_config.get("name")
                
                try:
                    logging.info(f"Processing SharePoint site: {site_name}")
                    changes = self.detect_changes_and_backup(site_name)
                    all_changes[site_name] = changes
                    
                except ValueError:
                    # Re-raise business exceptions
                    raise
                except Exception as site_error:
                    logging.error(f"Error processing site {site_name}: {site_error}")
                    all_changes[site_name] = []
                    continue
            
            # Generate consolidated summary report
            total_changes = sum(len(changes) for changes in all_changes.values())
            logging.info(f"Detection and backup cycle completed: {total_changes} changes across {len(all_changes)} sites")
            
            if total_changes > 0:
                self._generate_backup_summary_report(all_changes)
                
                # Generate standardized metadata for all changes
                logging.info("Generating standardized metadata for detected changes")
                self._generate_metadata_from_changes(all_changes)
                
                # Save standardized metadata to JSON and Excel
                metadata_success = self._save_standardized_metadata()
                if metadata_success:
                    logging.info(f"Standardized metadata saved for {len(self.metadata_list)} file entries")
                else:
                    logging.warning("Failed to save standardized metadata")
            else:
                logging.info("No changes detected - no metadata to generate")
            
            # Cleanup old snapshots
            self._cleanup_old_snapshots()
            
            return all_changes
            
        except ValueError:
            raise
        except Exception as e:
            logging.error(f"Error in detection and backup cycle: {e}")
            raise ValueError(f"Change detection and backup cycle failed: {e}")

    def run_flow(self) -> bool:
        """
        Main execution flow following framework pattern.
        
        This method implements the standard framework interface for process scripts.
        It handles initialization, execution, and cleanup, with proper error handling
        and exception reporting.
        
        Returns:
            bool: True if the flow executed successfully, False otherwise
            
        Example:
            >>> detector = S00ChangeDetectorBackup()
            >>> success = detector.run_flow()
            >>> if success:
            ...     print("Change detection and backup completed successfully")
        """
        try:
            logging.info("S00 SharePoint Change Detection and Backup flow started")
            
            # Clean OCR input directory to ensure only new/modified files are processed
            self._clean_ocr_input_directory()
            
            # Run the main detection and backup cycle
            all_changes = self.run_detection_and_backup_cycle()
            
            # Evaluate results
            total_changes = sum(len(changes) for changes in all_changes.values())
            
            # Update final statistics
            self.stats["end_time"] = dt.datetime.now().isoformat()
            
            if total_changes > 0:
                logging.info(f"Change detection and backup completed successfully - {total_changes} changes processed")
                logging.info(f"Final statistics: {self.stats}")
                return True
            else:
                logging.info("Change detection and backup completed - no changes detected")
                logging.info(f"Final statistics: {self.stats}")
                return True
                
        except Exception as e:
            logging.error(f"S00 Change Detection and Backup flow failed: {e}")
            ##self.exception_handler.send_system_exception(str(e))
            return False

    # Private helper methods (framework pattern)
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate MD5 hash of a file for change detection."""
        hash_md5 = hashlib.md5()
        
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        
        return hash_md5.hexdigest()

    def _get_site_config(self, site_name: str) -> Optional[Dict]:
        """Get configuration for specific site."""
        source_sites = self.sharepoint_config.get("source_sites", [])
        for site_config in source_sites:
            if site_config.get("name") == site_name:
                return site_config
        return None

    def _save_snapshot(self, snapshot: SiteSnapshot) -> None:
        """Save snapshot to disk using framework utility."""
        timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_snapshot_{snapshot.site_id}_{timestamp}.json"
        filepath = os.path.join(self.snapshots_dir, filename)
        
        save_json_file(asdict(snapshot), filepath)
        logging.debug(f"Backup snapshot saved: {filename}")

    def _load_previous_snapshot(self, site_name: str) -> Optional[SiteSnapshot]:
        """Load most recent backup snapshot for site, excluding the current run."""
        try:
            current_timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M")  # Match only date and hour/minute
            snapshot_files = [
                f for f in os.listdir(self.snapshots_dir)
                if f.startswith(f"backup_snapshot_{site_name}_") 
                and f.endswith(".json")
                and current_timestamp not in f  # Exclude current run snapshots
            ]
            
            if not snapshot_files:
                logging.info(f"No previous snapshot found for {site_name} - this appears to be the first run")
                return None
            
            # Get most recent by filename (contains timestamp)
            latest_file = sorted(snapshot_files)[-1]
            filepath = os.path.join(self.snapshots_dir, latest_file)
            
            logging.info(f"Loading previous snapshot for {site_name}: {latest_file}")
            data = read_json(filepath)
            return SiteSnapshot(**data)
            
        except Exception as e:
            logging.error(f"Error loading previous backup snapshot for {site_name}: {e}")
            return None

    def _backup_all_as_new(self, snapshot: SiteSnapshot) -> List[FileChange]:
        """Backup all files as new (first run scenario)."""
        changes = []
        for relative_path, file_info in snapshot.files.items():
            change = FileChange(
                file_path=file_info["full_path"],
                change_type="new",
                site_id=snapshot.site_id,
                country=snapshot.country,
                file_size=file_info["size"],
                last_modified=file_info["last_modified"],
                detection_timestamp=dt.datetime.now().isoformat(),
                file_hash=file_info.get("hash"),
                relative_path=relative_path,
                creation_time=file_info.get("creation_time")
            )
            
            # Backup the file
            backup_path = self._backup_file_to_regional_hub(change)
            change.backup_path = backup_path
            
            # Copy to OCR input if it's a compatible file type
            ocr_path = self._copy_to_ocr_input(
                file_info["full_path"], 
                relative_path, 
                snapshot.country
            )
            
            changes.append(change)
            self.stats["files_detected"] += 1
            
        return changes

    def _file_changed(self, current: Dict, previous: Dict) -> bool:
        """Determine if file has changed by comparing hash, size, and modification time."""
        # Compare hash if available (most reliable)
        current_hash = current.get("hash")
        previous_hash = previous.get("hash")
        
        if current_hash and previous_hash:
            return current_hash != previous_hash
        
        # Fallback to size and modification time
        size_changed = current.get("size", 0) != previous.get("size", 0)
        time_changed = current.get("last_modified", "") != previous.get("last_modified", "")
        
        return size_changed or time_changed

    def _is_folder_excluded(self, folder_name: str) -> bool:
        """Check if folder should be excluded from scanning."""
        return folder_name in self.exclude_folders or folder_name.startswith(".")

    def _is_file_allowed(self, file_path: str, filename: str) -> bool:
        """Check if file meets filtering criteria."""
        # Skip temporary files
        if filename.startswith("~$") or filename.startswith("."):
            return False
        
        # Check file extension if filter is set
        if self.file_types_allowed:
            file_ext = os.path.splitext(filename)[1].lower()
            if file_ext not in self.file_types_allowed:
                return False
        
        return True

    def _save_backup_report(self, site_name: str, changes: List[FileChange]) -> None:
        """Save backup report for specific site."""
        timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_report_{site_name}_{timestamp}.json"
        filepath = os.path.join(self.backup_reports_dir, filename)
        
        changes_data = [asdict(change) for change in changes]
        save_json_file(changes_data, filepath)
        logging.debug(f"Backup report saved: {filename}")

    def _generate_backup_summary_report(self, all_changes: Dict[str, List[FileChange]]) -> None:
        """Generate consolidated backup summary report."""
        timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"backup_summary_{timestamp}.json"
        filepath = os.path.join(self.backup_reports_dir, filename)
        
        summary = {
            "backup_timestamp": dt.datetime.now().isoformat(),
            "regional_hub_path": self.regional_hub_path,
            "total_sites": len(all_changes),
            "total_changes": sum(len(changes) for changes in all_changes.values()),
            "processing_statistics": self.stats,
            "sites": {}
        }
        
        for site_name, changes in all_changes.items():
            site_config = self._get_site_config(site_name)
            summary["sites"][site_name] = {
                "country": site_config.get("name", "Unknown"),
                "local_path": site_config.get("path", ""),
                "total_changes": len(changes),
                "new": len([c for c in changes if c.change_type == "new"]),
                "modified": len([c for c in changes if c.change_type == "modified"]),
                "deleted": len([c for c in changes if c.change_type == "deleted"]),
                "successfully_backed_up": len([c for c in changes if c.backup_path]),
                "changes": [asdict(change) for change in changes]
            }
        
        save_json_file(summary, filepath)
        logging.info(f"Backup summary report saved: {filename}")

    def _lookup_contact_info_from_excel(self, change: FileChange, primary_subfolder: Optional[str]) -> Dict[str, str]:
        """
        Lookup responsible and manager contact information from 'Listado encargados Chile.xlsx'.
        
        Matching Strategy:
        1. Match by primary_subfolder against 'Carpeta' column (folder-based)
        2. Match by original_filename against 'Documento' column (filename-based)
        3. Return empty values if no match found
        
        Args:
            change: FileChange object containing file information
            primary_subfolder: Extracted primary subfolder name (e.g., "1-. Gestión de Requerimiento-Reclamo")
            
        Returns:
            Dict with 5 fields: responsible_email, responsible_name, manager_email, manager_name, lob
        """
        # Default empty values
        contact_info = {
            "responsible_email": "",
            "responsible_name": "",
            "manager_email": "",
            "manager_name": "",
            "lob": ""
        }
        
        try:
            # Construct path to Excel file
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            excel_path = os.path.join(project_root, "input", "Listado encargados Chile.xlsx")
            
            if not os.path.exists(excel_path):
                logging.debug(f"Email lookup Excel file not found: {excel_path}")
                return contact_info
            
            # Map country to sheet name
            sheet_mapping = {
                "Brasil": "Brazil",
                "Chile": "Chile",
                "Colombia": "Colombia",
                "Uruguay": "Uruguay"
            }
            sheet_name = sheet_mapping.get(change.country, change.country)
            
            # Read Excel file
            try:
                df = pd.read_excel(excel_path, sheet_name=sheet_name)
            except Exception as sheet_error:
                logging.debug(f"Could not read sheet '{sheet_name}' from Excel: {sheet_error}")
                return contact_info
            
            # Verify required columns exist
            required_columns = ['Lob', 'Responsable', 'Responsible_email', 'Jefatura', 'Manager_email']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                logging.debug(f"Missing columns in Excel sheet '{sheet_name}': {missing_columns}")
                # Continue with available columns
            
            # Extract original filename
            original_filename = os.path.basename(change.file_path)
            if "__" in original_filename:
                original_filename = original_filename.split("__", 1)[0]
            
            # Clean filename for matching (remove extension, normalize spaces)
            clean_filename = os.path.splitext(original_filename)[0]
            clean_filename = ' '.join(clean_filename.split())  # Normalize whitespace
            
            matched_row = None
            match_type = None
            
            # Strategy 1: Match by primary_subfolder against 'Carpeta' column
            if primary_subfolder and 'Carpeta' in df.columns:
                # Try exact match first
                carpeta_matches = df[df['Carpeta'].astype(str).str.strip() == primary_subfolder]
                if not carpeta_matches.empty:
                    matched_row = carpeta_matches.iloc[0]
                    match_type = "carpeta_exact"
                    logging.debug(f"Matched by Carpeta (exact): '{primary_subfolder}'")
                else:
                    # Try partial match (folder contains or is contained)
                    carpeta_partial = df[df['Carpeta'].astype(str).str.contains(primary_subfolder, case=False, na=False)]
                    if not carpeta_partial.empty:
                        matched_row = carpeta_partial.iloc[0]
                        match_type = "carpeta_partial"
                        logging.debug(f"Matched by Carpeta (partial): '{primary_subfolder}'")
            
            # Strategy 2: Match by filename against 'Documento' column (fallback)
            if matched_row is None and 'Documento' in df.columns:
                # Normalize Documento column values
                df['Documento_clean'] = df['Documento'].astype(str).str.strip()
                df['Documento_clean'] = df['Documento_clean'].apply(lambda x: ' '.join(x.split()))
                
                # Try exact match
                doc_matches = df[df['Documento_clean'] == clean_filename]
                if not doc_matches.empty:
                    matched_row = doc_matches.iloc[0]
                    match_type = "documento_exact"
                    logging.debug(f"Matched by Documento (exact): '{clean_filename}'")
                else:
                    # Try partial match
                    doc_partial = df[df['Documento_clean'].str.contains(clean_filename, case=False, na=False)]
                    if not doc_partial.empty:
                        matched_row = doc_partial.iloc[0]
                        match_type = "documento_partial"
                        logging.debug(f"Matched by Documento (partial): '{clean_filename}'")
            
            # Extract contact information if match found
            if matched_row is not None:
                contact_info["responsible_email"] = str(matched_row.get('Responsible_email', '')).strip() if pd.notna(matched_row.get('Responsible_email')) else ""
                contact_info["responsible_name"] = str(matched_row.get('Responsable', '')).strip() if pd.notna(matched_row.get('Responsable')) else ""
                contact_info["manager_email"] = str(matched_row.get('Manager_email', '')).strip() if pd.notna(matched_row.get('Manager_email')) else ""
                contact_info["manager_name"] = str(matched_row.get('Jefatura', '')).strip() if pd.notna(matched_row.get('Jefatura')) else ""
                contact_info["lob"] = str(matched_row.get('Lob', '')).strip() if pd.notna(matched_row.get('Lob')) else ""
                
                logging.info(f"Contact info found ({match_type}): {original_filename} -> {contact_info['responsible_email']} | LOB: {contact_info['lob']}")
            else:
                logging.debug(f"No contact match found for: {original_filename} (subfolder: {primary_subfolder})")
            
        except Exception as e:
            logging.warning(f"Email lookup failed for {change.file_path}: {e}")
        
        return contact_info

    def _create_standardized_metadata(self, change: FileChange, workflow_stage: str = "detection") -> Dict[str, Any]:
        """
        Create standardized metadata entry for a file change.
        
        Args:
            change: FileChange object containing file information
            workflow_stage: Current workflow stage (detection|ocr|pii_analysis|reporting|completed)
            
        Returns:
            Dict containing standardized metadata following the new schema
        """
        current_time = dt.datetime.now()
        
        # Generate unique file ID based on path and content
        file_id = str(uuid.uuid4())[:8]  # Short UUID for readability
        
        # Extract clean filename without automation suffixes
        original_filename = os.path.basename(change.file_path)
        if "__" in original_filename:
            original_filename = original_filename.split("__", 1)[0]
        
        # File type classification
        file_extension = os.path.splitext(original_filename)[1].lower()
        file_type_map = {
            '.docx': 'document', '.doc': 'document', '.pdf': 'document',
            '.xlsx': 'spreadsheet', '.xls': 'spreadsheet', '.csv': 'spreadsheet',
            '.ppt': 'presentation', '.pptx': 'presentation',
            '.txt': 'text', '.rtf': 'text'
        }
        file_type = file_type_map.get(file_extension, 'other')
        
        # Calculate relative paths
        try:
            source_relative = os.path.relpath(change.file_path, 
                                           os.path.dirname(change.file_path).split(os.sep)[-2])
        except:
            source_relative = change.relative_path or os.path.basename(change.file_path)
        
        # Extract primary subfolder (first folder after country_path folder)
        # This is used for email routing in S4_pii_orchestrator._get_responsible_email_folder()
        primary_subfolder = None
        if change.relative_path:
            try:
                # Split path and get first component (subfolder after base)
                path_parts = change.relative_path.replace("\\", "/").split("/")
                if len(path_parts) > 1:
                    # First part is the primary subfolder (e.g., "1-. Gestión de Requerimiento-Reclamo")
                    primary_subfolder = path_parts[0]
                    logging.debug(f"Extracted primary_subfolder: '{primary_subfolder}' from relative_path: '{change.relative_path}'")
                elif len(path_parts) == 1 and path_parts[0] != os.path.basename(change.file_path):
                    # Single folder level (rare case)
                    primary_subfolder = path_parts[0]
            except Exception as e:
                logging.debug(f"Could not extract primary_subfolder from '{change.relative_path}': {e}")
        
        # Lookup contact information from Excel (responsible/manager emails)
        contact_info = self._lookup_contact_info_from_excel(change, primary_subfolder)
        
        # Format file size
        size_mb = change.file_size / (1024 * 1024)
        if size_mb >= 1:
            size_formatted = f"{size_mb:.2f} MB"
        elif change.file_size >= 1024:
            size_formatted = f"{change.file_size / 1024:.1f} KB"
        else:
            size_formatted = f"{change.file_size} B"
        
        # Determine processing status based on change type and backup success
        processing_status = "completed" if change.backup_path else "pending"
        if change.change_type == "deleted":
            processing_status = "archived"
        
        # Create standardized metadata entry
        metadata = {
            # File Identity & Classification
            "file_id": file_id,
            "original_filename": original_filename,
            "display_name": original_filename,
            "file_extension": file_extension,
            "file_type": file_type,
            
            # Source Information (SharePoint Integration)
            "source_region": change.country,
            "source_folder": os.path.dirname(source_relative) if source_relative != original_filename else "",
            "primary_subfolder": primary_subfolder,  # NEW - First subfolder after country_path for email routing
            "source_path": source_relative,
            "source_full_path": change.file_path,
            
            # Contact Information (Email Routing) - NEW
            "responsible_email": contact_info["responsible_email"],
            "responsible_name": contact_info["responsible_name"],
            "manager_email": contact_info["manager_email"],
            "manager_name": contact_info["manager_name"],
            "lob": contact_info["lob"],
            
            # Destination Information
            "destination_name": os.path.basename(change.backup_path) if change.backup_path else None,
            "destination_path": os.path.relpath(change.backup_path, self.regional_hub_path) if change.backup_path else None,
            "destination_full_path": change.backup_path,
            
            # File System Metadata
            "creation_time": change.creation_time,
            "last_modified": change.last_modified,
            "size_bytes": change.file_size,
            "size_formatted": size_formatted,
            
            # Lifecycle & Status Tracking
            "lifecycle_status": self._map_change_type_to_lifecycle(change.change_type),
            "workflow_stage": workflow_stage,
            "processing_status": processing_status,
            "last_processed_by": "S00_change_detector_backup",
            
            # Time Tracking
            "file_add": change.detection_timestamp,
            "current_review": current_time.isoformat(),
            "last_reviewed": None,  # Could be enhanced with previous snapshot comparison
            "time_without_modification_days": self._calculate_days_since_modified(change.last_modified),
            "time_without_modification_readable": self._format_time_since_modified(change.last_modified),
            
            # Integration Fields for S3_pii_orchestrator
            "pii_analysis_completed": False,
            "pii_analysis_timestamp": None,
            "pii_entities_found": 0,
            "report_generated": False,
            "email_sent": False,
            
            # Change Detection
            "is_new_file": change.change_type == "new",
            "is_modified": change.change_type == "modified",
            "moved_to_destination": change.backup_path is not None,
            "move_reason": change.change_type,
            
            # Technical Details
            "file_hash": change.file_hash,
            "detection_timestamp": change.detection_timestamp,
            "backup_success": change.backup_path is not None
        }
        
        return metadata
    
    def _map_change_type_to_lifecycle(self, change_type: str) -> str:
        """Map FileChange change_type to standardized lifecycle status."""
        mapping = {
            "new": "nuevo_archivo",
            "modified": "modificado", 
            "deleted": "file_eliminated"
        }
        return mapping.get(change_type, "active_file")
    
    def _calculate_days_since_modified(self, last_modified: str) -> float:
        """Calculate days since file was last modified."""
        try:
            if isinstance(last_modified, str):
                last_mod_dt = dt.datetime.fromisoformat(last_modified.replace('Z', '+00:00'))
            else:
                last_mod_dt = last_modified
            
            days_diff = (dt.datetime.now() - last_mod_dt.replace(tzinfo=None)).total_seconds() / 86400
            return round(days_diff, 2)
        except:
            return 0.0
    
    def _format_time_since_modified(self, last_modified: str) -> str:
        """Format time since modification in human-readable format."""
        try:
            days = self._calculate_days_since_modified(last_modified)
            if days < 1:
                hours = int(days * 24)
                minutes = int((days * 24 * 60) % 60)
                return f"{hours} hours and {minutes} minutes"
            elif days < 7:
                return f"{int(days)} day{'s' if int(days) != 1 else ''}"
            elif days < 30:
                weeks = int(days / 7)
                return f"{weeks} week{'s' if weeks != 1 else ''}"
            else:
                months = int(days / 30)
                return f"{months} month{'s' if months != 1 else ''}"
        except:
            return "unknown"
    
    def _save_standardized_metadata(self) -> bool:
        """
        Save standardized metadata to both JSON and Excel formats.
        
        Returns:
            bool: True if both formats saved successfully
        """
        try:
            if not self.metadata_list:
                logging.info("No metadata to save")
                return True
            
            # Save JSON format
            save_json_file(self.metadata_list, self.metadata_json_path)
            logging.info(f"Standardized metadata saved to JSON: {self.metadata_json_path}")
            
            # Save Excel format with enhanced error handling
            try:
                # Clean metadata for Excel - handle None values and complex types
                cleaned_metadata = []
                for item in self.metadata_list:
                    cleaned_item = {}
                    for key, value in item.items():
                        if value is None:
                            cleaned_item[key] = ""
                        elif isinstance(value, (list, dict)):
                            cleaned_item[key] = str(value)
                        else:
                            cleaned_item[key] = value
                    cleaned_metadata.append(cleaned_item)
                
                df = pd.DataFrame(cleaned_metadata)
                
                # Reorder columns for better readability
                preferred_columns = [
                    "file_id", "original_filename", "source_region", "primary_subfolder",
                    "responsible_email", "responsible_name", "manager_email", "manager_name", "lob",
                    "lifecycle_status", "workflow_stage", "processing_status", "file_type", 
                    "size_formatted", "creation_time", "last_modified", "detection_timestamp", 
                    "source_full_path", "destination_full_path", "backup_success"
                ]
                
                # Get available columns in preferred order, then remaining columns
                available_preferred = [col for col in preferred_columns if col in df.columns]
                remaining_columns = [col for col in df.columns if col not in preferred_columns]
                final_column_order = available_preferred + remaining_columns
                
                df = df[final_column_order]
                
                # Try framework utility first
                try:
                    save_excel_file(df, self.metadata_excel_path)
                    logging.info(f"Standardized metadata saved to Excel: {self.metadata_excel_path}")
                    return True
                except Exception as framework_error:
                    logging.warning(f"Framework Excel save failed: {framework_error}, trying pandas directly")
                    # Fallback to direct pandas export
                    df.to_excel(self.metadata_excel_path, index=False, engine='openpyxl')
                    logging.info(f"Standardized metadata saved to Excel (pandas fallback): {self.metadata_excel_path}")
                    return True
                    
            except ImportError as import_error:
                logging.error(f"Missing required packages for Excel export: {import_error}")
                logging.info("Install required packages: pip install pandas openpyxl xlsxwriter")
                return False
            except Exception as excel_error:
                logging.error(f"Failed to save metadata to Excel: {excel_error}")
                logging.warning("Excel export failed, but JSON was saved successfully")
                return False
                
        except Exception as e:
            logging.warning(f"Failed to save standardized metadata: {e}")
            return False

    def _generate_metadata_from_changes(self, all_changes: Dict[str, List[FileChange]]) -> None:
        """
        Generate standardized metadata entries from all detected file changes.
        
        Args:
            all_changes: Dictionary mapping site names to lists of FileChange objects
        """
        try:
            self.metadata_list = []  # Reset metadata list
            
            for site_name, changes in all_changes.items():
                logging.debug(f"Processing metadata for {len(changes)} changes in {site_name}")
                
                for change in changes:
                    try:
                        # Determine workflow stage based on processing results
                        workflow_stage = "detection"
                        if change.backup_path:
                            workflow_stage = "ocr" if self._is_ocr_compatible_file(change.file_path) else "completed"
                        
                        metadata = self._create_standardized_metadata(change, workflow_stage)
                        self.metadata_list.append(metadata)
                        
                    except Exception as e:
                        logging.error(f"Error creating metadata for {change.file_path}: {e}")
                        continue
            
            logging.info(f"Generated standardized metadata for {len(self.metadata_list)} files")
            
        except Exception as e:
            logging.error(f"Error generating metadata from changes: {e}")
            self.metadata_list = []

    def _cleanup_old_snapshots(self) -> None:
        """Clean up old backup snapshots based on retention policy."""
        try:
            retention_days = 30  # Keep snapshots for 30 days
            cutoff_date = dt.datetime.now() - dt.timedelta(days=retention_days)
            removed_count = 0
            
            for filename in os.listdir(self.snapshots_dir):
                if not filename.startswith("backup_snapshot_") or not filename.endswith(".json"):
                    continue
                
                filepath = os.path.join(self.snapshots_dir, filename)
                file_mtime = dt.datetime.fromtimestamp(os.path.getmtime(filepath))
                
                if file_mtime < cutoff_date:
                    os.remove(filepath)
                    removed_count += 1
                    logging.debug(f"Removed old backup snapshot: {filename}")
            
            if removed_count > 0:
                logging.info(f"Cleaned up {removed_count} old backup snapshots")
                
        except Exception as e:
            logging.error(f"Error cleaning up old backup snapshots: {e}")


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = S00ChangeDetectorBackup(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")