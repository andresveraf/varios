#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3 ML-based NER Detector

Advanced PII detection using spaCy NER and transformer models.
Context-aware and more accurate, but computationally intensive.

DOCUMENTATION ACCESS:
- Class overview: help(S3_MachineLearningNER) or S3_MachineLearningNER.__doc__
- Method details: help(S3_MachineLearningNER.is_valid_person_name)
- Blacklist explanations: See class docstring for complete blacklist system overview
- Usage examples: Included in method docstrings

QUICK REFERENCE - Blacklist Systems:
1. problematic_words_norm: Rejects Spanish adverbs, business terms (47 words)
2. name_trailer_blacklist_norm: Strips organizational suffixes (23 terms)  
3. financial_terms: Domain-specific insurance/pension terms (40+ terms)
"""

import os
import ssl
import logging
import datetime as dt
import re
import traceback
from typing import Optional, List, Dict, Tuple, Iterable, Any

import spacy

# Project imports
from src.utils.fmw_utils import save_json_file
from src.process_scripts.base_pii_detector import BasePIIDetector
from src.utils.pii_utils import (
    PIIValidators, TextProcessingUtils, EntityUtils, ExclusionLists
)

# Optional stemmer
try:
    import snowballstemmer
    STEMMING_AVAILABLE = True
    _SPANISH_STEMMER = snowballstemmer.stemmer("spanish")
except Exception as e:
    STEMMING_AVAILABLE = False
    _SPANISH_STEMMER = None
    logging.error(f"SnowballStemmer import error: {e}")

# Optional embedding reranker
try:
    from process_scripts.test.sbert_reranker import EmbeddingReranker
    EMBED_RERANK_AVAILABLE = True
except Exception as _emb_err:
    EMBED_RERANK_AVAILABLE = False
    EmbeddingReranker = None
    logging.warning(f"Embedding reranker unavailable: {_emb_err}")

# Transformers (HuggingFace)
try:
    from transformers import pipeline
    TRANSFORMERS_AVAILABLE = True
except ImportError as e:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("transformers library not available. Install with: pip install transformers torch")

try:
    import torch
    HAS_CUDA = torch.cuda.is_available()
except Exception as e:
    HAS_CUDA = False
    logging.error(f"Torch import or CUDA check error: {e}")

device_id = 0 if HAS_CUDA else -1

# spaCy NER model loading
NER_AVAILABLE = False
nlp = None
try:
    nlp = spacy.load(rf"C:\RPA\repositorio\OPS\OP01_ocr_pii\model_spacy\model-last")
    nlp.max_length = max(getattr(nlp, "max_length", 1_000_000), 2_000_000)
    NER_AVAILABLE = True
    logging.info("Spanish NER model loaded: model-last")
except OSError as e:
    try:
        nlp = spacy.load("es_core_news_lg", disable=["lemmatizer", "attribute_ruler"])
        nlp.max_length = max(getattr(nlp, "max_length", 1_000_000), 2_000_000)
        NER_AVAILABLE = True
        logging.info("Spanish NER model loaded: es_core_news_lg")
    except OSError as e2:
        logging.warning("Spanish NER model not found")
        NER_AVAILABLE = False

# Transformer pipeline setup
transformer_ner = None
TRANSFORMER_NER_AVAILABLE = False

if TRANSFORMERS_AVAILABLE:
    try:
        import warnings
        warnings.filterwarnings("ignore", message=".*pooler.*")

        cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models")
        os.makedirs(cache_dir, exist_ok=True)
        os.environ["TRANSFORMERS_CACHE"] = cache_dir
        os.environ["HF_HOME"] = cache_dir
        os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

        local_model_paths = [
            os.path.join(cache_dir, "mrm8488", "bert-spanish-cased-finetuned-ner"),
            os.path.join(cache_dir, "PlanTL-GOB-ES", "roberta-large-bne-capitel-ner"),
            os.path.join(cache_dir, "PlanTL-GOB-ES", "roberta-base-bne-capitel-ner"),
        ]

        for model_path in local_model_paths:
            if os.path.exists(model_path) and os.path.exists(os.path.join(model_path, "config.json")):
                try:
                    transformer_ner = pipeline(
                        "ner",
                        model=model_path,
                        tokenizer=model_path,
                        aggregation_strategy="simple",
                        device=device_id,
                    )
                    TRANSFORMER_NER_AVAILABLE = True
                    logging.info(f"[SUCCESS] Loaded local transformer NER: {os.path.basename(model_path)}")
                    break
                except Exception as e:
                    logging.warning(f"Failed to load local model {model_path}: {e}")

        if not TRANSFORMER_NER_AVAILABLE:
            model_options = [
                "PlanTL-GOB-ES/roberta-large-bne-capitel-ner",
                "PlanTL-GOB-ES/roberta-base-bne-capitel-ner",
                "mrm8488/bert-spanish-cased-finetuned-ner",
            ]
            for name in model_options:
                try:
                    transformer_ner = pipeline(
                        "ner",
                        model=name,
                        tokenizer=name,
                        aggregation_strategy="simple",
                        device=device_id,
                    )
                    TRANSFORMER_NER_AVAILABLE = True
                    logging.info(f"[SUCCESS] Downloaded transformer NER: {name}")
                    break
                except Exception as e:
                    logging.warning(f"Download failed for {name}: {e}")
    except Exception as e:
        logging.warning(f"[WARNING] Transformer init failed: {e}")


# PseudoTransformer (fallback)
class PseudoTransformerNER:
    def __init__(self) -> None:
        self.confidence_base = 0.85

    def __call__(self, text: str) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        try:
            # Simple person name pattern
            pat = r"\b([A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,}(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,}){1,3})\b"
            for m in re.finditer(pat, text):
                out.append({
                    "entity_group": "PER", 
                    "word": m.group(1), 
                    "score": 0.85, 
                    "start": m.start(1), 
                    "end": m.end(1)
                })
        except Exception as e:
            logging.warning(f"Pseudo NER error: {e}")
        return out

if TRANSFORMER_NER_AVAILABLE and transformer_ner is None:
    transformer_ner = PseudoTransformerNER()
    logging.info("[INFO] Using pseudo-transformer NER fallback")


class S3_MachineLearningNER(BasePIIDetector):
    """
    ML-based NER - context-aware and accurate PII detection.
    
    This detector uses spaCy and transformer models for named entity recognition,
    with sophisticated filtering to reduce false positives common in business documents.
    
    Key Features:
    - Dual NER pipeline: spaCy + Transformers for comprehensive coverage
    - Advanced name validation with blacklist systems
    - Context-aware filtering based on surrounding text
    - Lemmatization and stemming for language-aware matching
    - Embedding-based reranking for semantic validation
    
    Blacklist Systems:
    
    1. Problematic Words (self.problematic_words_norm):
       - Spanish adverbs: "posteriormente", "anteriormente", "actualmente"
       - Business terms: "administrador", "beneficiarios", "centralizacion"  
       - Process verbs: "realizamos", "procesamos", "validamos"
       - Domain terms: "emision", "polizas", "cotizacion"
       Purpose: Reject words ML models commonly mistake for person names
       
    2. Name Trailer Blacklist (self.name_trailer_blacklist_norm):
       - Organizational: "contingent", "division", "department", "group"
       - Job titles: "worker", "employee", "trabajador", "empleado"
       - Legal entities: "inc", "ltd", "sa", "s.a."
       Purpose: Strip trailing terms from valid names (e.g., "Juan Pérez Division" → "Juan Pérez")
       
    3. Financial Terms (self.financial_terms):
       - Insurance: "poliza", "seguro", "prima", "beneficiarios"
       - Pension: "renta", "pension", "afp", "cotizacion"  
       - Chilean system: "fonasa", "isapre", "superintendencia"
       Purpose: Reject domain-specific terms that aren't person names
       
    Usage:
        detector = S3_MachineLearningNER(config)
        results = detector.extract_pii_from_text("Juan Pérez Contingent trabaja aquí")
        # Returns: [{"PII_Type": "CUSTOMER_NAME", "PII_Value": "Juan Pérez", ...}]
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config=config)
        
        # ML-specific configuration
        self.use_lemmas = bool(self.config_env.get("USE_SPACY_LEMMAS", False))
        self.lemma_model_name = self.config_env.get("LEMMA_MODEL", "es_core_news_sm")
        self.use_stemming = True  # Always on in code
        self.use_embed_rerank = bool(self.config_env.get("USE_EMBED_RERANK", True))
        self.embed_model_name = self.config_env.get("EMBED_MODEL", "intfloat/multilingual-e5-small")
        
        # Initialize lemma pipeline
        self.nlp_lemma = None
        if self.use_lemmas:
            self._init_lemma_pipeline(self.lemma_model_name)

        # Initialize stemmer
        self._stemmer = _SPANISH_STEMMER if (STEMMING_AVAILABLE and self.use_stemming) else None

        # Initialize embedding reranker
        self._embed_reranker = None
        # Read additional reranker / text-embedding configuration from environment
        self.use_text_embedding = bool(self.config_env.get("USE_TEXT_EMBEDDING", True))
        # Prefer explicit TEXT_EMBEDDING_MODEL, fallback to EMBED_MODEL for backwards compatibility
        self.text_embedding_model = self.config_env.get("TEXT_EMBEDDING_MODEL", self.embed_model_name)
        self.rerank_top_k = int(self.config_env.get("RERANK_TOP_K", 5))
        self.rerank_similarity_threshold = float(self.config_env.get("RERANK_SIMILARITY_THRESHOLD", 0.6))
        self.rerank_batch_size = int(self.config_env.get("RERANK_BATCH_SIZE", 32))

        if self.use_embed_rerank and EMBED_RERANK_AVAILABLE and self.use_text_embedding:
            try:
                # Instantiate with tuned parameters from config.jsonc
                self._embed_reranker = EmbeddingReranker(
                    model_name=self.text_embedding_model,
                    encode_batch_size=self.rerank_batch_size,
                    rerank_top_k=self.rerank_top_k,
                    rerank_similarity_threshold=self.rerank_similarity_threshold,
                )
                logging.info(f"[SUCCESS] Embedding reranker loaded: {self.text_embedding_model} | batch={self.rerank_batch_size} | top_k={self.rerank_top_k} | thr={self.rerank_similarity_threshold}")
            except Exception as e:
                logging.warning(f"[WARNING] Could not initialize embedding reranker: {e}")

        # Enhanced context analyzer with ML capabilities
        from src.utils.pii_utils import ContextAnalyzer
        self.context_analyzer = ContextAnalyzer(
            use_lemmas=self.use_lemmas,
            use_stemming=self.use_stemming,
            nlp_lemma=self.nlp_lemma,
            stemmer=self._stemmer
        )

        # Financial domain terms for person rejection (expanded)
        self.financial_terms = {
            "vitalicias", "vitalicia", "poliza", "polizas", "renta", "mensual", "pension", "seguro", "seguros",
            "validacion", "beneficiarios", "traspaso", "cotizacion", "afiliado", "prima", "uf", "superintendencia",
            "fonasa", "isapre", "afp", "cuprum", "habitat", "provida", "planvital", "modelo", "capital", "uno",
            "chile", "ips", "scomp", "compañia", "aseguradora", "diferido", "intermediario", "garantizado",
            "solicitud", "endosos", "clausula", "articulo", "modalidad", "periodo", "fecha", "valor", "tasa",
            "descuento", "cierre", "casos", "cerrados", "recupera", "reporte", "exporta", "termina", "ready",
            "procesar", "imprime", "concluido", "direccion", "comuna", "ciudad", "estado", "civil", "nacimiento",
            "masculino", "femenino", "casado", "soltero", "viudo", "divorciado", "sistema", "salud", "invalidez",
        }

        # Problematic words blacklist - used to reject false-positive names
        # These are Spanish adverbs, business terms, and process-related words that
        # machine learning models often incorrectly classify as person names
        self.problematic_words = {
            # Spanish temporal adverbs that ML models mistake for names
            'posteriormente', 'anteriormente', 'actualmente', 'finalmente', 'inicialmente',
            'principalmente', 'especialmente', 'particularmente', 'generalmente', 'normalmente',
            
            # Business/administrative terms incorrectly detected as names
            'administrador', 'beneficiarios', 'centralizacion', 'fallocimiento', 'banco', 'area',
            
            # Process action verbs that appear in documents
            'presionamos', 'arrastrando', 'continuamos', 'seleccionamos', 'aceptacion',
            'realizamos', 'completamos', 'procesamos', 'verificamos', 'confirmamos',
            'ejecutamos', 'terminamos', 'validamos', 'revisamos', 'enviamos','enviado',
            
            # Mixed language and domain-specific terms
            'contingent', 'emision', 'creacion', 'polizas', 'renta', 'vitalicias', 
            'pension', 'worker', 'cotizacion', 'datos', 'validar', 'digital', 
            'dental', 'telefono', 'valido', 'hasta', 'sexo', 'nacimiento', 'cliente', 'pag',
            'codigo', 'responder', 'metlife', 'EOmetlife','Qmetlife', 'dental', 'contingent worker',
            'megocios', 'asegurado', 'asegurados', 'afiliado', 'afiliados', 'aseguradora',
            'gasto', 'deputy', 'manager', 'estimada','reclamos', 'realizado', 'por', 'analista',
            'asignada', 'Rechmos', 'fecha', 'glosa', 'nombre', 'asegurado', 'asegurada', 'asegurados',
            'aseguradas', 'cliente', 'clientes', 'titular', 'titulares', 'beneficiario', 'beneficiarios',
            'cotizacion', 'cotizaciones', 'pension', 'pensiones', 'poliza', 'polizas', 'polizas', 'prima',
            'primas', 'renta', 'rentas', 'vitalicia','ByPass', 'Deducible'

        }
        
        # Normalized problematic words for fast accent-insensitive matching
        # Purpose: Allows matching regardless of accents (e.g., "creación" matches "creacion")
        # Usage: Used in is_valid_person_name() to quickly reject false positives
        self.problematic_words_norm = {TextProcessingUtils.strip_accents(w.lower()) for w in self.problematic_words}

        # Name trailer blacklist - tokens commonly appended to real names by transformers
        # These appear when table parsers or OCR systems incorrectly combine person names
        # with adjacent organizational terms, job titles, or descriptive words
        self.name_trailer_blacklist = {
            # English organizational terms
            "contingent", "inc", "ltd", "group", "division", "department", "team", 
            "unit", "service", "agency", "cont.", "worker", "employee",
            
            # Spanish equivalents  
            "contingente", "sa", "s.a.", "división", "departamento", "equipo",
            "unidad", "servicio", "agencia", "trabajador", "empleado", "contingent", 
            "worker", "deputy", "manager", "analista", "asignada", "asignado",
        }
        
        # Normalized name trailer blacklist for accent-insensitive matching
        # Purpose: Strips common suffixes like "Jenifer Prado Contingent" → "Jenifer Prado"
        # Usage: Applied in both is_valid_person_name() and extract_transformer_ner()
        self.name_trailer_blacklist_norm = {TextProcessingUtils.strip_accents(w.lower()) for w in self.name_trailer_blacklist}

        # Precompute normalized sets for enhanced context analysis
        self._precompute_normalized_sets()

        logging.info(
            f"S3_MachineLearningNER initialized | "
            f"transformer={TRANSFORMER_NER_AVAILABLE} | "
            f"spacy_ner={NER_AVAILABLE} | "
            f"lemmas={'ON' if (self.use_lemmas and self.nlp_lemma) else 'OFF'} | "
            f"stemming={'ON' if self._stemmer else 'OFF'} | "
            f"rerank={'ON' if self._embed_reranker else 'OFF'}"
        )

    def _init_lemma_pipeline(self, model_name: str) -> None:
        """Initialize spaCy lemma pipeline for Spanish language processing"""
        try:
            nlp_lemma = spacy.load(model_name, disable=["ner"])
            nlp_lemma.max_length = max(getattr(nlp_lemma, "max_length", 1_000_000), 2_000_000)
            _ = [t.lemma_ for t in nlp_lemma("cotizaciones pólizas clientes")]
            self.nlp_lemma = nlp_lemma
            logging.info(f"[SUCCESS] Lemma pipeline loaded: {model_name}")
        except Exception as e:
            self.nlp_lemma = None
            self.use_lemmas = False
            logging.warning(f"[WARNING] Lemma pipeline init failed: {e}")

    def _precompute_normalized_sets(self):
        """
        Precompute normalized word sets for efficient context analysis.
        
        This method creates lemmatized and stemmed versions of context word sets
        to enable fast, language-aware matching during PII validation. The normalization
        helps handle variations in word forms (e.g., "cotización" vs "cotizaciones").
        
        Creates normalized sets for:
        - good_ctx_words: Terms indicating person name context ("nombre", "cliente", etc.)
        - bad_ctx_words: Terms indicating non-person context ("renta", "póliza", etc.)  
        - financial_terms: Domain-specific terms to reject as person names
        - phone_ctx_words: Terms indicating phone number context
        
        Each set is normalized in three ways:
        1. Base: Accent-stripped, lowercased
        2. Lemmas: Reduced to root forms using spaCy (if enabled)
        3. Stems: Reduced to stems using Spanish stemmer (if available)
        
        The appropriate normalized set is selected based on ML pipeline configuration.
        """
        self.good_ctx_words = {"nombre", "titular", "afiliado", "asegurado", "cliente", "conyuge", "cónyuge"}
        self.bad_ctx_words = {"renta", "mensual", "poliza", "póliza", "cotizacion", "cotización", "oferta", "scomp", "uf", "saldo"}
        self.phone_ctx_words = {"tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext"}

        self.good_ctx_lemmas = self._normalize_wordset(self.good_ctx_words, use_lemma=True)
        self.bad_ctx_lemmas = self._normalize_wordset(self.bad_ctx_words, use_lemma=True)
        self.financial_terms_lemmas = self._normalize_wordset(self.financial_terms, use_lemma=True)
        self.phone_ctx_lemmas = self._normalize_wordset(self.phone_ctx_words, use_lemma=True)

        self.good_ctx_stems = self._normalize_wordset(self.good_ctx_words, use_stem=True)
        self.bad_ctx_stems = self._normalize_wordset(self.bad_ctx_words, use_stem=True)
        self.financial_terms_stems = self._normalize_wordset(self.financial_terms, use_stem=True)
        self.phone_ctx_stems = self._normalize_wordset(self.phone_ctx_words, use_stem=True)

    def _normalize_wordset(self, words: Iterable[str], use_lemma: bool = False, use_stem: bool = False) -> set:
        """Normalize a set of words using lemma or stem if enabled"""
        words = list(words or [])
        if not words:
            return set()
        folded = [TextProcessingUtils.strip_accents(w.lower()) for w in words]
        if use_lemma and self.use_lemmas and self.nlp_lemma:
            return set(self._lemma_tokens(folded))
        if use_stem and self._stemmer:
            return set(self._stem_tokens(folded))
        return set(folded)

    def _ctx_tokens(self, text: str) -> List[str]:
        """Tokenize context text into alphabetic tokens"""
        return re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", text or "")

    def _lemma_tokens(self, tokens: List[str]) -> List[str]:
        """Lemmatize tokens using spaCy if available"""
        if not tokens:
            return []
        base = [TextProcessingUtils.strip_accents(t.lower()) for t in tokens]
        if self.use_lemmas and self.nlp_lemma:
            try:
                doc = self.nlp_lemma(" ".join(base))
                return [TextProcessingUtils.strip_accents(t.lemma_.lower()) for t in doc if t.lemma_]
            except Exception:
                return base
        return base

    def _stem_tokens(self, tokens: List[str]) -> List[str]:
        """Stem tokens using the Spanish stemmer if available"""
        if not tokens:
            return []
        base = [TextProcessingUtils.strip_accents(t.lower()) for t in tokens]
        if self._stemmer:
            try:
                return self._stemmer.stemWords(base)
            except Exception:
                return base
        return base

    def _iter_ner_chunks(self, text: str, max_chars: int = 512, overlap: int = 200) -> Iterable[Tuple[int, str]]:
        """Split text into overlapping chunks for NER processing"""
        n = len(text)
        start = 0
        while start < n:
            end = min(n, start + max_chars)
            yield start, text[start:end]
            if end == n:
                break
            start = end - overlap

    def _is_plausible_person_span(self, value: str) -> bool:
        """Heuristic to check if a string is a plausible person name span"""
        val = (value or "").strip()
        if not val: 
            return False
        if len(val) > self.MAX_PERSON_CHARS: 
            return False
        if len(val.split()) > self.MAX_PERSON_TOKENS: 
            return False
        return True

    def _assess_name_confidence(self, words: List[str]) -> float:
        """Assess confidence that a list of words is a valid Spanish person name"""
        if not words or len(words) < 2: 
            return 0.0
        
        conf = 0.0

        # Most common first names
        common_first = {
            "AGUSTÍN", "ALEJANDRO", "ALONSO", "ÁLVARO", "ANDRÉS", "ÁXEL", "BAUTISTA", "BENJAMÍN", "BRUNO", "CALEB",
            "CAMILO", "CARLOS", "CRISTÓBAL", "CRISTIAN", "DAMIÁN", "DANIEL", "DAVID", "DIEGO", "EDUARDO", "ELÍAS",
            "EMILIANO", "EMMANUEL", "ENRIQUE", "ESTEBAN", "ETHAN", "FEDERICO", "FERNANDO", "FRANCISCO", "GABRIEL",
            "GAEL", "GASPAR", "GERMÁN", "GUSTAVO", "HERNÁN", "IAN", "IGNACIO", "ISIDORO", "IVÁN", "JAIR", "JAIRO",
            "JASON", "JEREMY", "JHON", "JOAQUÍN", "JORGE", "JUAN", "JULIÁN", "KEVIN", "KIAN", "LEÓN", "LEONARDO",
            "LIAM", "LORENZO", "LUCCA", "LUIS", "MARCELO", "MARCO", "MARTÍN", "MATÍAS", "MATEO", "MAURICIO",
            "MAXIMILIANO", "MIGUEL", "NICOLÁS", "OLIVER", "OMAR", "ORLANDO", "PATRICIO", "PAULO", "PEDRO", "RAFAEL",
            "RAMIRO", "RICARDO", "ROBERTO", "RODRIGO", "RUBÉN", "SAMUEL", "SANTIAGO", "SEBASTIÁN", "SIMÓN", "THIAGO",
            "TOBÍAS", "TOMÁS", "VALENTINO", "VÍCTOR", "VICENTE", "WALTER", "XANDER", "ZAHIR",
            "AGUSTINA", "AINHOA", "AITANA", "ALBA", "ALEJANDRA", "ALEXA", "ALEXANDRA", "ALMENDRA", "AMANDA", "AMELIA",
            "ANAÍS", "ANTONELLA", "ANTONIA", "ARANTXA", "ARIADNA", "AROHA", "AZUL", "BELÉN", "BLANCA", "BRISA",
            "CAMILA", "CARLA", "CAROLINA", "CATALINA", "CELIA", "CLARA", "CLAUDIA", "CONSTANZA", "DANIELA", "DÉBORA",
            "DIANA", "DOMINIQUE", "ELISA", "ELIZABETH", "EMILIA", "EMMA", "ESMERALDA", "ESTEFANÍA", "FERNANDA",
            "FLORENCIA", "FRANCISCA", "GABRIELA", "GIOVANNA", "ISABELLA", "IVANNA", "JAVIERA", "JIMENA", "JOSEFINA",
            "JUANITA", "JULIETA", "KARINA", "KARLA", "KATIA", "KIARA", "LARA", "LAURA", "LAYLA", "LILA", "LUCIANA",
            "LUISA", "LUNA", "MACARENA", "MAGDALENA", "MANUELA", "MARÍA", "MARTINA", "MATILDA", "MÍA", "MILA",
            "MIREYA", "NATALIA", "NEREA", "NICOLE", "NOELIA", "OLIVIA", "PALOMA", "PAOLA", "PAULINA", "PAZ",
            "PENÉLOPE", "RENATA", "ROCÍO", "ROMINA", "ROSARIO", "SALOMÉ", "SAMANTHA", "SARA", "SOFÍA", "SOL",
            "TAMARA", "VALENTINA", "VALERIA", "VANIA", "VERÓNICA", "VICTORIA", "VIOLETA", "XIMENA", "YASNA",
            "YOLANDA", "ZOE"
        }
        
        # Most common surnames
        common_surn = {
            "GONZÁLEZ", "MUÑOZ", "ROJAS", "DÍAZ", "PÉREZ", "SOTO", "CONTRERAS", "SILVA", "MARTÍNEZ", "SEPÚLVEDA",
            "MORALES", "RODRÍGUEZ", "LÓPEZ", "ARAYA", "FUENTES", "HERNÁNDEZ", "TORRES", "ESPINOZA", "FLORES",
            "CASTILLO", "REYES", "VALENZUELA", "VARGAS", "RAMÍREZ", "GUTIÉRREZ", "HERRERA", "ÁLVAREZ", "VÁSQUEZ",
            "TAPIA", "SÁNCHEZ", "FERNÁNDEZ", "CARRASCO", "CORTÉS", "GÓMEZ", "JARA", "VERGARA", "RIVERA", "NÚÑEZ",
            "BRAVO", "FIGUEROA", "RIQUELME", "MOLINA", "VERA", "SANDOVAL", "GARCÍA", "VEGA", "MIRANDA", "ROMERO",
            "ORTIZ", "SALAZAR", "CAMPOS", "ORELLANA", "OLIVARES", "GARRIDO", "PARRA", "GALLARDO", "SAAVEDRA",
            "ALARCON", "AGUILERA", "PEÑA", "ZÚÑIGA", "RUIZ", "MEDINA", "GUZMÁN", "ESCOBAR", "NAVARRO", "PIZARRO",
            "GODOY", "CÁCERES", "HENRÍQUEZ", "ARAVENA", "MORENO", "LEIVA", "SALINAS", "VIDAL", "LAGOS", "VALDÉS",
            "RAMOS", "MALDONADO", "JIMÉNEZ", "YÁÑEZ", "BUSTOS", "ORTEGA", "PALMA", "CARVAJAL", "PINO", "ALVARADO",
            "PAREDES", "GUERRERO", "MORA", "POBLETE", "SÁEZ", "VENEGAS", "SANHUEZA", "BUSTAMANTE", "TORO",
            "NAVARRETE", "CÁRDENAS", "DA SILVA", "DOS SANTOS", "DE SOUZA", "RODRIGUES", "COSTA", "SANTOS", "SOUSA",
            "OLIVEIRA", "LIMA", "PEREIRA"
        }

        if words[0].upper() in common_first: 
            conf += 0.4
        elif words[0][0].isupper() and len(words[0]) >= 3: 
            conf += 0.2
        
        # Check for common second names in compound names (3 or more words)
        # We use the same list as common_first since most names can be first or second.
        if len(words) > 2 and words[1].upper() in common_first:
            conf += 0.25
        
        # Check for surnames
        for w in words[1:]:
            if w.upper() in common_surn: 
                conf += 0.3
            elif w[0].isupper() and len(w) >= 3: 
                conf += 0.1
        
        if 2 <= len(words) <= 4: 
            conf += 0.1
        if any(len(w) > 15 for w in words): 
            conf -= 0.2
        
        return min(max(conf, 0.0), 1.0)

    def is_valid_person_name(self, text: str) -> bool:
        """
        Enhanced person name validation with ML-based context analysis.
        
        This method performs comprehensive validation to distinguish genuine person names
        from false positives commonly generated by ML/NER models in document processing.
        
        Validation Steps:
        1. Strip trailing organizational terms (e.g., "Contingent", "Division") 
        2. Reject problematic words (Spanish adverbs, business terms, process words)
        3. Apply structural validation (2-4 words, alphabetic characters)
        4. Check against financial domain terms using lemmatization/stemming
        5. Validate against Chilean name patterns and common surnames
        
        Args:
            text (str): Candidate person name text to validate
            
        Returns:
            bool: True if text appears to be a valid person name, False otherwise
            
        Examples:
            >>> detector.is_valid_person_name("Juan Pérez Contingent")  # True (strips "Contingent")
            >>> detector.is_valid_person_name("posteriormente creacion")  # False (problematic words)
            >>> detector.is_valid_person_name("María González")  # True (valid name)
        """
        if not text or len(text.strip()) < 2: 
            return False
        
        # CRITICAL FIX: Explicit rejection of common Spanish adverbs and non-name words
        text_clean = text.strip().lower()
        words = text_clean.split()
        
        # Reject single words immediately - Chilean names require 2+ words
        if len(words) < 2:
            return False
        
        # Use centralized ExclusionLists for comprehensive filtering
        # Strip trailing terms and check exclusions
        cleaned_words = ExclusionLists.strip_trailing_terms(words)
        
        # After trimming, check if we still have valid name structure
        if len(cleaned_words) < 2:
            return False
        
        # Check each word against centralized exclusions (includes OCR artifacts)
        for word in cleaned_words:
            if ExclusionLists.is_excluded_word(word):
                return False

        # Check the full phrase for any exclusion patterns
        cleaned_text = " ".join(cleaned_words)
        if ExclusionLists.is_excluded_phrase(cleaned_text):
            return False
        
        # Use cleaned words for remaining validation
        words = cleaned_words
        
        # Apply all validation from regex version plus ML enhancements
        text_upper = text.upper()
        
        # Early exclusions
        form_field_patterns = [
            "CONYUGE", "CONYUGUE", "HIJOS", "FEMENINO", "MASCULINO", 
            "SOLTERO", "CASADO", "DIVORCIADO", "VIUDO", "ESTADO CIVIL",
            "BENEFICIARIOS", "TITULAR", "ASEGURADO", "COTIZANTE"
        ]
        if any(pattern in text_upper for pattern in form_field_patterns):
            return False
        
        # Enhanced exclusion using stemming/lemmatization
        prefix_words = {"nombre", "name", "sr", "sra", "señor", "señora", "don", "doña"}
        while words and words[0].lower() in prefix_words: 
            words = words[1:]
        
        if len(words) < 2 or len(words) > 4: 
            return False
        
        if any((not w.isalpha()) or len(w) < 2 for w in words): 
            return False
        
        # Enhanced financial domain detection using lemmas/stems
        if self.use_lemmas and self.nlp_lemma:
            norm_tokens = set(self._lemma_tokens(words))
            domain_set = self.financial_terms_lemmas
        elif self._stemmer:
            norm_tokens = set(self._stem_tokens(words))
            domain_set = self.financial_terms_stems
        else:
            norm_tokens = set(TextProcessingUtils.strip_accents(w.lower()) for w in words)
            domain_set = self._normalize_wordset(self.financial_terms)
        
        if len(norm_tokens & domain_set) >= 2: 
            return False
        
        # Enhanced substring matching
        remaining = TextProcessingUtils.strip_accents(" ".join(words).lower())
        if any(term in remaining for term in domain_set if len(term) >= 4): 
            return False
        
        return True

    def extract_transformer_ner(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract named entities using transformer-based NER with enhanced validation.
        
        This method processes text through transformer models to identify PII entities,
        with special handling for person names that includes:
        - Automatic stripping of trailing organizational terms
        - Enhanced validation against problematic word blacklists  
        - Context-aware filtering for low-confidence OCR text
        
        Process Flow:
        1. Split text into overlapping chunks (512 chars with 200 char overlap)
        2. Run transformer NER on each chunk
        3. Clean and normalize entity boundaries
        4. Strip trailing blacklisted terms (e.g., "Contingent", "Division")
        5. Apply person name validation if entity type is person
        6. Filter based on context quality and OCR confidence
        
        Args:
            text (str): Input text to process for named entity recognition
            
        Returns:
            List[Dict[str, Any]]: List of detected entities with metadata:
                - PII_Type: Normalized entity type (e.g., "TransformerPerson")
                - PII_Value: Cleaned entity text (trailing terms stripped)
                - Confidence: Model confidence score (0.0-1.0)
                - Source: Always "transformer"
                - start_pos/end_pos: Character positions in original text
                - pattern: Always None (not pattern-based)
                - label: Original model label
                
        Note:
            Uses name_trailer_blacklist_norm to automatically clean names like:
            "Jenifer Prado Contingent" → "Jenifer Prado"
        """
        results: List[Dict[str, Any]] = []
        if not TRANSFORMER_NER_AVAILABLE: 
            return results
        
        try:
            for offset, chunk in self._iter_ner_chunks(text, max_chars=512, overlap=200):
                entities = transformer_ner(chunk)
                for ent in entities:
                    entity_text = ent.get("word", "")
                    entity_label = ent.get("entity_group") or ent.get("entity", "UNKNOWN")
                    score = float(ent.get("score", 0.0))
                    start = int(ent.get("start", 0)) + offset
                    end = int(ent.get("end", 0)) + offset
                    
                    cleaned_text, new_start, new_end = EntityUtils.clean_entity_boundaries(
                        entity_text, entity_label, text, start, end
                    )
                    if not cleaned_text or len(cleaned_text.strip()) < 2: 
                        continue
                    
                    label_map = {
                        "PER": "TransformerPerson", "PERSON": "TransformerPerson", 
                        "ORG": "TransformerOrganization", "ORGANIZATION": "TransformerOrganization", 
                        "LOC": "TransformerLocation", "LOCATION": "TransformerLocation", 
                        "MISC": "TransformerMiscellaneous", "MISCELLANEOUS": "TransformerMiscellaneous"
                    }
                    pii_type = label_map.get((entity_label or "").upper(), f"Transformer{entity_label}")
                    
                    # Before validating, strip common trailing tokens (e.g. "Contingent")
                    if cleaned_text:
                        tokens = cleaned_text.strip().split()
                        if tokens:
                            while tokens and TextProcessingUtils.strip_accents(tokens[-1].lower()) in self.name_trailer_blacklist_norm:
                                tokens.pop()
                            if not tokens:
                                continue
                            # update cleaned_text and new_end after trimming
                            cleaned_text = " ".join(tokens).strip()
                            new_end = new_start + len(cleaned_text)
                    
                    if pii_type == "TransformerPerson":
                        if not self._is_plausible_person_span(cleaned_text): 
                            continue
                        if not self.is_valid_person_name(cleaned_text): 
                            continue
                        ctx = EntityUtils.extract_local_context(text, new_start, new_end)
                        if (self.last_image_ocr_conf is not None and 
                            self.last_image_ocr_conf < self.low_conf_threshold and 
                            not self.context_analyzer.person_context_ok(ctx)): 
                            continue
                        if (self.context_analyzer.looks_like_heading(ctx) and 
                            not self.context_analyzer.person_context_ok(ctx)): 
                            continue
                    
                    if cleaned_text.strip().isdigit() or len(cleaned_text.strip()) == 1: 
                        continue
                    
                    results.append({
                        "PII_Type": pii_type, 
                        "PII_Value": cleaned_text, 
                        "Confidence": round(score, 4), 
                        "Source": "transformer", 
                        "start_pos": new_start, 
                        "end_pos": new_end, 
                        "pattern": None, 
                        "label": entity_label
                    })
        except Exception as e:
            logging.error(f"Transformer NER error: {e}")
        
        return results

    def extract_pii_from_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract PII entities using ML methods: spaCy NER, transformer NER, with advanced post-processing.
        
        This is the main PII extraction pipeline that combines multiple ML approaches
        with sophisticated filtering to minimize false positives in business documents.
        
        Processing Pipeline:
        1. Text Cleaning:
           - Basic cleaning: Remove extra whitespace, normalize characters
           - Aggressive cleaning for spaCy: Remove stopwords, filter business patterns
           - Advanced cleaning for transformers: Preserve context while cleaning
           
        2. Multi-Model NER:
           - spaCy NER: Fast, rule-based + statistical model
           - Transformer NER: Deep learning model with chunked processing
           
        3. Entity Validation:
           - Person names: Apply blacklist filtering and name validation
           - All entities: Clean boundaries, validate plausibility
           
        4. Post-Processing:
           - Deduplication: Merge overlapping entities from different models
           - Embedding rerank: Semantic validation using sentence transformers
           - Strict filtering: Context-aware validation in strict mode
           
        5. Normalization:
           - Standardize entity types (e.g., TransformerPerson → CUSTOMER_NAME)
           - Assign labels for categorization (TextData vs SequenceNumber)
        
        Blacklist Integration:
        - problematic_words_norm: Rejects Spanish adverbs and business terms
        - name_trailer_blacklist_norm: Strips organizational suffixes from names
        - financial_terms: Prevents insurance/pension terms from being classified as names
        
        Args:
            text (str): Input text to analyze for PII entities
            
        Returns:
            List[Dict[str, Any]]: Detected PII entities with standardized metadata:
                - PII_Type: Standardized type (CUSTOMER_NAME, LOC, ORG, etc.)
                - PII_Value: Cleaned entity text
                - Confidence: Model confidence or None
                - Source: "spaCy" or "transformer"  
                - start_pos/end_pos: Character positions
                - Label: "TextData" or "SequenceNumber"
        """
        results: List[Dict[str, Any]] = []
        
        try:
            # Basic cleaning
            basic_cleaned_text = TextProcessingUtils.basic_clean_text(text)

            # Aggressive cleaning for NER (with stopwords removal)
            ner_text = TextProcessingUtils.aggressive_clean_text(basic_cleaned_text, self.spanish_stop_words)
            
            # Advanced cleaning for transformer NER
            transformer_ner_text = TextProcessingUtils.advanced_clean_text(basic_cleaned_text)
            
            # Pre-filter obvious non-person patterns from NER text
            ner_text = re.sub(r'\b(?:GESTIÓN|PROCESOS?|CARGA|PÓLIZAS?|POLIZAS?|CREACIÓN|RESULTADOS?)\s+[A-Z\s]{5,50}', ' ', ner_text, flags=re.IGNORECASE)
            ner_text = re.sub(r'\b[A-Z]{1,3}\s+[A-Z]{1,3}\s+[A-Z]{1,3}\b', ' ', ner_text)
            ner_text = re.sub(r'\.[A-Z]{3,4}\b', ' ', ner_text)

            # spaCy NER Extraction
            spacy_results: List[Dict[str, Any]] = []
            if NER_AVAILABLE:
                try:
                    doc = nlp(ner_text)
                    for ent in doc.ents:
                        # Clean entity boundaries
                        cleaned_text, new_start, new_end = EntityUtils.clean_entity_boundaries(
                            ent.text, ent.label_, ner_text, ent.start_char, ent.end_char
                        )
                        if cleaned_text is None: 
                            continue
                        
                        # Apply validation for person entities
                        person_labels = {"PER", "PERSON", "PERSONA", "SpanishName"}
                        if ent.label_ in person_labels:
                            # Apply comprehensive person name validation
                            if not self.is_valid_person_name(cleaned_text):
                                continue
                            # Apply additional plausibility check
                            if not self._is_plausible_person_span(cleaned_text):
                                continue
                        
                        spacy_results.append({
                            "PII_Type": ent.label_,
                            "PII_Value": cleaned_text,
                            "Confidence": None,
                            "Source": "spaCy",
                            "start_pos": new_start,
                            "end_pos": new_end,
                            "pattern": None,
                            "label": ent.label_
                        })
                except Exception as e:
                    logging.warning(f"spaCy NER failed: {e}")

            # Transformer NER Extraction
            transformer_results: List[Dict[str, Any]] = []
            if TRANSFORMER_NER_AVAILABLE:
                try:
                    ner_results = self.extract_transformer_ner(transformer_ner_text)
                    transformer_results.extend(ner_results)
                except Exception as e:
                    logging.warning(f"Transformer NER failed: {e}")

            # Merge and deduplicate
            all_results = spacy_results + transformer_results
            results = EntityUtils.dedupe_entities(all_results)

            # Embedding rerank (semantic)
            if self._embed_reranker:
                try:
                    results = self._embed_reranker.rerank(ner_text, results, context_window=48)
                except Exception as e:
                    logging.warning(f"Embedding rerank failed: {e}")

            # Strict post-filter for ML results
            if self.strict_mode and results:
                filtered: List[Dict[str, Any]] = []
                for e in results:
                    e_type = e.get("PII_Type", "")
                    value = e.get("PII_Value", "")
                    start, end = e.get("start_pos", 0), e.get("end_pos", 0)
                    
                    person_like = e_type in {"TransformerPerson", "SpanishName", "PER", "PERSON", "PERSONA"}
                    if person_like:
                        if not self._is_plausible_person_span(value): 
                            continue
                        
                        words = value.split()
                        name_conf = self._assess_name_confidence(words) if words else 0.0
                        ctx = EntityUtils.extract_local_context(text, start, end)
                        norm_val = EntityUtils._norm_value_for_key(value)
                        
                        same_value_sources = {
                            x["Source"] for x in results 
                            if x is not e and EntityUtils._norm_value_for_key(x.get("PII_Value", "")) == norm_val
                        }
                        has_consensus = len(same_value_sources) >= 1
                        from_person_context = e.get("label") == "Person_Context"
                        good_context = self.context_analyzer.person_context_ok(ctx)
                        
                        if has_consensus or good_context or name_conf >= self.person_min_conf or from_person_context:
                            if (self.last_image_ocr_conf is not None and 
                                self.last_image_ocr_conf < self.low_conf_threshold and 
                                self.context_analyzer.looks_like_heading(ctx) and 
                                not good_context):
                                continue
                            filtered.append(e)
                        else:
                            continue
                    else:
                        filtered.append(e)
                results = filtered

            # Normalize entity types
            self._normalize_entity_types(results)

            # Assign labels
            self._assign_entity_labels(results)

            results.sort(key=lambda r: (r.get("start_pos", 0), r.get("end_pos", 0)))
        except Exception as e:
            logging.error(f"Error extracting PII with ML methods: {e}")
        
        return results

    def _normalize_entity_types(self, results: List[Dict[str, Any]]) -> None:
        """Normalize entity types to standard names"""
        for entity in results:
            pii_type = entity.get("PII_Type")
            
             # Group LOC and TransformerLocation as LOC
            if pii_type in ["TransformerPerson", "CUSTOMER_NAME"]:
                entity["PII_Type"] = "CUSTOMER_NAME"
            
            # Group LOC and TransformerLocation as LOC
            if pii_type in ["TransformerLocation", "LOC"]:
                entity["PII_Type"] = "LOC"

            # Group MISC and TransformerMiscellaneous as MISC
            if pii_type in ["TransformerMiscellaneous", "MISC"]:
                entity["PII_Type"] = "MISC"

            # Group ORG and TransformerOrganization as ORG
            if pii_type in ["TransformerOrganization", "ORG"]:
                entity["PII_Type"] = "ORG"

    def _assign_entity_labels(self, results: List[Dict[str, Any]]) -> None:
        """Assign labels to entities for categorization"""
        numeric_types = {"RUT", "Amount", "CreditCard", "Account", "Phone", "Date", "NumberSequence", "SEQ_NUMBER", "PHONE_NUMBER", "DATE", "AMOUNT"}
        for entity in results:
            if entity.get("PII_Type") in numeric_types:
                entity["Label"] = "SequenceNumber"
            else:
                entity["Label"] = "TextData"

    def get_processing_summary(self) -> Dict[str, Any]:
        """Build a JSON summary of the last run"""
        summary = {
            "script_name": "S3_ml_ner",
            "detection_method": "machine_learning",
            "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "input_directory": self.input_dir,
            "output_directory": self.output_dir,
            "transformer_available": TRANSFORMER_NER_AVAILABLE,
            "spacy_available": NER_AVAILABLE,
            "lemmas_enabled": bool(self.use_lemmas and self.nlp_lemma),
            "stemming_enabled": bool(self._stemmer is not None),
            "embedding_rerank_enabled": bool(self._embed_reranker is not None),
        }
        
        try:
            excel_files = [
                f for f in os.listdir(self.output_dir) 
                if f.startswith("OCR_PII_Analysis_") and f.endswith(".xlsx")
            ]
        except Exception:
            excel_files = []
        
        summary["excel_reports_generated"] = len(excel_files)
        summary["latest_reports"] = excel_files[-5:] if excel_files else []
        return summary

    def run_flow(self) -> bool:
        """
        Main workflow:
        - Process all folders using ML-based PII detection
        - Save summary JSON
        """
        try:
            logging.info("----- Starting S3 ML-based NER Detection -----")
            success = self.process_all_folders()
            
            if success:
                summary = self.get_processing_summary()
                logging.info("S3 ML NER Processing Summary:")
                logging.info(f"  - Detection method: Machine Learning (spaCy + Transformers)")
                logging.info(f"  - Excel reports generated: {summary['excel_reports_generated']}")
                logging.info(f"  - Transformer NER available: {summary['transformer_available']}")
                logging.info(f"  - spaCy NER available: {summary['spacy_available']}")
                logging.info(f"  - Lemmas enabled: {summary['lemmas_enabled']}")
                logging.info(f"  - Stemming enabled: {summary['stemming_enabled']}")
                logging.info(f"  - Embedding rerank enabled: {summary['embedding_rerank_enabled']}")
                
                summary_path = os.path.join(self.process_data_dir, "S3_ml_ner_summary.json")
                save_json_file(summary, summary_path)
                logging.info("S3 ML NER detection completed successfully")
                return True
            else:
                logging.error("S3 ML NER detection failed")
                return False
        except Exception as e:
            logging.error(f"S3 ML NER workflow failed: {e}")
            return False


if __name__ == "__main__":
    from src.utils.fmw_utils import start_logging, read_config
    
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")
    
    detector = S3_MachineLearningNER(config=config)
    detector.run_flow()
    
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
