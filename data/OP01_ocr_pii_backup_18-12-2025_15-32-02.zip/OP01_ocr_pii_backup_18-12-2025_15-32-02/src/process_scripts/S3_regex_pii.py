#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3 Regex PII Detector

Fast, lightweight PII detection using regex patterns.
Focus on pattern-based detection for structured data like RUTs, phones, emails.
"""

import os
import logging
import datetime as dt
import re
from typing import Optional, List, Dict, Any

# Project imports
from src.utils.fmw_utils import save_json_file
from src.process_scripts.base_pii_detector import BasePIIDetector
from src.utils.pii_utils import (
    PIIValidators, PIIPatterns, TextProcessingUtils, EntityUtils, filter_identities_by_country
)

class S3_RegexPII(BasePIIDetector):
    """Regex-based PII detection - fast and lightweight"""

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config=config)
        
        # Regex-specific configuration
        self.strict_rut_digits_only = bool(self.config_global.get("STRICT_RUT_DIGITS_ONLY", True))
        
        # Load pattern-specific confidence scores from config
        self.confidence_scores = self.config_global.get("REGEX_CONFIDENCE_SCORES", {
            "PatronymicName": 0.85,
            "SurnameFirst_AllCaps": 0.88,
            "DoubleSurnameWithFirstNames": 0.87,
            "ChileanFullName": 0.87,
            "CompoundSpanishName": 0.84,
            "ContextualPersonName": 0.90,
            "TitledPersonName": 0.86,
            "RUT": 0.95,
            "Email": 0.92,
            "Phone": 0.80,
            "Address_StreetNum": 0.75,
            "NumberSequence": 0.70,
            "default": 0.80
        })
        
        logging.info(
            f"S3_RegexPII initialized | "
            f"strict_mode={self.strict_mode} | "
            f"strict_rut_digits_only={self.strict_rut_digits_only} | "
            f"stopwords={'ON' if self.use_stopwords_removal else 'OFF'} | "
            f"advanced_cleaning={'ON' if self.use_advanced_cleaning else 'OFF'} | "
            f"confidence_scores_loaded={len(self.confidence_scores)} patterns"
        )

    # Select the following PII types for regex detection
    def extract_pii_from_text(self, text: str, country: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Extract PII entities from text using regex patterns only.
        Fast and efficient for structured data patterns.
        
        Args:
            text: Text to extract PII from
            country: Detected country (e.g., 'Chile', 'Brasil', 'Colombia', 'Uruguay')
                     Used for country-aware identity number filtering
        
        Returns:
            List of PII entities with country filtering applied
        """
        results: List[Dict[str, Any]] = []
        
        try:
            # Basic text cleaning for regex processing
            basic_cleaned_text = TextProcessingUtils.basic_clean_text(text)

            # Enhanced name detection (replaces SpanishName pattern)
            enhanced_names = self._enhanced_name_extraction(basic_cleaned_text)
            results.extend(enhanced_names)

            # Regex extraction for all other patterns (excluding SpanishName)
            regex_results: List[Dict[str, Any]] = []
            
            country_map = {
                "Phone_Chile_Service": "Chile",
                "Phone_Argentina_Service": "Argentina",
                "Phone_Brazil_Service": "Brazil",
                "Phone_Uruguay_Service": "Uruguay",
                "Phone_Mexico_Service": "Mexico",
            }
            
            for ptype, pattern in PIIPatterns.PATTERNS.items():
                # Skip SpanishName - handled by enhanced extraction
                # Skip ChileanFullName - handled by enhanced extraction with validation
                # Skip CompoundSpanishName - generates too many false positives
                # Skip Person_Context - generates too many false positives
                # Skip PatronymicName - generates too many false positives
                # Skip SurnameFirst_AllCaps - handled by enhanced extraction
                # Skip DoubleSurnameWithFirstNames - handled by enhanced extraction
                if ptype in ["SpanishName", "ChileanFullName", "CompoundSpanishName", "Person_Context", "PatronymicName", "Chileanvariation", "SurnameFirst_AllCaps", "DoubleSurnameWithFirstNames"]:
                    continue
                
                for m in pattern.finditer(basic_cleaned_text):
                    value = m.group(1) if m.lastindex else m.group(0)
                    
                    # Special handling for different PII types
                    if ptype.startswith("RUT"):
                        norm = PIIValidators.normalize_rut(value)
                        is_valid = PIIValidators.validate_rut(value)
                        
                        if is_valid and norm:
                            # Check context if strict mode is enabled
                            if self.strict_rut_digits_only:
                                ctx = EntityUtils.extract_local_context(text, m.start(), m.end())
                                if not self.context_analyzer.rut_context_ok(ctx):
                                    continue
                            
                            regex_results.append({
                                "PII_Type": "RUT",
                                "PII_Value": norm,
                                "Confidence": None,
                                "Source": "regex",
                                "start_pos": m.start(1) if m.lastindex else m.start(0),
                                "end_pos": m.end(1) if m.lastindex else m.end(0),
                                "pattern": pattern.pattern,
                                "label": ptype,
                                "Valid": True
                            })
                        else:
                            continue  # Skip invalid RUTs
                            
                    elif ptype.startswith("Phone") or ptype in country_map:
                        # Check phone context if enabled
                        if self.strict_mode:
                            ctx = EntityUtils.extract_local_context(text, m.start(), m.end())
                            if not self.context_analyzer.phone_context_ok(ctx):
                                # Only skip if no phone context words found
                                phone_ctx_words = {"tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext"}
                                if not any(word in ctx for word in phone_ctx_words):
                                    continue
                        
                        # Tag all Phone_*_Service as Phone, annotate country if available
                        entity = {
                            "PII_Type": "Phone",
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": m.start(1) if m.lastindex else m.start(0),
                            "end_pos": m.end(1) if m.lastindex else m.end(0),
                            "pattern": pattern.pattern,
                            "label": ptype
                        }
                        if ptype in country_map:
                            entity["Country"] = country_map[ptype]
                        regex_results.append(entity)
                        
                    elif ptype == "Date":
                        # Expand date matches if more digits follow
                        end_pos = m.end(1) if m.lastindex else m.end(0)
                        # Check for more digits immediately after the match
                        extra_digits = ""
                        i = end_pos
                        while i < len(basic_cleaned_text) and basic_cleaned_text[i].isdigit():
                            extra_digits += basic_cleaned_text[i]
                            i += 1
                        if extra_digits:
                            value += extra_digits
                            end_pos += len(extra_digits)
                        
                        regex_results.append({
                            "PII_Type": ptype,
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": m.start(1) if m.lastindex else m.start(0),
                            "end_pos": end_pos if extra_digits else (m.end(1) if m.lastindex else m.end(0)),
                            "pattern": pattern.pattern,
                            "label": ptype
                        })
                        
                    elif ptype == "Account":
                        # Validate account numbers
                        if len(PIIValidators.sanitize_account(value)) >= 5:  # Minimum account length
                            regex_results.append({
                                "PII_Type": ptype,
                                "PII_Value": value,
                                "Confidence": None,
                                "Source": "regex",
                                "start_pos": m.start(1) if m.lastindex else m.start(0),
                                "end_pos": m.end(1) if m.lastindex else m.end(0),
                                "pattern": pattern.pattern,
                                "label": ptype
                            })
                            
                    else:
                        # Default handling for other types
                        regex_results.append({
                            "PII_Type": ptype,
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": m.start(1) if m.lastindex else m.start(0),
                            "end_pos": m.end(1) if m.lastindex else m.end(0),
                            "pattern": pattern.pattern,
                            "label": ptype
                        })

            # Combine enhanced names with other PII results
            all_results = enhanced_names + regex_results

            # Apply country-based filtering for identity numbers (if country detected)
            if country:
                logging.info(f"Applying country filtering for: {country}")
                all_results = filter_identities_by_country(
                    entities=all_results,
                    country=country,
                    strict_mode=True  # Exclude non-matching identities
                )
                logging.info(f"After country filtering: {len(all_results)} entities remaining")

            # Deduplicate results
            results = EntityUtils.dedupe_entities(all_results)

            # Context-aware post-filtering and priority suppression
            try:
                phone_context_words = {"tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext"}
                def has_phone_context(value):
                    idx = text.find(value)
                    if idx == -1:
                        return False
                    ctx_window = text[max(0, idx-40):idx].lower()
                    return any(w in ctx_window for w in phone_context_words)

                # If a NumberSequence or Amount is near phone context, reclassify as Phone
                for entity in results:
                    if entity.get("PII_Type") in {"NumberSequence", "Amount"}:
                        v = entity.get("PII_Value")
                        if has_phone_context(v) and len(v.replace(' ', '').replace('-', '')) >= 10:
                            entity["PII_Type"] = "Phone"

                # Suppress lower-priority types for same value
                priority = {"Email":4,"Date": 3, "DateTime": 3, "Time": 3, "Phone": 2, "NumberSequence": 1, "Amount": 1}
                value_groups = {}
                for entity in results:
                    v = entity.get("PII_Value")
                    t = entity.get("PII_Type")
                    p = priority.get(t, 0)
                    if v not in value_groups or p > priority.get(value_groups[v]["PII_Type"], 0):
                        value_groups[v] = entity
                results = list(value_groups.values())
            except Exception as e:
                logging.error(f"Error in context-aware post-filtering: {e}")

            # Normalize entity types
            self._normalize_entity_types(results)

            # Assign labels
            self._assign_entity_labels(results)

            results.sort(key=lambda r: (r.get("start_pos", 0), r.get("end_pos", 0)))
            logging.info(f"Total PII entities extracted: {len(results)} (enhanced names: {len(enhanced_names)}, other patterns: {len(regex_results)})")
            
        except Exception as e:
            logging.error(f"Error extracting PII with regex: {e}")
        
        return results

    def _is_plausible_person_span(self, value: str) -> bool:
        """Heuristic to check if a string is a plausible person name span"""
        val = (value or "").strip()
        if not val: 
            return False
        if len(val) > self.MAX_PERSON_CHARS: 
            return False
        if len(val.split()) > self.MAX_PERSON_TOKENS: 
            return False
        return True

    def _is_valid_person_name(self, text: str) -> bool:
        """
        Validate if a string is a plausible Spanish person name.
        CONSOLIDATED: Uses ExclusionLists for all exclusion checks.
        """
        if not text or len(text.strip()) < 2: 
            return False
        
        # Import exclusion utilities
        from src.utils.pii_utils import ExclusionLists, TextProcessingUtils
        
        # Early exclusions for obvious non-names
        text_upper = text.upper()
        words = text.split()
        
        # ========== CONSOLIDATED EXCLUSION CHECKS ==========
        
        # 1. Check if ANY word is excluded (verbs, prepositions, conjunctions, etc.)
        for word in words:
            if ExclusionLists.is_excluded_word(word):
                reason = ExclusionLists.get_exclusion_reason(word)
                logging.info(f"REJECTED '{text}': contains excluded word '{word}' ({reason})")
                return False
        
        # 2. Check if the entire phrase matches exclusion patterns
        if ExclusionLists.is_excluded_phrase(text):
            logging.info(f"REJECTED '{text}': matches excluded phrase pattern")
            return False
        
        # 3. Check for form field descriptions and demographic terms
        if ExclusionLists.is_form_field_pattern(text):
            logging.info(f"REJECTED '{text}': matches form field pattern")
            return False
        
        # ========== PATTERN-BASED EXCLUSIONS ==========
        
        # 4. Detect CamelCase patterns (TipoCredito, ProductType, etc.)
        for word in words:
            camel_case_count = len(re.findall(r'[a-z][A-Z]', word))
            if camel_case_count > 0:
                logging.info(f"REJECTED '{text}': CamelCase pattern in '{word}'")
                return False
        
        # 5. Exclude if contains multiple negation/status words
        status_words = {"SIN", "NO", "SI", "CON", "TIENE", "ES", "SON"}
        status_count = sum(1 for word in text_upper.split() if word in status_words)
        if status_count >= 2:
            logging.info(f"REJECTED '{text}': {status_count} status/negation words")
            return False
        
        # 6. Exclude obvious technical patterns
        if re.search(r'\b(?:HTTP|WWW|\.COM|\.CL|\.NET|\.ORG)\b', text_upper): 
            logging.info(f"REJECTED '{text}': contains URL pattern")
            return False
        
        if re.search(r'\b(?:XML|PDF|DOC|XLSX?|DOCX|CSV|JSON)\b', text_upper): 
            logging.info(f"REJECTED '{text}': contains file format pattern")
            return False
        
        # 7. Exclude if contains numbers mixed with text (likely codes/IDs)
        if re.search(r'\d.*[A-Z]|[A-Z].*\d', text_upper): 
            logging.info(f"REJECTED '{text}': mixed numbers/letters (code/ID)")
            return False
        
        # ========== STRUCTURAL VALIDATION ==========
        
        # 8. Basic word validation
        prefix_words = {"nombre", "name", "sr", "sra", "señor", "señora", "don", "doña"}
        filtered_words = [w for w in words if w.lower() not in prefix_words]
        
        if len(filtered_words) < 2 or len(filtered_words) > 4: 
            logging.info(f"REJECTED '{text}': {len(filtered_words)} words (need 2-4)")
            return False
        
        # 9. Check for incomplete names (last token too short like "Yenifer San")
        if len(filtered_words[-1]) < 3:
            logging.info(f"REJECTED '{text}': incomplete - last token '{filtered_words[-1]}' too short")
            return False
        
        # 10. Each word must be alphabetic and at least 2 characters
        if any((not w.isalpha()) or len(w) < 2 for w in filtered_words): 
            logging.info(f"REJECTED '{text}': non-alphabetic or single-char words")
            return False
        
        # 11. Check for financial domain terms (allow 1, reject if 2+)
        norm_tokens = set(TextProcessingUtils.strip_accents(w.lower()) for w in filtered_words)
        financial_matches = sum(1 for token in norm_tokens 
                              if token in ExclusionLists._FINANCIAL_DOMAIN_TERMS_NORM)
        
        if financial_matches >= 2: 
            logging.info(f"REJECTED '{text}': {financial_matches} financial domain terms")
            return False
        
        # ========== PASSED ALL CHECKS ==========
        logging.info(f"ACCEPTED '{text}': passed all validation checks")
        return True

    def _enhanced_name_extraction(self, text: str) -> List[Dict[str, Any]]:
        """
        Enhanced name extraction using contextual and structured name patterns.
        Removed ChileanFullName pattern due to high false positive rate.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            List[Dict[str, Any]]: Detected name entities with confidence scores
        """
        name_results = []
        
        try:
            # Strategy 1: Contextual name detection (highest confidence)
            contextual_pattern = PIIPatterns.PATTERNS.get("ContextualPersonName")
            if contextual_pattern:
                for match in contextual_pattern.finditer(text):
                    name_candidate = match.group(1).strip()
                    
                    # ========== STRICT PRE-VALIDATION (NO TOLERANCE) ==========
                    
                    # CRITICAL 1: Reject if any word starts with lowercase (not a proper name)
                    words = name_candidate.split()
                    if any(word and word[0].islower() for word in words):
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (lowercase word detected)")
                        continue
                    
                    # CRITICAL 2: Reject if less than 2 words (no single-word names from ContextualPersonName)
                    if len(words) < 2:
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (single word)")
                        continue
                    
                    # CRITICAL 3: Reject if only 1 or 2 characters per word (fragments like "Pag Nro", "los del")
                    if any(len(word) <= 2 for word in words):
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (contains short fragment words)")
                        continue
                    
                    # CRITICAL 4: Pre-check for excluded words (fast rejection)
                    from src.utils.pii_utils import ExclusionLists
                    if any(ExclusionLists.is_excluded_word(word) for word in words):
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (contains excluded word)")
                        continue
                    
                    # CRITICAL 5: Full structural validation (CamelCase, file patterns, status words, etc.)
                    if not self._is_valid_person_name(name_candidate):
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (failed structural validation)")
                        continue
                    
                    # ========== SCORING & DATABASE VALIDATION ==========
                    
                    # Check if name contains known Spanish components
                    is_known_name = ExclusionLists.is_likely_person_name(name_candidate)
                    
                    # Calculate validation score
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    # Adjust threshold based on whether name is in database
                    if is_known_name:
                        # Lower threshold for known Spanish names (more lenient)
                        required_threshold = 0.70
                        logging.debug(f"Known Spanish name detected: '{name_candidate}'")
                    else:
                        # Higher threshold for unknown names (more strict)
                        required_threshold = 0.80
                        logging.debug(f"Unknown name - applying strict threshold: '{name_candidate}'")
                    
                    # STRICT: Only accept names that meet the threshold
                    if validation_score >= required_threshold:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": name_candidate,
                            "Confidence": 0.92 if is_known_name else 0.85,  # Higher confidence for known names
                            "Source": "regex",
                            "start_pos": match.start(1),
                            "end_pos": match.end(1),
                            "pattern": "ContextualPersonName",
                            "validation_score": validation_score,
                            "is_known_name": is_known_name
                        })
                        logging.info(f"CONTEXTUAL ACCEPTED: '{name_candidate}' (score: {validation_score:.3f}, known: {is_known_name})")
                    else:
                        logging.debug(f"CONTEXTUAL REJECTED: '{name_candidate}' (score: {validation_score:.3f} < {required_threshold:.2f})")
            
            # Strategy 2: Titled names (high confidence)
            titled_pattern = PIIPatterns.PATTERNS.get("TitledPersonName")
            if titled_pattern:
                for match in titled_pattern.finditer(text):
                    name_candidate = match.group(1).strip()
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    if self._validate_enhanced_name(name_candidate) and validation_score >= 0.6:
                        name_results.append({
                            "PII_Type": "Person", 
                            "PII_Value": name_candidate,
                            "Confidence": self.confidence_scores.get("TitledPersonName", 0.86),
                            "Source": "regex",
                            "start_pos": match.start(1),
                            "end_pos": match.end(1),
                            "pattern": "TitledPersonName",
                            "validation_score": validation_score
                        })
            
            # Strategy 3: Chilean full names (medium-high confidence) - BULLETPROOF VALIDATION
            chilean_pattern = PIIPatterns.PATTERNS.get("ChileanFullName")
            if chilean_pattern:
                for match in chilean_pattern.finditer(text):
                    full_match = match.group(0).strip()
                    
                    # PRE-VALIDATION: Immediate single-word check before any processing
                    if len(full_match.split()) < 2:
                        logging.info(f"[NO] PRE-VALIDATION REJECTED '{full_match}': single word")
                        continue
                    
                    # PRE-VALIDATION: Check against consolidated exclusion lists
                    from src.utils.pii_utils import ExclusionLists
                    if ExclusionLists.is_excluded_phrase(full_match):
                        logging.info(f"[NO] PRE-VALIDATION REJECTED '{full_match}': excluded phrase")
                        continue
                    
                    validation_score = self._calculate_name_score(full_match)
                    
                    # VERY HIGH threshold - only accept high-confidence Chilean names
                    if self._validate_enhanced_name(full_match) and validation_score >= 0.75:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": full_match,
                            "Confidence": self.confidence_scores.get("ChileanFullName", 0.87),
                            "Source": "regex", 
                            "start_pos": match.start(),
                            "end_pos": match.end(),
                            "pattern": "ChileanFullName",
                            "validation_score": validation_score
                        })
                        logging.info(f"CHILEAN NAME DETECTED: '{full_match}' (score: {validation_score:.3f})")
                    else:
                        logging.info(f"[NO] VALIDATION FAILED: '{full_match}' (score: {validation_score:.3f})")
            
            # Strategy 4: ContextualPersonName (medium confidence) - HIGHEST threshold
            ContextualPersonName = PIIPatterns.PATTERNS.get("ContextualPersonName")
            if ContextualPersonName:
                for match in ContextualPersonName.finditer(text):
                    name_candidate = match.group(0).strip()
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    if self._validate_enhanced_name(name_candidate) and validation_score >= 0.8:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": name_candidate,
                            "Confidence": 0.75,
                            "Source": "regex",
                            "start_pos": match.start(),
                            "end_pos": match.end(),
                            "pattern": "ContextualPersonName", 
                            "validation_score": validation_score
                        })
            
            # Strategy 5: Patronymic names (medium confidence)
            patronymic_pattern = PIIPatterns.PATTERNS.get("PatronymicName")
            if patronymic_pattern:
                for match in patronymic_pattern.finditer(text):
                    name_candidate = match.group(0).strip()
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    if self._validate_enhanced_name(name_candidate) and validation_score >= 0.7:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": name_candidate,
                            "Confidence": self.confidence_scores.get("PatronymicName", 0.85),
                            "Source": "regex",
                            "start_pos": match.start(),
                            "end_pos": match.end(),
                            "pattern": "PatronymicName",
                            "validation_score": validation_score
                        })
            
            # Strategy 5.5: Double-barrel surnames with first names (medium-high confidence)
            # Handles names like "Villablanca Henriquez Felipe Eduardo"
            double_surname_pattern = PIIPatterns.PATTERNS.get("DoubleSurnameWithFirstNames")
            if double_surname_pattern:
                for match in double_surname_pattern.finditer(text):
                    name_candidate = match.group(0).strip()
                    
                    # PRE-VALIDATION: Must have at least 4 words (2 surnames + 2 first names)
                    if len(name_candidate.split()) < 4:
                        logging.info(f"[NO] DoubleSurnameWithFirstNames REJECTED '{name_candidate}': insufficient words")
                        continue
                    
                    # PRE-VALIDATION: Check against exclusion lists
                    from src.utils.pii_utils import ExclusionLists
                    if ExclusionLists.is_excluded_phrase(name_candidate):
                        logging.info(f"[NO] DoubleSurnameWithFirstNames REJECTED '{name_candidate}': excluded phrase")
                        continue
                    
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    # Medium-high threshold for compound surnames
                    if self._validate_enhanced_name(name_candidate) and validation_score >= 0.70:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": name_candidate,
                            "Confidence": self.confidence_scores.get("DoubleSurnameWithFirstNames", 0.87),
                            "Source": "regex",
                            "start_pos": match.start(),
                            "end_pos": match.end(),
                            "pattern": "DoubleSurnameWithFirstNames",
                            "validation_score": validation_score
                        })
                        logging.info(f"DOUBLE-SURNAME NAME DETECTED: '{name_candidate}' (score: {validation_score:.3f})")
                    else:
                        logging.info(f"[NO] DoubleSurnameWithFirstNames VALIDATION FAILED: '{name_candidate}' (score: {validation_score:.3f})")
            
            # Strategy 6: Surname-first ALL-CAPS names (medium-high confidence)
            # Handles Chilean OCR patterns like "VEGA TORO MARGARITA CRISTINA"
            surname_first_pattern = PIIPatterns.PATTERNS.get("SurnameFirst_AllCaps")
            if surname_first_pattern:
                for match in surname_first_pattern.finditer(text):
                    name_candidate = match.group(1).strip()
                    
                    # PRE-VALIDATION: Must have at least 2 words
                    if len(name_candidate.split()) < 2:
                        logging.info(f"[NO] SurnameFirst_AllCaps REJECTED '{name_candidate}': single word")
                        continue
                    
                    # PRE-VALIDATION: Check against exclusion lists
                    from src.utils.pii_utils import ExclusionLists
                    if ExclusionLists.is_excluded_phrase(name_candidate):
                        logging.info(f"[NO] SurnameFirst_AllCaps REJECTED '{name_candidate}': excluded phrase")
                        continue
                    
                    validation_score = self._calculate_name_score(name_candidate)
                    
                    # Medium-high threshold for ALL-CAPS names
                    if self._validate_enhanced_name(name_candidate) and validation_score >= 0.65:
                        name_results.append({
                            "PII_Type": "Person",
                            "PII_Value": name_candidate,
                            "Confidence": self.confidence_scores.get("SurnameFirst_AllCaps", 0.88),
                            "Source": "regex",
                            "start_pos": match.start(1),
                            "end_pos": match.end(1),
                            "pattern": "SurnameFirst_AllCaps",
                            "validation_score": validation_score
                        })
                        logging.info(f"SURNAME-FIRST ALL-CAPS NAME DETECTED: '{name_candidate}' (score: {validation_score:.3f})")
                    else:
                        logging.info(f"[NO] SurnameFirst_AllCaps VALIDATION FAILED: '{name_candidate}' (score: {validation_score:.3f})")
            
            # Deduplicate and sort by validation score first, then confidence
            name_results = EntityUtils.dedupe_entities(name_results)
            name_results.sort(key=lambda x: (x.get("validation_score", 0), x.get("Confidence", 0)), reverse=True)
            
            # FINAL FILTER: Only return names with validation_score >= 0.6
            filtered_results = [r for r in name_results if r.get("validation_score", 0) >= 0.6]
            
            logging.info(f"Enhanced name extraction: {len(name_results)} candidates -> {len(filtered_results)} after filtering")
            return filtered_results
            
        except Exception as e:
            logging.error(f"Error in enhanced name extraction: {e}")
            return []

    def _validate_enhanced_name(self, name_candidate: str) -> bool:
        """
        Enhanced validation for name candidates using multiple criteria.
        BULLETPROOF VERSION - Absolutely no single words allowed for ChileanFullName.
        
        Args:
            name_candidate (str): Name to validate
            
        Returns:
            bool: True if valid name, False otherwise
        """
        if not name_candidate or len(name_candidate.strip()) < 6:
            logging.info(f"[NO] REJECTED '{name_candidate}': too short (min 6 chars)")
            return False
        
        try:
            name_clean = name_candidate.strip().lower()
            words = name_clean.split()
            
            # CRITICAL FIX 1: ABSOLUTE REJECTION of single words - ChileanFullName REQUIRES 2+ words
            if len(words) == 1:
                logging.warning(f"[NO] SINGLE WORD REJECTED '{name_candidate}': ChileanFullName requires 2+ words")
                return False
            
            # CRITICAL FIX 2: Must have exactly 2-4 words for Chilean names
            if len(words) < 2 or len(words) > 4:
                logging.info(f"[NO] REJECTED '{name_candidate}': {len(words)} words (need 2-4)")
                return False
            
            # CRITICAL FIX 3: Use consolidated exclusion lists
            from src.utils.pii_utils import ExclusionLists
            
            # Check each word against exclusion lists
            for word in words:
                if ExclusionLists.is_excluded_word(word):
                    reason = ExclusionLists.get_exclusion_reason(word)
                    logging.warning(f"REJECTED '{name_candidate}': contains excluded word '{word}' ({reason})")
                    return False
            
            # Check if the entire phrase matches exclusion patterns
            if ExclusionLists.is_excluded_phrase(name_candidate):
                logging.warning(f"REJECTED '{name_candidate}': matches excluded phrase pattern")
                return False
            
            # CRITICAL FIX 4: Reject words with business/technical suffixes
            for word in words:
                if ExclusionLists.has_business_suffix(word):
                    logging.info(f"[NO] REJECTED '{name_candidate}': word '{word}' has business suffix")
                    return False
            
            # STRICT: Each word must be 2+ characters (except particles)
            particles = {"de", "del", "la", "las", "los", "y", "e", "da", "das", "do", "dos"}
            for word in words:
                if word not in particles:
                    if len(word) < 2:
                        logging.info(f"[NO] REJECTED '{name_candidate}': word '{word}' too short")
                        return False
            
            # Length validation
            if len(name_clean) > self.MAX_PERSON_CHARS:
                logging.info(f"[NO] REJECTED '{name_candidate}': too long ({len(name_clean)} chars)")
                return False
            
            # Word character validation - ONLY letters, hyphens, and apostrophes allowed
            for word in words:
                if word not in particles:
                    if not re.match(r'^[a-záéíóúñüA-ZÁÉÍÓÚÑÜ\'-]+$', word):
                        logging.info(f"[NO] REJECTED '{name_candidate}': word '{word}' contains invalid chars")
                        return False
            
            # CRITICAL FIX 5: At least one word should be in our Chilean names database
            from src.utils.pii_utils import PIIPatterns
            
            found_chilean_name = False
            for word in words:
                word_lower = word.lower()
                if (word_lower in PIIPatterns.COMMON_FIRST_NAMES or 
                    word_lower in PIIPatterns.COMMON_SURNAMES):
                    found_chilean_name = True
                    break
            
            if not found_chilean_name:
                logging.info(f"[NO] REJECTED '{name_candidate}': no recognized Chilean names found")
                return False
            
            # CRITICAL FIX 6: Require proper capitalization pattern
            capitalized_words = [w for w in name_candidate.split() if w and w[0].isupper()]
            if len(capitalized_words) < len(words) * 0.5:  # At least 50% of words should be capitalized
                logging.info(f"[NO] REJECTED '{name_candidate}': insufficient capitalization")
                return False
            
            logging.info(f"ACCEPTED '{name_candidate}': passed all validation checks")
            return True
            
        except Exception as e:
            logging.error(f"Error validating name candidate '{name_candidate}': {e}")
            return False

    def _calculate_name_score(self, name_candidate: str) -> float:
        """
        Calculate a validation score for name candidates based on Chilean naming patterns.
        BULLETPROOF VERSION - Zero score for single words and problematic terms.
        
        Args:
            name_candidate (str): Name to score
            
        Returns:
            float: Score from 0.0 to 1.0 (higher is better)
        """
        try:
            name_lower = name_candidate.lower().strip()
            words = name_lower.split()
            
            # CRITICAL: Zero score for single words - ChileanFullName requires 2+ words
            if not words or len(words) < 2:
                logging.warning(f"[NO] ZERO SCORE for '{name_candidate}': {len(words) if words else 0} words (need 2+)")
                return 0.0
            
            # CRITICAL: Zero score for excluded terms
            from src.utils.pii_utils import ExclusionLists
            
            # Check if any word or the full phrase matches exclusion patterns
            if ExclusionLists.is_excluded_phrase(name_candidate):
                logging.warning(f"ZERO SCORE for '{name_candidate}': matches excluded phrase")
                return 0.0
            
            for word in words:
                if ExclusionLists.is_excluded_word(word):
                    reason = ExclusionLists.get_exclusion_reason(word)
                    logging.warning(f"ZERO SCORE for '{name_candidate}': contains excluded word '{word}' ({reason})")
                    return 0.0
            
            score = 0.0
            
            # Base score for having 2+ words (REQUIRED)
            score += 0.5  # Increased from 0.4
            
            # Bonus for optimal Chilean name structure (3-4 words)
            if len(words) == 3:
                score += 0.2  # First + Last + Last
            elif len(words) == 4:
                score += 0.15  # First + Middle + Last + Last
            elif len(words) == 2:
                score += 0.15   # First + Last (acceptable, common for contextual names)
            
            # ========== ENHANCED: Name Database Component Scoring ==========
            from src.utils.pii_utils import ExclusionLists
            
            # Use new name component analysis for more accurate scoring
            name_analysis = ExclusionLists.get_name_components_score(name_candidate)
            
            # Bonus based on known name components
            if name_analysis['score'] >= 0.5:
                # At least 50% of words are known Spanish names
                score += 0.15
                logging.debug(f"[YES] Name component bonus for '{name_candidate}': {name_analysis['score']:.2f}")
            
            # Additional bonus if we have both first name AND surname
            if name_analysis['first_names'] and name_analysis['surnames']:
                score += 0.10
                logging.debug(f"[YES] Complete name structure: {name_analysis['first_names']} + {name_analysis['surnames']}")
            
            # Fallback to old method if no components found (for uncommon names)
            if name_analysis['score'] == 0.0:
                # Legacy first name check
                first_name = words[0]
                from src.utils.pii_utils import PIIPatterns
                if first_name in PIIPatterns.COMMON_FIRST_NAMES:
                    score += 0.10  # Reduced bonus
                
                # Legacy surname check
                for word in words[1:]:
                    if word in PIIPatterns.COMMON_SURNAMES:
                        score += 0.10
                        break
            
            # Proper capitalization bonus
            capitalized_count = sum(1 for word in name_candidate.split() if word and word[0].isupper())
            if capitalized_count == len(words):
                score += 0.1
            elif capitalized_count < len(words) * 0.5:
                score -= 0.15  # Stronger penalty for poor capitalization
            
            # Length appropriateness
            total_length = len(name_candidate)
            if 8 <= total_length <= 35:
                score += 0.05
            elif total_length < 8 or total_length > 40:
                score -= 0.1
            
            # Return final score (threshold validation happens in calling code)
            final_score = min(1.0, max(0.0, score))
            logging.info(f"SCORE for '{name_candidate}': {final_score:.3f}")
            return final_score
            
        except Exception as e:
            logging.error(f"Error calculating name score for '{name_candidate}': {e}")
            return 0.0

    def _normalize_entity_types(self, results: List[Dict[str, Any]]) -> None:
        """Normalize entity types to standard names"""
        for entity in results:
            pii_type = entity.get("PII_Type")
            
            # Group DateTime and Date as Date
            if pii_type == "DateTime":
                entity["PII_Type"] = "DATE"
            
            # Group Time as Date
            if pii_type == "Time":
                entity["PII_Type"] = "DATE"
            if pii_type == "Date":
                entity["PII_Type"] = "DATE"
                
            # Group all Phone service types as Phone
            phone_types = [
                "Phone_Chile_Service", "Phone_Argentina_Service", "Phone_Brazil_Service",
                "Phone_Uruguay_Service", "Phone_Mexico_Service"
            ]
            if pii_type in phone_types:
                entity["PII_Type"] = "Phone"

    def _assign_entity_labels(self, results: List[Dict[str, Any]]) -> None:
        """Assign labels to entities for categorization"""
        numeric_types = {"RUT", "Amount", "CreditCard", "Account", "Phone", "Date", "NumberSequence", "SEQ_NUMBER", "PHONE_NUMBER", "DATE", "AMOUNT"}
        for entity in results:
            if entity.get("PII_Type") in numeric_types:
                entity["Label"] = "SequenceNumber"
            else:
                entity["Label"] = "TextData"

    def get_processing_summary(self) -> Dict[str, Any]:
        """Build a JSON summary of the last run"""
        summary = {
            "script_name": "S3_regex_pii",
            "detection_method": "regex_only",
            "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "input_directory": self.input_dir,
            "output_directory": self.output_dir,
            "strict_mode": self.strict_mode,
            "strict_rut_digits_only": self.strict_rut_digits_only,
            "use_stopwords_removal": self.use_stopwords_removal,
            "use_advanced_cleaning": self.use_advanced_cleaning,
        }
        
        try:
            excel_files = [
                f for f in os.listdir(self.output_dir) 
                if f.startswith("OCR_PII_Analysis_") and f.endswith(".xlsx")
            ]
        except Exception:
            excel_files = []
        
        summary["excel_reports_generated"] = len(excel_files)
        summary["latest_reports"] = excel_files[-5:] if excel_files else []
        return summary

    def run_flow(self) -> bool:
        """
        Main workflow:
        - Process all folders using regex-based PII detection only
        - Save summary JSON
        """
        try:
            logging.info("----- Starting S3 Regex PII Detection -----")
            success = self.process_all_folders()
            
            if success:
                summary = self.get_processing_summary()
                logging.info("S3 Regex PII Processing Summary:")
                logging.info(f"  - Detection method: Regex patterns only")
                logging.info(f"  - Excel reports generated: {summary['excel_reports_generated']}")
                logging.info(f"  - Strict mode: {summary['strict_mode']}")
                logging.info(f"  - Strict RUT digits-only: {summary['strict_rut_digits_only']}")
                logging.info(f"  - Stop words removal: {summary['use_stopwords_removal']}")
                logging.info(f"  - Advanced cleaning: {summary['use_advanced_cleaning']}")
                
                summary_path = os.path.join(self.process_data_dir, "S3_regex_summary.json")
                save_json_file(summary, summary_path)
                logging.info("S3 Regex PII detection completed successfully")
                return True
            else:
                logging.error("S3 Regex PII detection failed")
                return False
        except Exception as e:
            logging.error(f"S3 Regex PII workflow failed: {e}")
            return False


if __name__ == "__main__":
    from src.utils.fmw_utils import start_logging, read_config
    
    start_logging(logs_level="info", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")
    
    detector = S3_RegexPII(config=config)
    detector.run_flow()
    
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
