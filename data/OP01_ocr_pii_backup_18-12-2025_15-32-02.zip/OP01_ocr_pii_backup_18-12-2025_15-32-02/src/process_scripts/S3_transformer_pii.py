#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S2 ML-Based PII Detector with Transformer Ensemble

Enhanced ML detection using:
1. Transformer ensemble (Spanish + Multilingual + English models)
2. Weighted voting for robust predictions
3. Caching for performance
4. Integration with existing validation framework
"""

import os
import re
import logging
import datetime as dt
from typing import Optional, List, Dict, Any

try:
    from sentence_transformers import SentenceTransformer, util
    import torch
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    logging.warning("Sentence Transformers not available - install with: pip install sentence-transformers")

# Project imports
from src.utils.fmw_utils import save_json_file
from src.process_scripts.base_pii_detector import BasePIIDetector
from src.utils.pii_utils import EntityUtils, ExclusionLists, PIIPatterns, TextProcessingUtils
from src.utils.transformer_ensemble import TransformerEnsemble


class S2_TransformerPII(BasePIIDetector):
    """
    ML-based PII detection using transformer ensemble + Sentence Transformers.
    
    Features:
    - Multi-model ensemble voting (token classification)
    - Sentence Transformer for semantic context analysis
    - Smart table detection and deduplication
    - Spanish-optimized detection
    - Confidence-based filtering
    - Integration with regex validation
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config=config)
        
        # Initialize transformer ensemble
        transformer_config = self.config_global.get("TRANSFORMER_CONFIG", {})
        
        if not transformer_config.get("enabled", True):
            logging.warning("Transformer ensemble is disabled in config")
            self.ensemble = None
        else:
            try:
                self.ensemble = TransformerEnsemble(transformer_config)
                logging.info("[OK] Transformer ensemble initialized successfully")
                
                # Log model info
                model_info = self.ensemble.get_model_info()
                logging.info(f"Models loaded: {model_info['models_loaded']}")
                logging.info(f"Device: {model_info['device']}")
                
            except Exception as e:
                logging.error(f"Failed to initialize transformer ensemble: {e}")
                self.ensemble = None
        
        # Initialize Sentence Transformer for context analysis
        self.sentence_transformer = None
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            try:
                # Use multilingual model for Spanish support
                self.sentence_transformer = SentenceTransformer(
                    'sentence-transformers/distiluse-base-multilingual-cased-v2'
                )
                logging.info("[OK] Sentence Transformer initialized successfully")
            except Exception as e:
                logging.error(f"Failed to initialize Sentence Transformer: {e}")
                self.sentence_transformer = None
        
        # Entity type mapping (transformer labels to our PII types)
        self.entity_type_map = {
            "PER": "Person",
            "PERSON": "Person",
            "ORG": "Organization",
            "ORGANIZATION": "Organization",
            "LOC": "Location",
            "LOCATION": "Location",
            "MISC": "Miscellaneous",
            "DATE": "Date",
            "TIME": "Time",
            "MONEY": "Amount",
            "PERCENT": "Percentage"
        }


    def _assign_entity_labels(self, results: List[Dict[str, Any]]) -> None:
        """Assign labels to entities for categorization"""
        numeric_types = {"DATE", "TIME", "PERCENT"}
        for entity in results:
            if entity.get("PII_Type") in numeric_types:
                entity["Label"] = "SequenceNumber"
            else:
                entity["Label"] = "TextData"
    
    def detect_pii(
        self,
        text: str,
        page_num: Optional[int] = None,
        file_path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Detect PII using transformer ensemble.
        
        Args:
            text: Input text to analyze
            page_num: Page number (for metadata)
            file_path: Source file path (for metadata)
            
        Returns:
            List of detected PII entities
        """
        if not text or not text.strip():
            return []
        
        if not self.ensemble:
            logging.warning("Transformer ensemble not available, returning empty results")
            return []
        
        try:
            start_time = dt.datetime.now()
            
            # Get predictions from ensemble
            raw_predictions = self.ensemble.detect_entities(text)
            
            # Convert to our PII format
            pii_entities = self._convert_predictions_to_pii(
                raw_predictions, 
                text, 
                page_num, 
                file_path
            )
            
            # Post-process: validate and filter
            validated_entities = self._validate_entities(pii_entities, text)
            
            processing_time = (dt.datetime.now() - start_time).total_seconds()
            
            logging.info(
                f"Transformer detection: {len(raw_predictions)} raw -> "
                f"{len(pii_entities)} converted -> {len(validated_entities)} validated "
                f"(in {processing_time:.2f}s)"
            )
            
            return validated_entities
            
        except Exception as e:
            logging.error(f"Error in transformer PII detection: {e}")
            return []

    def _convert_predictions_to_pii(
        self,
        predictions: List[Dict[str, Any]],
        text: str,
        page_num: Optional[int],
        file_path: Optional[str]
    ) -> List[Dict[str, Any]]:
        """
        Convert transformer predictions to PII entity format.
        
        Args:
            predictions: Raw transformer predictions
            text: Original text
            page_num: Page number
            file_path: Source file
            
        Returns:
            List of PII entities in standard format
        """
        pii_entities = []
        
        for pred in predictions:
            # Map entity type
            entity_group = pred.get("entity_group", "UNKNOWN")
            pii_type = self.entity_type_map.get(entity_group, entity_group)
            
            # Extract value from text using positions
            start = pred.get("start", 0)
            end = pred.get("end", 0)
            value = text[start:end] if start < end <= len(text) else pred.get("word", "")
            
            # Skip if empty or too short
            if not value or len(value) < 2:
                continue
            
            # Create PII entity
            entity = {
                "PII_Type": pii_type,
                "PII_Value": value.strip(),
                "Confidence": pred.get("score", 0.0),
                "Source": "transformer",
                "start_pos": start,
                "end_pos": end,
                "pattern": pred.get("source_model", "ensemble"),
                "label": entity_group
            }
            
            # Add ensemble metadata if available
            if "contributing_models" in pred:
                entity["ensemble_models"] = pred["contributing_models"]
                entity["vote_count"] = pred.get("vote_count", 1)
            
            # Add page/file metadata
            if page_num is not None:
                entity["Page"] = page_num
            if file_path:
                entity["File"] = os.path.basename(file_path)
            
            pii_entities.append(entity)
        
        return pii_entities

    def _validate_entities(
        self,
        entities: List[Dict[str, Any]],
        text: str
    ) -> List[Dict[str, Any]]:
        """
        Validate and filter detected entities using enhanced semantic analysis.
        
        Args:
            entities: List of detected entities
            text: Original text for context
            
        Returns:
            Filtered list of valid entities
        """
        validated = []
        
        for entity in entities:
            pii_type = entity.get("PII_Type")
            value = entity.get("PII_Value", "")
            
            # Skip if excluded
            if ExclusionLists.is_excluded_phrase(value):
                logging.debug(f"Excluded entity: '{value}'")
                continue
            
            # NEW: Reclassify misidentified Organizations as Persons
            if pii_type == "Organization":
                if self._is_person_name(value):
                    logging.debug(f"Reclassifying '{value}' from Organization to Person")
                    entity["PII_Type"] = "Person"
                    pii_type = "Person"
                else:
                    # Keep as organization if it doesn't match person name patterns
                    validated.append(entity)
                    continue
                
            if pii_type == "Location":
                if self._is_person_name(value):
                    logging.debug(f"Reclassifying '{value}' from Location to Person")
                    entity["PII_Type"] = "Person"
                    pii_type = "Person"
                else:
                    # Keep as location if it doesn't match person name patterns
                    validated.append(entity)
                    continue
            
            # Person-specific validation
            if pii_type == "Person":
                # Must have at least 2 words for person names
                if len(value.split()) < 2:
                    logging.debug(f"Rejected single-word person name: '{value}'")
                    continue
                
                # Check minimum length
                if len(value) < 6:
                    logging.debug(f"Rejected short person name: '{value}'")
                    continue
                
                # Additional validation for Chilean names
                words = value.split()
                valid_word_count = sum(
                    1 for word in words 
                    if len(word) >= 3 and not ExclusionLists.is_excluded_word(word)
                )
                
                if valid_word_count < 2:
                    logging.debug(f"Rejected person name with insufficient valid words: '{value}'")
                    continue
                
                # NEW: Semantic context analysis with Sentence Transformer
                if self.sentence_transformer and not self._is_valid_person_context(
                    entity, text, validated
                ):
                    logging.debug(f"Rejected '{value}' - invalid semantic context")
                    continue
            
            # Organization validation
            elif pii_type == "Organization":
                # Skip single-word organizations if they're common terms
                if len(value.split()) == 1 and ExclusionLists.is_excluded_word(value):
                    logging.debug(f"Excluded organization term: '{value}'")
                    continue
            
            # All validations passed
            validated.append(entity)
        
        # Assign labels to all validated entities
        self._assign_entity_labels(validated)
        
        return validated

    def _is_person_name(self, value: str) -> bool:
            """
            Detect if a value is likely a person name based on structure and patterns.
            Used to reclassify misidentified Organizations as Persons.
            
            Args:
                value: Text value to analyze
                
            Returns:
                True if likely a person name, False otherwise
            """
                # Calculate confidence score confidence weighting:
            # score = 0.0
            # words = value.split()
            
            # # Structure match (0-30 points)
            # if 2 <= len(words) <= 4:
            #     score += 30
            
            # # All words 3+ chars (0-20 points)
            # if all(len(w) >= 3 or w.lower() in {'de', 'del', 'la'} for w in words):
            #     score += 20
            
            # # Known name match (0-30 points)
            # common_names = PIIPatterns.COMMON_NAMES | PIIPatterns.COMMON_SURNAMES
            # matching = sum(1 for w in words if TextProcessingUtils.strip_accents(w.lower()) in common_names)
            # score += matching * 15
            
            # # ALL CAPS pattern (0-20 points)
            # if all(w.isupper() for w in words):
            #     score += 20
            
            # return score >= 40  # Threshold: 40+ points
            
            ########################################################################
            if not value or len(value) < 5:
                return False
            
            # Check word structure
            words = value.split()
            
            # Person names typically have 2-4 words
            if not (2 <= len(words) <= 4):
                return False
            
            # Each word should be mostly alphabetic with length >= 3
            connecting_words = {'de', 'del', 'la', 'las', 'los', 'y', 'e', 'van', 'von'}
            for word in words:
                word_normalized = TextProcessingUtils.strip_accents(word.lower())
                # Skip connecting words (de, del, la, etc.)
                if word_normalized in connecting_words:
                    continue
                
                # Each substantial word should be 3+ chars and mostly letters
                if len(word) < 3:
                    return False
                
                # Allow only letters and hyphens (e.g., "María-José")
                if not all(c.isalpha() or c == '-' for c in word):
                    return False
            
            # Check if words match common Spanish names
            name_words = [w for w in words if w.lower() not in connecting_words]
            
            # At least 2 name words
            if len(name_words) < 2:
                return False
            
            # Check if any word is in common names list (first names or surnames)
            common_names_combined = PIIPatterns.COMMON_NAMES | PIIPatterns.COMMON_SURNAMES
            matching_words = sum(
                1 for word in name_words 
                if TextProcessingUtils.strip_accents(word.lower()) in common_names_combined
            )
            
            # If at least one word matches a known name, it's likely a person
            if matching_words >= 1:
                return True
            
            # Even without known names, structure can suggest person (e.g., "JUAN CARLOS GOMEZ")
            # All caps with 2+ words of 3+ letters each
            if all(len(w) >= 3 and w.isupper() for w in name_words) and len(name_words) >= 2:
                return True
            
            # Mixed case names (typical Spanish names)
            if all(len(w) >= 3 for w in name_words):
                has_capital = any(w[0].isupper() for w in name_words)
                if has_capital:
                    return True
            
            return False

    def _is_valid_person_context(
        self,
        entity: Dict[str, Any],
        text: str,
        previously_validated: List[Dict[str, Any]]
    ) -> bool:
        """
        Use Sentence Transformer to validate if person name is in appropriate context.
        
        Args:
            entity: The entity to validate
            text: Original text
            previously_validated: Already validated entities
            
        Returns:
            True if entity should be kept, False to reject
        """
        start_pos = entity.get("start_pos", 0)
        end_pos = entity.get("end_pos", 0)
        value = entity.get("PII_Value", "")
        
        # Extract context window (200 chars before and after)
        context_start = max(0, start_pos - 200)
        context_end = min(len(text), end_pos + 200)
        context_snippet = text[context_start:context_end]
        
        # Check if context looks like document body or data table
        is_table_context = self._detect_table_structure(context_snippet)
        
        if is_table_context:
            # In table context, check if name appears in cleaner context elsewhere
            first_occurrence = text.find(value)
            first_snippet_start = max(0, first_occurrence - 200)
            first_snippet_end = min(len(text), first_occurrence + len(value) + 200)
            first_snippet = text[first_snippet_start:first_snippet_end]
            
            # If first occurrence is NOT in table, accept (primary mention)
            if not self._detect_table_structure(first_snippet):
                logging.debug(f"Name '{value}' found in table but primary mention is in body text - ACCEPTED")
                return True
            
            # Both in table context - reject
            logging.debug(f"Name '{value}' found in table context")
            return False
        
        # Not in table context - accept
        return True

    def _detect_table_structure(self, text_snippet: str) -> bool:
        """
        Use semantic understanding to detect if snippet is from a data table.
        
        Args:
            text_snippet: Text snippet to analyze
            
        Returns:
            True if likely table/data structure, False if body text
        """
        if not self.sentence_transformer:
            # Fallback to regex if Sentence Transformer unavailable
            return self._detect_table_structure_regex(text_snippet)
        
        try:
            # Reference sentences that indicate body text vs table data
            
            body_indicators = [
                "estimado señor",
                "le informamos que",
                "contacte con",
                "atentamente",
                "saludos cordiales",
                "estimada",
                "por favor",
                "la activación de mandatos físicos PAT se hace en la venta del negocio",
                "se debe registrar la activación que ha hecho el cliente",
                "una vez que se han recibido la documentación",
                "en caso de que mandato presente algún error, se contacta a asesor para gestión",
                "nota: esta misma gestión se realiza para cada mandato entregado",
                "esto se realiza para el Excel quede en el mismo orden",
                "posteriormente ingresar a sistema Serviex para registrar despacho",
                "imprimir carta de despacho",
                "en caso de que se superen ",
                "debe revisar cada uno de los casos"
]

            
            table_indicators = [
                "FechaEmision",
                "FECHA TERMINO",
                "RUT INTERMEDIARIO",
                "NOMBRE EJECUTIVO",
                "MONTO",
                "TIPO BONO",
                "FECHA CALCULO",
                "FECHA INICIO",
                "Sucursal",
                "NUEVO",
                "REF",
                "AC",
                "Agente Somete",
                "Rut Agente Somete",
                "Pago Bono",
                "Pago liquido",
                "Codigo Cliente",
                "SucursalCredito",
                "idSimulacion",
                "Clasificacion",
                "TipoCredito","RutIntermediarioAPagar",
                "ID COMISION","Validacion",
                "RutCliente","ID Simulacion", "Run Ejecutivo",
                "NombreCompleto","EMPRESA","POLIZA",
                "Caracteristica del Bono",
                "Monto Bono","MONTO IMPUTADO",
                "MONTO PAGADO","NUMERO DE POLIZA", 
                "Monto liquido Credito","NUMERO DOCUMENTO",
                "Periodo","MES", "MONTO","DESCRIPCION",
                "Mes Actual", "Mes Anterior","Variaciones",
                "tabla de datos", "ESTADO",
                "registro de empleados"
            ]
            
            # Encode snippet
            snippet_embedding = self.sentence_transformer.encode(
                text_snippet.lower(), 
                convert_to_tensor=True
            )
            
            # Check similarity to table indicators
            table_embeddings = self.sentence_transformer.encode(
                table_indicators, 
                convert_to_tensor=True
            )
            
            table_similarities = util.cos_sim(snippet_embedding, table_embeddings)
            max_table_sim = float(table_similarities.max())
            
            # Check similarity to body indicators
            body_embeddings = self.sentence_transformer.encode(
                body_indicators, 
                convert_to_tensor=True
            )
            
            body_similarities = util.cos_sim(snippet_embedding, body_embeddings)
            max_body_sim = float(body_similarities.max())
            
            logging.debug(
                f"Context analysis - Table similarity: {max_table_sim:.3f}, "
                f"Body similarity: {max_body_sim:.3f}"
            )
            
            # If table similarity significantly higher, it's a table
            return max_table_sim > max_body_sim + 0.1
            
        except Exception as e:
            logging.warning(f"Error in semantic table detection: {e}")
            return self._detect_table_structure_regex(text_snippet)

    def _detect_table_structure_regex(self, text_snippet: str) -> bool:
        """
        Fallback regex-based table detection.
        
        Args:
            text_snippet: Text snippet to analyze
            
        Returns:
            True if likely table structure
        """
        # Count indicators
        rut_pattern = r'\d{1,2}\.\d{3}\.\d{3}-\d'
        numbers = len(re.findall(r'\d+', text_snippet))
        ruts = len(re.findall(rut_pattern, text_snippet))
        
        # Table has many numbers and/or RUT patterns
        return numbers > 5 or ruts > 0

    def batch_detect(
        self,
        texts: List[str],
        metadata: Optional[List[Dict[str, Any]]] = None
    ) -> List[List[Dict[str, Any]]]:
        """
        Batch process multiple texts.
        
        Args:
            texts: List of texts to process
            metadata: Optional metadata for each text (page_num, file_path)
            
        Returns:
            List of entity lists (one per input text)
        """
        if not self.ensemble:
            return [[] for _ in texts]
        
        results = []
        
        for i, text in enumerate(texts):
            meta = metadata[i] if metadata and i < len(metadata) else {}
            page_num = meta.get("page_num")
            file_path = meta.get("file_path")
            
            entities = self.detect_pii(text, page_num, file_path)
            results.append(entities)
        
        return results

    def get_stats(self) -> Dict[str, Any]:
        """Get detection statistics including cache performance"""
        if not self.ensemble:
            return {"enabled": False}
        
        return self.ensemble.get_model_info()

    def extract_pii_from_text(
        self,
        text: str,
        country: Optional[str] = None,
        page_num: Optional[int] = None,
        file_path: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Extract PII from text (implements base class requirement).
        This is an alias for detect_pii to match base class interface.
        
        Args:
            text: Text to extract PII from
            country: Optional country for identity filtering (not used in transformer detection)
            page_num: Optional page number
            file_path: Optional file path
        """
        return self.detect_pii(text, page_num, file_path)

    def get_processing_summary(self) -> Dict[str, Any]:
        """Get processing summary (implements base class requirement)"""
        stats = self.get_stats()
        return {
            "detector_type": "S2_TransformerPII",
            "transformer_enabled": self.ensemble is not None,
            "statistics": stats
        }

    def run_flow(self) -> bool:
        """
        Main flow execution (implements base class requirement).
        Alias for run_process.
        """
        return self.run_process()

    def run_process(self) -> bool:
        """
        Main process execution (implements base class requirement).
        Processes all files in input directory.
        """
        try:
            logging.info("=" * 80)
            logging.info("Starting S2 Transformer PII Detection")
            logging.info("=" * 80)
            
            if not self.ensemble:
                logging.error("Transformer ensemble not available. Aborting.")
                return False
            
            # Get input files from config
            input_dir = self.config_global.get("INPUT", "../input")
            output_dir = self.config_global.get("OUTPUT", "../output")
            
            # Process files (implementation depends on your file structure)
            # This is a placeholder - adjust based on your workflow
            
            logging.info("S2 Transformer PII Detection completed successfully")
            
            # Log statistics
            stats = self.get_stats()
            logging.info("=" * 80)
            logging.info("DETECTION STATISTICS:")
            for key, value in stats.items():
                logging.info(f"  {key}: {value}")
            logging.info("=" * 80)
            
            return True
            
        except Exception as e:
            logging.error(f"Error in S2 Transformer PII process: {e}", exc_info=True)
            return False


# Test/demo function
def test_transformer_ensemble():
    """Test the transformer ensemble with sample text"""
    import json
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Load config
    try:
        with open('config.jsonc', 'r', encoding='utf-8') as f:
            # Remove comments
            content = '\n'.join(line.split('//')[0] for line in f.readlines())
            config = json.loads(content)
    except Exception as e:
        logging.error(f"Failed to load config: {e}")
        return
    
    # Sample Chilean Spanish text with PII
    test_text = """
    Santiago, 15 de octubre de 2025
    
    Estimado Sr. Juan Pérez González:
    
    Me dirijo a usted para informarle que su solicitud de RUT 12.345.678-9 
    ha sido procesada exitosamente. La empresa MetLife Chile ha revisado 
    su documentación.
    
    Por favor contacte a María Fernández Rodríguez en Concepción para 
    coordinar los siguientes pasos. Su póliza número 987654321 está activa.
    
    Atentamente,
    Carlos Ramírez Soto
    Gerente de Operaciones
    """
    
    print("=" * 80)
    print("Testing Transformer Ensemble")
    print("=" * 80)
    
    # Initialize detector
    detector = S2_TransformerPII(config=config)
    
    # Detect PII
    entities = detector.detect_pii(test_text, page_num=1, file_path="test_document.txt")
    
    print(f"\nDetected {len(entities)} PII entities:\n")
    
    for i, entity in enumerate(entities, 1):
        print(f"{i}. {entity['PII_Type']}: {entity['PII_Value']}")
        print(f"   Confidence: {entity['Confidence']:.3f}")
        print(f"   Source: {entity.get('pattern', 'N/A')}")
        if 'ensemble_models' in entity:
            print(f"   Models: {', '.join(entity['ensemble_models'])}")
        print()
    
    # Print statistics
    stats = detector.get_stats()
    print("=" * 80)
    print("STATISTICS:")
    print(json.dumps(stats, indent=2))
    print("=" * 80)


if __name__ == "__main__":
    test_transformer_ensemble()
