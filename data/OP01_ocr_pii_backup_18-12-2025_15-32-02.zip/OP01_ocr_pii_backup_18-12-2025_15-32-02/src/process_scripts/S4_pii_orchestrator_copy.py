#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3 PII Detection Orchestrator

Coordinates multiple PII detection methods: regex-based, ML-based, or hybrid approach.
Provides flexible detection strategies based on performance requirements.
"""

import os
import sys
import re
import logging
import datetime as dt
import argparse
import pandas as pd
import glob
import inspect
from datetime import datetime
from openpyxl.utils import get_column_letter
from typing import Dict, Any, List, Optional
from src.utils.send_email_utils import send_email, df2html
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 


from src.utils.fmw_utils import read_config, save_json_file, start_logging
try:
    from src.utils.pii_utils import ExclusionLists, PIIValidators, TextProcessingUtils
    EXCLUSION_LISTS_AVAILABLE = True
    logging.info("ExclusionLists imported successfully - enhanced entity cleaning enabled")
except ImportError as e:
    logging.warning(f"ExclusionLists import failed: {e} - using basic entity processing")
    EXCLUSION_LISTS_AVAILABLE = False
    # Create dummy classes to avoid errors
    class ExclusionLists:
        @classmethod
        def is_excluded_word(cls, word): return False
        @classmethod 
        def is_excluded_phrase(cls, phrase): return False
        @classmethod
        def has_business_suffix(cls, word): return False
        @classmethod
        def get_exclusion_reason(cls, word): return "N/A"


class EmailTemplateManager:
    """Manages HTML email templates for PII reports"""
    
    def __init__(self, template_dir: str = None):
        self.template_dir = template_dir or os.path.join(
            os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
            "input", "email_files"
        )
        
        # Load template configuration
        self.config_path = os.path.join(self.template_dir, "template_config.json")
        self.template_config = self._load_template_config()
        
        logging.info(f"EmailTemplateManager initialized | template_dir={self.template_dir}")
        
    def _load_template_config(self) -> dict:
        """Load template configuration from JSON file"""
        try:
            if os.path.exists(self.config_path):
                import json
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                logging.warning(f"Template config not found: {self.config_path}, using defaults")
                return self._get_default_config()
        except Exception as e:
            logging.error(f"Error loading template config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> dict:
        """Default template configuration if file is missing"""
        return {
            "email_templates": {
                "resume_email": {"template_file": "resume_email_template.html", "css_file": "email_styles.css"},
                "folder_email": {"template_file": "folder_email_template.html", "css_file": "email_styles.css"}
            },
            "risk_level_configs": {
                "RIESGO ALTO": {"css_class": "risk-high", "description": "Alto riesgo PII detectado"},
                "RIESGO MODERADO": {"css_class": "risk-medium", "description": "Riesgo moderado PII"},
                "RIESGO BAJO": {"css_class": "risk-low", "description": "Bajo riesgo PII"}
            }
        }
    
    def load_template(self, template_name: str) -> str:
        """Load HTML template from file"""
        template_config = self.template_config.get("email_templates", {}).get(template_name, {})
        template_file = template_config.get("template_file", f"{template_name}.html")
        template_path = os.path.join(self.template_dir, template_file)
        
        if not os.path.exists(template_path):
            logging.warning(f"Template not found: {template_path}, using fallback")
            return self._get_fallback_template(template_name)
        
        try:
            with open(template_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logging.error(f"Error loading template {template_name}: {e}")
            return self._get_fallback_template(template_name)
    
    def load_css_styles(self) -> str:
        """Load CSS styles from file and escape curly braces for email format compatibility"""
        css_path = os.path.join(self.template_dir, "email_styles.css")
        
        if not os.path.exists(css_path):
            logging.warning(f"CSS file not found: {css_path}, using default styles")
            return self._get_default_css()
        
        try:
            with open(css_path, 'r', encoding='utf-8') as f:
                css_content = f.read()
                # Escape curly braces to prevent issues with .format() in send_email
                css_content = css_content.replace('{', '{{').replace('}', '}}')
                return css_content
        except Exception as e:
            logging.error(f"Error loading CSS styles: {e}")
            return self._get_default_css()
    
    def render_template(self, template_name: str, **kwargs) -> str:
        """Render template with variables using simple string replacement"""
        try:
            # Load template content
            template_content = self.load_template(template_name)
            
            # Load and inject CSS styles
            css_styles = self.load_css_styles()
            template_content = template_content.replace("{{css_styles}}", css_styles)
            
            # Replace all template variables
            for key, value in kwargs.items():
                placeholder = f"{{{{{key}}}}}"
                template_content = template_content.replace(placeholder, str(value))
            
            return template_content
            
        except Exception as e:
            logging.error(f"Error rendering template {template_name}: {e}")
            return self._get_fallback_html(**kwargs)
    
    def get_risk_config(self, risk_level: str) -> dict:
        """Get risk level configuration"""
        return self.template_config.get("risk_level_configs", {}).get(risk_level, {
            "css_class": "risk-medium",
            "description": "Nivel de riesgo no definido",
            "recommendations": []
        })
    
    def generate_recommendations_html(self, risk_level: str) -> str:
        """Generate strategic recommendations HTML based on risk level"""
        risk_config = self.get_risk_config(risk_level)
        recommendations = risk_config.get("recommendations", [])
        
        if not recommendations:
            return ""
        
        recommendation_items = "".join([f"<li>{rec}</li>" for rec in recommendations])
        timeframe = risk_config.get("timeframe", "A determinar")
        priority = risk_config.get("priority", "normal")
        
        return f"""
        <div class="recommendations-section">
            <h3>📋 Recomendaciones Estratégicas</h3>
            <ul class="recommendation-list">
                {recommendation_items}
            </ul>
            <p class="recommendation-meta">
                <strong>Prioridad:</strong> {priority} | 
                <strong>Plazo sugerido:</strong> {timeframe}
            </p>
        </div>
        """
    
    def get_percentage_color_style(self, percentage_str: str) -> str:
        """
        Calculate inline color style for percentage based on a gradient scale.
        
        Color Scale (max red to min blue):
        - 0%: Blue (#0066cc) - No PII exposure
        - 1-25%: Green (#28a745) - Low exposure  
        - 26-50%: Yellow/Amber (#ffc107) - Moderate exposure
        - 51-75%: Orange (#fd7e14) - High exposure
        - 76-100%: Red (#dc3545) - Critical exposure
        
        Args:
            percentage_str: Percentage string like "45.5%" or "0%"
            
        Returns:
            str: Inline CSS style for the percentage color
        """
        try:
            # Extract numeric value from percentage string
            percentage_value = float(percentage_str.replace('%', '').strip())
            
            # Define color scale
            if percentage_value == 0:
                color = "#0066cc"  # Blue - No PII
            elif percentage_value <= 25:
                color = "#28a745"  # Green - Low
            elif percentage_value <= 50:
                color = "#ffc107"  # Yellow/Amber - Moderate
            elif percentage_value <= 75:
                color = "#fd7e14"  # Orange - High
            else:
                color = "#dc3545"  # Red - Critical
            
            return f"color: {color}; font-weight: bold;"
            
        except (ValueError, AttributeError) as e:
            logging.warning(f"Could not parse percentage '{percentage_str}': {e}")
            return "color: #6f42c1; font-weight: bold;"  # Default purple
    
    def _get_logo_base64(self) -> str:
        """
        Get MetLife logo as Base64 encoded string for email embedding.
        
        Returns:
            str: Base64 encoded image string (without data URI prefix), or empty string if logo not found
        """
        try:
            import base64
            logo_path = os.path.join(self.template_dir, "metlife_logo.png")
            
            if not os.path.exists(logo_path):
                logging.warning(f"Logo file not found: {logo_path}")
                return ""
            
            with open(logo_path, "rb") as img_file:
                logo_base64 = base64.b64encode(img_file.read()).decode('utf-8')
                logging.info(f"Logo loaded and encoded from: {logo_path}")
                return logo_base64
                
        except Exception as e:
            logging.error(f"Error encoding logo to Base64: {e}")
            return ""
    
    def get_logo_html(self, max_width: int = 180) -> str:
        """
        Get HTML img tag with embedded Base64 logo.
        
        Args:
            max_width: Maximum width in pixels for the logo
            
        Returns:
            str: HTML img tag with Base64 logo, or empty string if logo not found
        """
        logo_base64 = self._get_logo_base64()
        if not logo_base64:
            return ""
        
        return f'''<img src="data:image/png;base64,{logo_base64}" alt="MetLife" style="max-width:{max_width}px; height:auto;">'''
    
    def get_email_header_html(self) -> str:
        """
        Get complete email header HTML with MetLife branding.
        
        Returns:
            str: Complete HTML header with logo and brand bar
        """
        logo_html = self.get_logo_html(180)
        
        return f'''
        <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-bottom: 3px solid #0066b3; margin-bottom: 20px;">
            <tr>
                <td style="padding: 15px 25px;">
                    {logo_html if logo_html else '<span style="font-size: 24px; font-weight: bold; color: #0066b3;">MetLife</span>'}
                </td>
                <td style="padding: 15px 25px; text-align: right;">
                    <span style="font-size: 12px; color: #666666;">Sistema de Análisis PII</span>
                </td>
            </tr>
        </table>
        '''

    def _get_fallback_template(self, template_name: str) -> str:
        """Simple fallback template if file loading fails"""
        if template_name == "resume_email":
            return self._get_simple_resume_template()
        elif template_name == "folder_email":
            return self._get_simple_folder_template()
        else:
            return self._get_simple_resume_template()
    
    def _get_simple_resume_template(self) -> str:
        """Simple fallback resume template with MetLife logo"""
        return """
        <html>
        <body style="font-family: Arial, sans-serif; margin: 0; padding: 0;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-bottom: 2px solid #0066b3;">
                <tr>
                    <td style="padding: 15px 20px;">
                        <img src="https://www.metlife.com/content/dam/metlifecom/us/icons-header/MetLife.png" 
                             alt="MetLife" style="height: 35px; width: auto;">
                    </td>
                </tr>
            </table>
            <div style="padding: 20px;">
                <h1>🛡️ INFORME EJECUTIVO DE RIESGOS PII</h1>
                <p><strong>Fecha:</strong> {{timestamp}}</p>
                <p><strong>Archivos analizados:</strong> {{total_files}}</p>
                <p><strong>Archivos con PII:</strong> {{files_with_pii}}</p>
                <p><strong>Total detecciones:</strong> {{total_detections}}</p>
                <p><strong>Nivel de riesgo:</strong> {{risk_level_label}}</p>
                <div>{{strategic_recommendations}}</div>
            </div>
        </body>
        </html>
        """
    
    def _get_simple_folder_template(self) -> str:
        """Simple fallback folder template"""
        return """
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
            <h1>📁 REPORTE PII POR CARPETA</h1>
            <p><strong>Carpeta:</strong> {{folder_name}}</p>
            <p><strong>Archivos en carpeta:</strong> {{folder_total_files}}</p>
            <p><strong>Con PII:</strong> {{folder_files_with_pii}}</p>
        </body>
        </html>
        """
    
    def _get_default_css(self) -> str:
        """Basic default CSS if file loading fails - with escaped braces for email compatibility"""
        return """
        body {{ font-family: Arial, sans-serif; margin: 0; padding: 20px; }}
        .header {{ background: #1e3c72; color: white; padding: 20px; text-align: center; }}
        .kpi-table {{ width: 100%; margin: 20px 0; }}
        .kpi-value {{ font-size: 24px; font-weight: bold; }}
        .risk-high {{ color: #721c24; }}
        .risk-medium {{ color: #856404; }}
        .risk-low {{ color: #155724; }}
        """
    
    def _get_fallback_html(self, **kwargs) -> str:
        """Emergency fallback HTML if everything fails"""
        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; margin: 20px;">
            <h1>Error en Template</h1>
            <p>No se pudo cargar la plantilla correctamente.</p>
            <h3>Datos del reporte:</h3>
            <ul>
                {"".join([f"<li><strong>{k}:</strong> {v}</li>" for k, v in kwargs.items()])}
            </ul>
        </body>
        </html>
        """


class CountrySheetDetector:
    """Detect country from filename and return corresponding sheet name and email column"""
    
    def __init__(self):
        # Country detection patterns (case-insensitive)
        # Priority order: more specific patterns first
        self.country_patterns = [
            ('Brasil', r'(brasil|brazil|br)'),
            ('Colombia', r'(colombia|col)'),
            ('Chile', r'(chile|cl)'),
            ('Uruguay', r'(uruguay|uy)')
        ]
        
        # Sheet name mapping
        self.sheet_mapping = {
            'Brasil': 'Brazil',
            'Chile': 'Chile',
            'Colombia': 'Colombia',
            'Uruguay': 'Uruguay'
        }
        
        # Email column mapping
        self.email_column_mapping = {
            'Brasil': 'brazil_responsible_email',
            'Chile': 'chile_responsible_email',
            'Colombia': 'colombia_responsible_email',
            'Uruguay': 'uruguay_responsible_email'
        }
    
    def detect_country(self, filename: str) -> Optional[str]:
        """
        Extract country from filename using regex patterns
        
        Args:
            filename (str): The filename to analyze
            
        Returns:
            Optional[str]: Country name if detected, None otherwise
        """
        filename_lower = filename.lower()
        
        for country, pattern in self.country_patterns:
            if re.search(pattern, filename_lower):
                return country
        return None
    
    def get_sheet_name(self, filename: str) -> Optional[str]:
        """
        Get sheet name from filename
        
        Args:
            filename (str): The filename to analyze
            
        Returns:
            Optional[str]: Sheet name if country detected, None otherwise
        """
        country = self.detect_country(filename)
        if country:
            return self.sheet_mapping.get(country)
        return None
    
    def get_email_column(self, filename: str) -> Optional[str]:
        """
        Get email column name from filename for specific country
        
        Args:
            filename (str): The filename to analyze
            
        Returns:
            Optional[str]: Email column name if country detected, None otherwise
        """
        country = self.detect_country(filename)
        if country:
            return self.email_column_mapping.get(country)
        return None
    
    def process_file(self, filename: str) -> Dict:
        """
        Complete processing: detect country, get sheet, get email column
        
        Args:
            filename (str): The filename to process
            
        Returns:
            Dict: Processing result with country, sheet name, email column, and status
        """
        country = self.detect_country(filename)
        
        if not country:
            return {
                'filename': filename,
                'detected_country': None,
                'sheet_name': None,
                'email_column': None,
                'status': 'not_detected'
            }
        
        sheet_name = self.sheet_mapping.get(country)
        email_column = self.email_column_mapping.get(country)
        
        return {
            'filename': filename,
            'detected_country': country,
            'sheet_name': sheet_name,
            'email_column': email_column,
            'status': 'success'
        }


class S4PIIOrchestrator:
    """
    Orchestrates PII detection using different methods:
    - 'regex': Fast regex-only detection 
    - 'ml': Comprehensive ML-based detection (spaCy + transformers)
    - 'hybrid': Run both methods and compare/merge results
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        self.config = config or read_config()
        self.config_env = self.config.get("ENVIRONMENT", {})
        
        # Detection method configuration
        self.detection_method = self.config_env.get("DETECTION_METHOD", "hybrid").lower()
        
        # Performance settings
        self.enable_parallel = bool(self.config_env.get("ENABLE_PARALLEL_DETECTION", False))
        self.hybrid_merge_strategy = self.config_env.get("HYBRID_MERGE_STRATEGY", "union")  # union, intersection, ml_priority, weighted
        self.use_weighted_merge = bool(self.config_env.get("USE_WEIGHTED_MERGE", True))  # Enable confidence-weighted merge by default
        
        # Debug mode
        self.debug_mode = bool(self.config_env.get("DEBUG_MODE", False))
        
        # Email configuration - hardcoded defaults, no config.jsonc dependency
        self.send_email_on_completion = True  # Set to True to enable email functionality
        self.email_recipients_file = "input/_recipients.xlsx"
        
        # PII filtering for email reports - OCR_PII_Analysis_HYBRID is complete-
        self.email_excluded_pii_types = {
            "MISC", "Address_Keywords","Amount", "DATE","PartialRUT_Context",
            "Address_Keywords", "Health", 'ORG',"LOC", "TitledPersonName", "Address_StreetNum", "Organization",
            "Location", "Miscellaneous", "Account", "NumberSequence", "ContextualPersonName"
        } 
        
        self.email_excluded_sources = {"spaCy"} # Add spaCy to excluded sources
        
        # Directories
        self.input_dir = self.config_env.get("INPUT_PATH", "input/_file_input")
        self.output_dir = self.config_env.get("OUTPUT_PATH", "output")
        self.process_data_dir = self.config_env.get("PROCESS_DATA_PATH", "process_data")
        
        # Initialize detector instances
        self._regex_detector = None
        self._ml_detector = None
        
        # Initialize template manager
        self.template_manager = EmailTemplateManager()
        
        # Initialize country/sheet detector
        self.country_detector = CountrySheetDetector()
        
        # Initialize LOBs tracking list for email recipients
        self.lobs_founded = []
        
        logging.info(
            f"S4PIIOrchestrator initialized | "
            f"method={self.detection_method} | "
            f"hybrid_strategy={self.hybrid_merge_strategy} | "
            f"parallel={self.enable_parallel} | "
            f"email_enabled={self.send_email_on_completion}"
        )

    def _get_already_processed_files(self) -> set:
        """
        Get set of files that have already been analyzed for PII.
        
        Returns:
            set: Set of filenames already processed (empty set if no metadata exists)
        """
        try:
            # Check if metadata file exists from S00
            metadata_excel = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                "output", "_others", "files_metadata.xlsx"
            )
            
            if not os.path.exists(metadata_excel):
                logging.info("No previous metadata found - first run, all files will be processed")
                return set()
            
            try:
                df = pd.read_excel(metadata_excel)
                logging.info(f"Loaded metadata from: {metadata_excel}")
                
                # Get files that completed PII analysis (pii_analysis_completed == True)
                completed_mask = df.get('pii_analysis_completed', pd.Series([False] * len(df))) == True
                completed_files = df[completed_mask]
                
                if completed_files.empty:
                    logging.info("No previously processed files found in metadata")
                    return set()
                
                # Extract original filenames
                processed_files = set(completed_files['original_filename'].dropna().tolist())
                
                logging.info(f"Found {len(processed_files)} previously processed files:")
                for filename in list(processed_files)[:5]:  # Log first 5
                    logging.info(f"  - {filename}")
                if len(processed_files) > 5:
                    logging.info(f"  ... and {len(processed_files) - 5} more")
                
                return processed_files
                
            except Exception as e:
                logging.warning(f"Could not read metadata from {metadata_excel}: {e}")
                return set()
            
        except Exception as e:
            logging.error(f"Error getting processed files list: {e}")
            return set()

    def _should_process_file(self, folder_name: str, processed_files: set) -> bool:
        """
        Determine if a folder/file should be processed for PII analysis.
        
        Args:
            folder_name: Name of the folder to check (format: "COUNTRY - filename")
            processed_files: Set of already processed filenames
            
        Returns:
            bool: True if folder needs processing, False if already processed
        """
        # Extract original filename from folder name
        # Format: "COUNTRY - filename" where filename is the original file
        original_name = folder_name
        if ' - ' in folder_name:
            # Remove "COUNTRY - " prefix
            parts = folder_name.split(' - ', 1)
            if len(parts) == 2:
                original_name = parts[1].strip()
        
        # Check exact filename match (folder name vs filename with extension)
        if original_name in processed_files:
            logging.info(f"[SKIP] File already processed, skipping folder: {folder_name}")
            return False
        
        # Check base filename without extension
        # Folder: "1-. Procedimiento de Pago de Asegurados"
        # Metadata: "1-. Procedimiento de Pago de Asegurados.docx"
        name_without_ext = os.path.splitext(original_name)[0]
        for processed in processed_files:
            processed_without_ext = os.path.splitext(processed)[0]
            if name_without_ext == processed_without_ext:
                logging.info(f"[SKIP] File already processed (extension match), skipping folder: {folder_name}")
                return False
        
        # Check without numbering (e.g., "file (2).pdf" vs "file.pdf")
        base_name = re.sub(r'\s*\(\d+\)\s*', '', original_name)
        if base_name != original_name:
            base_name_without_ext = os.path.splitext(base_name)[0]
            for processed in processed_files:
                processed_without_ext = os.path.splitext(processed)[0]
                if base_name_without_ext == processed_without_ext:
                    logging.info(f"[SKIP] File variant already processed, skipping folder: {folder_name}")
                    return False
        
        logging.info(f"[PROCESS] Folder needs processing: {folder_name}")
        return True

    def _update_processed_file_metadata(self, filename: str, pii_count: int, 
                                        report_path: str = None, email_sent: bool = False):
        """
        Update metadata to mark file as processed for PII analysis.
        
        Args:
            filename: Name of processed folder (e.g., "Chile - 1-. Procedimiento de Pago de Asegurados")
            pii_count: Number of PII entities found
            report_path: Path to generated report (optional)
            email_sent: Whether notification email was sent
        """
        try:
            timestamp = dt.datetime.now().isoformat()
            
            metadata_excel = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                "output", "_others", "files_metadata.xlsx"
            )
            
            if not os.path.exists(metadata_excel):
                logging.warning("Metadata file not found for update")
                return
            
            # Read existing metadata
            df = pd.read_excel(metadata_excel)
            
            # Extract original filename (remove country prefix from folder name)
            original_name = filename
            if ' - ' in filename:
                parts = filename.split(' - ', 1)
                if len(parts) == 2:
                    original_name = parts[1].strip()
            
            # The metadata stores full filenames with extensions (e.g., "file.docx")
            # But folder names may not have extensions
            # Try multiple matching strategies
            mask = None
            
            # Strategy 1: Exact match with original_name
            mask = df['original_filename'] == original_name
            
            # Strategy 2: Match without extension (folder name vs filename with extension)
            if not mask.any():
                name_without_ext = os.path.splitext(original_name)[0]
                mask = df['original_filename'].apply(
                    lambda x: os.path.splitext(str(x))[0] == name_without_ext if pd.notna(x) else False
                )
            
            # Strategy 3: Partial match (in case of encoding issues like ó vs �)
            if not mask.any():
                # Normalize the search name
                normalized_search = original_name.replace('�', 'ó').replace('�', 'í').replace('�', 'ñ')
                mask = df['original_filename'].apply(
                    lambda x: normalized_search in str(x) or str(x) in normalized_search if pd.notna(x) else False
                )
            
            if mask.any():
                df.loc[mask, 'pii_analysis_completed'] = True
                df.loc[mask, 'pii_analysis_timestamp'] = timestamp
                df.loc[mask, 'pii_entities_found'] = pii_count
                df.loc[mask, 'report_generated'] = report_path is not None
                df.loc[mask, 'email_sent'] = email_sent
                df.loc[mask, 'workflow_stage'] = 'completed'
                df.loc[mask, 'processing_status'] = 'completed'
                df.loc[mask, 'last_processed_by'] = 'S4_pii_orchestrator'
                
                # Save updated metadata
                df.to_excel(metadata_excel, index=False, engine='openpyxl')
                matched_file = df.loc[mask, 'original_filename'].iloc[0]
                logging.info(f"[OK] Updated metadata for: {matched_file} (PII count: {pii_count})")
            else:
                logging.warning(f"File not found in metadata for update: {original_name}")
                logging.debug(f"Available filenames in metadata: {df['original_filename'].tolist()}")
            
        except Exception as e:
            logging.error(f"Error updating metadata for {filename}: {e}")

    def _get_regex_detector(self):
        """Lazy initialization of regex detector"""
        if self._regex_detector is None:
            from src.process_scripts.S3_regex_pii import S3_RegexPII
            self._regex_detector = S3_RegexPII(config=self.config)
        return self._regex_detector

    def _get_ml_detector(self):
        """Lazy initialization of ML detector - supports both transformer ensemble and legacy spaCy"""  
        if self._ml_detector is None:
            # Check if transformer config is enabled (check both root and GLOBAL locations)
            transformer_config = (
                self.config.get("TRANSFORMER_CONFIG", {}) or 
                self.config.get("GLOBAL", {}).get("TRANSFORMER_CONFIG", {})
            )
            use_transformers = transformer_config.get("enabled", False)
            
            if use_transformers:
                try:
                    from process_scripts.S3_transformer_pii import S2_TransformerPII
                    self._ml_detector = S2_TransformerPII(config=self.config)
                    logging.info("[OK] Using transformer ensemble for ML detection (S2_TransformerPII)")
                except ImportError as e:
                    logging.warning(f"Failed to load transformer ensemble: {e}, falling back to spaCy")
                    from src.process_scripts.S3_ml_ner import S3_MachineLearningNER
                    self._ml_detector = S3_MachineLearningNER(config=self.config)
                    logging.info("Using legacy spaCy-based ML detection (S3_MachineLearningNER)")
            else:
                from src.process_scripts.S3_ml_ner import S3_MachineLearningNER
                self._ml_detector = S3_MachineLearningNER(config=self.config)
                logging.info("Using legacy spaCy-based ML detection (S3_MachineLearningNER)")
        
        return self._ml_detector

    def _load_employee_list(self) -> set:
        """
        Load employee list from employees.xlsx file with name variations.
        
        Returns:
            set: Set of employee display names and variations (normalized for matching)
        """
        try:
            # Get the employees file path
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            employees_file = os.path.join(project_root, "input", "employees.xlsx")
            
            if not os.path.exists(employees_file):
                logging.warning(f"Employees file not found: {employees_file}")
                return set()
            
            # Read the Excel file
            import pandas as pd
            df_employees = pd.read_excel(employees_file)
            
            if 'Display Name' not in df_employees.columns:
                logging.warning("Column 'Display Name' not found in employees.xlsx")
                return set()
            
            # Get all employee names and create variations
            employee_names = set()
            variations_created = 0
            
            for name in df_employees['Display Name'].dropna():
                normalized_name = str(name).strip().lower()
                if normalized_name:
                    # Add the full name
                    employee_names.add(normalized_name)
                    
                    # Add name variations for partial matching
                    words = normalized_name.split()
                    if len(words) >= 3:  # Has at least 3 parts (e.g. "gabriela fernanda moreau")
                        # Add "first last" variation (skip middle names)
                        first_last = f"{words[0]} {words[-1]}"
                        employee_names.add(first_last)
                        variations_created += 1
                        
                        # Add "first middle" variation for cases like "Gabriela Fernanda"
                        first_middle = f"{words[0]} {words[1]}"
                        employee_names.add(first_middle)
                        variations_created += 1
                    
                    elif len(words) == 2:  # Two-part names
                        # Already covered by full name, but ensure both parts are accessible
                        first_name = words[0]
                        last_name = words[1]
                        if len(first_name) >= 3:  # Only meaningful names
                            employee_names.add(first_name)
                            variations_created += 1
                        if len(last_name) >= 3:
                            employee_names.add(last_name)
                            variations_created += 1
            
            total_names = len(employee_names)
            original_names = len(df_employees['Display Name'].dropna())
            
            logging.info(f"Loaded {original_names} original employee names from {employees_file}")
            logging.info(f"Created {variations_created} name variations for improved matching")
            logging.info(f"Total searchable names: {total_names}")
            
            return employee_names
            
        except Exception as e:
            logging.error(f"Error loading employee list: {e}")
            return set()

    def _load_employee_identifiers(self) -> Dict[str, str]:
        """
        Load Primary National Identifier Numbers (RUT) from employees.xlsx.
        Creates a mapping of cleaned identifiers to their employee names for PII validation.
        
        Cleaning: Removes all dots from identifier (e.g., "12.345.678-K" -> "12345678-K")
        
        >> Update for the rest of the countries as needed << the excel file have the country column
        
        Returns:
            Dict[str, str]: Mapping of cleaned identifier (RUT) -> employee name (normalized)
            Example: {"123456789": "gabriel moreau", "987654321": "maria rodriguez", ...}
            
        """
        try:
            # Get the employees file path
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            employees_file = os.path.join(project_root, "input", "employees.xlsx")
            
            if not os.path.exists(employees_file):
                logging.warning(f"Employees file not found for identifier loading: {employees_file}")
                return {}
            logging.info(f"Loading employee identifiers from: {employees_file}")
            
            # Read the Excel file
            import pandas as pd
            df_employees = pd.read_excel(employees_file)
            
            # Check for required columns
            required_columns = ['Display Name', 'Primary National Identifier Number']
            # Verify all required columns are present
            missing_columns = [col for col in required_columns if col not in df_employees.columns]
            
            if missing_columns:
                logging.warning(f"Required columns not found in employees.xlsx: {missing_columns}")
                logging.warning(f"Available columns: {df_employees.columns.tolist()}")
                return {}
            
            identifier_map = {}
            identifiers_loaded = 0
            identifiers_skipped = 0
            
            for _, row in df_employees.iterrows():
                try:
                    name = str(row['Display Name']).strip()
                    identifier = str(row['Primary National Identifier Number']).strip()
                    
                    # Skip invalid entries
                    if not name or not identifier or identifier.lower() == 'nan':
                        identifiers_skipped += 1
                        continue
                    
                    # CLEAN: Remove all dots from identifier (e.g., "12.345.678-K" -> "12345678-K")
                    cleaned_identifier = identifier.replace('.', '')
                    
                    # Normalize name for matching (lowercase)
                    normalized_name = name.lower()
                    
                    # Map cleaned identifier to normalized name
                    identifier_map[cleaned_identifier] = normalized_name
                    identifiers_loaded += 1
                    
                    logging.debug(f"Loaded identifier: '{identifier}' -> cleaned: '{cleaned_identifier}' -> name: '{normalized_name}'")
                    
                except Exception as e:
                    logging.debug(f"Error processing row for identifier loading: {e}")
                    identifiers_skipped += 1
                    continue
            
            logging.info(f"Loaded {identifiers_loaded} employee identifiers (dots cleaned, {identifiers_skipped} skipped)")
            if identifiers_loaded > 0:
                sample_ids = list(identifier_map.items())[:3]
                logging.debug(f"Sample identifiers loaded: {sample_ids}")
            
            return identifier_map
            
        except Exception as e:
            logging.error(f"Error loading employee identifiers: {e}")
            return {}

    def _load_exclusion_lists(self) -> Dict[str, set]:
        """
        Load exclusion lists from exclusiones.xlsx file.
        
        Returns:
            Dict[str, set]: Dictionary with exclusion sets for different categories
        """
        try:
            # Get the exclusions file path
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            exclusions_file = os.path.join(project_root, "input", "exclusiones.xlsx")
            
            if not os.path.exists(exclusions_file):
                logging.warning(f"Exclusions file not found: {exclusions_file}")
                return {}
            
            exclusions = {}
            
            # Load 'Cuenta' sheet
            try:
                df_cuenta = pd.read_excel(exclusions_file, sheet_name='Cuenta')
                if 'Cuenta' in df_cuenta.columns:
                    cuenta_values = set()
                    for value in df_cuenta['Cuenta'].dropna():
                        # Convert to string and normalize
                        normalized_value = str(value).strip()
                        if normalized_value:
                            cuenta_values.add(normalized_value)
                    exclusions['Cuenta'] = cuenta_values
                    logging.info(f"Loaded {len(cuenta_values)} exclusion values from 'Cuenta' sheet")
                else:
                    logging.warning("Column 'Cuenta' not found in 'Cuenta' sheet")
                    exclusions['Cuenta'] = set()
            except Exception as e:
                logging.warning(f"Error loading 'Cuenta' sheet: {e}")
                exclusions['Cuenta'] = set()
            
            # Load 'Centro costo' sheet
            try:
                df_centro = pd.read_excel(exclusions_file, sheet_name='Centro costo')
                if 'Centro de Costo' in df_centro.columns:
                    centro_values = set()
                    for value in df_centro['Centro de Costo'].dropna():
                        # Convert to string and normalize
                        normalized_value = str(value).strip()
                        if normalized_value:
                            centro_values.add(normalized_value)
                    exclusions['Centro de Costo'] = centro_values
                    logging.info(f"Loaded {len(centro_values)} exclusion values from 'Centro de Costo' sheet")
                else:
                    logging.warning("Column 'Centro de Costo' not found in 'Centro costo' sheet")
                    exclusions['Centro de Costo'] = set()
            except Exception as e:
                logging.warning(f"Error loading 'Centro costo' sheet: {e}")
                exclusions['Centro de Costo'] = set()
            
            total_exclusions = sum(len(values) for values in exclusions.values())
            logging.info(f"Total exclusion values loaded: {total_exclusions}")
            
            return exclusions
            
        except Exception as e:
            logging.error(f"Error loading exclusion lists: {e}")
            return {}

    def clean_detected_entity(self, entity_text: str, entity_type: str = "") -> Optional[str]:
        """
        Clean detected entity using two-step approach: word-level cleaning then phrase-level validation.
        
        This method implements the recommended approach of using word-level exclusion for cleaning
        (preserving valid words while removing problematic ones) followed by phrase-level validation
        for final filtering.
        
        Args:
            entity_text (str): Original detected entity text
            entity_type (str): Type of PII entity (for logging context)
            
        Returns:
            Optional[str]: Cleaned entity text if valid, None if should be excluded
            
        Examples:
            >>> self.clean_detected_entity("Juan Pérez contingent", "SpanishName")
            "Juan Pérez"  # Removes "contingent", keeps valid names
            
            >>> self.clean_detected_entity("CREACIÓN PÓLIZAS RV", "ContextualPersonName") 
            None  # Entire phrase is business process term
            
            >>> self.clean_detected_entity("posteriormente administración", "SpanishName")
            None  # All words are business terms, nothing left
        """
        try:
            if not entity_text or not entity_text.strip():
                return None
            
            # If ExclusionLists not available, return original text
            if not EXCLUSION_LISTS_AVAILABLE:
                return entity_text.strip()
            
            original_text = entity_text.strip()
            
            # Step 1: Word-level cleaning (preserve valid words, remove excluded ones)
            words = original_text.split()
            clean_words = []
            excluded_words = []
            
            for word in words:
                if not ExclusionLists.is_excluded_word(word):
                    clean_words.append(word)
                else:
                    excluded_words.append(word)
                    reason = ExclusionLists.get_exclusion_reason(word)
                    logging.debug(f"EXCLUDED WORD: '{word}' from '{original_text}' - reason: {reason}")
            
            # Check if we have enough valid words left (minimum 1 for single names, 2 for compound names)
            min_words_required = 1 if entity_type in {"CUSTOMER_NAME", "SpanishName"} else 1
            if len(clean_words) < min_words_required:
                logging.info(f"INSUFFICIENT WORDS: '{original_text}' reduced to {len(clean_words)} words, minimum {min_words_required} required")
                return None
            
            cleaned_phrase = " ".join(clean_words)
            
            # If no words were excluded, check if original phrase should be excluded entirely
            if not excluded_words and cleaned_phrase == original_text:
                # Step 2a: Direct phrase-level validation for unchanged text
                if ExclusionLists.is_excluded_phrase(cleaned_phrase):
                    logging.info(f"EXCLUDED PHRASE: '{cleaned_phrase}' contains exclusion patterns")
                    return None
                # Text is clean, return as-is
                return cleaned_phrase
            
            # Step 2b: Phrase-level validation for cleaned text
            if ExclusionLists.is_excluded_phrase(cleaned_phrase):
                logging.info(f"EXCLUDED CLEANED PHRASE: '{cleaned_phrase}' (from '{original_text}') contains exclusion patterns")
                return None
            
            # Success: return cleaned text
            if excluded_words:
                logging.info(f"CLEANED ENTITY: '{original_text}' -> '{cleaned_phrase}' (removed: {', '.join(excluded_words)})")
            
            return cleaned_phrase
            
        except Exception as e:
            logging.error(f"Error cleaning entity '{entity_text}': {e}")
            return entity_text  # Return original if cleaning fails

    def validate_cleaned_entity(self, entity_text: str, entity_type: str) -> bool:
        """
        Additional validation for cleaned entities to ensure they meet quality standards.
        
        Args:
            entity_text (str): Cleaned entity text
            entity_type (str): Type of PII entity
            
        Returns:
            bool: True if entity passes validation, False otherwise
        """
        try:
            if not entity_text or not entity_text.strip():
                return False
            
            # If ExclusionLists not available, do basic validation only
            if not EXCLUSION_LISTS_AVAILABLE:
                return len(entity_text.strip()) >= 2
            
            # Minimum length check
            if len(entity_text.strip()) < 2:
                logging.debug(f"VALIDATION FAILED: '{entity_text}' too short")
                return False
            
            # Check for business suffixes in remaining text
            if ExclusionLists.has_business_suffix(entity_text):
                logging.debug(f"VALIDATION FAILED: '{entity_text}' has business suffix")
                return False
            
            # For name types, ensure we have at least one alphabetic character
            name_types = {"CUSTOMER_NAME", "SpanishName", "ContextualPersonName", 
                        "TitledPersonName", "ChileanFullName", "CompoundSpanishName", 
                        "PatronymicName", "Name_With_Role","Chileanvariation", "DoubleSurnameWithFirstNames"}
        
            if entity_type in name_types:
                if not any(c.isalpha() for c in entity_text):
                    logging.debug(f"VALIDATION FAILED: '{entity_text}' contains no alphabetic characters")
                    return False
                
                # Check minimum word count for compound names
                words = entity_text.split()
                if entity_type in {"ChileanFullName", "CompoundSpanishName"} and len(words) < 2:
                    logging.debug(f"VALIDATION FAILED: '{entity_text}' compound name type requires minimum 2 words")
                    return False
            
            return True
            
        except Exception as e:
            logging.error(f"Error validating entity '{entity_text}': {e}")
            return True  # Return True on error to avoid blocking valid data

    def _strip_leading_city(self, entity_text: str) -> str:
        """
        Remove leading city/geographic names from detected entities.
        
        This prevents false positives where city names are captured as part of person names.
        Examples:
            "Antofagasta JORQUERA GUTIERREZ" -> "JORQUERA GUTIERREZ"
            "Arica Villablanca Henri" -> "Villablanca Henri"
            "Somete IRAMIREZ" -> "IRAMIREZ" (also strips OCR artifacts)
        
        Args:
            entity_text (str): Original detected entity text
            
        Returns:
            str: Entity text with leading city/geographic terms removed
        """
        try:
            if not entity_text or not entity_text.strip():
                return entity_text
            
            # If ExclusionLists not available, return original
            if not EXCLUSION_LISTS_AVAILABLE:
                return entity_text
            
            from src.utils.pii_utils import ExclusionLists, TextProcessingUtils
            
            tokens = entity_text.split()
            if len(tokens) <= 1:
                return entity_text  # Don't strip if only one token
            
            # Check if first token is a city or OCR artifact
            first_token = tokens[0]
            normalized_first = TextProcessingUtils.strip_accents(first_token.lower())
            
            # Check against geographic terms
            for city in ExclusionLists.GEOGRAPHIC_TERMS:
                normalized_city = TextProcessingUtils.strip_accents(city.lower())
                if normalized_first == normalized_city:
                    # Found a city, return rest of tokens
                    remaining = " ".join(tokens[1:])
                    logging.info(f"STRIPPED CITY: '{first_token}' from '{entity_text}' -> '{remaining}'")
                    return remaining if remaining else entity_text
            
            # Also check against OCR artifacts that appear as prefixes
            ocr_prefixes = {"somete", "emetlife", "metute", "autorzado"}
            if normalized_first in ocr_prefixes:
                remaining = " ".join(tokens[1:])
                logging.info(f"STRIPPED OCR ARTIFACT: '{first_token}' from '{entity_text}' -> '{remaining}'")
                return remaining if remaining else entity_text
            
            return entity_text
            
        except Exception as e:
            logging.error(f"Error stripping city from '{entity_text}': {e}")
            return entity_text  # Return original on error

    def get_exclusion_statistics(self, original_entities: List[Dict[str, Any]], 
                                final_entities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate detailed statistics about the exclusion process.
        
        Args:
            original_entities: List of entities before exclusion
            final_entities: List of entities after exclusion
            
        Returns:
            Dict with detailed exclusion statistics
        """
        try:
            original_count = len(original_entities)
            final_count = len(final_entities)
            excluded_count = original_count - final_count
            
            # Count by PII type
            original_types = {}
            final_types = {}
            
            for entity in original_entities:
                pii_type = entity.get("PII_Type", "Unknown")
                original_types[pii_type] = original_types.get(pii_type, 0) + 1
            
            for entity in final_entities:
                pii_type = entity.get("PII_Type", "Unknown")
                final_types[pii_type] = final_types.get(pii_type, 0) + 1
            
            # Calculate exclusion by type
            exclusion_by_type = {}
            for pii_type in original_types:
                original_type_count = original_types[pii_type]
                final_type_count = final_types.get(pii_type, 0)
                excluded_type_count = original_type_count - final_type_count
                exclusion_rate = (excluded_type_count / original_type_count * 100) if original_type_count > 0 else 0
                
                exclusion_by_type[pii_type] = {
                    "original": original_type_count,
                    "final": final_type_count,
                    "excluded": excluded_type_count,
                    "exclusion_rate": exclusion_rate
                }
            
            stats = {
                "total_original": original_count,
                "total_final": final_count,
                "total_excluded": excluded_count,
                "overall_exclusion_rate": (excluded_count / original_count * 100) if original_count > 0 else 0,
                "exclusion_by_type": exclusion_by_type
            }
            
            return stats
            
        except Exception as e:
            logging.error(f"Error generating exclusion statistics: {e}")
            return {}

    def _check_if_employee_by_identifier(self, pii_value: str, identifier_map: Dict[str, str]) -> str:
        """
        Check if a PII value (identifier/RUT) matches an employee identifier.
        Handles various RUT formats and cleaning (dots, suffixes).
        
        Args:
            pii_value (str): The PII value to check (should be a RUT/identifier)
            identifier_map (Dict[str, str]): Mapping of cleaned identifiers to employee names
            
        Returns:
            str: "Yes" if employee identifier found, "No" if not found or invalid input
            
        Examples:
            >>> identifier_map = {"123456789": "gabriel moreau", "987654321": "maria rodriguez"}
            >>> self._check_if_employee_by_identifier("12.345.6789", identifier_map)
            "Yes"  # After cleaning dots: "123456789" matches
            
            >>> self._check_if_employee_by_identifier("999999999", identifier_map)
            "No"   # Not found in employee database
            
            >>> self._check_if_employee_by_identifier("12.345.678-K", identifier_map)
            "Yes"  # Handles RUT format with suffix
        """
        try:
            if not pii_value or not identifier_map:
                return "No"
            
            # Normalize and clean the PII value
            normalized_pii = str(pii_value).strip()
            
            # Remove dots from PII value (handles formats like "12.345.678-K")
            cleaned_pii = normalized_pii.replace('.', '')
            
            # Check for exact match in identifier map
            if cleaned_pii in identifier_map:
                employee_name = identifier_map[cleaned_pii]
                logging.info(f"EMPLOYEE IDENTIFIER MATCH: '{normalized_pii}' (cleaned: '{cleaned_pii}') -> {employee_name}")
                return "Yes"
            
            # Try without the suffix (e.g., "123456789-K" -> "123456789")
            if '-' in cleaned_pii:
                base_identifier = cleaned_pii.split('-')[0]
                if base_identifier in identifier_map:
                    employee_name = identifier_map[base_identifier]
                    logging.info(f"EMPLOYEE IDENTIFIER MATCH (base): '{normalized_pii}' (base: '{base_identifier}') -> {employee_name}")
                    return "Yes"
            
            logging.debug(f"No identifier match found for '{normalized_pii}' (cleaned: '{cleaned_pii}')")
            return "No"
            
        except Exception as e:
            logging.error(f"Error checking employee identifier for '{pii_value}': {e}")
            return "No"

    def _check_if_employee(self, pii_value: str, employee_names: set, 
                          pii_type: str = "", identifier_map: Optional[Dict[str, str]] = None) -> str:
        """
        Enhanced check if a PII value matches an employee (by name or identifier).
        Routes to appropriate matching strategy based on PII_Type.
        
        This is the main entry point for employee detection, orchestrating different fuzzy matching
        strategies with fallback mechanisms. It handles OCR errors, name variations, and partial matches.
        
        Matching Strategy:
        1. For sequence/ID types: Check identifier map (RUT/national ID numbers)
        2. For name types: Check employee names with fuzzy matching
        3. Fallback: Try both strategies if no type specified
        
        Args:
            pii_value (str): The PII value to check against employee database
            employee_names (set): Set of normalized employee names and variations
            pii_type (str): Type of PII (used to select matching strategy)
                - Sequence types: "SEQ_NUMBER", "NumberSequence", "RUT", etc.
                - Name types: "CUSTOMER_NAME", "SpanishName", "Person", etc.
            identifier_map (Optional[Dict[str, str]]): Mapping of identifiers to employee names
            
        Returns:
            str: "Yes" if employee match found, "No" if no match or invalid input
            
        Examples:
            >>> # Check by identifier (RUT)
            >>> identifier_map = {"123456789": "gabriel moreau"}
            >>> self._check_if_employee("12.345.6789", employee_names, "SEQ_NUMBER", identifier_map)
            "Yes"
            
            >>> # Check by name
            >>> employee_names = {"gabriel moreau", "gabriela fernanda moreau"}
            >>> self._check_if_employee("Gabriel Moreau", employee_names, "CUSTOMER_NAME")
            "Yes"
            
            >>> # Fallback: try both
            >>> self._check_if_employee("12.345.6789", employee_names)
            "Yes"  # Tries identifier first, then name
            
        Note:
            Automatically detects FuzzyWuzzy availability and falls back to difflib if needed.
            Handles common OCR errors, gender variations, and missing middle names.
        """
        try:
            # Validate inputs
            if not pii_value:
                logging.warning(f"Empty PII value provided for employee check")
                return "No"
            
            if not employee_names and not identifier_map:
                logging.warning(f"Empty employee database provided for employee check of '{pii_value}'")
                return "No"
            
            # Check if the phrase should be excluded entirely (business terms, etc.)
            if EXCLUSION_LISTS_AVAILABLE and ExclusionLists.is_excluded_phrase(pii_value):
                logging.info(f"EXCLUDED PHRASE IN EMPLOYEE CHECK: '{pii_value}' matches exclusion patterns")
                return "No"
            
            # Define PII type categories
            sequence_number_types = {
                "SEQ_NUMBER", "NumberSequence", "NUMBERSEQUENCE", 
                "Secuencia numerica", "Sequence", "NumericSequence",
                "RUT", "IDENTIFICATION", "ID", "PartialRUT", "RUTPartial"
            }
            
            name_pii_types = {
                "CUSTOMER_NAME", "SpanishName", "ContextualPersonName", 
                "TitledPersonName", "ChileanFullName", "CompoundSpanishName", 
                "PatronymicName", "Name_With_Role", "Person", "Chileanvariation",
                "PersonName", "FullName", "DoubleSurnameWithFirstNames"
            }
            
            # STRATEGY 1: Check if PII_Type is a sequence/ID type and use identifier map
            if pii_type in sequence_number_types and identifier_map:
                logging.debug(f"Checking identifier '{pii_value}' (type: {pii_type}) against employee identifier map")
                identifier_result = self._check_if_employee_by_identifier(pii_value, identifier_map)
                if identifier_result == "Yes":
                    return "Yes"
            
            # STRATEGY 2: Check if PII_Type is a name type and use name matching
            if pii_type in name_pii_types and employee_names:
                logging.debug(f"Checking name '{pii_value}' (type: {pii_type}) against employee names")
                return self._check_if_employee_names_only(pii_value, employee_names)
            
            # STRATEGY 3: If no type provided or type is unknown, try both strategies
            if not pii_type:
                # Try identifier check first if available
                if identifier_map:
                    identifier_result = self._check_if_employee_by_identifier(pii_value, identifier_map)
                    if identifier_result == "Yes":
                        return "Yes"
                
                # Then try name check if available
                if employee_names:
                    return self._check_if_employee_names_only(pii_value, employee_names)
            
            return "No"
                
        except Exception as e:
            logging.error(f"Error in employee check for '{pii_value}' (type: {pii_type}): {e}")
            return "No"

    def _check_if_employee_names_only(self, pii_value: str, employee_names: set) -> str:
        """
        Internal method to check if a PII value matches an employee name using multi-tier fuzzy matching.
        
        This orchestrates different fuzzy matching strategies with fallback mechanisms.
        Handles OCR errors, name variations, and partial matches.
        
        Args:
            pii_value (str): The PII value to check against employee database
            employee_names (set): Set of normalized employee names and variations
            
        Returns:
            str: "Yes" if employee match found, "No" otherwise
        """
        try:
            # Normalize the PII value for matching
            normalized_pii = str(pii_value).strip().lower()
            
            # 1. Exact match first (fastest)
            if normalized_pii in employee_names:
                logging.info(f"EXACT MATCH: '{normalized_pii}' found in employee database")
                return "Yes"
            
            # 2. Try FuzzyWuzzy first, fall back to difflib if not available
            try:
                from fuzzywuzzy import fuzz, process
                logging.debug(f"Using FuzzyWuzzy for '{normalized_pii}'")
                result = self._fuzzy_employee_check_fuzzywuzzy(normalized_pii, employee_names, fuzz, process)
                return result
            except ImportError:
                logging.debug(f"FuzzyWuzzy not available, using difflib for '{normalized_pii}'")
                result = self._fuzzy_employee_check_difflib(normalized_pii, employee_names)
                return result
                
        except Exception as e:
            logging.error(f"Error in employee name check for '{pii_value}': {e}")
            return "No"
    
    def _fuzzy_employee_check_fuzzywuzzy(self, normalized_pii: str, employee_names: set, fuzz, process) -> str:
        """
        FuzzyWuzzy-based employee matching with STRICT first+last name validation.
        
        FIXED: Now requires BOTH first AND last names to match (not middle names only).
        Prevents false positives where middle names coincide between different people.
        
        Example false positive prevented:
            - PII: "kuncar hirmas cecilia margarita" (kuncar=first, hirmas=last, cecilia=middle1, margarita=middle2)
            - Employee: "cecilia margarita alfaro" (cecilia=first, margarita=middle, alfaro=last)
            - OLD: Would match on "cecilia margarita" at 83% (FALSE POSITIVE)
            - NEW: First name "kuncar" ≠ "cecilia" [->] REJECTED [YES]
        """
        import difflib
        
        employee_list = list(employee_names)
        
        # Filter to only 2+ word employee names (accepts "Gabriel Moreau" format)
        meaningful_employees = [name for name in employee_list if len(name.split()) >= 2]
        
        if not meaningful_employees:
            logging.debug(f"No meaningful employee names (2+ words) found")
            return self._enhanced_partial_matching(normalized_pii, employee_names)
        
        logging.debug(f"Filtered employee list: {len(employee_list)} -> {len(meaningful_employees)} (2+ word requirement)")
        
        # Extract first and last from PII
        pii_words = normalized_pii.split()
        pii_first = pii_words[0] if len(pii_words) > 0 else ""
        pii_last = pii_words[-1] if len(pii_words) > 0 else ""
        
        fuzzy_results = []
        
        # Token set ratio - good for partial matches with different word counts
        best_match_token_set = process.extractOne(
            normalized_pii, meaningful_employees, scorer=fuzz.token_set_ratio
        )
        
        if best_match_token_set and best_match_token_set[1] >= 80:
            matched_name = best_match_token_set[0]
            matched_words = matched_name.split()
            
            # Require 2+ words in matched employee name
            if len(matched_words) < 2:
                logging.debug(f"[NO] Token set rejected: matched name '{matched_name}' has only {len(matched_words)} words")
            else:
                # Extract first and last from BOTH PII and employee
                emp_first = matched_words[0]
                emp_last = matched_words[-1]
                
                # STRICT VALIDATION: Both first AND last names must match at 80%+
                first_similarity = difflib.SequenceMatcher(None, pii_first.lower(), emp_first.lower()).ratio()
                last_similarity = difflib.SequenceMatcher(None, pii_last.lower(), emp_last.lower()).ratio()
                
                logging.debug(f"Token_set strict validation for '{normalized_pii}' vs '{matched_name}':")
                logging.debug(f"  - First: '{pii_first}' vs '{emp_first}' = {first_similarity*100:.0f}%")
                logging.debug(f"  - Last: '{pii_last}' vs '{emp_last}' = {last_similarity*100:.0f}%")
                
                # BOTH first and last must be at least 80% similar
                if first_similarity >= 0.80 and last_similarity >= 0.80:
                    fuzzy_results.append(("token_set", best_match_token_set[1], matched_name))
                    logging.debug(f"[YES] Token_set PASSED strict first+last validation")
                else:
                    logging.debug(f"[NO] Token_set FAILED: first {first_similarity*100:.0f}% + last {last_similarity*100:.0f}%")
        
        # Token sort ratio - good for different word orders
        best_match_token_sort = process.extractOne(
            normalized_pii, meaningful_employees, scorer=fuzz.token_sort_ratio
        )
        
        if best_match_token_sort and best_match_token_sort[1] >= 85:
            matched_name = best_match_token_sort[0]
            matched_words = matched_name.split()
            
            if len(matched_words) < 2:
                logging.debug(f"[NO] Token_sort rejected: '{matched_name}' has only {len(matched_words)} words")
            else:
                emp_first = matched_words[0]
                emp_last = matched_words[-1]
                
                first_similarity = difflib.SequenceMatcher(None, pii_first.lower(), emp_first.lower()).ratio()
                last_similarity = difflib.SequenceMatcher(None, pii_last.lower(), emp_last.lower()).ratio()
                
                logging.debug(f"Token_sort strict validation: first {first_similarity*100:.0f}%, last {last_similarity*100:.0f}%")
                
                if first_similarity >= 0.80 and last_similarity >= 0.80:
                    fuzzy_results.append(("token_sort", best_match_token_sort[1], matched_name))
                    logging.debug(f"[YES] Token_sort PASSED strict first+last validation")
                else:
                    logging.debug(f"[NO] Token_sort FAILED strict validation")
        
        # Partial ratio - good for substring matches
        best_match_partial = process.extractOne(
            normalized_pii, meaningful_employees, scorer=fuzz.partial_ratio
        )
        
        if best_match_partial and best_match_partial[1] >= 90:
            matched_name = best_match_partial[0]
            matched_words = matched_name.split()
            
            if len(matched_words) < 2:
                logging.debug(f"[NO] Partial rejected: '{matched_name}' has only {len(matched_words)} words")
            else:
                emp_first = matched_words[0]
                emp_last = matched_words[-1]
                
                first_similarity = difflib.SequenceMatcher(None, pii_first.lower(), emp_first.lower()).ratio()
                last_similarity = difflib.SequenceMatcher(None, pii_last.lower(), emp_last.lower()).ratio()
                
                logging.debug(f"Partial strict validation: first {first_similarity*100:.0f}%, last {last_similarity*100:.0f}%")
                
                if first_similarity >= 0.80 and last_similarity >= 0.80:
                    fuzzy_results.append(("partial", best_match_partial[1], matched_name))
                    logging.debug(f"[YES] Partial PASSED strict first+last validation")
                else:
                    logging.debug(f"[NO] Partial FAILED strict validation")
        
        if fuzzy_results:
            best_result = max(fuzzy_results, key=lambda x: x[1])
            matched_employee_name = best_result[2]
            
            logging.info(f"[YES] FuzzyWuzzy EMPLOYEE MATCH (strict first+last name validation):")
            logging.info(f"    PII detected: '{normalized_pii}'")
            logging.info(f"    Matched employee: '{matched_employee_name}'")
            logging.info(f"    Method: {best_result[0].upper()}")
            logging.info(f"    Confidence: {best_result[1]}%")
            return "Yes"
        else:
            logging.debug(f"[NO] FuzzyWuzzy: No matches passed strict first+last name validation")
            return self._enhanced_partial_matching(normalized_pii, employee_names)
    
    def _fuzzy_employee_check_difflib(self, normalized_pii: str, employee_names: set) -> str:
        """
        Difflib-based employee matching fallback when FuzzyWuzzy is unavailable.
        
        This function uses Python's built-in difflib library for fuzzy string matching
        when FuzzyWuzzy cannot be imported. It provides basic fuzzy matching capabilities
        with a focus on overall string similarity.
        
        Uses difflib.get_close_matches() with:
        - Cutoff threshold: 75% similarity (balanced for OCR errors)
        - Returns top 3 matches for comparison
        - Calculates exact similarity ratio for logging
        
        Args:
            normalized_pii (str): Normalized PII value (lowercase, stripped)
            employee_names (set): Set of normalized employee names
            
        Returns:
            str: "Yes" if match found above 75% threshold, otherwise calls enhanced partial matching
            
        Examples:
            >>> # Simple similarity matching
            >>> normalized_pii = "gabriel moreau"
            >>> employee_names = {"gabriel moreau", "gabriela moreau", "miguel torres"}
            >>> result = self._fuzzy_employee_check_difflib(normalized_pii, employee_names)
            >>> result
            "Yes"  # Exact match: 100% similarity
            
            >>> # Handles minor OCR errors
            >>> normalized_pii = "gabriel moriau"  # 'e' -> 'i' OCR error
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}
            >>> result = self._fuzzy_employee_check_difflib(normalized_pii, employee_names)
            >>> result
            "Yes"  # High similarity: ~92% match
            
            >>> # Gender variation handling
            >>> normalized_pii = "gabriel moreau"
            >>> employee_names = {"gabriela fernanda moreau", "carlos ruiz"}
            >>> result = self._fuzzy_employee_check_difflib(normalized_pii, employee_names)
            >>> result
            "Yes"  # Partial similarity: ~80% match
            
            >>> # Below threshold, fallback to enhanced partial matching
            >>> normalized_pii = "completely different"
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}
            >>> result = self._fuzzy_employee_check_difflib(normalized_pii, employee_names)
            >>> # Returns result from _enhanced_partial_matching()
            
        Performance:
            - Uses built-in Python library (no external dependencies)
            - Efficient for medium-sized employee databases
            - Less sophisticated than FuzzyWuzzy but reliable fallback
            
        Note:
            This is the primary fallback when FuzzyWuzzy installation fails.
            Provides reasonable fuzzy matching for most common OCR scenarios.
        """
        import difflib
        
        employee_list = list(employee_names)
        
        # Use difflib.get_close_matches for fuzzy matching
        close_matches = difflib.get_close_matches(
            normalized_pii, employee_list, n=3, cutoff=0.75  # 75% similarity
        )
        
        if close_matches:
            best_match = close_matches[0]
            # Calculate similarity ratio
            similarity = difflib.SequenceMatcher(None, normalized_pii, best_match).ratio()
            logging.info(f"Difflib match: '{normalized_pii}' -> '{best_match}' (score: {similarity:.2%})")
            return "Yes"
        
        return self._enhanced_partial_matching(normalized_pii, employee_names)
    
    def _enhanced_partial_matching(self, normalized_pii: str, employee_names: set) -> str:
        """
        Advanced partial matching with STRICT 2+ word minimum requirement and multiple strategies for handling OCR errors.
        
        FIXED: Now only matches against employee names with 2+ words to prevent false positives.
        
        This function implements sophisticated matching strategies designed specifically for OCR-corrupted
        text and various name presentation formats. It uses multiple approaches to handle different
        types of matching challenges that simple fuzzy matching might miss.
        
        Matching Strategies:
        1. Standard Word Matching: Match 70% of meaningful words with 80% similarity each
        2. First+Last Name Priority: Focus on first and last names (80% threshold each)
        3. OCR Error Tolerance: Ignore problematic last words, match first two words
        4. Single Word Matching: Handle single names with 85% similarity (DISABLED - requires 2+ words)
        5. First+Last Combinations: Create and match "first last" patterns
        
        Common Words Filtering:
        Excludes common connectors: 'de', 'del', 'la', 'las', 'los', 'y', 'e', 'da', 'do', 'dos', 'das', 'von', 'van'
        
        Args:
            normalized_pii (str): Normalized PII value (lowercase, stripped)
            employee_names (set): Set of normalized employee names and variations
            
        Returns:
            str: "Yes" if any strategy finds a match, "No" if no matches found
            
        Examples:
            >>> # Strategy 1: Standard word matching (70% of words match at 80% similarity)
            >>> normalized_pii = "andres mauricio morales"
            >>> employee_names = {"andres mauricio morales perez", "maria rodriguez"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # 3/3 words match perfectly (100% match rate)
            
            >>> # Strategy 2: First+Last name priority (handles middle name issues)
            >>> normalized_pii = "gabriel moreau"  # Missing middle name
            >>> employee_names = {"gabriel fernando moreau", "carlos ruiz"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # first: "gabriel"=100%, last: "moreau"=100%
            
            >>> # Strategy 3: OCR error tolerance (ignores corrupted last word)
            >>> normalized_pii = "andres mauricio xyzabc"  # Last word corrupted by OCR
            >>> employee_names = {"andres mauricio morales", "maria rodriguez"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # First 2 words match: "andres" + "mauricio"
            
            >>> # Strategy 4: Single word matching
            >>> normalized_pii = "gabriela"
            >>> employee_names = {"gabriela fernanda moreau", "carlos ruiz"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # Single word matches at 85%+ similarity
            
            >>> # Strategy 5: First+Last combinations
            >>> normalized_pii = "gabriel fernando moreau"
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}  # Missing middle name in DB
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # "gabriel moreau" combo matches "gabriel moreau" at 85%+
            
            >>> # No match scenario
            >>> normalized_pii = "completely unknown person"
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "No"  # No strategy finds adequate matches
            
        Real-World OCR Scenarios:
            >>> # Handle OCR character substitutions
            >>> normalized_pii = "gabrlel moriau"  # 'i'->'l', 'e'->'i' OCR errors
            >>> employee_names = {"gabriel moreau"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # Individual word similarities above thresholds
            
            >>> # Handle missing/extra middle names
            >>> normalized_pii = "maria rodriguez"
            >>> employee_names = {"maria elena rodriguez gutierrez"}
            >>> result = self._enhanced_partial_matching(normalized_pii, employee_names)
            >>> result
            "Yes"  # First+Last strategy: "maria" + "rodriguez"
            
        Performance Considerations:
            - Processes meaningful words only (length >= 2, excludes common words)
            - Uses difflib for individual word comparisons (built-in, reliable)
            - Multiple strategies ensure high recall while maintaining precision
            - Detailed logging for debugging and audit trails
            
        Thresholds Explanation:
            - 70% word match rate: Balanced for partial names and OCR errors
            - 80% individual word similarity: Handles minor OCR character errors
            - 85% single word/combo similarity: Stricter for shorter matches
        """
        import difflib
        
        pii_words = normalized_pii.split()
        common_words = {'de', 'del', 'la', 'las', 'los', 'y', 'e', 'da', 'do', 'dos', 'das', 'von', 'van'}
        
        # Remove common words but keep meaningful parts
        meaningful_pii_words = [word for word in pii_words if word not in common_words and len(word) >= 2]
        
        # IMPORTANT: Filter employee names to ONLY 2+ word names (changed from 3+ to support "Gabriel Moreau" format)
        meaningful_employees = [name for name in employee_names if len(name.split()) >= 2]
        
        if not meaningful_employees:
            logging.debug(f"No meaningful employee names (2+ words) in database for partial matching")
            return "No"
        
        if len(meaningful_pii_words) >= 2:  # At least 2 meaningful words in PII
            for employee_name in meaningful_employees:
                employee_words = employee_name.split()
                meaningful_employee_words = [word for word in employee_words if word not in common_words and len(word) >= 2]
                
                # ADDITIONAL CHECK: Ensure employee name still has 2+ meaningful words
                if len(meaningful_employee_words) < 2:
                    continue
                
                # Strategy 1: Standard word matching with 70% THRESHOLD
                matches = 0
                total_pii_words = len(meaningful_pii_words)
                matched_words = []
                
                for pii_word in meaningful_pii_words:
                    # Use difflib to find similar words
                    word_matches = difflib.get_close_matches(pii_word, meaningful_employee_words, n=1, cutoff=0.8)
                    if word_matches:
                        matches += 1
                        matched_words.append(f"{pii_word}≈{word_matches[0]}")
                
                # Calculate match percentage
                match_percentage = matches / total_pii_words if total_pii_words > 0 else 0
                
                # REQUIRE: 70% match rate (for 2-word names: both must match)
                meets_percentage_threshold = match_percentage >= 0.7
                
                if meets_percentage_threshold:
                    # ENHANCED LOGGING: Show matched employee name
                    logging.info(f"[OK] PARTIAL EMPLOYEE MATCH (2+ word requirement):")
                    logging.info(f"    PII detected: '{normalized_pii}'")
                    logging.info(f"    Matched employee: '{employee_name}'")
                    logging.info(f"    Matched words: {matches}/{total_pii_words} ({match_percentage*100:.0f}%)")
                    logging.info(f"    Word matches: {', '.join(matched_words)}")
                    return "Yes"
                
                # Strategy 2: First + Last name priority matching (supports 2+ word names)
                if len(meaningful_pii_words) >= 2 and len(meaningful_employee_words) >= 2:
                    pii_first = meaningful_pii_words[0]
                    pii_last = meaningful_pii_words[-1]
                    emp_first = meaningful_employee_words[0]
                    emp_last = meaningful_employee_words[-1]
                    
                    # Check if first and last names are similar
                    first_similarity = difflib.SequenceMatcher(None, pii_first, emp_first).ratio()
                    last_similarity = difflib.SequenceMatcher(None, pii_last, emp_last).ratio()
                    
                    # If first and last names are very similar (works for 2-word names like "Gabriel Moreau")
                    if first_similarity >= 0.8 and last_similarity >= 0.8:
                        # ENHANCED LOGGING: Show matched employee name
                        logging.info(f"[OK] FIRST-LAST EMPLOYEE MATCH (2+ word requirement, strict validation):")
                        logging.info(f"    PII detected: '{normalized_pii}'")
                        logging.info(f"    Matched employee: '{employee_name}'")
                        logging.info(f"    First name similarity: {first_similarity*100:.0f}%")
                        logging.info(f"    Last name similarity: {last_similarity*100:.0f}%")
                        return "Yes"
                
                # Strategy 3: First-three-words matching (for 3+ word names with OCR errors in last word)
                if len(meaningful_pii_words) >= 3 and len(meaningful_employee_words) >= 3:
                    # Check if first 3 words match well, ignore the problematic last word
                    first_three_matches = 0
                    matched_first_words = []
                    for i in range(min(3, len(meaningful_pii_words))):
                        pii_word = meaningful_pii_words[i]
                        word_matches = difflib.get_close_matches(pii_word, meaningful_employee_words, n=1, cutoff=0.8)
                        if word_matches:
                            first_three_matches += 1
                            matched_first_words.append(f"{pii_word}≈{word_matches[0]}")
                    
                    if first_three_matches >= 3:  # All first three words match
                        # ENHANCED LOGGING: Show matched employee name
                        logging.info(f"[OK] FIRST-THREE-WORDS EMPLOYEE MATCH (3+ word names, ignoring OCR errors):")
                        logging.info(f"    PII detected: '{normalized_pii}'")
                        logging.info(f"    Matched employee: '{employee_name}'")
                        logging.info(f"    First 3 words matched: {', '.join(matched_first_words)}")
                        return "Yes"
        
        # DISABLED: Single-word matching to prevent false positives
        # Single words like "jacqueline" should NOT match full employee names
        elif len(meaningful_pii_words) < 2:
            logging.debug(f"[NO] Insufficient words '{normalized_pii}' ({len(meaningful_pii_words)} words) - requires 2+ words for valid employee match")
            return "No"
        
        # Strategy 4: First + middle + last combos (for 3+ word names with middle name variations)
        if len(pii_words) >= 3:
            # Try first + middle + last pattern
            first_middle_last = f"{pii_words[0]} {pii_words[1]} {pii_words[-1]}"
            
            # Create first+middle+last combinations from employee names (3+ words only)
            for employee_name in meaningful_employees:
                emp_words = employee_name.split()
                if len(emp_words) >= 3:
                    emp_first_middle_last = f"{emp_words[0]} {emp_words[1]} {emp_words[-1]}"
                    similarity = difflib.SequenceMatcher(None, first_middle_last, emp_first_middle_last).ratio()
                    if similarity >= 0.85:  # 85% similarity
                        # ENHANCED LOGGING: Show matched employee name
                        logging.info(f"[OK] FIRST-MIDDLE-LAST COMBO EMPLOYEE MATCH (3+ word names):")
                        logging.info(f"    PII pattern: '{first_middle_last}'")
                        logging.info(f"    Matched employee: '{employee_name}'")
                        logging.info(f"    Employee pattern: '{emp_first_middle_last}'")
                        logging.info(f"    Similarity: {similarity*100:.0f}%")
                        return "Yes"
        
        logging.debug(f"[NO] No valid employee match found for '{normalized_pii}' (2+ word requirement enforced)")
        return "No"
    
    def _basic_employee_check(self, pii_value: str, employee_names: set) -> str:
        """
        Basic employee checking fallback method with simple exact and subset matching.
        
        This is the most basic fallback when all other fuzzy matching methods are unavailable.
        It provides simple exact matching and basic word subset matching without similarity calculations.
        
        Matching Logic:
        1. Exact match: Direct string comparison after normalization
        2. Subset match: Check if all PII words appear in employee name (after removing common words)
        
        Common Words Filtered: 'de', 'del', 'la', 'las', 'los', 'y', 'e'
        
        Args:
            pii_value (str): Original PII value to check
            employee_names (set): Set of normalized employee names
            
        Returns:
            str: "Yes" if match found, "No" if no match, "N/A" if error occurred
            
        Examples:
            >>> # Exact match
            >>> pii_value = "Gabriel Moreau"
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}
            >>> result = self._basic_employee_check(pii_value, employee_names)
            >>> result
            "Yes"  # Exact match after normalization
            
            >>> # Subset matching
            >>> pii_value = "Gabriel Fernando"
            >>> employee_names = {"gabriel fernando moreau", "maria rodriguez"}
            >>> result = self._basic_employee_check(pii_value, employee_names)
            >>> result
            "Yes"  # {"gabriel", "fernando"} ⊆ {"gabriel", "fernando", "moreau"}
            
            >>> # Common words ignored
            >>> pii_value = "Gabriel de la Cruz"
            >>> employee_names = {"gabriel cruz martinez", "maria rodriguez"}
            >>> result = self._basic_employee_check(pii_value, employee_names)
            >>> result
            "Yes"  # {"gabriel", "cruz"} ⊆ {"gabriel", "cruz", "martinez"} (ignoring "de", "la")
            
            >>> # No match
            >>> pii_value = "Unknown Person"
            >>> employee_names = {"gabriel moreau", "maria rodriguez"}
            >>> result = self._basic_employee_check(pii_value, employee_names)
            >>> result
            "No"  # No exact match or subset relationship
            
            >>> # Error handling
            >>> pii_value = None
            >>> employee_names = {"gabriel moreau"}
            >>> result = self._basic_employee_check(pii_value, employee_names)
            >>> result
            "N/A"  # Error in processing
            
        Limitations:
            - No similarity calculations (strict matching only)
            - Cannot handle OCR errors or character substitutions
            - Limited to exact matches and simple word subset relationships
            - No threshold-based matching
            
        Use Cases:
            - Emergency fallback when all fuzzy matching libraries fail
            - Environments with strict dependency restrictions
            - Quick exact matching when performance is critical
            
        Note:
            This method is only used when both FuzzyWuzzy and difflib-based
            fuzzy matching are unavailable or have failed.
        """
        try:
            normalized_pii = str(pii_value).strip().lower()
            
            # Exact match
            if normalized_pii in employee_names:
                return "Yes"
            
            # Basic partial matching
            pii_words = set(normalized_pii.split())
            common_words = {'de', 'del', 'la', 'las', 'los', 'y', 'e'}
            pii_words = pii_words - common_words
            
            if len(pii_words) >= 2:
                for employee_name in employee_names:
                    employee_words = set(employee_name.split()) - common_words
                    if pii_words.issubset(employee_words):
                        return "Yes"
            
            return "No"
            
        except Exception as e:
            logging.warning(f"Error in basic employee check for '{pii_value}': {e}")
            return "N/A"

    def _create_employee_exclusion_mask(self, pii_df: pd.DataFrame) -> pd.Series:
        """
        Create a boolean mask for excluding employee names from PII results.
        
        Args:
            pii_df: DataFrame with PII detection results
            
        Returns:
            pd.Series: Boolean mask where True means exclude (is employee)
        """
        # Simple approach: check if Employee column exists and equals "Yes"
        if "Employee" in pii_df.columns:
            employee_mask = (pii_df["Employee"] == "Yes")
            excluded_count = employee_mask.sum()
            logging.info(f"Employee exclusion mask created: {excluded_count} employees identified for exclusion from {len(pii_df)} total entities")
            return employee_mask
        else:
            # Fallback: no employees to exclude
            logging.warning("Employee column not found in DataFrame, no employees will be excluded")
            return pd.Series([False] * len(pii_df), index=pii_df.index)

    def _create_exclusion_mask_for_resume(self, pii_df: pd.DataFrame) -> pd.Series:
        """
        Create a boolean mask for excluding specific values from resume report.
        Excludes values from exclusiones.xlsx for 'Secuencia numerica' PII type.
        
        Args:
            pii_df: DataFrame with PII detection results
            
        Returns:
            pd.Series: Boolean mask where True means exclude
        """
        try:
            exclusion_mask = pd.Series([False] * len(pii_df), index=pii_df.index)
            
            # Load exclusion lists
            exclusions = self._load_exclusion_lists()
            if not exclusions:
                logging.info("No exclusion values loaded, no additional exclusions will be applied")
                return exclusion_mask
            
            # Combine all exclusion values into one set for 'Secuencia numerica'
            all_exclusions = set()
            if 'Cuenta' in exclusions:
                all_exclusions.update(exclusions['Cuenta'])
            if 'Centro de Costo' in exclusions:
                all_exclusions.update(exclusions['Centro de Costo'])
            
            if not all_exclusions:
                logging.info("No exclusion values found in exclusiones.xlsx")
                return exclusion_mask
            
            excluded_count = 0
            # Check each row for exclusion values in 'Secuencia numerica' PII type
            # Handle different PII type variations
            numeric_sequence_types = {
                "NumberSequence", "Secuencia numerica", "SEQ_NUMBER", 
                "NUMBERSEQUENCE", "Sequence", "NumericSequence"
            }
            
            for idx, row in pii_df.iterrows():
                if row["PII_Type"] in numeric_sequence_types:
                    pii_value = str(row["PII_Value"]).strip()
                    if pii_value in all_exclusions:
                        exclusion_mask[idx] = True
                        excluded_count += 1
            
            logging.info(f"Exclusion mask created: {excluded_count} 'Secuencia numerica' values excluded from {len(pii_df)} total entities")
            if excluded_count > 0:
                logging.info(f"Sample excluded values: {list(all_exclusions)[:5]}...")
            
            return exclusion_mask
            
        except Exception as e:
            logging.error(f"Error creating exclusion mask: {e}")
            return pd.Series([False] * len(pii_df), index=pii_df.index)

    def _estimate_data_volume(self) -> Dict[str, Any]:
        """Estimate the volume of data to be processed"""
        stats = {
            "total_files": 0,
            "total_size_mb": 0.0,
            "image_files": 0,
            "text_files": 0,
            "pdf_files": 0,
            "folders": 0
        }
        
        try:
            input_path = os.path.abspath(self.input_dir)
            if not os.path.exists(input_path):
                logging.warning(f"Input directory not found: {input_path}")
                return stats
            
            for root, dirs, files in os.walk(input_path):
                # Count folders
                stats["folders"] += len(dirs)
                
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        file_size = os.path.getsize(file_path)
                        stats["total_size_mb"] += file_size / (1024 * 1024)
                        stats["total_files"] += 1
                        
                        # Categorize by extension
                        ext = os.path.splitext(file)[1].lower()
                        if ext in ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.gif']:
                            stats["image_files"] += 1
                        elif ext in ['.txt', '.md', '.log']:
                            stats["text_files"] += 1
                        elif ext == '.pdf':
                            stats["pdf_files"] += 1
                            
                    except (OSError, IOError) as e:
                        logging.warning(f"Could not get size for {file_path}: {e}")
                        
        except Exception as e:
            logging.error(f"Error estimating data volume: {e}")
            
        return stats

    def _merge_detection_results(self, regex_results: List[Dict[str, Any]], 
                                ml_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Merge results from regex and ML detectors based on strategy"""
        
        if self.hybrid_merge_strategy == "union":
            # Simple union of all results
            from src.utils.pii_utils import EntityUtils
            all_results = regex_results + ml_results
            
            # Ensure ALL processed folders are represented, even those with no PII
            # Get all folder names from results
            folders_with_results = set()
            for entity in all_results:
                if entity.get("Folder"):
                    folders_with_results.add(entity["Folder"])
            
            # Check if we need to add placeholder entities for folders with no results
            all_processed_folders = set()
            try:
                # Get all folders that were processed by scanning input directory
                if hasattr(self, 'input_dir') and os.path.exists(self.input_dir):
                    for folder_name in os.listdir(self.input_dir):
                        folder_path = os.path.join(self.input_dir, folder_name)
                        if os.path.isdir(folder_path) and not folder_name.startswith('.'):
                            all_processed_folders.add(folder_name)
                
                # Add placeholder entities for folders with no PII detection
                folders_without_results = all_processed_folders - folders_with_results
                for folder_name in folders_without_results:
                    placeholder_entity = {
                        "Detection_Method": "hybrid",
                        "File_Name": "No PII detected",
                        "Folder": folder_name,
                        "Source_Type": "folder_placeholder",
                        "PII_Type": "NO_PII_DETECTED",
                        "PII_Value": "No personal information found in this folder",
                        "Confidence": "N/A",
                        "start_pos": 0,
                        "end_pos": 0,
                        "Label": "NoDetection",
                        "Source": "hybrid_placeholder"
                    }
                    all_results.append(placeholder_entity)
                    logging.info(f"Added placeholder entity for folder with no PII: {folder_name}")
                    
            except Exception as e:
                logging.warning(f"Could not add placeholder entities: {e}")
            
            final_results = EntityUtils.dedupe_entities(all_results)
            logging.info(f"Union merge complete: {len(final_results)} total entities (including placeholders)")
            return final_results
        
        elif self.hybrid_merge_strategy == "intersection":
            # Only include entities found by both methods
            from src.utils.pii_utils import EntityUtils
            
            regex_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in regex_results}
            ml_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in ml_results}
            common_values = regex_values & ml_values
            
            results = []
            for result in regex_results + ml_results:
                norm_value = EntityUtils._norm_value_for_key(result.get("PII_Value", ""))
                if norm_value in common_values:
                    results.append(result)
            
            return EntityUtils.dedupe_entities(results)
        
        elif self.hybrid_merge_strategy == "ml_priority":
            # Prefer ML results, supplement with regex-only findings
            from src.utils.pii_utils import EntityUtils
            
            ml_values = {EntityUtils._norm_value_for_key(r.get("PII_Value", "")) for r in ml_results}
            
            results = list(ml_results)  # Start with all ML results
            
            # Add regex results that weren't found by ML
            for result in regex_results:
                norm_value = EntityUtils._norm_value_for_key(result.get("PII_Value", ""))
                if norm_value not in ml_values:
                    results.append(result)
            
            return EntityUtils.dedupe_entities(results)
        
        else:
            logging.warning(f"Unknown merge strategy: {self.hybrid_merge_strategy}, using union")
            return self._merge_detection_results(regex_results, ml_results)

    def _merge_detection_results_weighted(self, regex_results: List[Dict[str, Any]], 
                                          ml_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Advanced merge strategy using confidence-weighted scoring.
        
        This method intelligently combines regex and ML detections by:
        1. Assigning confidence scores to all detections
        2. Grouping overlapping/similar entities
        3. Selecting the highest-quality detection per entity
        4. Applying entity-type specific weighting
        
        Expected improvement: 15-25% better precision vs simple union/ml_priority
        """
        from src.utils.pii_utils import EntityUtils
        
        logging.info("=" * 60)
        logging.info("STARTING CONFIDENCE-WEIGHTED MERGE")
        logging.info(f"Input: {len(regex_results)} regex + {len(ml_results)} ML detections")
        
        # Step 1: Normalize and score all entities
        scored_entities = []
        
        # Entity type weights (higher = more trustworthy)
        entity_weights = {
            "EMAIL": {"regex": 0.95, "ml": 0.85},  # Regex excellent for emails
            "RUT": {"regex": 0.90, "ml": 0.75},     # Regex strong for RUT patterns
            "PHONE": {"regex": 0.85, "ml": 0.80},   # Both good for phones
            "NAME": {"regex": 0.60, "ml": 0.90},    # ML superior for names
            "LOCATION": {"regex": 0.50, "ml": 0.85}, # ML better for locations
            "ORGANIZATION": {"regex": 0.50, "ml": 0.85}, # ML better for orgs
            "DEFAULT": {"regex": 0.70, "ml": 0.80}  # Default weights
        }
        
        # Process regex results
        for entity in regex_results:
            pii_type = entity.get("PII_Type", "UNKNOWN").upper()
            confidence_str = entity.get("Confidence", "0.7")
            
            # Parse confidence (handle "High", numeric strings, etc.)
            if isinstance(confidence_str, str):
                if confidence_str.lower() == "high":
                    base_confidence = 0.9
                elif confidence_str.lower() == "medium":
                    base_confidence = 0.7
                elif confidence_str.lower() == "low":
                    base_confidence = 0.5
                else:
                    try:
                        base_confidence = float(confidence_str)
                    except:
                        base_confidence = 0.7
            else:
                base_confidence = float(confidence_str) if confidence_str else 0.7
            
            # Apply entity-type weight
            type_key = pii_type if pii_type in entity_weights else "DEFAULT"
            type_weight = entity_weights[type_key]["regex"]
            
            final_score = base_confidence * type_weight
            
            scored_entity = entity.copy()
            scored_entity["_weighted_score"] = final_score
            scored_entity["_source_method"] = "regex"
            scored_entity["_original_confidence"] = confidence_str
            scored_entities.append(scored_entity)
        
        # Process ML results
        for entity in ml_results:
            pii_type = entity.get("PII_Type", "UNKNOWN").upper()
            confidence_str = entity.get("Confidence", "0.8")
            
            # Parse confidence
            if isinstance(confidence_str, str):
                try:
                    base_confidence = float(confidence_str)
                except:
                    base_confidence = 0.8
            else:
                base_confidence = float(confidence_str) if confidence_str else 0.8
            
            # Apply entity-type weight
            type_key = pii_type if pii_type in entity_weights else "DEFAULT"
            type_weight = entity_weights[type_key]["ml"]
            
            final_score = base_confidence * type_weight
            
            scored_entity = entity.copy()
            scored_entity["_weighted_score"] = final_score
            scored_entity["_source_method"] = "ml"
            scored_entity["_original_confidence"] = confidence_str
            scored_entities.append(scored_entity)
        
        logging.info(f"Scored {len(scored_entities)} total entities")
        
        # Step 2: Group overlapping/duplicate entities
        entity_groups = []
        used_indices = set()
        
        for i, entity1 in enumerate(scored_entities):
            if i in used_indices:
                continue
            
            # Start new group with this entity
            group = [entity1]
            used_indices.add(i)
            
            norm_value1 = EntityUtils._norm_value_for_key(entity1.get("PII_Value", ""))
            pii_type1 = entity1.get("PII_Type", "")
            
            # Find similar entities
            for j, entity2 in enumerate(scored_entities):
                if j <= i or j in used_indices:
                    continue
                
                norm_value2 = EntityUtils._norm_value_for_key(entity2.get("PII_Value", ""))
                pii_type2 = entity2.get("PII_Type", "")
                
                # Group if: same type AND (exact match OR high similarity)
                if pii_type1 == pii_type2:
                    if norm_value1 == norm_value2:
                        group.append(entity2)
                        used_indices.add(j)
                    elif len(norm_value1) > 3 and len(norm_value2) > 3:
                        # Check substring overlap for similar entities
                        if norm_value1 in norm_value2 or norm_value2 in norm_value1:
                            group.append(entity2)
                            used_indices.add(j)
            
            entity_groups.append(group)
        
        logging.info(f"Grouped into {len(entity_groups)} unique entity groups")
        
        # Step 3: Select best entity from each group
        final_results = []
        ml_primary_count = 0
        regex_primary_count = 0
        
        for group in entity_groups:
            if len(group) == 1:
                # Only one detection, keep it
                best_entity = group[0]
            else:
                # Multiple detections, choose highest score
                best_entity = max(group, key=lambda e: e["_weighted_score"])
                
                logging.debug(f"Group of {len(group)} for '{best_entity.get('PII_Value', '')}': "
                            f"selected {best_entity['_source_method']} "
                            f"(score: {best_entity['_weighted_score']:.3f})")
            
            # Track source method statistics
            if best_entity["_source_method"] == "ml":
                ml_primary_count += 1
            else:
                regex_primary_count += 1
            
            # Clean up temporary fields
            result = best_entity.copy()
            result.pop("_weighted_score", None)
            result.pop("_source_method", None)
            result.pop("_original_confidence", None)
            
            # Update Detection_Method to reflect hybrid weighted merge
            result["Detection_Method"] = f"hybrid_weighted ({best_entity['_source_method']})"
            
            final_results.append(result)
        
        # Step 4: Add placeholder entities for folders with no PII
        all_processed_folders = set()
        folders_with_results = {e.get("Folder") for e in final_results if e.get("Folder")}
        
        try:
            if hasattr(self, 'input_dir') and os.path.exists(self.input_dir):
                for folder_name in os.listdir(self.input_dir):
                    folder_path = os.path.join(self.input_dir, folder_name)
                    if os.path.isdir(folder_path) and not folder_name.startswith('.'):
                        all_processed_folders.add(folder_name)
            
            folders_without_results = all_processed_folders - folders_with_results
            for folder_name in folders_without_results:
                placeholder_entity = {
                    "Detection_Method": "hybrid_weighted",
                    "File_Name": "No PII detected",
                    "Folder": folder_name,
                    "Source_Type": "folder_placeholder",
                    "PII_Type": "NO_PII_DETECTED",
                    "PII_Value": "No personal information found in this folder",
                    "Confidence": "N/A",
                    "start_pos": 0,
                    "end_pos": 0,
                    "Label": "NoDetection",
                    "Source": "hybrid_placeholder"
                }
                final_results.append(placeholder_entity)
                logging.debug(f"Added placeholder for folder: {folder_name}")
        
        except Exception as e:
            logging.warning(f"Could not add placeholder entities: {e}")
        
        # Final deduplication
        final_results = EntityUtils.dedupe_entities(final_results)
        
        logging.info("-" * 60)
        logging.info(f"MERGE COMPLETE: {len(final_results)} final entities")
        logging.info(f"  ML primary: {ml_primary_count} ({ml_primary_count/max(1,len(entity_groups))*100:.1f}%)")
        logging.info(f"  Regex primary: {regex_primary_count} ({regex_primary_count/max(1,len(entity_groups))*100:.1f}%)")
        logging.info("=" * 60)
        
        return final_results

    def _run_single_method(self, method: str) -> bool:
        """Run a single detection method"""
        try:
            if method == "regex":
                detector = self._get_regex_detector()
                logging.info("Running regex-based PII detection...")
                success = detector.run_flow()
                
                if success and self.send_email_on_completion:
                    # Find the generated Excel file
                    excel_files = [f for f in os.listdir(self.output_dir) 
                                 if f.startswith("OCR_PII_Analysis_REGEX") and f.endswith(".xlsx")]
                    if excel_files:
                        excel_path = os.path.join(self.output_dir, sorted(excel_files)[-1])
                        self._create_user_email_report(excel_path)
                
                return success
                
            elif method == "ml":
                detector = self._get_ml_detector()
                logging.info("Running ML-based PII detection...")
                success = detector.run_flow()
                
                if success and self.send_email_on_completion:
                    # Find the generated Excel file
                    excel_files = [f for f in os.listdir(self.output_dir) 
                                 if f.startswith("OCR_PII_Analysis_ML") and f.endswith(".xlsx")]
                    if excel_files:
                        excel_path = os.path.join(self.output_dir, sorted(excel_files)[-1])
                        self._create_user_email_report(excel_path)
                
                return success
                
            else:
                logging.error(f"Unknown detection method: {method}")
                return False
                
        except Exception as e:
            logging.error(f"Error running {method} detection: {e}")
            return False

    def _run_hybrid_method(self) -> bool:
        """Run both detection methods and merge results"""
        try:
            logging.info("Running hybrid PII detection (regex + ML)...")
            
            if self.enable_parallel:
                # TODO: Implement parallel execution
                logging.warning("Parallel execution not yet implemented, running sequentially")
            
            # Get folder filter if available
            folder_filter = getattr(self, '_folders_to_process', None)
            
            # Collect results from regex detection without generating Excel
            regex_detector = self._get_regex_detector()
            logging.info("Phase 1/2: Collecting regex detection results...")
            regex_results = regex_detector.collect_pii_results("regex", folder_filter=folder_filter)
            
            if not regex_results:
                logging.warning("No results from regex detection")
            else:
                logging.info(f"Regex detection found {len(regex_results)} PII entities")
            
            # Collect results from ML detection without generating Excel
            ml_detector = self._get_ml_detector()
            logging.info("Phase 2/2: Collecting ML detection results...")
            ml_results = ml_detector.collect_pii_results("ml", folder_filter=folder_filter)
            
            if not ml_results:
                logging.warning("No results from ML detection")
            else:
                logging.info(f"ML detection found {len(ml_results)} PII entities")
            
            # If neither method found anything, return False
            if not regex_results and not ml_results:
                logging.error("No PII entities found by either detection method")
                return False
            
            # Merge results according to configured strategy
            logging.info(f"Merging results using strategy: {self.hybrid_merge_strategy}")
            
            # Use confidence-weighted merge if enabled, otherwise use traditional merge
            if self.use_weighted_merge:
                logging.info("Using confidence-weighted merge (advanced)")
                combined_results = self._merge_detection_results_weighted(regex_results, ml_results)
            else:
                logging.info("Using traditional merge strategy")
                combined_results = self._merge_detection_results(regex_results, ml_results)
            
            logging.info(f"Combined results: {len(combined_results)} PII entities after merge")
            
            # Initialize metadata path for version control in hybrid report
            self._initialize_metadata_path()
            self.update_metadata_with_version_control()
            
            # Generate single Excel report with combined results
            logging.info("Generating hybrid Excel report...")
            excel_path = self.create_hybrid_excel_report(
                regex_results, ml_results, combined_results, self.hybrid_merge_strategy
            )
            
            if not excel_path:
                logging.error("Failed to generate hybrid Excel report")
                return False
            
            # Generate hybrid summary JSON
            self._generate_hybrid_summary_json(regex_results, ml_results, combined_results)
            
            # Send user email with simplified report
            if self.send_email_on_completion:
                email_success = self._create_user_email_report(excel_path)
                if not email_success:
                    logging.warning("Main report generated successfully but email sending failed")
            
            # Send resume email with files_metadata.xlsx integration
            resume_email_success = self._send_resume_email()
            if not resume_email_success:
                logging.warning("Resume email sending failed, but main process completed successfully")
            
            # Update metadata for processed folders
            folder_filter = getattr(self, '_folders_to_process', None)
            if folder_filter:
                logging.info("\n--- Updating metadata for processed folders ---")
                for folder_name in folder_filter:
                    # Count PII entities for this folder
                    folder_pii_count = sum(1 for r in combined_results if r.get('Folder') == folder_name)
                    self._update_processed_file_metadata(
                        filename=folder_name,
                        pii_count=folder_pii_count,
                        report_path=excel_path,
                        email_sent=self.send_email_on_completion
                    )
            
            logging.info("Hybrid detection completed successfully - single combined report generated")
            return True
            
        except Exception as e:
            logging.error(f"Error running hybrid detection: {e}")
            return False

    def _generate_hybrid_summary_json(self, regex_results: List[Dict[str, Any]], 
                                       ml_results: List[Dict[str, Any]], 
                                       combined_results: List[Dict[str, Any]]) -> None:
        """Generate a summary JSON comparing both detection methods with actual results"""
        try:
            # Analyze results by detection method
            regex_count = len(regex_results)
            ml_count = len(ml_results)
            combined_count = len(combined_results)
            
            # Count unique entities (entities that appear in both methods)
            regex_values = {f"{r.get('PII_Type', '')}_{r.get('PII_Value', '')}" for r in regex_results}
            ml_values = {f"{m.get('PII_Type', '')}_{m.get('PII_Value', '')}" for m in ml_results}
            common_entities = len(regex_values & ml_values)
            
            # Count by PII type
            regex_types = {}
            ml_types = {}
            combined_types = {}
            
            for result in regex_results:
                pii_type = result.get('PII_Type', 'Unknown')
                regex_types[pii_type] = regex_types.get(pii_type, 0) + 1
            
            for result in ml_results:
                pii_type = result.get('PII_Type', 'Unknown')
                ml_types[pii_type] = ml_types.get(pii_type, 0) + 1
                
            for result in combined_results:
                pii_type = result.get('PII_Type', 'Unknown')
                combined_types[pii_type] = combined_types.get(pii_type, 0) + 1
            
            summary = {
                "orchestrator": "S4PIIOrchestrator",
                "detection_mode": "hybrid",
                "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "merge_strategy": self.hybrid_merge_strategy,
                "results_summary": {
                    "regex_entities_found": regex_count,
                    "ml_entities_found": ml_count,
                    "combined_entities_final": combined_count,
                    "common_entities_both_methods": common_entities,
                    "regex_only_entities": regex_count - common_entities if common_entities <= regex_count else 0,
                    "ml_only_entities": ml_count - common_entities if common_entities <= ml_count else 0
                },
                "pii_type_breakdown": {
                    "regex_types": regex_types,
                    "ml_types": ml_types,
                    "combined_types": combined_types
                },
                "detection_methods": {
                    "regex_detection": {
                        "completed": True,
                        "method": "pattern_matching",
                        "entities_found": regex_count
                    },
                    "ml_detection": {
                        "completed": True,
                        "method": "machine_learning",
                        "entities_found": ml_count
                    }
                },
                "data_volume": self._estimate_data_volume(),
                "output_directory": self.output_dir,
                "excel_report_generated": True,
                "excel_report_type": "single_hybrid_file"
            }
            
            # Save hybrid summary
            summary_path = os.path.join(self.process_data_dir, "S3_hybrid_summary.json")
            save_json_file(summary, summary_path)
            logging.info(f"Hybrid detection summary saved to: {summary_path}")
            logging.info(f"Summary: Regex={regex_count}, ML={ml_count}, Combined={combined_count}, Common={common_entities}")
            
        except Exception as e:
            logging.error(f"Error generating hybrid summary JSON: {e}")

    def _generate_hybrid_summary(self, regex_detector, ml_detector) -> None:
        """Legacy method - kept for compatibility"""
        logging.warning("Using legacy _generate_hybrid_summary method - this should be replaced with _generate_hybrid_summary_json")

    def create_hybrid_excel_report(self, regex_results: List[Dict[str, Any]], 
                                   ml_results: List[Dict[str, Any]], 
                                   combined_results: List[Dict[str, Any]], 
                                   merge_strategy: str) -> str:
        """
        Generate hybrid Excel report with combined results from both detection methods.
        
        IMPORTANT: This hybrid report INCLUDES employees for complete audit trail visibility.
        Employee exclusion is applied only to:
        - Folder-specific Excel reports (for email distribution)
        - Filtered user reports
        - Resume reports
        
        Args:
            regex_results: Results from regex detection
            ml_results: Results from ML detection  
            combined_results: Merged results from both methods
            merge_strategy: Strategy used for merging (union, intersection, ml_priority)
            
        Returns:
            str: Path to created hybrid Excel report file
        """
        import pandas as pd
        import datetime as dt
        from src.utils.pii_utils import extract_page_number, get_sensitivity_level
        
        def extract_status_from_folder(folder_name: str) -> str:
            """Extract status from folder name by splitting on '__'"""
            try:
                if not folder_name or folder_name.strip() == "":
                    return "unknown"
                
                # Split by '__' and get the last part
                parts = folder_name.split('__')
                if len(parts) > 1:
                    status = parts[-1].strip()
                    # Clean up common suffixes and normalize
                    if status.lower() in ['modificado', 'nuevo_archivo']:
                        return status.lower()
                    return status
                else:
                    return "sin_cambios"  # No suffix found
            except Exception as e:
                logging.warning(f"Error extracting status from folder '{folder_name}': {e}")
                return "unknown"
            
        def clean_folder_name(folder_name: str) -> str:
            """Clean folder name by removing suffix after '__'"""
            try:
                if not folder_name or folder_name.strip() == "":
                    return folder_name
                
                # Split by '__' and get the first part (clean name)
                parts = folder_name.split('__')
                return parts[0].strip()
                
            except Exception as e:
                logging.warning(f"Error cleaning folder name '{folder_name}': {e}")
                return folder_name
            
        
        try:
            if not combined_results:
                logging.warning("No PII entities to report in hybrid mode")
                return None
            
            # Load employee list once at the beginning
            employee_names = self._load_employee_list()
            identifier_map = self._load_employee_identifiers()
            
            logging.info(f"Loaded {len(employee_names)} employee name variations for matching")
            logging.info(f"Loaded {len(identifier_map)} employee identifiers (RUTs) for matching")
            
            # Create Excel rows from combined entities
            pii_rows = []
            for pii_entity in combined_results:
                # Step 1: Clean the detected entity using ExclusionLists
                original_value = pii_entity.get("PII_Value", "")
                entity_type = pii_entity.get("PII_Type", "")
                
                cleaned_value = self.clean_detected_entity(original_value, entity_type)
                if cleaned_value is None:
                    # Entity was excluded by cleaning process
                    continue
                
                # Step 1.5: Additional validation of cleaned entity
                if not self.validate_cleaned_entity(cleaned_value, entity_type):
                    logging.info(f"VALIDATION FAILED: '{cleaned_value}' (from '{original_value}') failed additional quality checks")
                    continue
                
                # Step 1.6: Strip leading city names from person name types
                name_types = {"Person", "PatronymicName", "SurnameFirst_AllCaps", 
                            "ChileanFullName", "CompoundSpanishName", "SpanishName",
                            "ContextualPersonName", "TitledPersonName", "Chileanvariation", "DoubleSurnameWithFirstNames"}
                
                if entity_type in name_types:
                    cleaned_value = self._strip_leading_city(cleaned_value)
                    logging.debug(f"Applied city stripping to {entity_type}: '{original_value}' -> '{cleaned_value}'")
                
                # Update entity with cleaned value
                pii_entity["PII_Value"] = cleaned_value
                
                # Get page number from filename
                filename = pii_entity.get("File_Name", "unknown")
                page_number = extract_page_number(filename)
                sensitivity_level = get_sensitivity_level(pii_entity["PII_Type"])
                
                # Extract status from folder name
                folder_name_raw = pii_entity.get("Folder", "")
                status_file = extract_status_from_folder(folder_name_raw)
                folder_name_clean = clean_folder_name(folder_name_raw)
                
                # Step 2: Check if cleaned PII value is an employee (for name-related PII types)
                employee_status = "N/A"
                name_pii_types = {
                    "CUSTOMER_NAME", "SpanishName", "ContextualPersonName", 
                    "TitledPersonName", "ChileanFullName", "CompoundSpanishName", 
                    "PatronymicName", "Name_With_Role",'Person',"Chileanvariation",
                    "DoubleSurnameWithFirstNames",
                    # Spanish PII type names
                    "Nombre de cliente", "Nombre", "Nombre completo", "Nombre personal",
                    "Cliente", "Persona", "Individuo"
                }
                
                # Define sequence/ID types for identifier checking
                sequence_pii_types = {
                    "RUT", "SEQ_NUMBER", "NumberSequence", "NUMBERSEQUENCE",
                    "Secuencia numerica", "IDENTIFICATION", "ID", "PartialRUT", "RUTPartial"
                }
                
                # Check name-based PII types
                if pii_entity["PII_Type"] in name_pii_types:
                    employee_status = self._check_if_employee(
                        pii_value=cleaned_value, 
                        employee_names=employee_names,
                        pii_type=pii_entity["PII_Type"],
                        identifier_map=identifier_map
                    )
                    
                    # For HYBRID report: Include employees but mark them clearly
                    # Other reports will filter employees later using the Employee column
                    if employee_status == "Yes":
                        logging.info(f"EMPLOYEE NAME DETECTED: '{cleaned_value}' identified as employee, including in hybrid report with Employee=Yes flag")
                
                # Check RUT/identifier-based PII types
                elif pii_entity["PII_Type"] in sequence_pii_types and identifier_map:
                    employee_status = self._check_if_employee(
                        pii_value=cleaned_value,
                        employee_names=employee_names,
                        pii_type=pii_entity["PII_Type"],
                        identifier_map=identifier_map
                    )
                    if employee_status == "Yes":
                        logging.info(f"EMPLOYEE RUT DETECTED: '{cleaned_value}' identified as employee RUT, including in hybrid report with Employee=Yes flag")
                
                pii_rows.append({
                    "Report_Generated": dt.datetime.now().strftime("%d-%m-%Y"),  ## New field for report generation date
                    "File": filename,
                    "Folder": folder_name_clean,
                    "Status_file": status_file,
                    "Source_Type": pii_entity.get("Source_Type", "").replace("_", " ").title(),
                    "Page": page_number,
                    "PII_Type": pii_entity["PII_Type"],
                    "PII_Value": pii_entity["PII_Value"],
                    "PII_Length": len(pii_entity["PII_Value"]),
                    "Confidence_Score": pii_entity.get("Confidence", "N/A"),
                    "Detection_Method": pii_entity.get("Detection_Method", "unknown"),
                    "Source": pii_entity.get("Source", ""),
                    "Start_Position": pii_entity.get("start_pos", ""),
                    "End_Position": pii_entity.get("end_pos", ""),
                    "Sensitivity_Level": sensitivity_level,
                    "Pattern": pii_entity.get("pattern", ""),
                    "Label": pii_entity.get("Label", ""),
                    # "Original_Text": pii_entity.get("Original_Text", "")[:100] + "..." if len(pii_entity.get("Original_Text", "")) > 100 else pii_entity.get("Original_Text", ""),
                    "Original_Text": pii_entity.get("Original_Text", ""),
                    "Extraction_Confidence": pii_entity.get("Extraction_Confidence", "N/A"),
                    "Employee": employee_status  # NEW COLUMN
                })
            
            # Generate and log detailed exclusion statistics
            final_entities_with_values = [{"PII_Type": row["PII_Type"], "PII_Value": row["PII_Value"]} for row in pii_rows]
            exclusion_stats = self.get_exclusion_statistics(combined_results, final_entities_with_values)
            
            logging.info(f"EXCLUSION SUMMARY: {exclusion_stats.get('total_excluded', 0)}/{exclusion_stats.get('total_original', 0)} entities excluded ({exclusion_stats.get('overall_exclusion_rate', 0):.1f}% exclusion rate)")
            logging.info(f"FINAL ENTITY COUNT: {exclusion_stats.get('total_final', 0)} entities passed all cleaning and validation checks")
            
            # Log exclusion breakdown by PII type
            if self.debug_mode and exclusion_stats.get('exclusion_by_type'):
                logging.info("EXCLUSION BREAKDOWN BY PII TYPE:")
                for pii_type, type_stats in exclusion_stats['exclusion_by_type'].items():
                    if type_stats['excluded'] > 0:
                        logging.info(f"  {pii_type}: {type_stats['excluded']}/{type_stats['original']} excluded ({type_stats['exclusion_rate']:.1f}%)")
            
            # Create DataFrames
            pii_df = pd.DataFrame(pii_rows)
            
            # Add version control information from metadata
            pii_df = self._add_version_control_from_metadata(pii_df)
            
            # Generate summary statistics for hybrid mode
            hybrid_summary = self._generate_hybrid_summary_stats(pii_df, merge_strategy, regex_results, ml_results)
            summary_df = pd.DataFrame([hybrid_summary])
            
            # Generate output filename
            import os
            os.makedirs(self.output_dir, exist_ok=True)
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(self.output_dir, f"OCR_PII_Analysis_HYBRID_{timestamp}.xlsx")
            
            # Create Excel file
            with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
                summary_df.to_excel(writer, sheet_name="Hybrid_Summary", index=False)
                pii_df.to_excel(writer, sheet_name="Combined_PII_Results", index=False)
                
                # Create method breakdown sheets if we have multiple methods
                detection_methods = pii_df["Detection_Method"].unique()
                if len(detection_methods) > 1:
                    for method in detection_methods:
                        method_df = pii_df[pii_df["Detection_Method"] == method]
                        sheet_name = f"{method.upper()}_Results"[:31]  # Excel sheet name limit
                        method_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Format the sheets
                self._format_hybrid_excel_sheets(writer, pii_df, summary_df)
            
            logging.info(f"Hybrid Excel report created: {output_file}")
            logging.info(f"Report contains: {len(pii_df)} PII entities from {len(detection_methods)} detection method(s)")
            logging.info(f"Merge strategy used: {merge_strategy}")
            
            # Log status distribution for debugging
            status_counts = pii_df["Status_file"].value_counts().to_dict()
            logging.info(f"File status distribution: {status_counts}")
            
            return output_file
            
        except Exception as e:
            logging.error(f"Error creating hybrid Excel report: {e}")
            return None

    def _generate_hybrid_summary_stats(self, pii_df, merge_strategy: str, 
                                       regex_results: List[Dict], ml_results: List[Dict]) -> Dict[str, Any]:
        """Generate summary statistics for hybrid mode Excel report"""
        try:
            import datetime as dt
            
            # Count entities by detection method
            method_counts = pii_df["Detection_Method"].value_counts().to_dict()
            
            # Count by PII type
            pii_type_counts = pii_df["PII_Type"].value_counts().to_dict()
            
            # Count by source type
            source_type_counts = pii_df["Source_Type"].value_counts().to_dict()
            
            stats = {
                "Report_Generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Report_Type": "Hybrid Detection Analysis",
                "Merge_Strategy": merge_strategy,
                "Total_PII_Entities": len(pii_df),
                "Unique_Files_Processed": pii_df["File"].nunique(),
                "Detection_Methods_Used": ", ".join(method_counts.keys()),
                "Regex_Entities": len(regex_results),
                "ML_Entities": len(ml_results),
                "Combined_Entities": len(pii_df),
                "Most_Common_PII_Type": max(pii_type_counts.items(), key=lambda x: x[1])[0] if pii_type_counts else "None",
                "Image_OCR_Entities": source_type_counts.get("Image Ocr", 0),
                "Text_File_Entities": source_type_counts.get("Text File", 0),
                "Average_PII_Length": float(pii_df["PII_Length"].mean()) if not pii_df.empty else 0.0,
            }
            
            return stats
            
        except Exception as e:
            logging.error(f"Error generating hybrid summary stats: {e}")
            return {"Error": str(e)}

    def _format_hybrid_excel_sheets(self, writer, pii_df, summary_df):
        """Format the hybrid Excel report sheets"""
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
            
            # Format Combined_PII_Results sheet (always exists in hybrid reports)
            if "Combined_PII_Results" not in writer.sheets:
                logging.warning("Combined_PII_Results sheet not found in hybrid report")
                return
            
            pii_ws = writer.sheets["Combined_PII_Results"]
            logging.info("Formatting sheet: Combined_PII_Results")
                
                # Set column widths
            column_widths = {'A': 15, 'B': 20, 'C': 15, 'D': 15, 'E': 15, 'F': 30, 'G': 8, 'H': 15}
            for col, width in column_widths.items():
                pii_ws.column_dimensions[col].width = width
            
            # Auto-size columns based on content
            if isinstance(pii_df, pd.DataFrame) and not pii_df.empty:
                for idx, col in enumerate(pii_df.columns, start=1):
                    try:
                        max_cell = max((len(str(v)) for v in pii_df[col].fillna('')), default=0)
                    except Exception:
                        max_cell = 0
                    header_len = len(str(col))
                    calculated = max(header_len, max_cell) + 2  # padding
                    width = max(8, min(50, calculated))
                    col_letter = get_column_letter(idx)
                    pii_ws.column_dimensions[col_letter].width = width
            else:
                # Fallback sensible defaults if dataframe empty
                for i, col_letter in enumerate(list("ABCDEFGH"), start=1):
                    pii_ws.column_dimensions[col_letter].width = 15
            
            # Format headers - dark blue with white text
            header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
            for cell in pii_ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = header_fill_dark_blue
                cell.alignment = Alignment(horizontal="center")
            
            # Color code by file status
            status_colors = {
                "modificado": PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid"),      # Light yellow
                "nuevo_archivo": PatternFill(start_color="D5E8D4", end_color="D5E8D4", fill_type="solid"),  # Light green
                "sin_cambios": PatternFill(start_color="F8CECC", end_color="F8CECC", fill_type="solid"),    # Light red
            }
            
            # Apply status coloring if Status_file column exists
            if 'Status_file' in pii_df.columns or 'Estatus documento' in pii_df.columns:
                # Find the correct column index
                status_col_name = 'Estatus documento' if 'Estatus documento' in pii_df.columns else 'Status_file'
                status_col_idx = list(pii_df.columns).index(status_col_name) + 1
                
                for row_idx, row in enumerate(pii_ws.iter_rows(min_row=2, max_row=len(pii_df) + 1), 2):
                    if len(row) > status_col_idx - 1:
                        status_value = str(row[status_col_idx - 1].value).lower() if row[status_col_idx - 1].value else ""
                        fill_color = status_colors.get(status_value)
                        if fill_color:
                            for cell in row:
                                cell.fill = fill_color
            
            logging.info("✅ Sheet 'Combined_PII_Results' formatted successfully")
        
            # Format Summary Analysis sheet (same code as before)
            if "Summary_Analysis" in writer.sheets:
                summary_ws = writer.sheets["Summary_Analysis"]
                logging.info(f"Formatting sheet: Summary_Analysis")
                
                # Set column widths
                summary_ws.column_dimensions['A'].width = 25  # Category
                summary_ws.column_dimensions['B'].width = 30  # Metric
                summary_ws.column_dimensions['C'].width = 15  # Count
                summary_ws.column_dimensions['D'].width = 15  # Percentage
                
                # Format headers
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                category_fill_light = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
                header_font = Font(bold=True, color="FFFFFF")
                section_font = Font(bold=True, color="000000")
                
                for cell in summary_ws[1]:
                    cell.font = header_font
                    cell.fill = header_fill_dark_blue
                    cell.alignment = Alignment(horizontal="center")
                
                logging.info(f"✅ Sheet 'Summary_Analysis' formatted successfully")
                        
        except Exception as e:
            logging.error(f"Error formatting user Excel sheets: {e}")

    def _create_user_email_report(self, excel_file_path: str) -> bool:
        """
        Create and send simplified email reports for end users.
        Sends one email per folder with only files from that folder.
        
        Args:
            excel_file_path (str): Path to the main Excel report file
            
        Returns:
            bool: True if all emails sent successfully, False otherwise
        """
        try:
            logging.info(f"Email functionality called - enabled: {self.send_email_on_completion}")
            if not self.send_email_on_completion:
                logging.info("Email sending is disabled in configuration")
                return True
                
            if not os.path.exists(excel_file_path):
                logging.error(f"Excel file not found: {excel_file_path}")
                return False
            
            # Initialize metadata path early so folder reports can use version control
            self._initialize_metadata_path()
            
            # Update metadata with version control information before folder processing
            if hasattr(self, 'files_metadata_path') and self.files_metadata_path:
                logging.info("Updating metadata with version control for folder reports...")
                self.update_metadata_with_version_control()
            
            # Read the Combined_PII_Results sheet from Excel
            logging.info("Reading Excel file for email report...")
            try:
                pii_df = pd.read_excel(excel_file_path, sheet_name="Combined_PII_Results")
                logging.info(f"Loaded {len(pii_df)} PII entities from Excel")
            except Exception as e:
                logging.error(f"Error reading Excel file: {e}")
                return False
            
            # Get ALL unique folders from original data BEFORE filtering to ensure complete coverage
            all_unique_folders = pii_df['Folder'].unique()
            logging.info(f"Found {len(all_unique_folders)} total folders to process for emails (before filtering)")
            logging.info(f"Folders: {list(all_unique_folders)}")
            
            # Apply filtering for PII analysis but keep original folder list
            original_count = len(pii_df)
            
            # Create comprehensive filter for folder reports and emails:
            # 1. Exclude specified PII types
            # 2. Exclude specified sources  
            # 3. Exclude employees (Employee != "Yes")
            filtered_df = pii_df[
                ~pii_df["PII_Type"].isin(self.email_excluded_pii_types) &  # Exclude specified PII types
                ~pii_df["Source"].isin(self.email_excluded_sources) & # Exclude specified sources
                (pii_df["Employee"] != "Yes")]  # Exclude employees
            
            filtered_count = len(filtered_df)
            excluded_count = original_count - filtered_count
            employee_count = len(pii_df[pii_df["Employee"] == "Yes"])
            
            logging.info(f"Email filtering applied: {original_count} -> {filtered_count} entities")
            logging.info(f"  - Excluded by PII type: {len(pii_df[pii_df['PII_Type'].isin(self.email_excluded_pii_types)])}")
            logging.info(f"  - Excluded by source: {len(pii_df[pii_df['Source'].isin(self.email_excluded_sources)])}")
            logging.info(f"  - Excluded employees: {employee_count}")
            logging.info(f"  - Total excluded: {excluded_count}")
            
            logging.info(f"Email filtering: {excluded_count} entities excluded, {filtered_count} included")
            logging.info(f"Excluded PII types: {list(self.email_excluded_pii_types)}")
            
            # Continue with ALL folders regardless of filtering results
            unique_folders = all_unique_folders
            logging.info(f"Processing emails for ALL {len(unique_folders)} folders regardless of PII count")
            
            all_emails_sent = True
            
            self.lobs_founded = []
            
                # Process each folder separately - ALL folders receive emails
            for folder_name in unique_folders:
                try:
                    logging.info(f"Processing email for folder: {folder_name}")
                    
                    # Get original data for this folder (before filtering)
                    folder_original_df = pii_df[pii_df['Folder'] == folder_name].copy()
                    folder_original_count = len(folder_original_df)
                    
                    # Check if this folder has placeholder entities (NO_PII_DETECTED)
                    has_placeholder = any(row['PII_Type'] == 'NO_PII_DETECTED' for _, row in folder_original_df.iterrows())
                    
                    # Get real PII entities (exclude placeholders)
                    folder_real_pii = folder_original_df[folder_original_df['PII_Type'] != 'NO_PII_DETECTED'].copy()
                    real_pii_count = len(folder_real_pii)
                    
                    # Get filtered data for this folder (critical PII only)
                    folder_df = filtered_df[filtered_df['Folder'] == folder_name].copy()
                    folder_filtered_df = folder_df[folder_df['PII_Type'] != 'NO_PII_DETECTED'].copy()
                    folder_entity_count = len(folder_filtered_df)
                    
                    # Determine folder status
                    if folder_entity_count > 0: # Dataframe has critical PII
                        # Has critical PII after filtering
                        email_type = "critical"
                        entity_count_for_subject = folder_entity_count
                        subject_suffix = f"{entity_count_for_subject} Entidades PII Críticas"
                        folder_data_for_excel = folder_filtered_df
                        folder_data_for_stats = folder_filtered_df  # Use actual filtered data for statistics
                    # elif real_pii_count > 0:
                    #     # Has PII but filtered out as non-critical
                    #     email_type = "filtered"
                    #     entity_count_for_subject = real_pii_count
                    #     subject_suffix = f"Análisis Completado - {entity_count_for_subject} entidades no críticas"
                    #     folder_data_for_excel = folder_real_pii
                    else:
                        # No PII found (has placeholder or truly empty)
                        email_type = "clean"
                        entity_count_for_subject = 0
                        subject_suffix = 0 #"Sin PII Detectado"
                        
                        # Get real status from original folder data
                        real_status = 'sin_cambios'  # Default fallback
                        if 'Status_file' in folder_original_df.columns and len(folder_original_df) > 0:
                            # Get the most common status from the folder
                            status_series = folder_original_df['Status_file'].dropna()
                            if not status_series.empty:
                                real_status = status_series.mode()[0] if len(status_series.mode()) > 0 else status_series.iloc[0]
                                logging.info(f"Zero-PII folder: extracted real Status_file = '{real_status}' from original data")
                                
                        # Create minimal data for Excel with placeholder row (for user display)
                        folder_data_for_excel = pd.DataFrame({
                            'Folder': [folder_name],
                            'PII_Type': ['Sin detección'],
                            'PII_Value': ['No se detectaron entidades PII'],
                            'File': ['N/A'],
                            'Page': ['N/A'],
                            'Status_file': [real_status]  # FIXED: Use real status from folder data
                        })
                        
                        # CRITICAL FIX: Create EMPTY DataFrame for statistics calculation
                        # This ensures summary shows 0 entities, 0 files, "Sin detección" for PII type
                        folder_data_for_stats = pd.DataFrame(columns=folder_data_for_excel.columns)
                        logging.info(f"Zero-PII folder '{folder_name}': Created empty stats DataFrame (0 rows) for accurate summary")
                    
                    logging.info(f"Folder '{folder_name}': {real_pii_count} real entities, {folder_entity_count} critical entities, type: {email_type}, placeholder: {has_placeholder}")
                    
                    # Create folder-specific Excel report (uses placeholder DataFrame for display)
                    folder_excel_path = self._create_folder_specific_excel_report(
                        folder_data_for_excel, folder_name, excel_file_path, is_zero_pii=(email_type != "critical")
                    )
                    
                    if not folder_excel_path:
                        logging.error(f"Failed to create Excel report for folder: {folder_name}")
                        all_emails_sent = False
                        continue
                    
                    # Generate folder-specific summary statistics
                    # CRITICAL: Use empty DataFrame for zero-PII folders to show accurate counts (0 entities, 0 files)
                    if email_type == "clean":
                        folder_summary_stats = self._generate_folder_summary_stats(folder_data_for_stats, folder_name)
                        logging.info(f"Summary statistics for zero-PII folder '{folder_name}': Total entities = 0, Files = 0")
                    else:
                        folder_summary_stats = self._generate_folder_summary_stats(folder_data_for_excel, folder_name)
                    
                    # Create summary HTML table for email body
                    summary_html = df2html(folder_summary_stats)
                    
                    # Prepare email content with folder name
                    timestamp = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    email_filename = os.path.basename(folder_excel_path)
                    
                    # Email subject
                    subject = f"Reporte PII - Archivo: '{folder_name}' - {subject_suffix}"
                    
                    # MetLife Brand Bar Footer HTML
                    metlife_footer = """
                        <div style="background-color: #f8f9fa; padding: 20px 25px; text-align: center; border-top: 1px solid #e9ecef; margin-top: 30px;">
                            <p style="margin: 0 0 10px 0; font-size: 14px; color: #333333; font-weight: bold;">Sistema Automatizado de Análisis PII</p>
                            <p style="margin: 0; font-size: 12px; color: #666666;">Este es un reporte automatizado generado por el sistema de detección de información personal.</p>
                            <!-- MetLife Brand Bar -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 20px;">
                                <tr>
                                    <td style="background-color: #0066b3; height: 8px; width: 60%;"></td>
                                    <td style="background-color: #00a3e0; height: 8px; width: 10%;"></td>
                                    <td style="background-color: #c4d600; height: 8px; width: 25%;"></td>
                                    <td style="background-color: #0066b3; height: 8px; width: 5%;"></td>
                                </tr>
                            </table>
                        </div>
                    """
                    
                    # Create differentiated email body content based on email type
                    # Get header with embedded logo
                    email_header = self.template_manager.get_email_header_html()
                    
                    if email_type == "critical":
                        body = f"""
                        <html>
                        <body style="font-family: Arial, sans-serif; margin:0; padding:0;">
                            {email_header}
                            <div style="padding: 20px 25px;">
                                <h1 style="color: #d73027;">ALERTA: Resumen de Análisis de Detección PII - ENTIDADES CRÍTICAS DETECTADAS</h1>
                                <p><strong>ATENCIÓN:</strong> El análisis de detección de información personal (PII) ha identificado <strong>{entity_count_for_subject} entidades críticas</strong> en el archivo "{folder_name}".</p>
                                <p>Se requiere revisión inmediata de la información detectada. A continuación se presenta un resumen detallado:</p>
                                {summary_html}
                                <p style="color: #d73027; font-weight: bold;">IMPORTANTE: Esta información contiene datos sensibles que requieren manejo confidencial.</p>
                            </div>
                            {metlife_footer}
                        </body>
                        </html>
                        """
                    elif email_type == "filtered":
                        body = f"""
                        <html>
                        <body style="font-family: Arial, sans-serif; margin:0; padding:0;">
                            {email_header}
                            <div style="padding: 20px 25px;">
                                <h1 style="color: #2c7fb8;">ℹ️ Resumen de Análisis de Detección PII - ENTIDADES NO CRÍTICAS</h1>
                                <p>El análisis de detección de información personal (PII) ha sido completado para el archivo "{folder_name}".</p>
                                <p><strong>Resultado:</strong> Se detectaron {entity_count_for_subject} entidades clasificadas como no críticas o de bajo riesgo.</p>
                                <p>A continuación se presenta un resumen del análisis realizado:</p>
                                {summary_html}
                                <p style="color: #2c7fb8; font-weight: bold;">INFORMACIÓN: Entidades de bajo riesgo - Revisar según políticas internas.</p>
                            </div>
                            {metlife_footer}
                        </body>
                        </html>
                        """
                    else:  # clean
                        body = f"""
                        <html>
                        <body style="font-family: Arial, sans-serif; margin:0; padding:0;">
                            {email_header}
                            <div style="padding: 20px 25px;">
                                <h1 style="color: #2c7fb8;">SIN PII DETECTADOS - Resumen de Análisis de Detección PII </h1>
                                <p>El análisis de detección de información personal (PII) ha sido completado exitosamente para el archivo "{folder_name}".</p>
                                <p><strong>Resultado:</strong> No se detectaron entidades PII en este documento.</p>
                                <p>A continuación se presenta un resumen del análisis realizado:</p>
                                {summary_html}
                                <p style="color: #2c7fb8; font-weight: bold;">INFORMACIÓN: Este documento ha sido procesado y no requiere acciones adicionales de seguridad.</p>
                            </div>
                            {metlife_footer}
                        </body>
                        </html>
                        """
                    
                    # Send folder-specific email
                    folder_email_sent = self._send_folder_email(
                        subject, body, folder_excel_path, folder_name
                    )
                    
                    if folder_email_sent:
                        if email_type == "critical":
                            logging.info(f"Email sent successfully for folder '{folder_name}' - {entity_count_for_subject} critical entities detected")
                        elif email_type == "filtered":
                            logging.info(f"Email sent successfully for folder '{folder_name}' - {entity_count_for_subject} non-critical entities detected")
                        else:
                            logging.info(f"Email sent successfully for folder '{folder_name}' - No PII detected")
                    else:
                        logging.error(f"Failed to send email for folder '{folder_name}'")
                        all_emails_sent = False
                        
                except Exception as folder_error:
                    logging.error(f"Error processing folder '{folder_name}': {folder_error}")
                    all_emails_sent = False
                    continue
            
            # Log final results with comprehensive coverage metrics
            critical_pii_folders = len([f for f in unique_folders if len(filtered_df[filtered_df['Folder'] == f]) > 0])
            zero_pii_folders = len(unique_folders) - critical_pii_folders
            
            if all_emails_sent:
                logging.info(f"[OK]ALL folder emails sent successfully - {len(unique_folders)} total folders processed")
                logging.info(f"Email distribution:")
                logging.info(f"  - {critical_pii_folders} folders with CRITICAL PII (red alert emails)")
                logging.info(f"  - {zero_pii_folders} folders with NO PII (zero-PII notification emails)")
                logging.info(f"SUMMARY: {len(unique_folders)} emails sent (100% coverage)")
            else:
                logging.warning(f"[NO] Some folder emails failed - {len(unique_folders)} folders attempted")
                logging.info(f"Email distribution:")
                logging.info(f"  - {critical_pii_folders} folders with CRITICAL PII")
                logging.info(f"  - {zero_pii_folders} folders with NO PII (zero-PII notifications)")
            
            return all_emails_sent
                
        except Exception as e:
            logging.error(f"Error creating user email reports: {e}")
            return False

    def _create_filtered_excel_report(self, filtered_df: pd.DataFrame, original_excel_path: str) -> str:
        """
        Create a simplified 2-sheet Excel report for email distribution.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data
            original_excel_path (str): Path to original Excel file
            
        Returns:
            str: Path to created email Excel file
        """
        try:
            # Create user-friendly columns (remove technical fields)
            user_columns = [
                "Report_Generated", "File", "Folder", "Status_file", 
                "PII_Type", "PII_Value", "Page", "Source_Type", "Employee"
            ]
            
            # Filter to only user-relevant columns that exist
            available_columns = [col for col in user_columns if col in filtered_df.columns]
            user_df = filtered_df[available_columns].copy()
            
            # Create summary analysis sheet
            summary_df = self._create_summary_analysis_sheet(filtered_df)
            
            # Generate email-specific filename
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            email_filename = f"PII_User_Report_{timestamp}.xlsx"
            email_excel_path = os.path.join(self.output_dir, email_filename)
            
            # Create 2-sheet Excel file
            with pd.ExcelWriter(email_excel_path, engine="openpyxl") as writer:
                # Sheet 1: Filtered PII Results
                user_df.to_excel(writer, sheet_name="PII_Results", index=False)
                
                # Sheet 2: Summary Analysis
                summary_df.to_excel(writer, sheet_name="Summary_Analysis", index=False)
                
                # Format sheets for better readability
                self._format_user_excel_sheets(writer, user_df, summary_df)
            
            logging.info(f"User Excel report created: {email_excel_path}")
            return email_excel_path
            
        except Exception as e:
            logging.error(f"Error creating filtered Excel report: {e}")
            return None

    def _create_folder_specific_excel_report(self, folder_df: pd.DataFrame, 
                                           folder_name: str, original_excel_path: str, is_zero_pii: bool = False) -> str:
        """
        Create a folder-specific 2-sheet Excel report for email distribution.
        
        Args:
            folder_df (pd.DataFrame): PII data for specific folder (filtered or original based on is_zero_pii)
            folder_name (str): Name of the folder
            original_excel_path (str): Path to original Excel file
            is_zero_pii (bool): True if folder has no critical PII (uses original data for placeholders)
            
        Returns:
            str: Path to created folder-specific Excel file
        """
        try:
            # Debug: Check if version control column exists in input data
            logging.info(f"=== DEBUG FOLDER EXCEL CREATION: {folder_name} ===")
            logging.info(f"Input folder_df shape: {folder_df.shape}")
            logging.info(f"Input folder_df columns: {folder_df.columns.tolist()}")
            if 'Control de version' in folder_df.columns:
                version_data = folder_df['Control de version'].dropna()
                logging.info(f"Version control data in input: {len(version_data)} entries, values: {list(version_data.unique())}")
            else:
                logging.info("No 'Control de version' column in input folder_df")
            
            # Add version control information from metadata first
            # Ensure we work with a proper copy to avoid DataFrame view issues
            folder_df = folder_df.copy()
            
            # Debug the data being passed to version control function
            logging.info(f"Calling version control function for folder: {folder_name}")
            logging.info(f"Sample folder data: {folder_df['Folder'].unique()[:3] if 'Folder' in folder_df.columns else 'No Folder column'}")
            
            folder_df = self._add_version_control_from_metadata(folder_df)
            
            # Debug: Check after adding version control
            if 'Control de version' in folder_df.columns:
                version_data = folder_df['Control de version'].dropna()
                unique_values = folder_df['Control de version'].unique()
                non_empty_values = [v for v in unique_values if str(v).strip() != '']
                logging.info(f"Version control data after metadata merge: {len(version_data)} entries, values: {list(version_data.unique())}")
                logging.info(f"All version control values (including empty): {list(unique_values)}")
                logging.info(f"Non-empty version control values: {list(non_empty_values)}")
            else:
                logging.info("No 'Control de version' column after metadata merge")
            logging.info("=== END DEBUG FOLDER EXCEL CREATION ===")
            
            # Create user-friendly columns (remove technical fields)
            user_columns = [
                "Report_Generated", "File","Page", "Folder", "Status_file", 
                "PII_Type", "PII_Value", "Label", "Control de version", "Employee"   ] # "Source_Type"
            
            ########################################################################################
            # Filter to only user-relevant columns that exist
            available_columns = [col for col in user_columns if col in folder_df.columns]
            user_df = folder_df[available_columns].copy()
            
            logging.info(f"Available columns: {available_columns}")
            logging.info(f"Missing columns: {set(user_columns) - set(available_columns)}")
            
            # Rename columns for end users (English -> Spanish) — only rename existing cols
            rename_map = {
                "Report_Generated": "Fecha de reporte",
                "File": "Archivo",
                "Page": "Pagina",
                "Folder": "Documento",
                "Status_file": "Estatus documento",
                "PII_Type": "Tipo de PII",
                "PII_Value": "PII detectado",
                "Label": "Tag PII",
                "Control de version": "Control de version",
                "Employee": "Empleado"
            }
            rename_map = {k: v for k, v in rename_map.items() if k in user_df.columns}
            if rename_map:
                user_df = user_df.rename(columns=rename_map)
                
            logging.info(f"user_df shape AFTER translation: {user_df.shape}")
            logging.info(f"user_df columns AFTER translation: {user_df.columns.tolist()}")
            ########################################################################################
            # Standardize PII_Type values to Spanish equivalents using comprehensive mapping
            mapping = {
                # Primary mappings for common PII types
                "CUSTOMER_NAME": "Nombre de cliente",
                "ContextualPersonName": "Nombre de cliente",
                "SEQ_NUMBER": "Secuencia numerica", 
                "DATE": "Fecha",
                "AMOUNT": "Monto",
                "Amount": "Monto",
                "PHONE_NUMBER": "Telefono",
                "PHONE": "Telefono", 
                "Phone": "Telefono",
                "NumberSequence": "Secuencia numerica",
                "NUMBERSEQUENCE": "Secuencia numerica",
                "Person": "Nombre de cliente",
                "PERSON": "Nombre de cliente",
                "RUT": "RUT",
                
                # Additional comprehensive mappings
                "EMAIL": "Correo electronico",
                "Email": "Correo electronico",
                "DOCUMENT": "Documento",
                "Document": "Documento",
                "ID": "Identificacion",
                "IDENTIFICATION": "Identificacion",
                "ADDRESS": "Direccion",
                "Address": "Direccion",
                "NAME": "Nombre",
                "Name": "Nombre",
                "CREDIT_CARD": "Tarjeta de credito",
                "CreditCard": "Tarjeta de credito",
                "ACCOUNT": "Cuenta",
                "Account": "Cuenta",
                "BANK": "Banco",
                "Bank": "Banco"
            }
            # for col_name in ("PII_Type", "Tipo de PII"):
                # if col_name in df.columns:
            if "Tipo de PII" in user_df.columns:
                user_df['Tipo de PII'] = user_df['Tipo de PII'].map(mapping).fillna(user_df['Tipo de PII'])

            ########################################################################################
            mapping_tag = {'TextData': 'Datos Texto', 'SequenceNumber': 'Datos numericos'}
            if "Tag PII" in user_df.columns:
                user_df['Tag PII'] = user_df['Tag PII'].map(mapping_tag).fillna(user_df['Tag PII'])

            ########################################################################################
            mapping_tag = {
                'nuevo_archivo': 'Archivo Nuevo',
                'modificado': 'Archivo Modificado',
                'sin_cambios': 'Sin Cambios'
                }
            
            if "Estatus documento" in user_df.columns:
                user_df['Estatus documento'] = user_df['Estatus documento'].map(mapping_tag).fillna(user_df['Estatus documento'])
            ########################################################################################
            
            # Handle zero-PII folders with appropriate messaging
            if is_zero_pii and user_df.empty:
                logging.info(f"Folder '{folder_name}' has no critical PII - creating placeholder report")
                # Create placeholder DataFrame for zero-PII folders with clear message
                placeholder_data = {
                    'Fecha de reporte': [dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
                    'Archivo': ['Análisis completado'],
                    'Pagina': ['N/A'],
                    'Documento': [folder_name],
                    'Estatus documento': ['Sin cambios'],
                    'Tipo de PII': ['Sin detección'],
                    'PII detectado': ['No hay PII detectados en el documento'],
                    'Tag PII': ['Información'],
                    'Control de version': ['N/A']
                }
                user_df = pd.DataFrame(placeholder_data)
                logging.info(f"Created zero-PII placeholder for folder: {folder_name}")
            
            # Create folder-specific summary analysis sheet using translated data
            # Use _create_summary_analysis_sheet which works with already-translated columns
            summary_df = self._create_summary_analysis_sheet(user_df)  # Uses Spanish columns from user_df
            
            # Generate folder-specific filename
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M")
            safe_folder_name = "".join(c for c in folder_name if c.isalnum() or c in (' ', '_', '-')).strip()
            safe_folder_name = safe_folder_name.replace(' ', '_')[:30]  # Limit length for filename
            
            email_filename = f"PII_Report_{safe_folder_name}_{timestamp}.xlsx"
            email_excel_path = os.path.join(self.output_dir, email_filename)
            
            # Create 2-sheet Excel file
            logging.info(f"Creating Excel with {len(user_df.columns)} columns: {user_df.columns.tolist()}")
            with pd.ExcelWriter(email_excel_path, engine="openpyxl") as writer:
                # Sheet 1: Always use 'PII_Results' for consistency (shows actual PII or clear zero-PII message)
                user_df.to_excel(writer, sheet_name="PII_Results", index=False)
                logging.info(f"Written sheet 'PII_Results' with {len(user_df.columns)} columns ({len(user_df)} rows)")
                
                # Sheet 2: Folder-Specific Summary Analysis
                summary_df.to_excel(writer, sheet_name="Summary_Analysis", index=False)
                logging.info(f"Written sheet 'Summary_Analysis' with {len(summary_df.columns)} columns")
                
                # Format sheets for better readability
                self._format_user_excel_sheets(writer, user_df, summary_df)
            
            logging.info(f"Folder Excel report created: {email_excel_path}")
            return email_excel_path
            
        except Exception as e:
            logging.error(f"Error creating folder-specific Excel report for '{folder_name}': {e}")
            return None

    def _generate_folder_summary_stats(self, folder_df: pd.DataFrame, folder_name: str) -> pd.DataFrame:
        """
        Generate folder-specific summary statistics.
        Enhanced to properly handle status translation for email display.
        
        Args:
            folder_df (pd.DataFrame): Filtered PII data for specific folder
            folder_name (str): Name of the folder
            
        Returns:
            pd.DataFrame: Summary statistics for folder email
        """
        try:
            # Basic statistics for this folder
            total_entities = len(folder_df)
            unique_files = folder_df['File'].nunique() if 'File' in folder_df.columns and not folder_df.empty else 1
            
            # ENHANCED STATUS DETECTION - Read from metadata file first
            status_mapping = {
                # Raw English values from metadata (need translation)
                'nuevo_archivo': 'Archivo Nuevo',
                'modificado': 'Archivo Modificado', 
                'sin_cambios': 'Sin Cambios',
                
                # Already translated Spanish values (keep as-is)
                'Archivo Nuevo': 'Archivo Nuevo',
                'Archivo Modificado': 'Archivo Modificado', 
                'Sin Cambios': 'Sin Cambios',
                
                # Mixed case variations
                'archivo nuevo': 'Archivo Nuevo',
                'archivo_nuevo': 'Archivo Nuevo',
                'NUEVO_ARCHIVO': 'Archivo Nuevo',
                'MODIFICADO': 'Archivo Modificado',
                'SIN_CAMBIOS': 'Sin Cambios',
                'modificado': 'Archivo Modificado',
                
                # Default fallbacks
                'unknown': 'Estado Desconocido',
                'desconocido': 'Estado Desconocido'
            }
            
            # STRATEGY 1: Read status from metadata file (PRIMARY SOURCE)
            detection_type = "Estado Desconocido"  # Default fallback
            
            try:
                # Get metadata file path
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                metadata_paths = [
                    os.path.join(project_root, "output", "_others", "files_metadata.xlsx"),
                    os.path.join(project_root, "output", "files_metadata.xlsx"),
                ]
                
                metadata_df = None
                for metadata_path in metadata_paths:
                    if os.path.exists(metadata_path):
                        metadata_df = pd.read_excel(metadata_path)
                        logging.debug(f"Reading metadata from: {metadata_path}")
                        break
                
                if metadata_df is not None and not metadata_df.empty:
                    # Extract folder name without region prefix for matching
                    # Example: "Brasil - Procedimiento Convenios..." -> "Procedimiento Convenios..."
                    clean_folder_name = folder_name
                    if " - " in folder_name:
                        parts = folder_name.split(" - ", 1)
                        if len(parts) > 1:
                            clean_folder_name = parts[1]  # Take part after " - "
                    
                    logging.debug(f"Searching metadata for folder: '{folder_name}' -> clean: '{clean_folder_name}'")
                    
                    # Look for matching files in metadata
                    # Try multiple matching strategies
                    matching_rows = []
                    
                    # Strategy 1: Exact filename match
                    if 'original_filename' in metadata_df.columns:
                        # Remove extension for comparison
                        clean_folder_base = clean_folder_name.replace('.docx', '').replace('.pdf', '').replace('.xlsx', '')
                        for idx, row in metadata_df.iterrows():
                            orig_filename = str(row['original_filename']).replace('.docx', '').replace('.pdf', '').replace('.xlsx', '')
                            if clean_folder_base.lower() in orig_filename.lower() or orig_filename.lower() in clean_folder_base.lower():
                                matching_rows.append(row)
                    
                    # Strategy 2: Source region matching
                    if not matching_rows and 'source_region' in metadata_df.columns:
                        folder_region = folder_name.split(" - ")[0] if " - " in folder_name else ""
                        if folder_region:
                            region_matches = metadata_df[metadata_df['source_region'].str.contains(folder_region, case=False, na=False)]
                            if not region_matches.empty:
                                matching_rows = region_matches.to_dict('records')
                    
                    # Extract lifecycle_status from matching rows
                    if matching_rows and 'lifecycle_status' in metadata_df.columns:
                        # Get the most common status from matching files
                        statuses = [row['lifecycle_status'] for row in matching_rows if pd.notna(row['lifecycle_status'])]
                        if statuses:
                            most_common_status = max(set(statuses), key=statuses.count)
                            
                            # Apply translation mapping
                            status_key = str(most_common_status).strip()
                            if status_key in status_mapping:
                                detection_type = status_mapping[status_key]
                                logging.info(f"Metadata status found for '{folder_name}': '{status_key}' -> '{detection_type}'")
                            else:
                                # Try case-insensitive match
                                for key, value in status_mapping.items():
                                    if key.lower() == status_key.lower():
                                        detection_type = value
                                        logging.info(f"Metadata status found (case-insensitive) for '{folder_name}': '{status_key}' -> '{detection_type}'")
                                        break
                                else:
                                    logging.warning(f"No mapping found for metadata status '{status_key}' in folder '{folder_name}'")
                                    detection_type = status_key.replace('_', ' ').title()
                    else:
                        logging.debug(f"No matching metadata rows found for folder '{folder_name}'")
                        
                else:
                    logging.warning("Metadata file not found or empty, falling back to PII DataFrame status")
                    
            except Exception as e:
                logging.error(f"Error reading metadata file for status detection: {e}")
            
            # STRATEGY 2: Fallback to PII DataFrame status if metadata lookup failed
            if detection_type == "Estado Desconocido":
                if 'Status_file' in folder_df.columns and not folder_df.empty:
                    # Get the most common status from the folder
                    status_series = folder_df['Status_file'].dropna()
                    if not status_series.empty:
                        most_common_status = status_series.mode()[0] if len(status_series.mode()) > 0 else status_series.iloc[0]
                        
                        # Apply translation mapping with case-insensitive matching
                        status_key = str(most_common_status).strip()
                        
                        # Try exact match first
                        if status_key in status_mapping:
                            detection_type = status_mapping[status_key]
                        else:
                            # Try case-insensitive match
                            status_key_lower = status_key.lower()
                            for key, value in status_mapping.items():
                                if key.lower() == status_key_lower:
                                    detection_type = value
                                    break
                            else:
                                # If no match found, try to clean and translate
                                cleaned_status = status_key.replace('_', ' ').title()
                                if cleaned_status in status_mapping:
                                    detection_type = status_mapping[cleaned_status]
                                else:
                                    # Last resort: use the raw value but clean it up
                                    detection_type = cleaned_status
                                    
                elif 'Estatus documento' in folder_df.columns and not folder_df.empty:
                    # Handle Spanish column name (already translated data)
                    status_series = folder_df['Estatus documento'].dropna()
                    if not status_series.empty:
                        most_common_status = status_series.mode()[0] if len(status_series.mode()) > 0 else status_series.iloc[0]
                        
                        # Apply translation mapping
                        status_key = str(most_common_status).strip()
                        detection_type = status_mapping.get(status_key, status_key)
            
            # Enhanced debug logging for status translation
            logging.debug(f"=== STATUS DETECTION DEBUG for folder '{folder_name}' ===")
            logging.debug(f"  Final detection_type: '{detection_type}'")
            logging.debug(f"  Folder name: '{folder_name}'")
            
            # Debug PII DataFrame status if available
            if 'Status_file' in folder_df.columns:
                logging.debug(f"  PII DataFrame status values: {folder_df['Status_file'].unique().tolist()}")
            if 'Estatus documento' in folder_df.columns:
                logging.debug(f"  PII DataFrame Spanish status: {folder_df['Estatus documento'].unique().tolist()}")
                
            logging.debug("=== END STATUS DETECTION DEBUG ===")
            
            # PII Type translation mapping
            pii_mapping = {
                # Primary mappings for common PII types
                "CUSTOMER_NAME": "Nombre de cliente",
                "ContextualPersonName": "Nombre de cliente",
                "SEQ_NUMBER": "Secuencia numerica", 
                "DATE": "Fecha",
                "AMOUNT": "Monto",
                "Amount": "Monto",
                "PHONE_NUMBER": "Telefono",
                "PHONE": "Telefono", 
                "Phone": "Telefono",
                "NumberSequence": "Secuencia numerica",
                "NUMBERSEQUENCE": "Secuencia numerica",
                "Person": "Nombre de cliente",
                "PERSON": "Nombre de cliente",
                "RUT": "RUT",
                
                # Additional comprehensive mappings
                "EMAIL": "Correo electronico",
                "Email": "Correo electronico",
                "DOCUMENT": "Documento",
                "Document": "Documento",
                "ID": "Identificacion",
                "IDENTIFICATION": "Identificacion",
                "ADDRESS": "Direccion",
                "Address": "Direccion",
                "NAME": "Nombre",
                "Name": "Nombre",
                "CREDIT_CARD": "Tarjeta de credito",
                "CreditCard": "Tarjeta de credito",
                "ACCOUNT": "Cuenta",
                "Account": "Cuenta",
                "BANK": "Banco",
                "Bank": "Banco"
            }

            # Determine most common PII type
            if total_entities > 0 and 'PII_Type' in folder_df.columns:
                # Apply PII type translation first
                pii_types_translated = folder_df['PII_Type'].map(pii_mapping).fillna(folder_df['PII_Type'])
                top_pii_types = pii_types_translated.value_counts()
                most_common_pii = top_pii_types.index[0] if len(top_pii_types) > 0 else "Ninguno"
                most_common_count = top_pii_types.iloc[0] if len(top_pii_types) > 0 else 0
            else:
                most_common_pii = "Ninguno"
                most_common_count = 0
            
            # Create summary data with proper translations
            summary_data = {
                "Métrica": [
                    "Archivo Analizado",
                    "Tipo de Detección",
                    "Total de Entidades PII en Carpeta",
                    "Archivos con PII en esta Carpeta", 
                    "Tipo de PII Más Común en Carpeta",
                    "Reporte Generado"
                ],
                "Valor": [
                    folder_name,
                    detection_type,  # Now properly translated
                    0 if (total_entities == 0 or folder_df.empty) else total_entities,  # FIXED: Show 0 for zero-PII
                    0 if (total_entities == 0 or folder_df.empty) else unique_files,   # FIXED: Show 0 for zero-PII
                    "Sin detección" if (total_entities == 0 or folder_df.empty) else f"{most_common_pii} : {most_common_count} ocurrencias",  # FIXED: Show "Sin detección" for zero-PII
                    dt.datetime.now().strftime("%Y-%m-%d %H:%M")
                ]
            }
            
            return pd.DataFrame(summary_data)
            
        except Exception as e:
            logging.error(f"Error generating folder summary stats for '{folder_name}': {e}")
            return pd.DataFrame({"Métrica": ["Error"], "Valor": [str(e)]})

    def _create_folder_summary_analysis_sheet(self, folder_df: pd.DataFrame, folder_name: str) -> pd.DataFrame:
        """
        Create folder-specific summary analysis sheet with breakdowns.
        
        Args:
            folder_df (pd.DataFrame): Filtered PII data for specific folder
            folder_name (str): Name of the folder
            
        Returns:
            pd.DataFrame: Folder-specific summary analysis data
        """
        try:
            # Safe guards
            if folder_df is None or folder_df.empty:
                return pd.DataFrame([
                    {"Categoría": "RESUMEN EJECUTIVO", "Métrica": folder_name, "Cantidad": "", "Porcentaje": ""},
                    {"Categoría": "", "Métrica": "No se encontraron entidades PII en esta carpeta", "Cantidad": "", "Porcentaje": ""}
                ])
            
            total_entities = len(folder_df)
            unique_files = int(folder_df['File'].nunique()) if 'File' in folder_df.columns else 0
            # number of unique files in this folder that contain at least one PII entity
            files_with_pii = unique_files
            
            # Build rows
            rows = []
            
            # Header / summary (kept as normal rows; top merged decorative header is applied in formatter)
            # rows.append({"Categoría": "RESUMEN EJECUTIVO", "Métrica": "Carpeta Analizada", "Cantidad": folder_name, "Porcentaje": ""})
            rows.append({"Categoría": "RESUMEN EJECUTIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            rows.append({"Categoría": "", "Métrica": "Total de Entidades PII (filas)", "Cantidad": total_entities, "Porcentaje": "100%"})
            rows.append({"Categoría": "", "Métrica": "Archivos Afectados (únicos)", "Cantidad": unique_files, "Porcentaje": ""})
            rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})  # separator
            
            # PII type breakdown (sorted by count) - show top N (configurable)
            if 'PII_Type' in folder_df.columns and not folder_df['PII_Type'].empty:
                pii_type_counts = folder_df['PII_Type'].value_counts()
                rows.append({"Categoría": "DESGLOSE POR TIPO DE PII", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                top_n = min(8, len(pii_type_counts))  # show up to 8 most common types for compactness
                for pii_type, count in pii_type_counts.head(top_n).items():
                    pct = (count / total_entities) * 100 if total_entities > 0 else 0.0
                    rows.append({
                        "Categoría": "",
                        "Métrica": str(pii_type),
                        "Cantidad": int(count),
                        "Porcentaje": f"{pct:.1f}%"
                    })
                rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # File status section removed - status is now displayed in the top merged header row
            # "Estado de archivo: Modificado" instead of a separate section
            
            # Source type breakdown (sorted)
            if 'Source_Type' in folder_df.columns and not folder_df['Source_Type'].empty:
                source_counts = folder_df['Source_Type'].value_counts()
                rows.append({"Categoría": "TIPOS DE FUENTE", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for source, count in source_counts.items():
                    pct = (count / total_entities) * 100 if total_entities > 0 else 0.0
                    rows.append({
                        "Categoría": "",
                        "Métrica": str(source),
                        "Cantidad": int(count),
                        "Porcentaje": f"{pct:.1f}%"
                    })
                rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # Additional useful detail: most common PII and sample files (limit examples)
            try:
                most_common_pii = folder_df['PII_Type'].mode()[0] if 'PII_Type' in folder_df.columns and not folder_df['PII_Type'].empty else None
                if most_common_pii:
                    # increase examples to max 5 for more context
                    sample_files = folder_df[folder_df['PII_Type'] == most_common_pii]['File'].unique()[:3].tolist()
                    rows.append({"Categoría": "DETALLE ADICIONAL", "Métrica": "Tipo PII Más Común", "Cantidad": most_common_pii, "Porcentaje": ""})
                    rows.append({"Categoría": "", "Métrica": "Ejemplos de Archivos con este PII (máx 3)", "Cantidad": ", ".join(sample_files), "Porcentaje": ""})
                    rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            except Exception:
                # ignore optional detail if something fails
                pass
            
            # Footer / generation timestamp
            rows.append({"Categoría": "", "Métrica": "Reporte Generado", "Cantidad": dt.datetime.now().strftime("%Y-%m-%d %H:%M"), "Porcentaje": ""})
            
            return pd.DataFrame(rows, columns=["Categoría", "Métrica", "Cantidad", "Porcentaje"])
            
        except Exception as e:
            logging.error(f"Error creating folder summary analysis for '{folder_name}': {e}")
            return pd.DataFrame([{"Categoría": "Error", "Métrica": "Análisis Falló", "Cantidad": str(e), "Porcentaje": ""}])


    def _send_folder_email(self, subject: str, body: str, excel_path: str, folder_name: str) -> bool:
        """
        Send email for a specific folder.
        Obtiene el destinatario del archivo: Listado encargados Chile.xlsx - columna 'Responsible_email'
        Filters emails by detected country/sheet from folder name.
        
        Args:
            subject (str): Email subject
            body (str): Email body HTML
            excel_path (str): Path to Excel attachment
            folder_name (str): Name of the folder
            
        Returns:
            bool: True if email sent successfully, False otherwise
        """
        try:
            # Detect country/sheet from folder name to filter emails appropriately
            detected_sheet_name = self.country_detector.get_sheet_name(folder_name)
            logging.info(f"Detected sheet from folder name '{folder_name}': {detected_sheet_name}")
            
            # Get recipient email based on folder name from "Listado encargados Chile.xlsx" filtered by sheet
            responsible_email, no_se_usa = self._get_responsible_email(folder_name, sheet_name=detected_sheet_name)
            
            if not responsible_email:
                logging.warning(f"No responsible email found for folder '{folder_name}'. Using fallback email.")
                responsible_email = "andres.n.vera@provida.cl"  # Fallback
            
            logging.info(f"Folder email recipient for '{folder_name}': {responsible_email}")
            
            # Convert to absolute path to fix Outlook issues
            excel_path = os.path.abspath(excel_path)
            logging.info(f"Folder '{folder_name}' Excel absolute path: {excel_path}")
            
            # Verify file exists with absolute path
            if not os.path.exists(excel_path):
                logging.error(f"Folder Excel file not found at absolute path: {excel_path}")
                return False
            
            # Create temporary HTML files for email in output directory
            os.makedirs(self.output_dir, exist_ok=True)
            safe_folder_name = "".join(c for c in folder_name if c.isalnum() or c in ('_', '-'))
            temp_body_file = os.path.join(self.output_dir, f"temp_email_body_{safe_folder_name}.html")
            temp_wrapper_file = os.path.join(self.output_dir, f"temp_email_wrapper_{safe_folder_name}.html")
            
            try:
                # Create body file
                with open(temp_body_file, 'w', encoding='utf-8') as f:
                    f.write(body)
                
                # Create wrapper file with body content
                wrapper_html = f"""
                    {body}
                """
                with open(temp_wrapper_file, 'w', encoding='utf-8') as f:
                    f.write(wrapper_html)
                
                logging.info(f"Sending email for folder '{folder_name}' to '{responsible_email}' - Subject: {subject}")
                
                # Send email using framework's send_email function
                email_sent = send_email(
                    subject=subject,
                    to=[responsible_email],  # Use responsible email from Excel file
                    body_file=temp_body_file,
                    wrapper_file=temp_wrapper_file,
                    environment="dev",
                    attachments=[excel_path]
                )
                
                return email_sent
                
            finally:
                # Clean up temporary files
                for temp_file in [temp_body_file, temp_wrapper_file]:
                    try:
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                            logging.debug(f"Cleaned up temp file: {temp_file}")
                    except Exception as cleanup_error:
                        logging.warning(f"Failed to clean up temp file {temp_file}: {cleanup_error}")
            
        except Exception as e:
            logging.error(f"Error sending folder email for '{folder_name}': {e}")
            return False

    def _get_manager_emails(self, sheet_name: str = None) -> list:
        """
        Get manager emails from 'Listado encargados Chile.xlsx' file.
        Always reads from the 'Manager_email' column.
        
        Args:
            sheet_name (str): The detected sheet name (Chile, Brazil, Colombia, Uruguay)
            
        Returns:
            list: List of manager email addresses, empty list if file not found
        """
        try:
            # Get project root
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            # Build path to the manager list file
            manager_list_path = os.path.join(project_root, "input", "Listado encargados Chile.xlsx")
            
            logging.info(f"Looking for manager email file: {manager_list_path}")
            logging.info(f"Reading from sheet: {sheet_name or 'Chile (default)'}")
            
            if not os.path.exists(manager_list_path):
                logging.warning(f"Manager email file not found: {manager_list_path}")
                return []
            
            # Use provided sheet name or default to 'Chile'
            sheet_to_read = sheet_name if sheet_name else 'Chile'
            
            try:
                # Read the Excel file from the specified sheet
                df_managers = pd.read_excel(manager_list_path, sheet_name=sheet_to_read)
                logging.info(f"Successfully read sheet '{sheet_to_read}' from manager file")
            except Exception as e:
                logging.warning(f"Could not read sheet '{sheet_to_read}': {e}. Trying 'Chile' sheet...")
                df_managers = pd.read_excel(manager_list_path, sheet_name='Chile')
            
            # Always use the default Manager_email column
            email_column = 'Manager_email'
            
            logging.info(f"Using column '{email_column}'")
            
            # Verify the email column exists
            if email_column not in df_managers.columns:
                logging.error(f"Email column '{email_column}' not found. Available columns: {df_managers.columns.tolist()}")
                return []
            
            # Extract unique manager emails (remove NaN and duplicates)
            manager_emails = df_managers[email_column].dropna().unique().tolist()
            
            # Filter out empty strings and invalid emails
            manager_emails = [email.strip() for email in manager_emails if email and str(email).strip()]
            
            logging.info(f"Found {len(manager_emails)} manager email(s) from '{email_column}': {manager_emails}")
            
            return manager_emails
            
        except Exception as e:
            logging.error(f"Error reading manager emails: {e}")
            return [] 

    def _get_responsible_email(self, folder_name: str, sheet_name: str = None) -> Optional[str]:
        """
        Get responsible email for a specific folder from 'Listado encargados Chile.xlsx'.
        Matches folder name against the manager list to find the responsible person.
        Always reads from the 'Responsible_email' column.
        
        Args:
            folder_name: Name of the folder (document name)
            sheet_name: The detected sheet name (received for context but not used for column selection)
            
        Returns:
            str: Email address of responsible person, None if not found
        """
        try:
            # Get project root | CAMBIAR POR
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            # Build path to the manager list file
            manager_list_path = os.path.join(project_root, "input", "Listado encargados Chile.xlsx")
            
            logging.info(f"Getting responsible email for folder: '{folder_name}' (sheet: {sheet_name})")
            
            if not os.path.exists(manager_list_path):
                logging.warning(f"Manager email file not found: {manager_list_path}")
                return None, None
            
            # Read the Excel file
            df_managers = pd.read_excel(manager_list_path, sheet_name=sheet_name)
            
            # Always use the default Responsible_email column
            email_column = 'Responsible_email'
            
            logging.info(f"Using column '{email_column}' for sheet '{sheet_name}'")
            
            # Verify the email column exists
            if email_column not in df_managers.columns:
                logging.error(f"Email column '{email_column}' not found. Available columns: {df_managers.columns.tolist()}")
                return None, None
            
            # Clean folder name for matching (remove region prefix, extension, etc.)
            clean_folder = self._clean_filename_for_matching(folder_name)
            
            logging.info(f"Searching for responsible email for folder: '{folder_name}' (cleaned: '{clean_folder}')")
            
            # Try to find matching row in manager list
            for idx, row in df_managers.iterrows():
                nombre_documento = row['Documento']
                
                # # Clean the manager folder name for matching
                clean_manager_folder = self._clean_filename_for_matching(str(nombre_documento))
                
                if clean_manager_folder.lower() == clean_folder.lower():
                    logging.info('Nombre de archivo encontrado: ', clean_manager_folder)
                    logging.info('Obteniendo el correo')
                    responsible_email = row['Responsible_email']
                    manager_email = row['Manager_email']
                    lob_founded = row['Lob']
                    if lob_founded is not None and not pd.isna(lob_founded):
                        self.lobs_founded.append(lob_founded)
                    return str(responsible_email).strip(), str(manager_email).strip()
            
            logging.debug(f"No matching folder found in manager list for: '{folder_name}'")
            return None, None
            
        except Exception as e:
            logging.error(f"Error reading responsible email for '{folder_name}': {e}")
            return None, None

    def _generate_user_summary_stats(self, filtered_df: pd.DataFrame) -> pd.DataFrame:
        """
        Generate user-friendly summary statistics.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data
            
        Returns:
            pd.DataFrame: Summary statistics for email
        """
        try:
            # Basic statistics
            total_entities = len(filtered_df)
            unique_files = filtered_df['File'].nunique() if 'File' in filtered_df.columns else 0
            unique_folders = filtered_df['Folder'].nunique() if 'Folder' in filtered_df.columns else 0
            
            # Top PII types
            if 'PII_Type' in filtered_df.columns:
                top_pii_types = filtered_df['PII_Type'].value_counts().head(3)
                most_common_pii = top_pii_types.index[0] if len(top_pii_types) > 0 else "None"
                most_common_count = top_pii_types.iloc[0] if len(top_pii_types) > 0 else 0
            else:
                most_common_pii = "Unknown"
                most_common_count = 0
            
            # File status distribution - COUNT UNIQUE FILES, not entities
            if 'Status_file' in filtered_df.columns:
                # Get unique files by status
                modified_files = filtered_df[filtered_df['Status_file'] == 'modificado']['File'].nunique() if 'File' in filtered_df.columns else 0
                new_files = filtered_df[filtered_df['Status_file'] == 'nuevo_archivo']['File'].nunique() if 'File' in filtered_df.columns else 0
            else:
                modified_files = new_files = 0
            
            summary_data = {
                "Métrica": [
                    "Total de Entidades PII Encontradas",
                    "Archivos que Contienen PII (imagenes/texto)", 
                    "Carpetas Procesadas",
                    "Tipo de PII Más Común",
                    # "Archivos Modificados con PII",
                    # "Archivos Nuevos con PII",
                    "Reporte Generado"
                ],
                "Valor": [
                    total_entities,
                    unique_files,
                    unique_folders,
                    f"{most_common_pii} ({most_common_count})",
                    # modified_files,
                    # new_files,
                    dt.datetime.now().strftime("%Y-%m-%d %H:%M")
                ]
            }
            
            return pd.DataFrame(summary_data)
            
        except Exception as e:
            logging.error(f"Error generating user summary stats: {e}")
            return pd.DataFrame({"Metric": ["Error"], "Value": [str(e)]})

    def _create_summary_analysis_sheet(self, filtered_df: pd.DataFrame) -> pd.DataFrame:
        """
        Create dynamic summary analysis sheet with breakdowns.
        Uses already-translated data from PII_Results for consistency.
        
        Args:
            filtered_df (pd.DataFrame): Filtered PII data (should have Spanish columns if from PII_Results)
            
        Returns:
            pd.DataFrame: Summary analysis data
        """
        try:
            logging.info(f"Processing Function: {inspect.currentframe().f_code.co_name}")
            logging.debug(f"Filtered DataFrame columns: {filtered_df.columns.tolist()}")
            summary_rows = []
            
            # Detect if we have Spanish or English columns (use Spanish if available)
            pii_type_col = "Tipo de PII" if "Tipo de PII" in filtered_df.columns else "PII_Type"
            status_col = "Estatus documento" if "Estatus documento" in filtered_df.columns else "Status_file"
            file_col = "Archivo" if "Archivo" in filtered_df.columns else "File"
            folder_col = "Documento" if "Documento" in filtered_df.columns else "Folder"
            source_col = "Source_Type"  # This column doesn't get translated in PII_Results currently
            
            # Header section
            summary_rows.extend([
                {"Categoría": "RESUMEN EJECUTIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""},
                {"Categoría": "", "Métrica": "Total de Entidades PII", "Cantidad": len(filtered_df), "Porcentaje": "100%"},
                {"Categoría": "", "Métrica": "Archivos imagenes/texto Afectados", "Cantidad": filtered_df[file_col].nunique() if file_col in filtered_df.columns else 0, "Porcentaje": ""},
                {"Categoría": "", "Métrica": "Archivos unicos analizados", "Cantidad": filtered_df[folder_col].nunique() if folder_col in filtered_df.columns else 0, "Porcentaje": ""},
                {"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""},
            ])
            
            # PII Type breakdown - use already translated values
            if pii_type_col in filtered_df.columns and not filtered_df.empty:
                pii_type_counts = filtered_df[pii_type_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR TIPO DE PII", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for pii_type, count in pii_type_counts.head(10).items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # No need for translation - already translated in PII_Results
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": str(pii_type),  # Already in Spanish if from PII_Results
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
                
                summary_rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # File Status breakdown - use already translated values  
            if status_col in filtered_df.columns and not filtered_df.empty:
                status_counts = filtered_df[status_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR ESTADO DE ARCHIVO", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for status, count in status_counts.items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # If using Spanish column, no translation needed. If English, apply minimal cleanup
                    if status_col == "Estatus documento":
                        # Apply translation mapping even for Spanish column
                        status_mapping = {
                            'nuevo_archivo': 'Nuevo Archivo',
                            'modificado': 'Modificado'
                        }
                        status_display = status_mapping.get(str(status), str(status))
                    else:
                        # English column - apply translation mapping
                        status_mapping = {
                            'nuevo_archivo': 'Nuevo Archivo',
                            'modificado': 'Modificado'
                        }
                        status_display = status_mapping.get(str(status), str(status).replace("_", " ").title())
                        
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": status_display,
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
                
                summary_rows.append({"Categoría": "", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
            
            # Source Type breakdown
            if source_col in filtered_df.columns and not filtered_df.empty:
                source_counts = filtered_df[source_col].value_counts()
                total_entities = len(filtered_df)
                
                summary_rows.append({"Categoría": "DESGLOSE POR TIPO DE FUENTE", "Métrica": "", "Cantidad": "", "Porcentaje": ""})
                
                for source, count in source_counts.items():
                    percentage = f"{(count / total_entities) * 100:.1f}%"
                    # Apply minimal cleanup for source types
                    source_display = str(source).replace("_", " ").title()
                    summary_rows.append({
                        "Categoría": "",
                        "Métrica": source_display,
                        "Cantidad": count,
                        "Porcentaje": percentage
                    })
            
            return pd.DataFrame(summary_rows)
            
        except Exception as e:
            logging.error(f"Error creating summary analysis sheet: {e}")
            return pd.DataFrame([{"Categoría": "Error", "Métrica": "Análisis Falló", "Cantidad": str(e), "Porcentaje": ""}])

    def _format_user_excel_sheets(self, writer, pii_df: pd.DataFrame, summary_df: pd.DataFrame) -> None:
        """
        Format the user Excel sheets with clean, professional styling.
        Always formats 'PII_Results' sheet (shows actual PII or zero-PII message).
        
        Args:
            writer: Excel writer object
            pii_df (pd.DataFrame): PII results dataframe
            summary_df (pd.DataFrame): Summary dataframe
        """
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
            
            # Format PII_Results sheet (always exists with this name)
            if "PII_Results" not in writer.sheets:
                logging.warning("PII_Results sheet not found in writer")
                return
            
            pii_ws = writer.sheets["PII_Results"]
            logging.info("Formatting sheet: PII_Results")

                
            # Set column widths
            column_widths = {'A': 15, 'B': 20, 'C': 15, 'D': 15, 'E': 15, 'F': 30, 'G': 8, 'H': 15}
            for col, width in column_widths.items():
                pii_ws.column_dimensions[col].width = width
            
            # Auto-size columns based on content (header + cell max length)
            # Cap widths for readability: min 8, max 50
            if isinstance(pii_df, pd.DataFrame) and not pii_df.empty:
                for idx, col in enumerate(pii_df.columns, start=1):
                    try:
                        max_cell = max((len(str(v)) for v in pii_df[col].fillna('')), default=0)
                    except Exception:
                        max_cell = 0
                    header_len = len(str(col))
                    calculated = max(header_len, max_cell) + 2  # padding
                    width = max(8, min(50, calculated))
                    col_letter = get_column_letter(idx)
                    pii_ws.column_dimensions[col_letter].width = width
            else:
                # Fallback sensible defaults if dataframe empty
                for i, col_letter in enumerate(list("ABCDEFGH"), start=1):
                    pii_ws.column_dimensions[col_letter].width = 15
            
            # Format headers
            # Use dark-blue headers for consistency with folder summary screenshots
            header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
            for cell in pii_ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = header_fill_dark_blue
                cell.alignment = Alignment(horizontal="center")
            
            # Color code by file status (priority) and detection method (secondary)
            status_colors = {
                "modificado": PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid"),      # Light yellow
                "nuevo_archivo": PatternFill(start_color="D5E8D4", end_color="D5E8D4", fill_type="solid"),  # Light green
                "sin_cambios": PatternFill(start_color="F8CECC", end_color="F8CECC", fill_type="solid"),    # Light red
                # Translated Spanish values (after column renaming)
                "archivo nuevo": PatternFill(start_color="D5E8D4", end_color="D5E8D4", fill_type="solid"),
                "archivo modificado": PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid"),
            }
            
            # Apply status coloring - check for both English and Spanish column names
            status_col_name = None
            if 'Estatus documento' in pii_df.columns:
                status_col_name = 'Estatus documento'
            elif 'Status_file' in pii_df.columns:
                status_col_name = 'Status_file'
            
            if status_col_name:
                status_col_idx = list(pii_df.columns).index(status_col_name) + 1  # Excel is 1-indexed
                
                for row_idx, row in enumerate(pii_ws.iter_rows(min_row=2, max_row=len(pii_df) + 1), 2):
                    if len(row) > status_col_idx - 1:
                        status_value = str(row[status_col_idx - 1].value).lower() if row[status_col_idx - 1].value else ""
                        fill_color = status_colors.get(status_value)
                        if fill_color:
                            for cell in row:
                                cell.fill = fill_color
            
            # Format Summary Analysis sheet
            if "Summary_Analysis" in writer.sheets:
                summary_ws = writer.sheets["Summary_Analysis"]
                
                # Set column widths
                summary_ws.column_dimensions['A'].width = 25  # Category
                summary_ws.column_dimensions['B'].width = 30  # Metric
                summary_ws.column_dimensions['C'].width = 15  # Count
                summary_ws.column_dimensions['D'].width = 15  # Percentage
                
                # Format headers
                # Prepare fills & fonts
                header_fill_dark_blue = PatternFill(start_color="2F5597", end_color="2F5597", fill_type="solid")
                category_fill_light = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
                header_font = Font(bold=True, color="FFFFFF")
                section_font = Font(bold=True, color="000000")
                
                # Insert a decorative merged header row above the dataframe header (pandas header will be shifted down)
                try:
                    # Insert a blank row at top so we can add a merged title row
                    summary_ws.insert_rows(1)
                except Exception:
                    # If insertion fails (rare), continue and attempt to format existing header
                    pass
                
                # Try to extract folder name and status from the summary_df (these are present when folder-specific)
                folder_display = ""
                status_display = ""
                
                try:
                    if isinstance(summary_df, pd.DataFrame):
                        # Get folder name from the folder_name parameter passed to the sheet creation
                        # Since we removed "Carpeta Analizada" row, we need to get it from the data
                        if isinstance(pii_df, pd.DataFrame) and 'Folder' in pii_df.columns and not pii_df['Folder'].empty:
                            # Get the most common folder name (should be consistent within folder-specific reports)
                            folder_display = pii_df['Folder'].mode()[0] if not pii_df['Folder'].empty else ""
                        else:
                            folder_display = ""
                        
                        # Get status from the pii_df if available (most common status)
                        try:
                            if isinstance(pii_df, pd.DataFrame) and 'Estatus documento' in pii_df.columns and not pii_df['Estatus documento'].empty:
                                # Use the Spanish column name and get the most common status
                                status_display = pii_df['Estatus documento'].mode()[0]
                            elif isinstance(pii_df, pd.DataFrame) and 'Status_file' in pii_df.columns and not pii_df['Status_file'].empty:
                                # Fallback to English column with proper translation
                                status_raw = pii_df['Status_file'].mode()[0]
                                # Translate to Spanish
                                status_mapping = {
                                    'modificado': 'Modificado',
                                    'nuevo_archivo': 'Nuevo Archivo', 
                                    'sin_cambios': 'Sin Cambios'
                                }
                                status_display = status_mapping.get(status_raw, status_raw.replace("_", " ").title())
                            else:
                                status_display = "Desconocido"
                        except Exception:
                            status_display = "Desconocido"
                except Exception:
                    folder_display = folder_display or ""
                    status_display = status_display or ""
                
                # Write merged top header and style it
                try:
                    merged_text = f"Carpeta Analizada: {folder_display}    |    Estado de archivo: {status_display}"
                    summary_ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=4)
                    top_cell = summary_ws.cell(row=1, column=1)
                    top_cell.value = merged_text
                    top_cell.font = header_font
                    top_cell.fill = header_fill_dark_blue
                    top_cell.alignment = Alignment(horizontal="center", vertical="center")
                except Exception:
                    # ignore merge/write errors and continue formatting rest
                    pass
                
                # The DataFrame header row is now at excel row 2 (after insertion). Format it bold/centered and give it the dark-blue fill.
                header_row_idx = 2
                try:
                    for cell in summary_ws[header_row_idx]:
                        cell.font = header_font
                        cell.fill = header_fill_dark_blue
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                except Exception:
                    # If iterating row fails, try per-column approach
                    for col_idx in range(1, 5):
                        cell = summary_ws.cell(row=header_row_idx, column=col_idx)
                        cell.font = header_font
                        cell.fill = header_fill_dark_blue
                        cell.alignment = Alignment(horizontal="center", vertical="center")
                
                # Freeze panes so header row stays visible. Freeze above row 3 (so rows 1-2 remain visible).
                try:
                    summary_ws.freeze_panes = summary_ws['A3']
                except Exception:
                    # Fallback textual form
                    try:
                        summary_ws.freeze_panes = "A3"
                    except Exception:
                        pass
                
                # Format category/section header rows (soft blue) - start from row 3 to skip the decorative header + df header
                for row in summary_ws.iter_rows(min_row=3, max_row=summary_ws.max_row):
                    try:
                        first_cell = row[0]
                        second_cell = row[1] if len(row) > 1 else None
                        
                        # Detect section title rows:
                        # 1. Standard rule: first cell is ALL UPPER and second cell is empty (e.g., "DESGLOSE POR TIPO DE PII")
                        # 2. Special case: "DETALLE ADICIONAL" row should be formatted even if it has content in following cells
                        is_section_title = False
                        if first_cell.value and isinstance(first_cell.value, str):
                            cell_value = first_cell.value.strip()
                            # Check if it's a standard section header (all caps + empty second cell)
                            if cell_value == cell_value.upper() and (not second_cell or not second_cell.value):
                                is_section_title = True
                            # Special case for "DETALLE ADICIONAL" - always format regardless of following cells
                            elif cell_value.upper() == "DETALLE ADICIONAL":
                                is_section_title = True
                        
                        if is_section_title:
                            # Apply section header formatting to entire row
                            for cell in row:
                                cell.font = section_font
                                cell.fill = category_fill_light
                                # Keep left alignment for category column, center for numbers
                                if cell.col_idx in (3, 4):
                                    cell.alignment = Alignment(horizontal="center")
                                else:
                                    cell.alignment = Alignment(horizontal="left")
                    except Exception:
                        continue
                
                # Ensure numeric columns alignment and simple formatting for the rest of rows
                for row in summary_ws.iter_rows(min_row=3, max_row=summary_ws.max_row):
                    try:
                        # Align quantity and percentage
                        qty_cell = summary_ws.cell(row=row[0].row, column=3)
                        pct_cell = summary_ws.cell(row=row[0].row, column=4)
                        qty_cell.alignment = Alignment(horizontal="right")
                        pct_cell.alignment = Alignment(horizontal="right")
                    except Exception:
                        continue
                            
        except Exception as e:
            logging.error(f"Error formatting user Excel sheets: {e}")

    def run_detection(self) -> bool:
        """Main orchestration method with smart file filtering"""
        try:
            logging.info("=" * 80)
            logging.info("S4 PII Detection - Starting with smart file filtering")
            logging.info("=" * 80)
            logging.info(f"Configured method: {self.detection_method}")
            
            # Validate method
            valid_methods = ["regex", "ml", "hybrid"]
            if self.detection_method not in valid_methods:
                logging.error(f"Invalid detection method: {self.detection_method}. Valid options: {valid_methods}")
                return False
            
            # Get OCR input directory
            input_dir = os.path.join(self.input_dir)
            if not os.path.exists(input_dir):
                logging.warning(f"OCR input directory not found: {input_dir}")
                return False
            
            # Get list of already processed files
            logging.info("\n--- Checking for previously processed files ---")
            processed_files = self._get_already_processed_files()
            
            # Get all folders in OCR input directory (S1 creates one folder per file)
            all_folders = [
                f for f in os.listdir(input_dir) 
                if os.path.isdir(os.path.join(input_dir, f)) and not f.startswith('.')
            ]
            logging.info(f"\nTotal folders in OCR input directory: {len(all_folders)}")
            
            # Filter folders based on processing status
            folders_to_process = []
            skipped_folders = []
            
            for folder_name in all_folders:
                # Check if folder should be processed
                if self._should_process_file(folder_name, processed_files):
                    folders_to_process.append(folder_name)
                else:
                    skipped_folders.append(folder_name)
            
            # Log summary
            logging.info("\n" + "=" * 80)
            logging.info(f"PROCESSING SUMMARY:")
            logging.info(f"  Total folders found:      {len(all_folders)}")
            logging.info(f"  Already processed:        {len(skipped_folders)}")
            logging.info(f"  New/Modified to process:  {len(folders_to_process)}")
            logging.info("=" * 80 + "\n")
            
            if skipped_folders:
                logging.info("Skipped folders (already processed):")
                for folder_name in skipped_folders[:10]:  # Show first 10
                    logging.info(f"  [OK] {folder_name}")
                if len(skipped_folders) > 10:
                    logging.info(f"  ... and {len(skipped_folders) - 10} more")
            
            if not folders_to_process:
                logging.info("[OK] No new folders to process - all files already analyzed")
                return True
            
            logging.info(f"\nFolders queued for PII processing:")
            for folder_name in folders_to_process[:10]:  # Show first 10
                logging.info(f"  [->] {folder_name}")
            if len(folders_to_process) > 10:
                logging.info(f"  ... and {len(folders_to_process) - 10} more")
            
            # Store the filtered list for use in the actual detection methods
            self._folders_to_process = folders_to_process
            
            # Execute detection
            if self.detection_method == "hybrid":
                return self._run_hybrid_method()
            else:
                return self._run_single_method(self.detection_method)
                
        except Exception as e:
            logging.error(f"Orchestration failed: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return False

    def run_flow(self) -> bool:
        """
        Main workflow method - follows the same pattern as S0, S1, S2, S3 scripts
        Required by MainProcess in main.py
        """
        return self.run_detection()

    def _extract_country_from_filename(self, filename: str) -> Optional[str]:
        """
        Extract country from filename using region prefixes.
        
        Args:
            filename: Filename or folder name with country prefix (e.g., "Brasil - documento.pdf")
            
        Returns:
            str: Country name ("Brasil", "Chile", "Colombia", "Uruguay") or None if not found
        """
        if not filename or pd.isna(filename):
            return None
            
        filename_str = str(filename)
        
        # Region prefixes to detect
        region_prefixes = ['Brasil - ', 'Chile - ', 'Colombia - ', 'Uruguay - ']
        
        for prefix in region_prefixes:
            if filename_str.startswith(prefix):
                # Return country name without separator
                return prefix.rstrip(' - ')
        
        return None

    def _send_resume_email(self) -> bool:
        """
        Sends summary emails by country integrating files_metadata.xlsx with PII detections.
        Detects unique countries in the data and sends filtered email for each country.
        
        Returns:
            bool: True if all country emails sent successfully, False otherwise
        """
        try:
            logging.info("Starting generation and sending of country-specific summary emails")
            
            # Obtener directorios base
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            input_dir = self.config.get("paths", {}).get("input", "input")
            if not os.path.isabs(input_dir):
                input_dir = os.path.join(project_root, input_dir)
            
            # Define search paths, prioritizing known location
            metadata_search_paths = [
                # User-specific location (first priority)
                os.path.join(project_root, "output", "_others", "files_metadata.xlsx"),
                # Alternative locations
                os.path.join(project_root, "output", "files_metadata.xlsx"),
                os.path.join(input_dir, "files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "_others", "files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "files_metadata.xlsx")
            ]
            
            logging.info(f"Searching for files_metadata.xlsx in {len(metadata_search_paths)} paths:")
            for i, path in enumerate(metadata_search_paths):
                logging.info(f"  {i+1}. {path}")
            
            metadata_files = []
            for search_path in metadata_search_paths:
                logging.debug(f"Checking existence of: {search_path}")
                # Use os.path.exists instead of glob for specific paths
                if os.path.exists(search_path) and os.path.isfile(search_path):
                    logging.info(f"Found files_metadata.xlsx at: {search_path}")
                    metadata_files.append(search_path)
                    break  # Use the first file found
                            
            # If not found with specific paths, search with glob in input/
            if not metadata_files:
                glob_search_path = os.path.join(input_dir, "**/files_metadata.xlsx")
                logging.debug(f"Searching with glob in: {glob_search_path}")
                found_files = glob.glob(glob_search_path, recursive=True)
                if found_files:
                    logging.info(f"Found metadata with glob: {found_files}")
                    metadata_files.extend(found_files)
                            
            if not metadata_files:
                logging.warning("files_metadata.xlsx not found in search paths. Summary email will not be sent.")
                return False
            
            files_metadata_path = metadata_files[0]
            logging.info(f"Found files_metadata.xlsx at: {files_metadata_path}")
            
            # Store the metadata path for use in other methods
            self.files_metadata_path = files_metadata_path
            
            # Update metadata with version control information from text files
            logging.info("Updating metadata with version control information...")
            self.update_metadata_with_version_control()
            
            # Search for the latest PII analysis file
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            pii_files = glob.glob(os.path.join(output_dir, "OCR_PII_Analysis_HYBRID_*.xlsx"))
            
            if not pii_files:
                logging.warning("No PII analysis files found. Summary email will not be sent.")
                return False
            
            # Get the most recent file
            latest_pii_file = max(pii_files, key=os.path.getmtime)
            logging.info(f"Using most recent PII file: {latest_pii_file}")
            
            # Detect unique countries from metadata file
            logging.info("\n" + "=" * 80)
            logging.info("DETECTANDO PAÍSES EN LOS DATOS")
            logging.info("=" * 80)
            
            metadata_df = pd.read_excel(files_metadata_path)
            
            # Debug: Show metadata structure
            logging.info(f"Metadata columns: {metadata_df.columns.tolist()}")
            logging.info(f"Metadata records: {len(metadata_df)}")
            
            # Extract countries from source_region column (primary method)
            countries = set()
            
            if 'source_region' in metadata_df.columns:
                logging.info("Using 'source_region' column for country detection")
                unique_regions = metadata_df['source_region'].dropna().unique()
                logging.info(f"Unique regions found: {unique_regions.tolist()}")
                
                # Map region names to country names
                region_to_country = {
                    'Chile': 'Chile',
                    'Brazil': 'Brasil',
                    'Brasil': 'Brasil',
                    'Colombia': 'Colombia',
                    'Uruguay': 'Uruguay'
                }
                
                for region in unique_regions:
                    region_str = str(region).strip()
                    if region_str in region_to_country:
                        country = region_to_country[region_str]
                        countries.add(country)
                        logging.info(f"Mapped region '{region_str}' -> country '{country}'")
                    else:
                        logging.warning(f"Unknown region: {region_str}")
            
            # Fallback: Try to extract from destination_path if source_region didn't work
            if not countries and 'destination_path' in metadata_df.columns:
                logging.info("Fallback: Extracting countries from 'destination_path'")
                for dest_path in metadata_df['destination_path'].dropna():
                    # Extract first part of path (e.g., "Chile\root\..." -> "Chile")
                    path_parts = str(dest_path).split('\\')
                    if path_parts and path_parts[0] in ['Chile', 'Brasil', 'Brazil', 'Colombia', 'Uruguay']:
                        country = 'Brasil' if path_parts[0] == 'Brazil' else path_parts[0]
                        countries.add(country)
            
            # Last resort: Try filename prefixes
            if not countries:
                logging.info("Last resort: Checking for country prefixes in filenames")
                filename_columns = ['original_filename', 'file_name', 'display_name']
                
                for col in filename_columns:
                    if col in metadata_df.columns:
                        for filename in metadata_df[col].dropna():
                            country = self._extract_country_from_filename(filename)
                            if country:
                                countries.add(country)
                                logging.info(f"Found country '{country}' from filename prefix in '{col}'")
            
            if not countries:
                logging.warning("No se detectaron países en los datos de metadata.")
                logging.warning("Verifique que la columna 'source_region' contenga valores válidos: Chile, Brasil, Colombia, Uruguay")
                return False
            
            logging.info(f"Países detectados: {sorted(countries)}")
            logging.info(f"Total de países a procesar: {len(countries)}")
            logging.info("=" * 80 + "\n")
            
            # Process each country separately
            all_success = True
            results = {}
            
            for country in sorted(countries):
                logging.info(f"\n{'=' * 80}")
                logging.info(f"PROCESSING COUNTRY: {country}")
                logging.info(f"{'=' * 80}")
                
                # Reset LOBs list for each country to prevent cross-country contamination
                self.lobs_founded = []
                
                try:
                    # Create country-specific Excel report
                    country_excel_path = self._create_country_specific_resume_excel(
                        files_metadata_path, 
                        latest_pii_file, 
                        country
                    )
                    
                    if not country_excel_path:
                        logging.error(f"Could not create Excel file for {country}")
                        results[country] = "Error: Could not create Excel"
                        all_success = False
                        continue
                    
                    # Send country-specific email
                    success = self._send_country_specific_resume_email(
                        country_excel_path,
                        files_metadata_path,
                        latest_pii_file,
                        country
                    )
                    
                    if success:
                        logging.info(f"✓ Email sent successfully for {country}")
                        results[country] = "Sent successfully"
                    else:
                        logging.error(f"✗ Error sending email for {country}")
                        results[country] = "Error sending email"
                        all_success = False
                        
                except Exception as e:
                    logging.error(f"Error processing {country}: {e}")
                    results[country] = f"Error: {str(e)}"
                    all_success = False
            
            # Log final summary
            logging.info(f"\n{'=' * 80}")
            logging.info("COUNTRY-SPECIFIC EMAIL SENDING SUMMARY")
            logging.info(f"{'=' * 80}")
            for country, status in sorted(results.items()):
                logging.info(f"  {country}: {status}")
            logging.info(f"{'=' * 80}\n")
            
            return all_success
            
        except Exception as e:
            logging.error(f"Error sending country-specific summary emails: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return False

    def _create_resume_excel_report(self, files_metadata_path: str, pii_analysis_path: str) -> Optional[str]:
        """
        Crea archivo Excel de resumen integrando metadata y análisis PII.
        
        Args:
            files_metadata_path: Ruta al archivo files_metadata.xlsx
            pii_analysis_path: Ruta al archivo de análisis PII más reciente
            
        Returns:
            str: Ruta al archivo Excel generado, None si hay error
        """
        try:
            # Leer files_metadata.xlsx
            metadata_df = pd.read_excel(files_metadata_path)
            logging.info(f"Metadata load: {len(metadata_df)} files - shape: {metadata_df.shape}")
            logging.info(f"Metadata columns: {metadata_df.columns.tolist()}")
            
            # Leer análisis PII (hoja "Combined_PII_Results")
            pii_df = pd.read_excel(pii_analysis_path, sheet_name="Combined_PII_Results")
            logging.info(f"Analysis PII load: {len(pii_df)} detections - shape: {pii_df.shape}")
            
            # FOR RESUME EMAIL: Apply filtering for email notifications but use unfiltered data for statistics
            # Save original data for statistics calculation
            original_pii_df = pii_df.copy()
            original_count = len(pii_df)
            
            # Apply filtering for email notifications only (for Consolidado PII sheet)
            resume_excluded_types = set(self.email_excluded_pii_types or set())
            resume_excluded_sources = set(self.email_excluded_sources or set())
            
            # Create employee exclusion mask
            employee_mask = self._create_employee_exclusion_mask(pii_df)
            
            # Create exclusion mask for specific values (Cuenta, Centro de Costo)
            exclusion_values_mask = self._create_exclusion_mask_for_resume(pii_df)
            
            # Create individual exclusion masks for debugging
            type_exclusion_mask = pii_df["PII_Type"].isin(resume_excluded_types)
            source_exclusion_mask = pii_df["Source"].isin(resume_excluded_sources)
            
            filtered_df = pii_df[
                ~type_exclusion_mask & 
                ~source_exclusion_mask &
                ~employee_mask &  # Exclude employees
                ~exclusion_values_mask  # Exclude specific values from exclusiones.xlsx
            ]
            filtered_count = len(filtered_df)
            excluded_count = original_count - filtered_count
            employee_excluded_count = employee_mask.sum()
            exclusion_values_count = exclusion_values_mask.sum()
            type_excluded_count = type_exclusion_mask.sum()
            source_excluded_count = source_exclusion_mask.sum()
            other_excluded_count = excluded_count - employee_excluded_count - exclusion_values_count - type_excluded_count - source_excluded_count
            
            logging.info(f"Resume email filtering breakdown:")
            logging.info(f"  - PII Type exclusions: {type_excluded_count}")
            logging.info(f"  - Source exclusions: {source_excluded_count}")
            logging.info(f"  - Employee exclusions: {employee_excluded_count}")
            logging.info(f"  - Exclusion values (Cuenta/Centro de Costo): {exclusion_values_count}")
            logging.info(f"  - Other exclusions: {other_excluded_count}")
            logging.info(f"Resume excluded types: {list(resume_excluded_types)}")
            
            # Show what's being detected
            if original_count > 0:
                logging.info(f"PII Types distribution in original data: {pii_df['PII_Type'].value_counts().to_dict()}")
                logging.info(f"Sources distribution in original data: {pii_df['Source'].value_counts().to_dict()}")
            
            logging.info(f"Statistics will be calculated using FILTERED data ({filtered_count} entities)")
            
            if filtered_df.empty:
                logging.warning("No PII entities remain after filtering for Consolidado PII sheet")
                # Still create the report but with zero detections in Consolidado PII
                filtered_df = pii_df.head(0)  # Empty DataFrame with same columns
            
            # DEBUG: Verify PII data processing (using filtered data for statistics)
            logging.info("=== DEBUG PII DATA PROCESSING (FILTERED FOR STATS) ===")
            logging.info(f"Filtered PII DataFrame shape: {filtered_df.shape}")
            logging.info(f"Filtered PII DataFrame columns: {filtered_df.columns.tolist()}")
            if 'Folder' in filtered_df.columns:
                logging.info(f"Sample Folder values: {filtered_df['Folder'].head().tolist()}")
                logging.info(f"Unique folders count: {filtered_df['Folder'].nunique()}")
            logging.info("=== END DEBUG PII DATA PROCESSING (FILTERED FOR STATS) ===")
            
            # Helper function to clean filenames for matching
            def clean_filename_for_matching(filename):
                """Clean filename by removing automation suffixes, region prefixes, and extension"""
                if pd.isna(filename) or not filename:
                    return ''
                
                # Convert to string and get basename
                clean_name = os.path.basename(str(filename))
                
                # Remove region prefixes (Brasil - , Chile - , Colombia - , Uruguay - )
                region_prefixes = ['Brasil - ', 'Chile - ', 'Colombia - ', 'Uruguay - ']
                for prefix in region_prefixes:
                    if clean_name.startswith(prefix):
                        clean_name = clean_name[len(prefix):]
                        break
                
                # Remove anything after the first double-underscore "__" (most robust rule)
                if "__" in clean_name:
                    clean_name = clean_name.split("__", 1)[0]
                else:
                    # Fallback: remove a set of common automation suffixes if present
                    suffixes_to_remove = [
                        '_vfinal__modificado',
                        '__modificado',
                        '__nuevo_archivo',
                        '_vfinal',
                        '__processed',
                        '__updated'
                    ]
                    for suffix in suffixes_to_remove:
                        if suffix in clean_name:
                            clean_name = clean_name.split(suffix, 1)[0]
                            break
                
                # Only remove extension if it's a real file extension (has common file extensions)
                # This prevents treating "2." as having an extension
                common_extensions = ['.docx', '.pdf', '.xlsx', '.txt', '.doc', '.ppt', '.pptx']
                for ext in common_extensions:
                    if clean_name.lower().endswith(ext):
                        clean_name = clean_name[:-len(ext)]
                        break
                
                return clean_name.strip()
            
            # Extract and clean filename from 'Folder' column for matching USING FILTERED DATA
            logging.info("=== DEBUG FILENAME CLEANING PROCESS (FILTERED DATA FOR STATS) ===")
            filtered_df['Archivo_Base'] = filtered_df['Folder'].apply(clean_filename_for_matching)
            
            # Debug filename cleaning results
            if len(filtered_df) > 0:
                logging.info("Sample filename cleaning results:")
                for i, (original, cleaned) in enumerate(zip(filtered_df['Folder'].head(), filtered_df['Archivo_Base'].head())):
                    logging.info(f"  {i+1}: '{original}' -> '{cleaned}'")
            
            # Count detections by file using filtered data for statistics
            pii_counts = filtered_df.groupby('Archivo_Base')['PII_Type'].agg(['count', 'nunique']).reset_index()
            pii_counts.columns = ['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']
            
            logging.info(f"PII counts after groupby (FILTERED FOR STATS): {len(pii_counts)} unique files")
            logging.info(f"Sample pii_counts:\n{pii_counts.head()}")
            
            # Get PII types by file using filtered data
            pii_types_by_file = filtered_df.groupby('Archivo_Base')['PII_Type'].apply(lambda x: ', '.join(x.unique())).reset_index()
            pii_types_by_file.columns = ['Archivo_Base', 'Tipos_PII_Detectados']
            
            # Translate PII types in comma-separated strings to Spanish
            def translate_pii_types_string(pii_types_string):
                """Translate comma-separated PII types string to Spanish"""
                if pd.isna(pii_types_string) or pii_types_string == 'Ninguno':
                    return pii_types_string
                
                # Translation mapping
                pii_translation_map = {
                    "CUSTOMER_NAME": "Nombre de cliente",
                    "ContextualPersonName": "Nombre de cliente",
                    "SEQ_NUMBER": "Secuencia numerica", 
                    "DATE": "Fecha",
                    "AMOUNT": "Monto",
                    "Amount": "Monto",
                    "PHONE_NUMBER": "Telefono",
                    "PHONE": "Telefono", 
                    "Phone": "Telefono",
                    "NUMBERSEQUENCE": "Secuencia numerica",
                    "NumberSequence": "Secuencia numerica",
                    "PERSON": "Nombre de cliente",
                    "Person": "Nombre de cliente",
                    "RUT": "RUT",
                    "EMAIL": "Correo electronico",
                    "Address": "Direccion",
                    "ADDRESS": "Direccion",
                    "ID_NUMBER": "Numero de identificacion",
                    "CREDIT_CARD": "Tarjeta de credito",
                    "BANK_ACCOUNT": "Cuenta bancaria",
                    "SSN": "Numero de seguridad social",
                    "TAX_ID": "Numero tributario"
                }
                
                # Split by comma, translate each type, and join back
                try:
                    pii_types = [pii_type.strip() for pii_type in pii_types_string.split(',')]
                    translated_types = []
                    
                    for pii_type in pii_types:
                        translated = pii_translation_map.get(pii_type, pii_type)
                        translated_types.append(translated)
                    
                    return ', '.join(translated_types)
                except Exception as e:
                    logging.warning(f"Error translating PII types string '{pii_types_string}': {e}")
                    return pii_types_string
            
            # Apply translation to the PII types column
            pii_types_by_file['Tipos_PII_Detectados'] = pii_types_by_file['Tipos_PII_Detectados'].apply(translate_pii_types_string)
            
            logging.info(f"PII types by file (FILTERED & TRANSLATED): {len(pii_types_by_file)} entries")
            logging.info("=== END DEBUG FILENAME CLEANING PROCESS (FILTERED DATA FOR STATS) ===")
            
            # Preparar datos para merge
            # Crear columns compatibles con metadata actual - Files_metadata.xlsx

            metadata_df['file_name'] = metadata_df['original_filename']  # Use 'original_filename' column
            metadata_df['folder_name'] = metadata_df['source_folder'] if 'source_folder' in metadata_df.columns else metadata_df['source_region']
            
            # Calculate file size in MB from existing size_bytes column or file path
            def get_file_size_mb(row):
                try:
                    # First try to use size_bytes column if available
                    if 'size_bytes' in row.index and pd.notna(row['size_bytes']):
                        return round(row['size_bytes'] / (1024 * 1024), 2)
                    # Fallback to checking source_full_path
                    elif 'source_full_path' in row.index and pd.notna(row['source_full_path']) and os.path.exists(row['source_full_path']):
                        size_bytes = os.path.getsize(row['source_full_path'])
                        return round(size_bytes / (1024 * 1024), 2)
                    return 0.0
                except:
                    return 0.0
            
            metadata_df['file_size_mb'] = metadata_df.apply(get_file_size_mb, axis=1)
            metadata_df['modification_date'] = metadata_df['last_modified'] if 'last_modified' in metadata_df.columns else ''
            
            # Crear claves para merge - extraer nombre base del archivo de metadata también
            metadata_df['Archivo_Base'] = metadata_df['file_name'].apply(clean_filename_for_matching)
            
            # DEBUG: Verify metadata processing
            logging.info("=== DEBUG METADATA PROCESSING ===")
            logging.info(f"Metadata DataFrame shape: {metadata_df.shape}")
            logging.info(f"Metadata columns: {metadata_df.columns.tolist()}")
            logging.info(f"'Control de version' in metadata_df: {'Control de version' in metadata_df.columns}")
            if 'Control de version' in metadata_df.columns:
                version_data = metadata_df['Control de version'].dropna()
                logging.info(f"Metadata version control data: {len(version_data)} entries with values: {list(version_data.unique())}")
            if len(metadata_df) > 0:
                logging.info("Sample metadata filename cleaning:")
                for i, (original, cleaned) in enumerate(zip(metadata_df['file_name'].head(), metadata_df['Archivo_Base'].head())):
                    logging.info(f"  {i+1}: '{original}' -> '{cleaned}'")
            logging.info("=== END DEBUG METADATA PROCESSING ===")
            
            # Agregar logging para debug del matching
            logging.info(f"Archivos únicos en metadata: {metadata_df['Archivo_Base'].nunique()}")
            logging.info(f"Archivos únicos en PII: {len(pii_counts)}")
            logging.info(f"Muestra de nombres base PII: {pii_counts['Archivo_Base'].head().tolist()}")
            logging.info(f"Muestra de nombres base metadata: {metadata_df['Archivo_Base'].head().tolist()}")

            # Hacer join usando la clave común 'Archivo_Base'
            logging.info("=== DEBUG MERGE PROCESS (FILTERED DATA FOR STATS) ===")
            logging.info(f"Before merge - metadata_df shape: {metadata_df.shape}")
            logging.info(f"Before merge - pii_counts (filtered) shape: {pii_counts.shape}")
            logging.info(f"Sample metadata Archivo_Base: {metadata_df['Archivo_Base'].head().tolist()}")
            logging.info(f"Sample pii_counts Archivo_Base: {pii_counts['Archivo_Base'].head().tolist()}")
            
            # First merge
            enriched_df = metadata_df.merge(pii_counts[['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']], 
                                        on='Archivo_Base', how='left')
            
            logging.info(f"After first merge - enriched_df shape: {enriched_df.shape}")
            logging.info(f"'Control de version' in enriched_df: {'Control de version' in enriched_df.columns}")
            if 'Control de version' in enriched_df.columns:
                version_data = enriched_df['Control de version'].dropna()
                logging.info(f"Version control data found: {len(version_data)} entries with values: {list(version_data.unique())}")
            logging.info(f"Total_Detecciones null count: {enriched_df['Total_Detecciones'].isna().sum()}")
            logging.info(f"Total_Detecciones > 0 count (before fillna): {(enriched_df['Total_Detecciones'] > 0).sum()}")
            
            # Check for successful matches
            successful_merges = enriched_df[enriched_df['Total_Detecciones'].notna()]
            if len(successful_merges) > 0:
                logging.info(f"Successful merges (FILTERED DATA): {len(successful_merges)}")
                for idx, row in successful_merges.head(3).iterrows():
                    logging.info(f"  Match: '{row['Archivo_Base']}' -> {row['Total_Detecciones']} detections")
            else:
                logging.error("NO SUCCESSFUL MERGES! Checking key mismatches...")
                # Compare keys
                meta_keys = set(metadata_df['Archivo_Base'].tolist())
                pii_keys = set(pii_counts['Archivo_Base'].tolist())
                common_keys = meta_keys & pii_keys
                logging.error(f"Metadata unique keys: {len(meta_keys)}")
                logging.error(f"PII unique keys: {len(pii_keys)}")
                logging.error(f"Common keys: {len(common_keys)}")
                if common_keys:
                    logging.info(f"Sample common keys: {list(common_keys)[:5]}")
                else:
                    logging.error(f"Sample metadata keys: {list(meta_keys)[:5]}")
                    logging.error(f"Sample PII keys: {list(pii_keys)[:5]}")
            
            # Second merge
            enriched_df = enriched_df.merge(pii_types_by_file[['Archivo_Base', 'Tipos_PII_Detectados']], 
                                          on='Archivo_Base', how='left')
            
            logging.info(f"After second merge - enriched_df shape: {enriched_df.shape}")
            logging.info("=== END DEBUG MERGE PROCESS (FILTERED DATA FOR STATS) ===")
            
            # Llenar valores nulos
            enriched_df['Total_Detecciones'] = enriched_df['Total_Detecciones'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Unicos'] = enriched_df['Tipos_PII_Unicos'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Detectados'] = enriched_df['Tipos_PII_Detectados'].fillna('Ninguno')
            
            # Ensure version control column exists in enriched_df
            if 'Control de version' not in enriched_df.columns:
                enriched_df['Control de version'] = ''
            
            # Reordenar columnas
            columns_order = ['file_name', 'folder_name', 'file_size_mb', 'modification_date', 
                           'Total_Detecciones', 'Tipos_PII_Unicos', 'Tipos_PII_Detectados', 'Control de version']
            
            # Agregar columnas faltantes si existen en el DataFrame
            available_columns = [col for col in columns_order if col in enriched_df.columns]
            final_df = enriched_df[available_columns]
            
            # Version control should already be in enriched_df from metadata merge
            # Only call _add_version_control_from_metadata if the column is empty or missing
            if 'Control de version' not in final_df.columns or final_df['Control de version'].isna().all():
                final_df = self._add_version_control_from_metadata(final_df)
            
            
            #################################################################################
            # Rename output columns for the resume Excel (adjust display names as needed)
            rename_map = {
                "file_name": "Archivo",          
                "folder_name": "Carpeta",
                "file_size_mb": "Tamaño MB",
                "modification_date": "Fecha Modificación",
                "Total_Detecciones": "Total Detecciones",
                "Tipos_PII_Unicos": "Tipos PII Únicos",
                "Tipos_PII_Detectados": "Tipos PII Detectados",
                "Control de version": "Control de version"
            }
            # Only rename columns that actually exist to avoid KeyErrors
            rename_map = {k: v for k, v in rename_map.items() if k in final_df.columns}
            if rename_map:
                final_df = final_df.rename(columns=rename_map)
            #################################################################################
            
            # Generar estadísticas de resumen usando datos NO FILTRADOS para estadísticas precisas
            summary_stats = self._generate_resume_summary_stats(enriched_df, pii_counts)
            
            # Crear archivo Excel con formato
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            resume_filename = f"Resumen_Archivos_PII_{timestamp}.xlsx"
            
            # Obtener ruta de output de forma segura
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                # Si es ruta relativa, hacerla absoluta desde el directorio del proyecto
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            # Asegurar que el directorio existe
            os.makedirs(output_dir, exist_ok=True)
            
            resume_path = os.path.join(output_dir, resume_filename)
            logging.info(f"Creando archivo Excel de resumen en: {resume_path}")
            
            with pd.ExcelWriter(resume_path, engine='openpyxl') as writer:
                # Hoja 1: Datos enriquecidos
                final_df.to_excel(writer, sheet_name='Resumen Archivos', index=False)
                
                # Hoja 2: Estadísticas (usando datos no filtrados)
                summary_stats.to_excel(writer, sheet_name='Estadísticas Resumen', index=False)
                
                # Hoja 3: Detalle consolidado de PII (usar datos FILTRADOS para emails)
                try:
                    if not filtered_df.empty:
                        # Add version control information to filtered data first
                        filtered_df = self._add_version_control_from_metadata(filtered_df)
                        
                        # Seleccionar columnas relevantes para exportar (solo las que existan)
                        pii_export_cols = [col for col in ['File', 'Folder', 'Page', 'PII_Type', 'PII_Value', 'Label', 'Control de version'] if col in filtered_df.columns]
                        
                        if pii_export_cols:
                            pii_results_export = filtered_df[pii_export_cols].copy()
                            
                            # Renombrar columnas para mejor legibilidad en español
                            rename_map_pii = {
                                'File': 'Archivo',
                                'Folder': 'Documento revisado',
                                'PII_Type': 'Tipo de PII',
                                'PII_Value': 'Valor PII',
                                'Page': 'Página',
                                'Label': 'Tipo de Dato',
                                'Control de version': 'Control de version'
                            }
                            
                            # Solo renombrar columnas que existen
                            rename_map_final = {k: v for k, v in rename_map_pii.items() if k in pii_results_export.columns}
                            if rename_map_final:
                                pii_results_export = pii_results_export.rename(columns=rename_map_final)
                                
                            
                            mapping = {
                            # Primary mappings for common PII types
                            "CUSTOMER_NAME": "Nombre de cliente",
                            "SEQ_NUMBER": "Secuencia numerica", 
                            "DATE": "Fecha",
                            "AMOUNT": "Monto",
                            "Amount": "Monto",
                            "PHONE_NUMBER": "Telefono",
                            "PHONE": "Telefono", 
                            "Phone": "Telefono",
                            "NumberSequence": "Secuencia numerica",
                            "NUMBERSEQUENCE": "Secuencia numerica",
                            "Person": "Nombre de cliente",
                            "PERSON": "Nombre de cliente",
                            "RUT": "RUT",
                            
                            # Additional comprehensive mappings
                            "EMAIL": "Correo electronico",
                            "Email": "Correo electronico",
                            "DOCUMENT": "Documento",
                            "Document": "Documento",
                            "ID": "Identificacion",
                            "IDENTIFICATION": "Identificacion",
                            "ADDRESS": "Direccion",
                            "Address": "Direccion",
                            "NAME": "Nombre",
                            "Name": "Nombre",
                            "CREDIT_CARD": "Tarjeta de credito",
                            "CreditCard": "Tarjeta de credito",
                            "ACCOUNT": "Cuenta",
                            "Account": "Cuenta",
                            "BANK": "Banco",
                            "Bank": "Banco"
                            }
                            
                            if "Tipo de PII" in pii_results_export.columns:
                                pii_results_export['Tipo de PII'] = pii_results_export['Tipo de PII'].map(mapping).fillna(pii_results_export['Tipo de PII'])

                            mapping_tag = {'TextData': 'Datos Texto', 'SequenceNumber': 'Datos numericos'}
                            if "Tipo de Dato" in pii_results_export.columns:
                                pii_results_export['Tipo de Dato'] = pii_results_export['Tipo de Dato'].map(mapping_tag).fillna(pii_results_export['Tipo de Dato'])

                            # Exportar a nueva hoja
                            pii_results_export.to_excel(writer, sheet_name='Consolidado PII', index=False)
                            logging.info(f"Added Consolidado PII sheet with {len(pii_results_export)} records")
                        else:
                            logging.warning("No suitable columns found for Consolidado PII sheet")
                    else:
                        logging.info("No PII data to export to Consolidado PII sheet (filtered_df is empty)")
                except Exception as e:
                    logging.warning(f"No se pudo añadir hoja 'PII_Results' al resumen: {e}")
                
                # Aplicar formato
                self._format_resume_excel_sheets(writer, final_df, summary_stats)
            
            logging.info(f"Resume Excel report created: {resume_path}")
            logging.info(f"Statistics calculated from FILTERED data ({filtered_count} entities)")
            logging.info(f"Consolidado PII sheet contains same FILTERED data ({filtered_count} entities, {excluded_count} excluded from total)")
            return resume_path
            
        except Exception as e:
            logging.error(f"Error creando archivo Excel de resumen: {e}")
            return None

    def _create_country_specific_resume_excel(self, files_metadata_path: str, 
                                              pii_analysis_path: str, 
                                              country: str) -> Optional[str]:
        """
        Crea archivo Excel de resumen filtrado por país específico.
        
        Args:
            files_metadata_path: Ruta al archivo files_metadata.xlsx
            pii_analysis_path: Ruta al archivo de análisis PII más reciente
            country: Nombre del país a filtrar ("Brasil", "Chile", "Colombia", "Uruguay")
            
        Returns:
            str: Ruta al archivo Excel generado, None si hay error
        """
        try:
            logging.info(f"Creating summary Excel for country: {country}")
            
            # Read metadata and filter by country
            metadata_df = pd.read_excel(files_metadata_path)
            logging.info(f"Total metadata records: {len(metadata_df)}")
            
            # Map country name to region name (reverse mapping)
            country_to_region = {
                'Chile': 'Chile',
                'Brasil': 'Brazil',  # Note: metadata uses 'Brazil' but we use 'Brasil'
                'Colombia': 'Colombia',
                'Uruguay': 'Uruguay'
            }
            
            region_name = country_to_region.get(country, country)
            logging.info(f"Filtering by country '{country}' mapped to region '{region_name}'")
            
            # Filter metadata by source_region column
            if 'source_region' in metadata_df.columns:
                # Try both the country name and region name
                metadata_df = metadata_df[
                    (metadata_df['source_region'].astype(str) == region_name) |
                    (metadata_df['source_region'].astype(str) == country)
                ].copy()
                logging.info(f"Filtered metadata by source_region: {len(metadata_df)} records")
            else:
                # Fallback: Filter by destination_path
                if 'destination_path' in metadata_df.columns:
                    metadata_df = metadata_df[
                        metadata_df['destination_path'].astype(str).str.startswith(f"{region_name}\\")
                    ].copy()
                    logging.info(f"Filtered metadata by destination_path: {len(metadata_df)} records")
            
            logging.info(f"Filtered metadata records for {country}: {len(metadata_df)}")
            
            if metadata_df.empty:
                logging.warning(f"No metadata found for country: {country}")
                return None
            
            # Get list of filenames for this country to filter PII data
            country_filenames = set(metadata_df['original_filename'].dropna().tolist())
            logging.info(f"Country filenames to match: {len(country_filenames)}")
            logging.info(f"Sample country filenames: {list(country_filenames)[:3]}")
            
            # Read PII analysis and filter by country
            pii_df = pd.read_excel(pii_analysis_path, sheet_name="Combined_PII_Results")
            logging.info(f"Total PII records: {len(pii_df)}")
            
            # Debug: Show sample Folder values
            if 'Folder' in pii_df.columns and len(pii_df) > 0:
                logging.info(f"Sample PII Folder values: {pii_df['Folder'].unique().tolist()[:3]}")
            
            # Filter PII data by country prefix in Folder column
            # The Folder column contains values like "Chile - 123.1-Gestión mandatos físicos PAC"
            # We filter by checking if the Folder starts with the country prefix
            if 'Folder' in pii_df.columns:
                # Country prefixes to check
                country_prefixes = {
                    'Chile': ['Chile - ', 'Chile-'],
                    'Brasil': ['Brasil - ', 'Brasil-', 'Brazil - ', 'Brazil-'],
                    'Colombia': ['Colombia - ', 'Colombia-'],
                    'Uruguay': ['Uruguay - ', 'Uruguay-']
                }
                
                prefixes_to_check = country_prefixes.get(country, [f"{country} - ", f"{country}-"])
                logging.info(f"Filtering PII data by prefixes: {prefixes_to_check}")
                
                # Create mask for rows that match any of the country prefixes
                mask = pd.Series([False] * len(pii_df))
                for prefix in prefixes_to_check:
                    mask = mask | pii_df['Folder'].astype(str).str.startswith(prefix)
                
                pii_df = pii_df[mask].copy()
                logging.info(f"PII records after country filter: {len(pii_df)}")
            
            logging.info(f"Filtered PII records for {country}: {len(pii_df)}")
            
            # Save original count before filtering
            original_pii_df = pii_df.copy()
            original_count = len(pii_df)
            
            # Apply PII filtering (same as original method)
            resume_excluded_types = set(self.email_excluded_pii_types or set())
            resume_excluded_sources = set(self.email_excluded_sources or set())
            
            employee_mask = self._create_employee_exclusion_mask(pii_df)
            exclusion_values_mask = self._create_exclusion_mask_for_resume(pii_df)
            type_exclusion_mask = pii_df["PII_Type"].isin(resume_excluded_types) if "PII_Type" in pii_df.columns else pd.Series([False] * len(pii_df))
            source_exclusion_mask = pii_df["Source"].isin(resume_excluded_sources) if "Source" in pii_df.columns else pd.Series([False] * len(pii_df))
            
            filtered_df = pii_df[
                ~type_exclusion_mask & 
                ~source_exclusion_mask &
                ~employee_mask &
                ~exclusion_values_mask
            ].copy()
            
            filtered_count = len(filtered_df)
            excluded_count = original_count - filtered_count
            
            logging.info(f"Country {country} - Filtered PII: {filtered_count}, Excluded: {excluded_count}")
            
            if filtered_df.empty:
                logging.warning(f"No PII entities remain after filtering for {country}")
                filtered_df = pii_df.head(0)
            
            # Helper function to clean filenames (same as original)
            def clean_filename_for_matching(filename):
                if pd.isna(filename) or not filename:
                    return ''
                clean_name = os.path.basename(str(filename))
                region_prefixes = ['Brasil - ', 'Chile - ', 'Colombia - ', 'Uruguay - ']
                for prefix in region_prefixes:
                    if clean_name.startswith(prefix):
                        clean_name = clean_name[len(prefix):]
                        break
                if "__" in clean_name:
                    clean_name = clean_name.split("__", 1)[0]
                common_extensions = ['.docx', '.pdf', '.xlsx', '.txt', '.doc', '.ppt', '.pptx']
                for ext in common_extensions:
                    if clean_name.lower().endswith(ext):
                        clean_name = clean_name[:-len(ext)]
                        break
                return clean_name.strip()
            
            # Process filtered data
            filtered_df['Archivo_Base'] = filtered_df['Folder'].apply(clean_filename_for_matching)
            
            # Count detections by file
            pii_counts = filtered_df.groupby('Archivo_Base')['PII_Type'].agg(['count', 'nunique']).reset_index()
            pii_counts.columns = ['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']
            
            # Get PII types by file
            pii_types_by_file = filtered_df.groupby('Archivo_Base')['PII_Type'].apply(
                lambda x: ', '.join(x.unique())
            ).reset_index()
            pii_types_by_file.columns = ['Archivo_Base', 'Tipos_PII_Detectados']
            
            # Translate PII types (reuse translation function from original method)
            def translate_pii_types_string(pii_types_string):
                if pd.isna(pii_types_string) or pii_types_string == 'Ninguno':
                    return pii_types_string
                pii_translation_map = {
                    "CUSTOMER_NAME": "Nombre de cliente",
                    "ContextualPersonName": "Nombre de cliente",
                    "SEQ_NUMBER": "Secuencia numerica",
                    "DATE": "Fecha",
                    "AMOUNT": "Monto",
                    "PHONE_NUMBER": "Telefono",
                    "PHONE": "Telefono",
                    "NUMBERSEQUENCE": "Secuencia numerica",
                    "PERSON": "Nombre de cliente",
                    "RUT": "RUT",
                    "EMAIL": "Correo electronico",
                    "ADDRESS": "Direccion"
                }
                try:
                    pii_types = [pii_type.strip() for pii_type in pii_types_string.split(',')]
                    translated_types = [pii_translation_map.get(pii_type, pii_type) for pii_type in pii_types]
                    return ', '.join(translated_types)
                except Exception as e:
                    return pii_types_string
            
            pii_types_by_file['Tipos_PII_Detectados'] = pii_types_by_file['Tipos_PII_Detectados'].apply(
                translate_pii_types_string
            )
            
            # Process metadata
            metadata_df['file_name'] = metadata_df['original_filename']
            metadata_df['folder_name'] = metadata_df['source_folder'] if 'source_folder' in metadata_df.columns else metadata_df['source_region']
            
            def get_file_size_mb(row):
                try:
                    if 'size_bytes' in row.index and pd.notna(row['size_bytes']):
                        return round(row['size_bytes'] / (1024 * 1024), 2)
                    elif 'source_full_path' in row.index and pd.notna(row['source_full_path']) and os.path.exists(row['source_full_path']):
                        size_bytes = os.path.getsize(row['source_full_path'])
                        return round(size_bytes / (1024 * 1024), 2)
                    return 0.0
                except:
                    return 0.0
            
            metadata_df['file_size_mb'] = metadata_df.apply(get_file_size_mb, axis=1)
            metadata_df['modification_date'] = metadata_df['last_modified'] if 'last_modified' in metadata_df.columns else ''
            metadata_df['Archivo_Base'] = metadata_df['file_name'].apply(clean_filename_for_matching)
            
            # Merge metadata with PII counts
            enriched_df = metadata_df.merge(
                pii_counts[['Archivo_Base', 'Total_Detecciones', 'Tipos_PII_Unicos']], 
                on='Archivo_Base', 
                how='left'
            )
            enriched_df = enriched_df.merge(
                pii_types_by_file[['Archivo_Base', 'Tipos_PII_Detectados']], 
                on='Archivo_Base', 
                how='left'
            )
            
            # Fill null values
            enriched_df['Total_Detecciones'] = enriched_df['Total_Detecciones'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Unicos'] = enriched_df['Tipos_PII_Unicos'].fillna(0).astype(int)
            enriched_df['Tipos_PII_Detectados'] = enriched_df['Tipos_PII_Detectados'].fillna('Ninguno')
            
            if 'Control de version' not in enriched_df.columns:
                enriched_df['Control de version'] = ''
            
            # Select and rename columns
            columns_order = ['file_name', 'folder_name', 'file_size_mb', 'modification_date', 
                           'Total_Detecciones', 'Tipos_PII_Unicos', 'Tipos_PII_Detectados', 'Control de version']
            available_columns = [col for col in columns_order if col in enriched_df.columns]
            final_df = enriched_df[available_columns]
            
            if 'Control de version' not in final_df.columns or final_df['Control de version'].isna().all():
                final_df = self._add_version_control_from_metadata(final_df)
            
            # Rename columns to Spanish
            rename_map = {
                "file_name": "Archivo",
                "folder_name": "Carpeta",
                "file_size_mb": "Tamaño MB",
                "modification_date": "Fecha Modificación",
                "Total_Detecciones": "Total Detecciones",
                "Tipos_PII_Unicos": "Tipos PII Únicos",
                "Tipos_PII_Detectados": "Tipos PII Detectados",
                "Control de version": "Control de version"
            }
            rename_map = {k: v for k, v in rename_map.items() if k in final_df.columns}
            if rename_map:
                final_df = final_df.rename(columns=rename_map)
            
            # Generate summary stats
            summary_stats = self._generate_resume_summary_stats(enriched_df, pii_counts)
            
            # Create Excel file with country in filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            resume_filename = f"Resumen_Archivos_PII_{country}_{timestamp}.xlsx"
            
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            os.makedirs(output_dir, exist_ok=True)
            resume_path = os.path.join(output_dir, resume_filename)
            
            logging.info(f"Creating summary Excel file for {country} at: {resume_path}")
            
            with pd.ExcelWriter(resume_path, engine='openpyxl') as writer:
                # Sheet 1: Enriched files
                final_df.to_excel(writer, sheet_name='Resumen Archivos', index=False)
                
                # Sheet 2: Summary stats
                summary_stats.to_excel(writer, sheet_name='Estadísticas Resumen', index=False)
                
                # Sheet 3: Consolidated PII (filtered)
                try:
                    if not filtered_df.empty:
                        filtered_df = self._add_version_control_from_metadata(filtered_df)
                        pii_export_cols = [col for col in ['File', 'Folder', 'Page', 'PII_Type', 'PII_Value', 'Label', 'Control de version'] if col in filtered_df.columns]
                        
                        if pii_export_cols:
                            pii_results_export = filtered_df[pii_export_cols].copy()
                            rename_map_pii = {
                                'File': 'Archivo',
                                'Folder': 'Documento revisado',
                                'PII_Type': 'Tipo de PII',
                                'PII_Value': 'Valor PII',
                                'Page': 'Página',
                                'Label': 'Tipo de Dato',
                                'Control de version': 'Control de version'
                            }
                            rename_map_final = {k: v for k, v in rename_map_pii.items() if k in pii_results_export.columns}
                            if rename_map_final:
                                pii_results_export = pii_results_export.rename(columns=rename_map_final)
                            
                            # Translate PII types
                            mapping = {
                                "CUSTOMER_NAME": "Nombre de cliente",
                                "SEQ_NUMBER": "Secuencia numerica",
                                "DATE": "Fecha",
                                "AMOUNT": "Monto",
                                "PHONE_NUMBER": "Telefono",
                                "PHONE": "Telefono",
                                "NUMBERSEQUENCE": "Secuencia numerica",
                                "PERSON": "Nombre de cliente",
                                "RUT": "RUT",
                                "EMAIL": "Correo electronico",
                                "ADDRESS": "Direccion"
                            }
                            if "Tipo de PII" in pii_results_export.columns:
                                pii_results_export['Tipo de PII'] = pii_results_export['Tipo de PII'].map(mapping).fillna(pii_results_export['Tipo de PII'])
                            
                            mapping_tag = {'TextData': 'Datos Texto', 'SequenceNumber': 'Datos numericos'}
                            if "Tipo de Dato" in pii_results_export.columns:
                                pii_results_export['Tipo de Dato'] = pii_results_export['Tipo de Dato'].map(mapping_tag).fillna(pii_results_export['Tipo de Dato'])
                            
                            pii_results_export.to_excel(writer, sheet_name='Consolidado PII', index=False)
                            logging.info(f"Added Consolidado PII sheet with {len(pii_results_export)} records for {country}")
                except Exception as e:
                    logging.warning(f"Could not add 'Consolidado PII' sheet to {country} summary: {e}")
                
                # Apply formatting
                self._format_resume_excel_sheets(writer, final_df, summary_stats)
            
            logging.info(f"Resume Excel report for {country} created: {resume_path}")
            return resume_path
            
        except Exception as e:
            logging.error(f"Error creating summary Excel file for {country}: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return None

    def _extract_lobs_from_folders(self, folder_names: list, country: str) -> list:
        """
        Extract LOBs from folder names by matching against 'Listado encargados Chile.xlsx'.
        
        Args:
            folder_names: List of folder names to match (e.g., "Chile - 123.1-Gestión mandatos")
            country: Country name to determine sheet name
            
        Returns:
            list: List of unique LOBs found for the given folders
        """
        try:
            if not folder_names:
                logging.info(f"No folder names provided for LOB extraction")
                return []
            
            # Get project root
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            # Build path to the manager list file
            manager_list_path = os.path.join(project_root, "input", "Listado encargados Chile.xlsx")
            
            if not os.path.exists(manager_list_path):
                logging.warning(f"Manager list file not found: {manager_list_path}")
                return []
            
            # Get sheet name for country
            sheet_name = self.country_detector.get_sheet_name(country)
            logging.info(f"Extracting LOBs for country '{country}' from sheet '{sheet_name}'")
            
            # Read the Excel file
            try:
                df_managers = pd.read_excel(manager_list_path, sheet_name=sheet_name)
            except Exception as e:
                logging.warning(f"Could not read sheet '{sheet_name}': {e}. Trying 'Chile' sheet...")
                df_managers = pd.read_excel(manager_list_path, sheet_name='Chile')
            
            # Verify required columns
            if 'Documento' not in df_managers.columns or 'Lob' not in df_managers.columns:
                logging.error(f"Required columns 'Documento' or 'Lob' not found. Available: {df_managers.columns.tolist()}")
                return []
            
            lobs_found = []
            matched_folders = []
            
            # Clean folder names and match against manager list
            for folder_name in folder_names:
                clean_folder = self._clean_filename_for_matching(str(folder_name))
                
                for idx, row in df_managers.iterrows():
                    nombre_documento = row['Documento']
                    if pd.isna(nombre_documento):
                        continue
                    clean_manager_folder = self._clean_filename_for_matching(str(nombre_documento))
                    
                    if clean_manager_folder.lower() == clean_folder.lower():
                        lob = row['Lob']
                        if lob is not None and not pd.isna(lob):
                            lob_str = str(lob).strip()
                            if lob_str and lob_str not in lobs_found:
                                lobs_found.append(lob_str)
                                matched_folders.append(folder_name)
                                logging.debug(f"Matched folder '{folder_name}' -> LOB '{lob_str}'")
                        break
            
            logging.info(f"Extracted {len(lobs_found)} unique LOBs from {len(matched_folders)} matched folders")
            logging.info(f"LOBs found: {lobs_found}")
            
            return lobs_found
            
        except Exception as e:
            logging.error(f"Error extracting LOBs from folders: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return []

    def _get_lob_based_emails(self, country: str) -> list:
        """
        Get email recipients based on LOBs found during processing.
        Reads from glosa_lobs.xlsx, filters by PAIS and LOB columns.
        
        Args:
            country: Country name ("Brasil", "Chile", "Colombia", "Uruguay")
            
        Returns:
            list: List of unique email addresses from RESPONSABLE column
        """
        try:
            if not self.lobs_founded:
                logging.info(f"No LOBs found for country {country}, skipping LOB-based email lookup")
                return []
            
            # Build path to glosa_lobs.xlsx
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            glosa_lobs_path = os.path.join(project_root, "input", "glosa_lobs.xlsx")
            
            if not os.path.exists(glosa_lobs_path):
                logging.warning(f"glosa_lobs.xlsx not found at: {glosa_lobs_path}")
                return []
            
            # Read the Excel file
            df_glosa = pd.read_excel(glosa_lobs_path)
            logging.info(f"Loaded glosa_lobs.xlsx: {len(df_glosa)} rows")
            logging.info(f"LOBs to search for country {country}: {list(set(self.lobs_founded))}")
            
            # Verify required columns exist
            required_columns = ['LOB', 'RESPONSABLE', 'PAIS']
            missing_columns = [col for col in required_columns if col not in df_glosa.columns]
            if missing_columns:
                logging.error(f"Missing columns in glosa_lobs.xlsx: {missing_columns}")
                return []
            
            # Filter by country (PAIS) AND LOB
            filtered_df = df_glosa[
                (df_glosa['PAIS'].astype(str).str.strip() == country) &
                (df_glosa['LOB'].isin(self.lobs_founded))
            ]
            
            logging.info(f"Matched {len(filtered_df)} rows for country '{country}' with LOBs: {list(set(self.lobs_founded))}")
            
            if filtered_df.empty:
                logging.info(f"No LOB matches found for country {country}")
                return []
            
            # Extract emails from RESPONSABLE column (handle semicolon-separated values)
            lob_emails = []
            for responsable in filtered_df['RESPONSABLE'].dropna():
                # Split by semicolon in case of multiple emails
                emails = str(responsable).split(';')
                for email in emails:
                    email_clean = email.strip()
                    if email_clean and '@' in email_clean:
                        lob_emails.append(email_clean)
            
            # Remove duplicates while preserving order
            unique_lob_emails = list(dict.fromkeys(lob_emails))
            logging.info(f"LOB-based emails for {country}: {unique_lob_emails}")
            
            return unique_lob_emails
            
        except Exception as e:
            logging.error(f"Error getting LOB-based emails for {country}: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return []

    def _send_country_specific_resume_email(self, resume_excel_path: str, 
                                           metadata_path: str, 
                                           pii_path: str,
                                           country: str) -> bool:
        """
        Sends summary email for a specific country.
        
        Args:
            resume_excel_path: Path to country summary Excel file
            metadata_path: Path to files_metadata.xlsx file
            pii_path: Path to PII analysis file
            country: Country name ("Brasil", "Chile", "Colombia", "Uruguay")
            
        Returns:
            bool: True if email sent successfully, False otherwise
        """
        try:
            logging.info(f"Sending summary email for country: {country}")
            
            # Map country to sheet name using country_detector
            sheet_name = self.country_detector.get_sheet_name(country)
            logging.info(f"Country '{country}' mapped to sheet: '{sheet_name}'")
            
            # Get manager emails for this country's sheet
            manager_emails = self._get_manager_emails(sheet_name=sheet_name)
            
            if not manager_emails:
                logging.warning(f"No manager emails found for {country} (sheet: {sheet_name})")
                # Fallback to default email
                manager_emails = ["andres.n.vera@provida.cl"]
                logging.info(f"Using default email: {manager_emails}")
            
            # Read summary data from Excel to generate email content
            df_resumen = pd.read_excel(resume_excel_path, sheet_name='Resumen Archivos')
            
            # Extract folder names from the 'Archivo' column to get LOBs
            folder_names = []
            if 'Archivo' in df_resumen.columns:
                folder_names = df_resumen['Archivo'].dropna().unique().tolist()
                logging.info(f"Found {len(folder_names)} unique folders for LOB extraction")
            
            # Extract LOBs from folder names by matching against Listado encargados
            self.lobs_founded = self._extract_lobs_from_folders(folder_names, country)
            logging.info(f"Populated lobs_founded with {len(self.lobs_founded)} LOBs: {self.lobs_founded}")
            
            # Get LOB-based emails and merge with manager emails (deduplicated)
            lob_emails = self._get_lob_based_emails(country)
            if lob_emails:
                logging.info(f"Adding {len(lob_emails)} LOB-based recipients for {country}")
                # Merge and deduplicate emails (case-insensitive)
                all_emails_lower = {email.lower(): email for email in manager_emails}
                for email in lob_emails:
                    if email.lower() not in all_emails_lower:
                        all_emails_lower[email.lower()] = email
                manager_emails = list(all_emails_lower.values())
                logging.info(f"Combined recipients for {country} (deduplicated): {manager_emails}")
            
            logging.info(f"Final recipients for {country}: {manager_emails}")
            df_stats = pd.read_excel(resume_excel_path, sheet_name='Estadísticas Resumen')
            
            # Extract key statistics
            total_files = len(df_resumen)
            files_with_pii = len(df_resumen[df_resumen['Total Detecciones'] > 0]) if 'Total Detecciones' in df_resumen.columns else 0
            total_detections = int(df_resumen['Total Detecciones'].sum()) if 'Total Detecciones' in df_resumen.columns else 0
            percentage_with_pii = f"{(files_with_pii/total_files*100):.1f}%" if total_files > 0 else "0%"
            
            # Determine risk level based on PII exposure
            risk_level = self._assess_pii_risk_level(files_with_pii, total_files, total_detections)
            
            # Generate email subject with country (matching original format)
            timestamp = datetime.now().strftime("%d/%m/%Y")
            subject = f"Informe Ejecutivo - Análisis de Riesgos PII - {risk_level['label']} - {timestamp} - {country}"
            
            # Generate strategic recommendations using template manager
            strategic_recommendations = self.template_manager.generate_recommendations_html(risk_level['label'])
            
            # Define risk level inline styles for email compatibility
            risk_styles = {
                "RIESGO BAJO": "background-color: #28a745; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;",
                "RIESGO MODERADO": "background-color: #ffc107; color: #212529; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;",
                "RIESGO ALTO": "background-color: #dc3545; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;"
            }
            
            # Calculate percentage color style
            percentage_color_style = self.template_manager.get_percentage_color_style(percentage_with_pii)
            
            # Prepare template variables for country-specific email
            template_vars = {
                "subject": subject,
                "timestamp": timestamp,
                "total_files": total_files,
                "files_with_pii": files_with_pii,
                "total_detections": total_detections,
                "percentage_with_pii": percentage_with_pii,
                "percentage_color_style": percentage_color_style,
                "risk_level_label": risk_level['label'],
                "risk_level_css_class": risk_level.get('css_class', 'risk-medium'),
                "risk_level_description": risk_level['description'],
                "risk_level_inline_style": risk_styles.get(risk_level['label'], risk_styles["RIESGO MODERADO"]),
                "strategic_recommendations": strategic_recommendations,
                "pii_filename": "",
                "resume_filename": os.path.basename(resume_excel_path),
                "analysis_timestamp": datetime.now().strftime('%d/%m/%Y %H:%M'),
                "country": country,
                "logo_base64": self.template_manager._get_logo_base64()
            }
            
            # Render email template using the same template as original
            logging.info(f"Rendering resume email template for {country}...")
            try:
                body_html = self.template_manager.render_template("resume_email", **template_vars)
                logging.info(f"Template rendered successfully for {country}. HTML length: {len(body_html)}")
            except Exception as e:
                logging.error(f"Template rendering failed for {country}: {e}")
                raise
            
            # Convert to absolute path
            resume_excel_path = os.path.abspath(resume_excel_path)
            
            if not os.path.exists(resume_excel_path):
                logging.error(f"Excel file not found: {resume_excel_path}")
                return False
            
            # Send email using the same infrastructure as original
            logging.info(f"Sending executive email for {country}: {subject}")
            
            # Create temporary files for email
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            os.makedirs(output_dir, exist_ok=True)
            safe_country = "".join(c for c in country if c.isalnum() or c in ('_', '-'))
            temp_body_file = os.path.join(output_dir, f"temp_resume_email_body_{safe_country}.html")
            temp_wrapper_file = os.path.join(output_dir, f"temp_resume_email_wrapper_{safe_country}.html")
            
            try:
                # Create temporary files
                with open(temp_body_file, 'w', encoding='utf-8') as f:
                    f.write(body_html)
                
                with open(temp_wrapper_file, 'w', encoding='utf-8') as f:
                    wrapper_content = "\n" + body_html + "\n"
                    f.write(wrapper_content)
                
                logging.info(f"Country-specific email recipients for {country}: {manager_emails}")
                
                # Send email using the framework function
                result = send_email(
                    subject=subject,
                    to=manager_emails,
                    cc=[],
                    bcc=[],
                    body_file=temp_body_file,
                    wrapper_file=temp_wrapper_file,
                    environment="dev",
                    attachments=[resume_excel_path]
                )
                
                if result:
                    logging.info(f"Email sent successfully for {country} to: {manager_emails}")
                else:
                    logging.error(f"Failed to send email for {country}")
                
                return result
                
            finally:
                # Clean up temporary files
                for temp_file in [temp_body_file, temp_wrapper_file]:
                    try:
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                    except Exception:
                        pass  # Not critical if temporary files cannot be deleted
            
        except Exception as e:
            logging.error(f"Error in _send_country_specific_resume_email for {country}: {e}")
            import traceback
            logging.error(traceback.format_exc())
            return False

    def _generate_resume_summary_stats(self, enriched_df: pd.DataFrame, pii_counts: pd.DataFrame = None) -> pd.DataFrame:
        """
        Genera estadísticas de resumen para el email de resumen.
        
        Args:
            enriched_df: DataFrame con datos enriquecidos
            pii_counts: DataFrame con conteos de PII por archivo (opcional)
            
        Returns:
            pd.DataFrame: Estadísticas de resumen
        """
        try:
            stats_data = []
            
            # DEBUG: Input DataFrames analysis
            logging.info("=== DEBUG RESUME SUMMARY STATS GENERATION ===")
            logging.info(f"enriched_df shape: {enriched_df.shape}")
            logging.info(f"enriched_df columns: {enriched_df.columns.tolist()}")
            if 'Total_Detecciones' in enriched_df.columns:
                logging.info(f"Total_Detecciones column info:")
                logging.info(f"  - Type: {enriched_df['Total_Detecciones'].dtype}")
                logging.info(f"  - Null count: {enriched_df['Total_Detecciones'].isna().sum()}")
                logging.info(f"  - > 0 count: {(enriched_df['Total_Detecciones'] > 0).sum()}")
                logging.info(f"  - Sum: {enriched_df['Total_Detecciones'].sum()}")
                logging.info(f"  - Sample values: {enriched_df['Total_Detecciones'].head().tolist()}")
                logging.info(f"  - Max value: {enriched_df['Total_Detecciones'].max()}")
            
            if pii_counts is not None:
                logging.info(f"pii_counts provided: {len(pii_counts)} entries")
                logging.info(f"pii_counts sample:\n{pii_counts.head()}")
            else:
                logging.info("pii_counts is None")
            
            # Estadísticas generales
            # FIXED: Use enriched_df directly as the base for counting
            total_files = len(enriched_df)  # All files in the enriched metadata
            files_with_pii = len(enriched_df[enriched_df['Total_Detecciones'] > 0])
            files_without_pii = total_files - files_with_pii
            total_detections = int(enriched_df['Total_Detecciones'].sum())
            
            # DEBUG: Show calculation results
            logging.info(f"CALCULATIONS:")
            logging.info(f"  - total_files (len enriched_df): {total_files}")
            logging.info(f"  - files_with_pii (Total_Detecciones > 0): {files_with_pii}")
            logging.info(f"  - files_without_pii: {files_without_pii}")
            logging.info(f"  - total_detections (sum): {total_detections}")
            logging.info("=== END DEBUG RESUME SUMMARY STATS GENERATION ===")
            
            stats_data.extend([
                ['Total de Archivos Procesados', total_files],
                ['Archivos con PII Detectado', files_with_pii],
                ['Archivos sin PII', files_without_pii],
                ['Total de Detecciones PII', total_detections],
                ['Porcentaje de Archivos con PII', f"{(files_with_pii/total_files*100):.1f}%" if total_files > 0 else "0%"]
            ])
            
            # Estadísticas por carpeta
            if 'folder_name' in enriched_df.columns:
                folder_stats = enriched_df.groupby('folder_name').agg({
                    'file_name': 'count',
                    'Total_Detecciones': 'sum',
                    'Tipos_PII_Unicos': 'sum'
                }).reset_index()
                
                stats_data.append(['--- Estadísticas por Carpeta ---', ''])
                for _, row in folder_stats.iterrows():
                    stats_data.extend([
                        [f"Carpeta: {row['folder_name']}", ''],
                        [f"  - Archivos", row['file_name']],
                        [f"  - Detecciones PII", row['Total_Detecciones']],
                        [f"  - Tipos PII Únicos", row['Tipos_PII_Unicos']]
                    ])
            
            # Top 5 archivos con más detecciones
            top_files = enriched_df.nlargest(5, 'Total_Detecciones')[['file_name', 'Total_Detecciones']]
            if len(top_files) > 0:
                stats_data.append(['--- Top 5 Archivos con más PII ---', ''])
                for _, row in top_files.iterrows():
                    stats_data.append([row['file_name'], row['Total_Detecciones']])
            
            return pd.DataFrame(stats_data, columns=['Métrica', 'Valor'])
            
        except Exception as e:
            logging.error(f"Error generando estadísticas de resumen: {e}")
            return pd.DataFrame(columns=['Métrica', 'Valor'])

    def _format_resume_excel_sheets(self, writer, files_df: pd.DataFrame, summary_df: pd.DataFrame) -> None:
        """
        Aplica formato a las hojas del Excel de resumen.
        
        Args:
            writer: ExcelWriter object
            files_df: DataFrame con archivos enriquecidos
            summary_df: DataFrame con estadísticas de resumen
        """
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            
            # Formato para hoja de archivos
            ws_files = writer.sheets['Resumen Archivos']
            
            # Encabezados en negrita
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            
            for col_num, column_title in enumerate(files_df.columns, 1):
                cell = ws_files.cell(row=1, column=col_num)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
            
            # Auto-fit columns: calcular ancho según contenido (header + celdas)
            try:
                # Calcular ancho máximo por columna
                for idx, col in enumerate(files_df.columns, start=1):
                    col_letter = get_column_letter(idx)
                    # Longitud del encabezado
                    max_length = len(str(col)) if col is not None else 0
                    # Revisar cada celda en la columna
                    for cell in ws_files[col_letter]:
                        try:
                            value = cell.value
                            if value is None:
                                continue
                            # Convertir a cadena y medir longitud
                            cell_length = len(str(value))
                            if cell_length > max_length:
                                max_length = cell_length
                        except Exception:
                            continue
                    # Ajustar ancho con padding y límites razonables
                    adjusted_width = max(8, max_length + 2)
                    ws_files.column_dimensions[col_letter].width = adjusted_width
            except Exception as e:
                logging.warning(f"Auto-fit columns failed for 'Resumen Archivos': {e}")
                # Fallback sensible widths
                try:
                    ws_files.column_dimensions['A'].width = 25
                    ws_files.column_dimensions['B'].width = 20
                    ws_files.column_dimensions['C'].width = 15
                    ws_files.column_dimensions['D'].width = 20
                    ws_files.column_dimensions['E'].width = 18
                    ws_files.column_dimensions['F'].width = 18
                    ws_files.column_dimensions['G'].width = 40
                except Exception:
                    pass
            
            # Formato condicional para archivos con PII
            for row in range(2, len(files_df) + 2):
                pii_count = ws_files.cell(row=row, column=5).value or 0
                try:
                    if pii_count > 0:
                        for col in range(1, len(files_df.columns) + 1):
                            ws_files.cell(row=row, column=col).fill = PatternFill(
                                start_color="FFE6E6", end_color="FFE6E6", fill_type="solid"
                            )
                except Exception:
                    continue
            # Formato para hoja de estadísticas
            ws_stats = writer.sheets['Estadísticas Resumen']
            
            # Encabezados
            for col_num in range(1, 3):
                cell = ws_stats.cell(row=1, column=col_num)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")
            
            # Ajustar ancho
            ws_stats.column_dimensions['A'].width = 35
            ws_stats.column_dimensions['B'].width = 20
            
            # Resaltar métricas importantes
            important_metrics = ['Total de Archivos Procesados', 'Archivos con PII Detectado', 'Total de Detecciones PII']
            for row in range(2, len(summary_df) + 2):
                metric = ws_stats.cell(row=row, column=1).value
                if metric in important_metrics:
                    ws_stats.cell(row=row, column=1).font = Font(bold=True)
                    ws_stats.cell(row=row, column=2).font = Font(bold=True, color="D32F2F")
            
            # Formato para hoja "Consolidado PII" si existe
            if 'Consolidado PII' in writer.sheets:
                ws_pii = writer.sheets['Consolidado PII']
                
                # Encabezados con formato azul y texto blanco
                for col_num in range(1, ws_pii.max_column + 1):
                    cell = ws_pii.cell(row=1, column=col_num)
                    cell.font = header_font  # Bold white text
                    cell.fill = header_fill  # Blue background
                    cell.alignment = Alignment(horizontal="center")
                
                # Auto-ajustar ancho de columnas
                try:
                    for idx in range(1, ws_pii.max_column + 1):
                        col_letter = get_column_letter(idx)
                        max_length = 0
                        
                        # Calcular ancho máximo de la columna
                        for cell in ws_pii[col_letter]:
                            try:
                                value = cell.value
                                if value is None:
                                    continue
                                cell_length = len(str(value))
                                if cell_length > max_length:
                                    max_length = cell_length
                            except Exception:
                                continue
                        
                        # Ajustar ancho con padding y límites razonables
                        adjusted_width = max(8, min(max_length + 3, 50))  # Min 8, Max 50
                        ws_pii.column_dimensions[col_letter].width = adjusted_width
                        
                except Exception as e:
                    logging.warning(f"Auto-fit columns failed for 'Consolidado PII': {e}")
                    # Fallback: anchos fijos sensibles
                    try:
                        ws_pii.column_dimensions['A'].width = 25  # Archivo
                        ws_pii.column_dimensions['B'].width = 30  # Documento revisado
                        ws_pii.column_dimensions['C'].width = 15  # Tipo PII
                        ws_pii.column_dimensions['D'].width = 25  # Valor PII
                        ws_pii.column_dimensions['E'].width = 12  # Página
                        ws_pii.column_dimensions['F'].width = 20  # Tipo de Dato
                    except Exception:
                        pass
                
                logging.info("Applied formatting to 'Consolidado PII' sheet")
                    
        except Exception as e:
            logging.error(f"Error aplicando formato al Excel de resumen: {e}")

    def _send_single_resume_email(self, resume_excel_path: str, metadata_path: str, pii_path: str) -> bool:
        """
        Envía el email ejecutivo de resumen con análisis estratégico de riesgos PII usando templates.
        
        Args:
            resume_excel_path: Ruta al archivo Excel de resumen
            metadata_path: Ruta al archivo de metadata
            pii_path: Ruta al archivo de análisis PII
            
        Returns:
            bool: True si el email se envió exitosamente
        """
        try:
            # Leer estadísticas del resumen
            # Find the most recent Resumen_Archivos_PII_* file for accurate metrics
            output_dir = os.path.dirname(resume_excel_path) if resume_excel_path else "output"
            
            # Look for the most recent resume file
            import glob
            resume_pattern = os.path.join(output_dir, "Resumen_Archivos_PII_*.xlsx")
            all_resume_files = glob.glob(resume_pattern)
            
            data_source_file = resume_excel_path  # Default fallback
            detected_sheet_name = None
            
            if all_resume_files:
                # Sort by modification time (most recent first)
                all_resume_files.sort(key=os.path.getmtime, reverse=True)
                
                # Use the most recent resume file
                most_recent_file = all_resume_files[0]
                data_source_file = most_recent_file
                logging.info(f"Using most recent resume file: {os.path.basename(most_recent_file)}")
                                
                # Detect country from filename to determine which sheet to read
                detected_sheet_name = self.country_detector.get_sheet_name(os.path.basename(most_recent_file))
                logging.info(f"Detected sheet name from filename: {detected_sheet_name}")
                
                # Log all available resume files for debugging
                logging.info(f"Available resume files ({len(all_resume_files)}):")
                for i, file_path in enumerate(all_resume_files, 1):
                    mod_time = datetime.fromtimestamp(os.path.getmtime(file_path)).strftime('%Y-%m-%d %H:%M:%S')
                    logging.info(f"  {i}. {os.path.basename(file_path)} (modified: {mod_time})")
            else:
                logging.warning(f"No resume files found with pattern: {resume_pattern}")
                logging.info(f"Using fallback file: {os.path.basename(resume_excel_path) if resume_excel_path else 'None'}")
            
            # Read the CORRECT metrics from the selected file
            total_files = 0
            files_with_pii = 0
            total_detections = 0
            percentage_with_pii = "0%"
            
            try:
                if os.path.exists(data_source_file):
                    logging.info(f"Reading metrics from: {os.path.basename(data_source_file)}")
                    
                    # Determine which sheet to read based on country detection
                    # Default to 'Estadísticas Resumen', but try country-specific sheet if detected
                    sheet_to_read = 'Estadísticas Resumen'
                    
                    if detected_sheet_name:
                        # Try to read from country-specific sheet first
                        try:
                            df_estadisticas = pd.read_excel(data_source_file, sheet_name=detected_sheet_name)
                            logging.info(f"Successfully read country-specific sheet: {detected_sheet_name}")
                        except Exception as e:
                            logging.warning(f"Could not read sheet '{detected_sheet_name}': {e}. Falling back to default sheet.")
                            df_estadisticas = pd.read_excel(data_source_file, sheet_name=sheet_to_read)
                    else:
                        df_estadisticas = pd.read_excel(data_source_file, sheet_name=sheet_to_read)
                    
                    if not df_estadisticas.empty:
                        # Convert to dict for easy access
                        metrics = dict(zip(df_estadisticas['Métrica'], df_estadisticas['Valor']))
                        
                        # Extract values from the summary
                        total_files = metrics.get('Total de Archivos Procesados', 0)
                        files_with_pii = metrics.get('Archivos con PII Detectado', 0)
                        total_detections = metrics.get('Total de Detecciones PII', 0)
                        percentage_with_pii = metrics.get('Porcentaje de Archivos con PII', '0%')
                        
                        # Log found documents by reading from Resumen Archivos sheet
                        try:
                            df_resumen = pd.read_excel(data_source_file, sheet_name='Resumen Archivos')
                            if 'Archivo' in df_resumen.columns:
                                all_documents = df_resumen['Archivo'].tolist()
                                logging.info(f"Documents found ({len(all_documents)} total):")
                                for i, doc in enumerate(all_documents, 1):
                                    logging.info(f"  {i}. {doc}")
                        except Exception as e:
                            logging.warning(f"Could not read document list: {e}")
                        
                        logging.info("=== CORRECT METRICS FROM ESTADÍSTICAS RESUMEN SHEET ===")
                        logging.info(f"Source: {os.path.basename(data_source_file)}")
                        logging.info(f"Detected Sheet: {detected_sheet_name or 'Default (Estadísticas Resumen)'}")
                        logging.info(f"  - total_files: {total_files}")
                        logging.info(f"  - files_with_pii: {files_with_pii}")
                        logging.info(f"  - total_detections: {total_detections}")
                        logging.info(f"  - percentage_with_pii: {percentage_with_pii}")
                        logging.info("=== END CORRECT METRICS ===")
                    else:
                        logging.warning("'Estadísticas Resumen' sheet is empty")
                        
                else:
                    logging.error(f"Data source file not found: {data_source_file}")
                    
            except Exception as e:
                logging.error(f"Error reading metrics from {os.path.basename(data_source_file)}: {e}")
                
                # Fallback: try to read from Consolidado PII sheet if available
                try:
                    df_consolidado = pd.read_excel(data_source_file, sheet_name='Consolidado PII')
                    if not df_consolidado.empty and 'Documento revisado' in df_consolidado.columns:
                        total_files = df_consolidado['Documento revisado'].nunique()
                        excluded_mask = df_consolidado['Valor PII'] == 'No personal information found in this folder'
                        total_detections = len(df_consolidado) - excluded_mask.sum()
                        files_with_pii = df_consolidado[~excluded_mask]['Documento revisado'].nunique()
                        percentage_with_pii = f"{(files_with_pii/total_files*100):.1f}%" if total_files > 0 else "0%"
                        logging.info("Using fallback metrics from 'Consolidado PII' sheet")
                    else:
                        # Use default zeros if everything fails
                        total_files = files_with_pii = total_detections = 0
                        percentage_with_pii = "0%"
                except Exception as e2:
                    logging.error(f"Fallback also failed: {e2}")
                    # Use default zeros if everything fails
                    total_files = files_with_pii = total_detections = 0
                    percentage_with_pii = "0%"
            
            # Determinar nivel de riesgo y recomendaciones estratégicas
            risk_level = self._assess_pii_risk_level(files_with_pii, total_files, total_detections)
            
            # Generar asunto ejecutivo
            timestamp = datetime.now().strftime("%d/%m/%Y")
            subject = f"Informe Ejecutivo - Análisis de Riesgos PII - {risk_level['label']} - {timestamp}"
            
            # Generate strategic recommendations using template manager
            strategic_recommendations = self.template_manager.generate_recommendations_html(risk_level['label'])
            
            # Define risk level inline styles for email compatibility
            risk_styles = {
                "RIESGO BAJO": "background-color: #28a745; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;",
                "RIESGO MEDIO": "background-color: #ffc107; color: #212529; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;",
                "RIESGO ALTO": "background-color: #dc3545; color: white; padding: 8px 16px; border-radius: 4px; font-weight: bold; font-size: 14px; display: inline-block; margin: 5px 0;"
            }
            
            # Calculate percentage color style
            percentage_color_style = self.template_manager.get_percentage_color_style(percentage_with_pii)
            
            # Prepare template variables
            template_vars = {
                "subject": subject,
                "timestamp": timestamp,
                "total_files": total_files,
                "files_with_pii": files_with_pii,
                "total_detections": total_detections,
                "percentage_with_pii": percentage_with_pii,
                "percentage_color_style": percentage_color_style,
                "risk_level_label": risk_level['label'],
                "risk_level_css_class": risk_level['css_class'],
                "risk_level_description": risk_level['description'],
                "risk_level_inline_style": risk_styles.get(risk_level['label'], risk_styles["RIESGO MEDIO"]),
                "strategic_recommendations": strategic_recommendations,
                "pii_filename": os.path.basename(pii_path),
                "resume_filename": os.path.basename(resume_excel_path),
                "analysis_timestamp": datetime.now().strftime('%d/%m/%Y %H:%M'),
                "logo_base64": self.template_manager._get_logo_base64()
            }
            
            # Render email template
            logging.info("Rendering resume email template...")
            try:
                body_html = self.template_manager.render_template("resume_email", **template_vars)
                logging.info(f"Template rendered successfully. HTML length: {len(body_html)}")
            except Exception as e:
                logging.error(f"Template rendering failed: {e}")
                raise
            
            # Enviar email
            logging.info(f"Enviando email ejecutivo: {subject}")
            
            # Crear archivos temporales para el email
            output_dir = self.config.get("paths", {}).get("output", "output")
            if not os.path.isabs(output_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                output_dir = os.path.join(project_root, output_dir)
            
            os.makedirs(output_dir, exist_ok=True)
            temp_body_file = os.path.join(output_dir, "temp_resume_email_body.html")
            temp_wrapper_file = os.path.join(output_dir, "temp_resume_email_wrapper.html")
            
            try:
                # Crear archivos temporales
                with open(temp_body_file, 'w', encoding='utf-8') as f:
                    f.write(body_html)
                
                with open(temp_wrapper_file, 'w', encoding='utf-8') as f:
                    # Use simple string concatenation instead of f-string to avoid formatting issues
                    wrapper_content = "\n" + body_html + "\n"
                    f.write(wrapper_content)
                
                # Get recipients from "Listado encargados Chile.xlsx" filtered by detected sheet
                # Extract country from folder name (before " - " separator)
                # Example: "Brazil - 123.1-Gestión mandatos físicos PAC" -> "Brazil"
                country_from_folder = None
                try:
                    df_resumen = pd.read_excel(data_source_file, sheet_name='Resumen Archivos')
                    if not df_resumen.empty and 'Archivo' in df_resumen.columns:
                        # Get first document to extract country
                        first_doc = df_resumen['Archivo'].iloc[0]
                        if ' - ' in first_doc:
                            country_from_folder = first_doc.split(' - ')[0].strip()
                            logging.info(f"Extracted country from folder name: '{country_from_folder}'")
                except Exception as e:
                    logging.warning(f"Could not extract country from folder name: {e}")
                
                # Map country to sheet name
                country_to_sheet = {
                    'Brazil': 'Brazil',
                    'Brasil': 'Brazil',
                    'Chile': 'Chile',
                    'Colombia': 'Colombia',
                    'Uruguay': 'Uruguay'
                }
                
                # manager_emails = self._get_manager_emails(sheet_name=sheet_for_managers)
                ruta_glosa_lob = os.path.join(project_root, "input", "glosa_lobs.xlsx")
                df_glosa_lob = pd.read_excel(ruta_glosa_lob)
                
                logging.info(f"LOBs encontrados en documentos: {self.lobs_founded}")
                logging.info(f"Columnas en glosa_lobs.xlsx: {df_glosa_lob.columns.tolist()}")
                
                lob_emails = []
                
                # Make match between self.lobs_founded and df_glosa_lob
                if 'LOB' in df_glosa_lob.columns and 'RESPONSABLE' in df_glosa_lob.columns:
                    # Filter rows where LOB matches any value in self.lobs_founded
                    matched_rows = df_glosa_lob[df_glosa_lob['LOB'].isin(self.lobs_founded)]
                    
                    if not matched_rows.empty:
                        # Extract emails from RESPONSABLE column
                        for responsable in matched_rows['RESPONSABLE'].dropna():
                            # Handle multiple emails separated by semicolon
                            emails = str(responsable).split(';')
                            for email in emails:
                                email_clean = email.strip()
                                if email_clean and '@' in email_clean:
                                    lob_emails.append(email_clean)
                        
                        # Remove duplicates while preserving order
                        manager_emails = list(dict.fromkeys(lob_emails))
                        
                if not lob_emails:
                    logging.warning("No manager emails found in 'Listado encargados Chile.xlsx'. Using fallback email.")
                    manager_emails = ["andres.n.vera@provida.cl"]  # Fallback
                
                logging.info(f"Resume email recipients (managers): {manager_emails}")
                
                # Enviar email usando la función del framework
                return send_email(
                    subject=subject,
                    to=manager_emails,  # Use manager emails from Excel file
                    cc=[],
                    bcc=[],
                    body_file=temp_body_file,
                    wrapper_file=temp_wrapper_file,
                    environment="dev",
                    attachments=[resume_excel_path]
                )
                
            finally:
                # Limpiar archivos temporales
                for temp_file in [temp_body_file, temp_wrapper_file]:
                    try:
                        if os.path.exists(temp_file):
                            os.remove(temp_file)
                    except Exception:
                        pass  # No es crítico si no se pueden eliminar los archivos temporales
            
        except Exception as e:
            logging.error(f"Error enviando email ejecutivo: {e}")
            return False
        
        
    

    def _assess_pii_risk_level(self, files_with_pii: int, total_files: int, total_detections: int) -> dict:
        """
        Evalúa el nivel de riesgo estratégico basado en métricas PII.
        
        Args:
            files_with_pii: Número de archivos con PII detectado
            total_files: Total de archivos procesados
            total_detections: Total de detecciones PII
            
        Returns:
            dict: Información del nivel de riesgo con etiqueta, descripción y CSS
        """
        if files_with_pii == 0:
            return {
                'label': 'RIESGO MÍNIMO',
                'description': 'No se detectaron exposiciones de información personal. La organización mantiene un control efectivo de datos sensibles.',
                'css_class': 'risk-low'
            }
        
        # Calcular porcentaje de exposición
        exposure_rate = (files_with_pii / total_files) * 100 if total_files > 0 else 0
        avg_detections_per_file = total_detections / files_with_pii if files_with_pii > 0 else 0
        
        if exposure_rate <= 10 and avg_detections_per_file <= 5:
            return {
                'label': 'RIESGO BAJO',
                'description': 'Exposición limitada de PII detectada. Se recomienda revisión preventiva y implementación de controles adicionales.',
                'css_class': 'risk-low'
            }
        elif exposure_rate <= 25 or avg_detections_per_file <= 15:
            return {
                'label': 'RIESGO MODERADO',
                'description': 'Nivel de exposición PII que requiere atención inmediata. Se sugiere auditoría de procesos y capacitación del personal.',
                'css_class': 'risk-medium'
            }
        else:
            return {
                'label': 'RIESGO ALTO',
                'description': 'Exposición significativa de información personal identificada. Requiere intervención ejecutiva inmediata y plan de remediación.',
                'css_class': 'risk-high'
            }

    def _generate_strategic_recommendations(self, risk_level: dict, files_with_pii: int, total_files: int) -> str:
        """
        Genera recomendaciones estratégicas basadas en el nivel de riesgo.
        
        Args:
            risk_level: Información del nivel de riesgo
            files_with_pii: Archivos con PII detectado
            total_files: Total de archivos
            
        Returns:
            str: HTML con recomendaciones estratégicas
        """
        recommendations_html = ""
        
        if 'MÍNIMO' in risk_level['label'] or 'BAJO' in risk_level['label']:
            recommendations_html += """
                
            """
        
        elif 'MODERADO' in risk_level['label']:
            recommendations_html += """
                
                
            """
        
        else:  # RIESGO ALTO
            recommendations_html += """
                
                
                
            """
        
        # Agregar recomendación general de monitoreo
        recommendations_html += """
        """
        
        return recommendations_html

    def get_available_methods(self) -> Dict[str, bool]:
        """Check availability of different detection methods"""
        available = {}
        
        # Check regex method (always available)
        available["regex"] = True
        
        # Check ML method dependencies
        try:
            import spacy
            import transformers
            available["ml"] = True
        except ImportError:
            available["ml"] = False
        
        # Hybrid available if ML is available
        available["hybrid"] = available["ml"]
        
        return available

    def extract_version_control_info(self, text_file_path):
        """
        Extract version control information from text files.
        
        Looks for patterns like:
        Control de Versiones
        Version | Usuario | Fecha | Observaciones
        1.0 | Alvaro Montalva | 08-2024 | Creación del Procedimiento
        
        Args:
            text_file_path: Path to the extracted text file
            
        Returns:
            dict: Latest version control information or None
        """
        try:
            if not os.path.exists(text_file_path):
                return None
                
            with open(text_file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Look for "Control de Versiones" table
            import re
            
            # Pattern to find version control sections
            version_pattern = r'(?i)control\s+de\s+version(?:es)?'
            
            # Find the section
            matches = list(re.finditer(version_pattern, content))
            if not matches:
                return None
            
            latest_date = None
            latest_version_info = None
            
            # Process each version control section found
            for match in matches:
                start_pos = match.end()
                # Look for version entries after the header
                # Pattern: version | user | date | observations
                entry_pattern = r'(\d+\.\d+)\s*[\|\s]+([^|\n]+)[\|\s]+(\d{1,2}[-/]\d{4}|\d{4}[-/]\d{1,2})\s*[\|\s]*([^\n]*)'
                
                # Search in the next 1000 characters after "Control de Versiones"
                search_text = content[start_pos:start_pos + 1000]
                entries = re.findall(entry_pattern, search_text)
                
                for version, user, date_str, observations in entries:
                    try:
                        # Parse date - handle formats like 08-2024, 2024-08, 08/2024, 2024/08
                        date_clean = date_str.strip()
                        if '-' in date_clean:
                            parts = date_clean.split('-')
                        elif '/' in date_clean:
                            parts = date_clean.split('/')
                        else:
                            continue
                            
                        if len(parts) == 2:
                            # Determine which part is month and which is year
                            part1, part2 = parts
                            if len(part1) == 4:  # Format: 2024-08
                                year, month = int(part1), int(part2)
                            elif len(part2) == 4:  # Format: 08-2024
                                month, year = int(part1), int(part2)
                            else:
                                continue
                                
                            # Create date for comparison (using day 1 of the month)
                            from datetime import datetime
                            current_date = datetime(year, month, 1)
                            
                            if latest_date is None or current_date > latest_date:
                                latest_date = current_date
                                latest_version_info = {
                                    'version': version.strip(),
                                    'user': user.strip(),
                                    'date': date_clean,
                                    'observations': observations.strip(),
                                    'formatted_date': current_date.strftime('%m-%Y')
                                }
                    except (ValueError, IndexError):
                        continue
            
            return latest_version_info
            
        except Exception as e:
            if self.debug_mode:
                print(f"Error extracting version control from {text_file_path}: {e}")
            return None

    def update_metadata_with_version_control(self):
        r"""
        Update files_metadata.xlsx with version control information extracted from text files.

        Searches for extracted_text folders INSIDE each document folder:
        C:\RPA\...\input\_file_input\[Document Folder]\extracted_text\
        
        Example:
        C:\RPA\...\input\_file_input\Chile - 123.1-Gestión mandatos físicos PAC\extracted_text\page_1_*.txt
        """
        try:
            if not self.files_metadata_path or not os.path.exists(self.files_metadata_path):
                logging.warning("files_metadata.xlsx not found, cannot update version control info")
                return
            
            # Load existing metadata
            df_metadata = pd.read_excel(self.files_metadata_path)
            
            logging.info(f"=== METADATA UPDATE WITH VERSION CONTROL ===")
            logging.info(f"Metadata file: {self.files_metadata_path}")
            logging.info(f"Total files in metadata: {len(df_metadata)}")
            
            # Add version control column if it doesn't exist
            if 'Control de version' not in df_metadata.columns:
                df_metadata['Control de version'] = ''
            
            # Get the input directory - this is where document folders are
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            base_input_dir = os.path.join(project_root, "input", "_file_input")
            
            logging.info(f"Searching for extracted_text in document folders under: {base_input_dir}")
            
            if not os.path.exists(base_input_dir):
                logging.warning(f"Input directory not found: {base_input_dir}")
                return
            
            # Process each file in metadata
            version_updated = 0
            
            for idx, row in df_metadata.iterrows():
                original_name = row['original_filename']
                logging.debug(f"Processing metadata entry: {original_name}")
                
                # Search for this document's extracted_text folder
                version_info = self._find_version_control_in_document_folder(
                    base_input_dir, 
                    original_name
                )
                
                if version_info:
                    df_metadata.at[idx, 'Control de version'] = version_info['formatted_date']
                    logging.info(f"[OK] Found version control '{version_info['formatted_date']}' for: {original_name}")
                    version_updated += 1
                else:
                    logging.debug(f"❌ No version control found for: {original_name}")
            
            # Save updated metadata
            df_metadata.to_excel(self.files_metadata_path, index=False)
            logging.info(f"[OK] Metadata updated: {version_updated}/{len(df_metadata)} files with version control")
            logging.info(f"Saved to: {self.files_metadata_path}")
            
        except Exception as e:
            logging.error(f"Error updating metadata with version control: {e}")
            if self.debug_mode:
                import traceback
                traceback.print_exc()

    def _find_version_control_in_document_folder(self, base_input_dir, original_filename):
        """
        Search for version control info in the document's extracted_text folder.
        
        Location: [base_input_dir]/[Document Folder Name]/extracted_text/
        
        Args:
            base_input_dir: Base input directory (e.g., .../_file_input)
            original_filename: Original document filename from metadata
            
        Returns:
            dict with version control info or None
        """
        try:
            # List all folders in the base input directory
            if not os.path.exists(base_input_dir):
                logging.debug(f"Base input directory not found: {base_input_dir}")
                return None
            
            document_folders = [f for f in os.listdir(base_input_dir) 
                              if os.path.isdir(os.path.join(base_input_dir, f))]
            
            logging.debug(f"Found {len(document_folders)} document folders in {base_input_dir}")
            
            # Clean filename for matching (remove extension, region prefix, etc.)
            cleaned_filename = self._clean_filename_for_matching(original_filename)
            
            logging.debug(f"Searching for version control for: '{original_filename}' (cleaned: '{cleaned_filename}')")
            
            # Search through each document folder
            for folder_name in document_folders:
                folder_path = os.path.join(base_input_dir, folder_name)
                
                # Check if this folder matches the document we're looking for
                cleaned_folder_name = self._clean_filename_for_matching(folder_name)
                
                # Match on cleaned names (handles region prefixes, extensions, etc.)
                if cleaned_filename.lower() != cleaned_folder_name.lower():
                    logging.debug(f"Folder '{folder_name}' does not match '{original_filename}'")
                    continue
                
                logging.debug(f"[OK]Folder match found: '{folder_name}'")
                
                # Look for extracted_text subfolder
                extracted_text_path = os.path.join(folder_path, "extracted_text")
                
                if not os.path.exists(extracted_text_path):
                    logging.debug(f"  No extracted_text folder in: {folder_name}")
                    continue
                
                logging.debug(f"  [OK]Found extracted_text folder: {extracted_text_path}")
                
                # Search all .txt files in extracted_text
                version_info = self._search_version_control_in_text_files(extracted_text_path)
                
                if version_info:
                    logging.info(f"  [OK]Found version control: {version_info['formatted_date']}")
                    return version_info
                else:
                    logging.debug(f"  [NO] No version control found in text files")
            
            logging.debug(f"❌ No matching document folder found for: {original_filename}")
            return None
            
        except Exception as e:
            logging.error(f"Error searching for version control in document folder: {e}")
            return None
    
    def _search_version_control_in_text_files(self, extracted_text_dir):
        """
        Search through all .txt files in a folder for version control information.
        
        Args:
            extracted_text_dir: Path to the extracted_text folder
            
        Returns:
            dict with version control info or None
        """
        try:
            if not os.path.exists(extracted_text_dir):
                return None
            
            # Get all .txt files
            txt_files = [f for f in os.listdir(extracted_text_dir) if f.endswith('.txt')]
            
            logging.debug(f"    Searching {len(txt_files)} text files for version control...")
            
            for txt_file in txt_files:
                txt_path = os.path.join(extracted_text_dir, txt_file)
                
                try:
                    with open(txt_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Search for version control patterns
                    version_info = self._extract_version_control_from_text(content)
                    
                    if version_info:
                        logging.debug(f"    [OK]Found in: {txt_file}")
                        return version_info
                        
                except Exception as e:
                    logging.debug(f"    Error reading {txt_file}: {e}")
                    continue
            
            logging.debug(f"    [NO] No version control found in any text file")
            return None
            
        except Exception as e:
            logging.error(f"Error searching text files: {e}")
            return None
    
    def _extract_version_control_from_text(self, text):
        """
        Extract version control date from text content.
        
        Looks for patterns like:
        - "Control de Versiones" or "Control de version"
        - Version tables with dates (08-2024, 2024-08, etc.)
        
        Args:
            text: Text content to search
            
        Returns:
            dict with version info or None
        """
        try:
            import re
            from datetime import datetime
            
            # Patterns to find version control dates
            patterns = [
                # Version with month-year (08-2024 or 2024-08)
                r'(\d{1,2}[-/]\d{4}|\d{4}[-/]\d{1,2})',
                # Date in various formats (DD/MM/YYYY)
                r'(\d{1,2}[-/]\d{1,2}[-/]\d{4})',
            ]
            
            dates_found = []
            
            for pattern in patterns:
                matches = re.findall(pattern, text)
                dates_found.extend(matches)
            
            if not dates_found:
                return None
            
            # Process dates to find the most recent one
            latest_date = None
            latest_info = None
            
            for date_str in dates_found:
                try:
                    # Parse date
                    date_clean = date_str.strip()
                    
                    if '-' in date_clean:
                        parts = date_clean.split('-')
                    elif '/' in date_clean:
                        parts = date_clean.split('/')
                    else:
                        continue
                    
                    if len(parts) == 2:
                        # Two-part date (month-year or year-month)
                        part1, part2 = parts
                        
                        if len(part1) == 4:  # Format: 2024-08
                            year, month = int(part1), int(part2)
                        elif len(part2) == 4:  # Format: 08-2024
                            month, year = int(part1), int(part2)
                        else:
                            continue
                        
                        # Create comparable date
                        current_date = datetime(year, month, 1)
                        
                        if latest_date is None or current_date > latest_date:
                            latest_date = current_date
                            latest_info = {
                                'raw_date': date_clean,
                                'formatted_date': f"{month:02d}-{year}"
                            }
                            
                    elif len(parts) == 3:
                        # Three-part date (DD-MM-YYYY or similar)
                        day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
                        current_date = datetime(year, month, day)
                        
                        if latest_date is None or current_date > latest_date:
                            latest_date = current_date
                            latest_info = {
                                'raw_date': date_clean,
                                'formatted_date': f"{month:02d}-{year}"
                            }
                            
                except (ValueError, IndexError):
                    continue
            
            return latest_info
            
        except Exception as e:
            logging.error(f"Error extracting version control: {e}")
            return None

    def _find_version_control_for_document(self, base_input_dir, original_name, source_folder):
        """
        Find version control information for a specific document by searching through its text files.
        
        Args:
            base_input_dir: Base directory containing document folders
            original_name: Original filename from metadata
            source_folder: Source folder name from metadata
            
        Returns:
            dict: Version control information or None
        """
        try:
            # Clean the original name for matching
            clean_name = self._clean_filename_for_matching(original_name)
            
            # Search for matching folders in the input directory
            folder_candidates = []
            
            # Try to find folders that match the document
            for folder_name in os.listdir(base_input_dir):
                folder_path = os.path.join(base_input_dir, folder_name)
                if not os.path.isdir(folder_path):
                    continue
                    
                # Check if this folder could contain our document
                if self._is_document_folder_match(folder_name, clean_name, source_folder):
                    folder_candidates.append(folder_path)
            
            if self.debug_mode:
                print(f"Found {len(folder_candidates)} folder candidates for {original_name}")
            
            # Search for version control in all candidate folders
            latest_version_info = None
            
            for folder_path in folder_candidates:
                extracted_text_dir = os.path.join(folder_path, "extracted_text")
                
                if not os.path.exists(extracted_text_dir):
                    continue
                
                # Search all text files in the extracted_text directory
                for text_file in os.listdir(extracted_text_dir):
                    if not text_file.endswith('.txt'):
                        continue
                        
                    text_file_path = os.path.join(extracted_text_dir, text_file)
                    version_info = self.extract_version_control_info(text_file_path)
                    
                    if version_info:
                        # Keep the latest version found
                        if latest_version_info is None:
                            latest_version_info = version_info
                        else:
                            # Compare dates to keep the latest
                            try:
                                from datetime import datetime
                                current_date = self._parse_version_date(version_info['date'])
                                latest_date = self._parse_version_date(latest_version_info['date'])
                                
                                if current_date and latest_date and current_date > latest_date:
                                    latest_version_info = version_info
                            except:
                                # If date comparison fails, keep the first one found
                                pass
            
            return latest_version_info
            
        except Exception as e:
            if self.debug_mode:
                print(f"Error finding version control for {original_name}: {e}")
            return None

    def _is_document_folder_match(self, folder_name, clean_document_name, source_folder):
        """
        Check if a folder could contain the specified document.
        
        Args:
            folder_name: Name of the folder to check
            clean_document_name: Cleaned document name
            source_folder: Source folder from metadata
            
        Returns:
            bool: True if folder could contain the document
        """
        try:
            # Clean the folder name for comparison
            clean_folder = self._clean_filename_for_matching(folder_name)
            
            # Check if document name appears in folder name
            if clean_document_name.lower() in clean_folder.lower():
                return True
                
            # Check if folder name appears in document name
            if clean_folder.lower() in clean_document_name.lower():
                return True
                
            # Check against source folder if available
            if source_folder and source_folder.lower() in folder_name.lower():
                return True
                
            return False
            
        except Exception as e:
            if self.debug_mode:
                print(f"Error in folder matching: {e}")
            return False

    def _parse_version_date(self, date_str):
        """
        Parse version date string into datetime object for comparison.
        
        Args:
            date_str: Date string like "08-2024" or "12-2024"
            
        Returns:
            datetime: Parsed date or None
        """
        try:
            from datetime import datetime
            
            date_clean = date_str.strip()
            if '-' in date_clean:
                parts = date_clean.split('-')
            elif '/' in date_clean:
                parts = date_clean.split('/')
            else:
                return None
                
            if len(parts) == 2:
                part1, part2 = parts
                if len(part1) == 4:  # Format: 2024-08
                    year, month = int(part1), int(part2)
                elif len(part2) == 4:  # Format: 08-2024
                    month, year = int(part1), int(part2)
                else:
                    return None
                    
                return datetime(year, month, 1)
                
        except (ValueError, IndexError):
            return None
        
        return None

    def _add_version_control_from_metadata(self, df):
        """
        Add version control column to DataFrame from metadata.
        
        Args:
            df: DataFrame with file information
            
        Returns:
            DataFrame with added 'Control de version' column
        """
        try:
            if not self.files_metadata_path or not os.path.exists(self.files_metadata_path):
                df['Control de version'] = ''
                return df
            
            # Load metadata
            df_metadata = pd.read_excel(self.files_metadata_path)
            
            if 'Control de version' not in df_metadata.columns:
                df['Control de version'] = ''
                return df
            
            # Create a mapping from cleaned filename to version control
            version_mapping = {}
            for _, row in df_metadata.iterrows():
                original_name = row['original_filename']  # Use correct column name
                version_control = row.get('Control de version', '')
                
                # Clean the filename for matching (remove .docx, etc.)
                cleaned_name = self._clean_filename_for_matching(original_name)
                version_mapping[cleaned_name] = version_control
                
                # Always log metadata mapping for version control debugging
                logging.info(f"VERSION CONTROL METADATA MAPPING: '{original_name}' -> '{cleaned_name}' = '{version_control}'")
            
            # Add version control column to the main DataFrame
            df['Control de version'] = ''
            
            for idx, row in df.iterrows():
                # For PII data, use the 'Folder' column which contains the document folder name
                file_name = None
                if 'Folder' in df.columns:
                    file_name = row['Folder']
                elif 'Archivo' in df.columns:
                    file_name = row['Archivo']
                elif 'File' in df.columns:
                    file_name = row['File']
                
                if file_name:
                    # Clean the folder name to extract just the document name
                    cleaned_name = self._clean_filename_for_matching(file_name)
                    
                    # Always log PII data matching attempts for version control debugging
                    logging.info(f"VERSION CONTROL PII LOOKUP: '{file_name}' -> '{cleaned_name}'")
                    
                    if cleaned_name in version_mapping:
                        version_value = version_mapping[cleaned_name]
                        # Handle NaN values properly
                        if str(version_value).lower() in ['nan', 'none', '']:
                            version_value = ''
                        
                        # Use .loc for more reliable DataFrame assignment
                        df.loc[idx, 'Control de version'] = version_value
                        logging.debug(f"VERSION CONTROL MATCH SUCCESS: '{cleaned_name}' = '{version_mapping[cleaned_name]}' -> setting '{version_value}'")
                    else:
                        logging.debug(f"VERSION CONTROL MATCH FAILED: '{cleaned_name}'")
                        logging.debug(f"Available version control keys: {list(version_mapping.keys())}")
            
            return df
            
        except Exception as e:
            if self.debug_mode:
                print(f"Error adding version control from metadata: {e}")
            df['Control de version'] = ''
            return df

    def _initialize_metadata_path(self):
        """
        Initialize metadata path early so it can be used by folder reports.
        This is the same logic used in _send_resume_email but extracted for early use.
        """
        try:
            if hasattr(self, 'files_metadata_path') and self.files_metadata_path:
                return  # Already initialized
                
            # Search for files_metadata.xlsx in various locations
            metadata_files = []
            
            # Get input directory
            input_dir = self.config.get("paths", {}).get("input", "input")
            if not os.path.isabs(input_dir):
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                input_dir = os.path.join(project_root, input_dir)
            
            # Search in common locations
            search_paths = [
                os.path.join(input_dir, "_others", "files_metadata.xlsx"),
                os.path.join(input_dir, "files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "_others", "files_metadata.xlsx"),
                os.path.join(os.path.dirname(input_dir), "output", "files_metadata.xlsx")
            ]
            
            logging.info(f"Searching for files_metadata.xlsx in {len(search_paths)} locations:")
            for i, path in enumerate(search_paths, 1):
                logging.info(f"  {i}. {path}")
                if os.path.exists(path):
                    metadata_files.append(path)
                    break
            
            # If not found, try glob search
            if not metadata_files:
                glob_search_path = os.path.join(input_dir, "**/files_metadata.xlsx")
                found_files = glob.glob(glob_search_path, recursive=True)
                if found_files:
                    logging.info(f"Found metadata with glob: {found_files}")
                    metadata_files.extend(found_files)
            
            if metadata_files:
                self.files_metadata_path = metadata_files[0]
                logging.info(f"Initialized files_metadata_path: {self.files_metadata_path}")
            else:
                logging.warning("Could not find files_metadata.xlsx for folder reports")
                self.files_metadata_path = None
                
        except Exception as e:
            logging.error(f"Error initializing metadata path: {e}")
            self.files_metadata_path = None

    def _clean_filename_for_matching(self, filename):
        """
        Clean filename for consistent matching between PII data and metadata.
        Removes country prefixes and normalizes the filename.
        
        Args:
            filename: Original filename
            
        Returns:
            Cleaned filename for matching
        """
        if pd.isna(filename):
            return ""
        
        cleaned = str(filename)
        
        # Remove country prefixes
        prefixes_to_remove = [
            'Colombia - ', 'Brazil - ', 'Chile - ', 'Uruguay - ',
            'Colombia-', 'Brazil-', 'Chile-', 'Uruguay-', 'Brasil - ',
            'Brasil-'
        ]
        
        for prefix in prefixes_to_remove:
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):]
                break
        
        # Normalize whitespace (replace multiple spaces with single space)
        # This fixes issues with OCR-generated text that may have inconsistent spacing
        cleaned = ' '.join(cleaned.split())
        
        # Remove file extensions (only common file extensions, not all dots)
        common_extensions = ['.docx', '.pdf', '.xlsx', '.txt', '.doc', '.ppt', '.pptx', '.xls']
        for ext in common_extensions:
            if cleaned.lower().endswith(ext.lower()):
                cleaned = cleaned[:-len(ext)]
                break
        
        return cleaned.strip()


def main():
    """Command line interface"""
    parser = argparse.ArgumentParser(description="S3 PII Detection Orchestrator")
    parser.add_argument(
        "--method", 
        choices=["regex", "ml", "hybrid"],
        default="hybrid",
        help="Detection method to use (default: hybrid)"
    )
    parser.add_argument(
        "--config", 
        type=str,
        help="Path to configuration file"
    )
    parser.add_argument(
        "--log-level", 
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="INFO",
        help="Logging level (default: INFO)"
    )
    parser.add_argument(
        "--check-methods",
        action="store_true", 
        help="Check availability of detection methods and exit"
    )
    
    args = parser.parse_args()
    
    # Initialize logging
    # start_logging(logs_level=args.log_level, show_console_logs=True, save_logs=True)
    
    try:
        # Load configuration
        if args.config:
            # Custom config loading logic here if needed
            config = read_config()
        else:
            config = read_config()
        
        # Override method from command line
        if "ENVIRONMENT" not in config:
            config["ENVIRONMENT"] = {}
        config["ENVIRONMENT"]["DETECTION_METHOD"] = args.method
        
        # Initialize orchestrator
        orchestrator = S4PIIOrchestrator(config=config)
        
        # Check methods if requested
        if args.check_methods:
            available = orchestrator.get_available_methods()
            print("Available detection methods:")
            for method, is_available in available.items():
                status = "[OK]" if is_available else "[NOT AVAILABLE]"
                print(f"  {status} {method}")
            return 0
        
        # Run detection
        logging.info(f"Starting PII detection with method: {args.method}")
        success = orchestrator.run_detection()
        
        if success:
            logging.info("PII detection completed successfully")
            return 0
        else:
            logging.error("PII detection failed")
            return 1
            
    except KeyboardInterrupt:
        logging.info("Detection interrupted by user")
        return 1
    except Exception as e:
        logging.error(f"Orchestration error: {e}")
        return 1


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")
    state = S4PIIOrchestrator(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
