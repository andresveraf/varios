#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Base PII Detector

Base class with common functionality for PII detection modules:
- OCR processing
- Text cleaning and normalization  
- Excel reporting
- Entity validation helpers
"""

import os
import logging
import datetime as dt
import cv2
import numpy as np
import pandas as pd
import pytesseract
import spacy
import json
import io
import re
from typing import Optional, List, Dict, Tuple, Any
from abc import ABC, abstractmethod

# Try to import pytesseract for scanned PDF support
try:
    import pytesseract as pytess_ocr
    PYTESSERACT_AVAILABLE = True
except ImportError:
    PYTESSERACT_AVAILABLE = False

# Try to import pdfplumber for better PDF detection
try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False

# Try to import fitz for PDF processing
try:
    import fitz
    FITZ_AVAILABLE = True
except ImportError:
    FITZ_AVAILABLE = False

# Project imports
from src.utils.fmw_utils import start_logging, read_config, save_json_file
from src.process_scripts.base_process import ProcessBase
from src.utils.pii_utils import (
    PIIValidators, TextProcessingUtils, EntityUtils, ContextAnalyzer, 
    ExclusionLists, get_sensitivity_level, extract_page_number, generate_simple_embedding,
    filter_identities_by_country
)

def _conditionally_set_tesseract_paths(tesseract_cmd: Optional[str], tessdata_prefix: Optional[str]) -> None:
    """Set Tesseract paths if they exist"""
    try:
        if tesseract_cmd and os.path.exists(tesseract_cmd):
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
        if tessdata_prefix and os.path.exists(tessdata_prefix):
            os.environ["TESSDATA_PREFIX"] = tessdata_prefix
    except Exception as e:
        logging.warning(f"Could not set Tesseract paths: {e}")

class BasePIIDetector(ProcessBase, ABC):
    """Base class with common functionality for PII detection"""
    
    DEFAULT_TESSERACT_CONFIG = r"--oem 3 --psm 6"
    OCR_LOW_CONF_THRESHOLD_DEFAULT = 45
    PERSON_MIN_CONF_DEFAULT = 0.60
    STRICT_MODE_DEFAULT = True
    MAX_PERSON_CHARS = 40
    MAX_PERSON_TOKENS = 5

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config=config)
        
        self.state_name = "Workflow"
        self.now = dt.datetime.now()
        
        self.input_dir = self.config_env["DOWNLOAD_FOLDER"]
        self.output_dir = self.config_env["OUTPUT_FOLDER"]
        self.process_data_dir = self.config_env["DOWNLOAD_FOLDER"]
        
        # Setup Tesseract paths
        cfg_tess_cmd = self.config_env["TESSERACT_CMD"]
        cfg_tessdata = self.config_env["TESSDATA_PREFIX"]
        _conditionally_set_tesseract_paths(cfg_tess_cmd, cfg_tessdata)
        
        # Configuration parameters
        self.tesseract_config = self.config_global.get("TESSERACT_CONFIG", self.DEFAULT_TESSERACT_CONFIG)
        self.low_conf_threshold = int(self.config_global.get("OCR_LOW_CONF_THRESHOLD", self.OCR_LOW_CONF_THRESHOLD_DEFAULT))
        self.strict_mode = bool(self.config_global.get("STRICT_MODE", self.STRICT_MODE_DEFAULT))
        self.person_min_conf = float(self.config_global.get("PERSON_MIN_CONF", self.PERSON_MIN_CONF_DEFAULT))
        
        # Text processing configuration
        self.use_stopwords_removal = bool(self.config_env.get("USE_STOPWORDS_REMOVAL", True))
        self.use_advanced_cleaning = bool(self.config_global.get("USE_ADVANCED_CLEANING", True))
        
        # Tracking for OCR confidence
        self.last_image_ocr_conf: Optional[float] = None
        
        # Initialize Spanish stop words
        self.spanish_stop_words = self._load_spanish_stop_words()
        
        # Initialize context analyzer
        self.context_analyzer = ContextAnalyzer()

    def _get_ocr_language_for_path(self, file_path: str) -> str:
        """
        Determine OCR language based on file path matching source sites.
        Checks both path and folder/file names for region keywords.
        
        Args:
            file_path: Path to the file being processed
            
        Returns:
            str: OCR language code (e.g., 'spa', 'por', 'spa+eng')
        """
        try:
            # Get source sites configuration
            source_sites = self.config.get("SHAREPOINT_SITES", {}).get("source_sites", [])
            
            # Normalize the file path for comparison
            normalized_path = os.path.normpath(file_path).lower()
            
            # Check each source site to find a match
            for site in source_sites:
                if not site.get("enabled", False):
                    continue
                
                site_name = site.get("name", "").lower()
                site_path = os.path.normpath(site.get("path", "")).lower()
                
                # Strategy 1: Check if config path is in the file path
                if site_path and site_path in normalized_path:
                    ocr_lang = site.get("ocr_language", "spa")
                    logging.info(f"[OCR-LANGUAGE] Detected region '{site.get('name')}' from source path, using language: {ocr_lang}")
                    return ocr_lang
                
                # Strategy 2: Check if site name appears in folder/file names
                # Extract folder names from the path
                path_parts = normalized_path.split(os.sep)
                for part in path_parts:
                    if site_name and site_name in part:
                        ocr_lang = site.get("ocr_language", "spa")
                        logging.info(f"[OCR-LANGUAGE] Detected region '{site.get('name')}' from folder name, using language: {ocr_lang}")
                        return ocr_lang
            
            # Default fallback to Spanish
            default_lang = "spa"
            logging.info(f"[OCR-LANGUAGE] No region match found, using default language: {default_lang}")
            return default_lang
            
        except Exception as e:
            logging.warning(f"Error detecting OCR language for path, using default 'spa': {e}")
            return "spa"

    def _load_spanish_stop_words(self) -> set:
        """Load Spanish stop words from spaCy or use fallback"""
        try:
            nlp_stopwords = spacy.load("es_core_news_sm")
            spanish_stop_words = nlp_stopwords.Defaults.stop_words
            logging.info(f"Spanish stop words loaded: {len(spanish_stop_words)} words")
            return spanish_stop_words
        except OSError:
            # Fallback: manual Spanish stop words
            spanish_stop_words = {
                "el", "la", "de", "que", "y", "a", "en", "un", "es", "se", "no", "te", "lo", "le", "da", "su", "por", "son", 
                "con", "para", "al", "una", "del", "los", "las", "si", "mi", "tu", "yo", "él", "me", "nos", "ya", "muy",
                "pero", "más", "todo", "esta", "está", "este", "tiene", "sus", "fue", "ser", "han", "sin", "sobre", "año",
                "años", "hasta", "puede", "como", "bien", "tras", "dos", "tres", "donde", "hacer", "cada", "vez", "desde",
                "era", "así", "entre", "hay", "había", "sido", "será", "hecho", "mismo", "otra", "otro", "algunos", "tan",
                "tanto", "solo", "sólo", "también", "también", "ni", "o", "pero", "porque", "cuando", "antes", "después"
            }
            logging.info(f"Using fallback Spanish stop words: {len(spanish_stop_words)} words")
            return spanish_stop_words

    def remove_stopwords(self, text: str) -> str:
        """Remove Spanish stop words from text to improve PII detection accuracy"""
        if not self.use_stopwords_removal:
            return text
            
        try:
            import re
            words = re.findall(r'\b\w+\b', text)
            filtered_words = []
            
            for word in words:
                word_lower = word.lower()
                if word_lower not in self.spanish_stop_words:
                    filtered_words.append(word)
                    
            return " ".join(filtered_words)
        except Exception as e:
            logging.warning(f"Error removing stop words: {e}")
            return text

    # ==================== TEXT QUALITY & ADVANCED CLEANING ====================
    
    def _is_pdf_scanned(self, pdf_path: str) -> bool:
        """
        Detect if PDF is scanned (image-based) vs native text.
        
        Args:
            pdf_path (str): Path to PDF file
            
        Returns:
            bool: True if scanned/image-based, False if native text
        """
        try:
            if not PDFPLUMBER_AVAILABLE:
                return False
            
            with pdfplumber.open(pdf_path) as pdf:
                text_pages = 0
                pages_to_check = min(3, len(pdf.pages))
                
                for page in pdf.pages[:pages_to_check]:
                    text = page.extract_text()
                    if text and len(text.strip()) > 100:
                        text_pages += 1
                
                # If less than half of checked pages have text, it's scanned
                is_scanned = text_pages < pages_to_check / 2
                logging.debug(f"PDF scanned detection: {is_scanned} (text in {text_pages}/{pages_to_check} pages)")
                return is_scanned
                
        except Exception as e:
            logging.debug(f"Error detecting if PDF is scanned: {e}")
            return False
    
    def _extract_text_from_scanned_pdf(self, pdf_path: str) -> Dict[int, str]:
        """
        Extract text from scanned (image-based) PDF using Tesseract OCR with Spanish support.
        
        Args:
            pdf_path (str): Path to scanned PDF
            
        Returns:
            Dict[int, str]: Page number -> extracted text
        """
        if not PYTESSERACT_AVAILABLE or not FITZ_AVAILABLE:
            logging.warning("pytesseract or fitz not available - cannot extract from scanned PDF")
            return {}
        
        try:
            from PIL import Image
            page_texts = {}
            doc = fitz.open(pdf_path)
            
            logging.info(f"Extracting text from scanned PDF using Tesseract OCR: {pdf_path}")
            
            for page_num in range(len(doc)):
                try:
                    # Render PDF page to image with 2x zoom for better OCR quality
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
                    
                    # Convert to PIL Image
                    img_data = pix.tobytes("ppm")
                    img = Image.open(io.BytesIO(img_data))
                    
                    # Run Tesseract OCR with dynamic language detection
                    ocr_lang = self._get_ocr_language_for_path(pdf_path)
                    logging.info(f"OCR language for page {page_num + 1}: {ocr_lang}")
                    text = pytesseract.image_to_string(
                        img,
                        lang=ocr_lang,
                        config='--oem 3 --psm 6'
                    )
                    
                    page_texts[page_num + 1] = text or ""
                    logging.debug(f"OCR'd page {page_num + 1} ({len(text) if text else 0} chars)")
                    
                except Exception as page_err:
                    logging.warning(f"OCR error on page {page_num + 1}: {page_err}")
                    page_texts[page_num + 1] = ""
            
            doc.close()
            return page_texts
            
        except Exception as e:
            logging.error(f"Error in scanned PDF OCR: {e}")
            return {}
    
    def _advanced_clean_text(self, text: str) -> str:
        """
        Advanced OCR text cleaning - fixes common OCR errors specific to Spanish documents.
        
        Args:
            text (str): Raw extracted text
            
        Returns:
            str: Cleaned text with OCR errors corrected
        """
        if not text:
            return ""
        
        # 1. Fix common OCR character substitutions (Spanish-specific)
        ocr_substitutions = {
            r'\brn\b': 'm',      # Common: "rn" mistaken for "m" in words
            r'(?<=[a-z])l1(?=[a-z])': 'll',  # "l1" -> "ll"
            r'\b0O\b': 'OO',     # "0O" (zero O) -> "OO"
            r'(?<=[a-z])S5': 'SS',  # "S5" -> "SS"
        }
        
        for pattern, replacement in ocr_substitutions.items():
            text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
        
        # 2. Remove OCR artifacts (control chars, garbage)
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        text = re.sub(r'[^\w\s\-\.,:;¿?¡!\(\)\[\]\{\}áéíóúñÁÉÍÓÚÑüÜ@/]', '', text)
        
        # 3. Fix spacing
        text = re.sub(r'[ \t]+', ' ', text)  # Multiple spaces -> single
        text = re.sub(r'\s+([,.;:!?])', r'\1', text)  # Remove space before punctuation
        text = re.sub(r'(?<=[,.;:!?])\s*(?=[A-Z])', ' ', text)  # Ensure space after punctuation
        
        # 4. Normalize dashes/hyphens (RUT format, etc.)
        text = re.sub(r'[-‐‑–—]', '-', text)
        
        # 5. Remove duplicate consecutive lines
        lines = text.split('\n')
        unique_lines = []
        prev_line = ""
        
        for line in lines:
            stripped = line.strip()
            if stripped and stripped != prev_line:
                unique_lines.append(line)
                prev_line = stripped
            elif not stripped and (not unique_lines or unique_lines[-1].strip()):
                # Keep single blank lines
                unique_lines.append(line)
        
        text = '\n'.join(unique_lines)
        
        # 6. Remove excessive blank lines
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        
        # 7. Fix RUT format (important for PII detection)
        text = re.sub(r'(\d{1,2})\.(\d{3})\.(\d{3})-(\d)', r'\1.\2.\3-\4', text)
        
        # 8. Fix common Spanish patterns
        text = re.sub(r'\bel\s+rut\b', 'El RUT', text, flags=re.IGNORECASE)
        text = re.sub(r'\bs\.a\.?\b', 'S.A.', text, flags=re.IGNORECASE)
        text = re.sub(r'\bltda\.?\b', 'Ltda.', text, flags=re.IGNORECASE)
        
        return text.strip()
    
    def _score_text_quality(self, text: str) -> Dict[str, Any]:
        """
        Score extracted text quality to identify reliable extractions.
        
        Args:
            text (str): Extracted text to score
            
        Returns:
            Dict with quality score (0-100) and metrics
        """
        if not text:
            return {"score": 0, "reason": "empty", "metrics": {}}
        
        text_len = len(text)
        metrics = {
            "length": text_len,
            "has_spaces": " " in text,
            "has_newlines": "\n" in text,
            "avg_line_length": text_len / (text.count("\n") + 1) if text else 0,
            "special_char_ratio": len(re.findall(r'[^\w\s]', text)) / text_len if text_len > 0 else 0,
            "uppercase_ratio": len(re.findall(r'[A-Z]', text)) / text_len if text_len > 0 else 0,
            "digit_ratio": len(re.findall(r'\d', text)) / text_len if text_len > 0 else 0,
        }
        
        score = 100
        reasons = []
        
        # Quality penalties
        if text_len < 50:
            score -= 40
            reasons.append("too_short")
        elif text_len < 100:
            score -= 20
            reasons.append("very_short")
        
        if metrics["special_char_ratio"] > 0.4:
            score -= 25
            reasons.append("high_artifact_ratio")
        
        if metrics["uppercase_ratio"] > 0.8:
            score -= 15
            reasons.append("excessive_uppercase")
        
        if metrics["digit_ratio"] > 0.5:
            score -= 10
            reasons.append("excessive_digits")
        
        # Quality bonuses
        if metrics["has_newlines"] and 40 < metrics["avg_line_length"] < 150:
            score += 10
            reasons.append("good_structure")
        
        return {
            "score": max(0, min(100, score)),
            "metrics": metrics,
            "quality_flags": reasons
        }

    # ==================== END TEXT QUALITY ====================

    # ==================== TESSERACT OPTIMIZATION ====================

    def _get_optimal_tesseract_config(self, image: np.ndarray) -> str:
        """
        Select optimal Tesseract config based on image content.
        PSM (Page Segmentation Mode) has HUGE impact on accuracy: +15-40% improvement.
        
        Args:
            image (np.ndarray): Input image
            
        Returns:
            str: Optimized Tesseract config string
            
        PSM Modes:
        - 3: Fully automatic page segmentation (DEFAULT for mixed layouts)
        - 4: Assume a single column of text of variable sizes
        - 5: Assume a single uniform block of text
        - 6: Assume a single uniform block of text (screenshots) ← DEFAULT CURRENT
        - 11: Sparse text (mostly blank page)
        """
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Analyze image characteristics
            height, width = image.shape[:2]
            aspect_ratio = width / height if height > 0 else 1.0
            
            # Detect edges/structure for complexity analysis
            edges = cv2.Canny(gray, 50, 150)
            edge_density = np.sum(edges > 0) / (height * width) if height * width > 0 else 0
            
            # Detect lines for structured content
            lines = cv2.HoughLines(edges, 1, np.pi/180, 100)
            line_count = len(lines) if lines is not None else 0
            
            # Analyze brightness distribution
            brightness_mean = np.mean(gray)
            brightness_std = np.std(gray)
            
            logging.debug(f"Image analysis: aspect={aspect_ratio:.2f}, edges={edge_density:.3f}, "
                         f"lines={line_count}, brightness={brightness_mean:.1f}±{brightness_std:.1f}")
            
            # Decision logic for PSM selection
            
            # 1. Wide/landscape layouts (likely tables/multi-column)
            if aspect_ratio > 1.8:
                config = r"--oem 3 --psm 4"
                reason = "Landscape layout (columns)"
                
            # 2. Tall/portrait layouts (likely forms/single column)
            elif aspect_ratio < 0.6:
                config = r"--oem 3 --psm 5"
                reason = "Portrait layout (single block)"
                
            # 3. Highly structured content (many lines detected = table/grid)
            elif line_count > 15 and edge_density > 0.15:
                config = r"--oem 3 --psm 4"
                reason = "Structured content (table/grid)"
                
            # 4. Low structure/sparse content (blank areas)
            elif edge_density < 0.05:
                config = r"--oem 3 --psm 11"
                reason = "Sparse text (mostly blank)"
                
            # 5. Standard uniform text block (screenshots, typical documents)
            else:
                config = r"--oem 3 --psm 6"
                reason = "Uniform text block"
            
            logging.debug(f"PSM selection: {config} ({reason})")
            return config
            
        except Exception as e:
            logging.warning(f"Error selecting PSM, using default: {e}")
            return r"--oem 3 --psm 6"  # Safe default

    def extract_text_multi_pass(self, image_path: str, lang: str = None) -> Tuple[str, float]:
        """
        Multi-pass OCR: Try multiple PSM configurations and pick the best result.
        Expected improvement: +20-30% on difficult images.
        
        Args:
            image_path (str): Path to image file
            lang (str): OCR language code. If None, auto-detect from path.
            
        Returns:
            Tuple[str, float]: (best_text, best_confidence)
        """
        try:
            filename = os.path.basename(image_path)
            logging.info(f"[MULTI-PASS-START] Beginning multi-pass OCR for {filename}")
            
            # Auto-detect language if not provided
            if lang is None:
                lang = self._get_ocr_language_for_path(image_path)
            
            data = np.fromfile(image_path, dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if image is None:
                logging.error(f"[MULTI-PASS-ERROR] Failed to decode image: {filename}")
                return "", 0.0
            
            # Try multiple PSM modes (3, 4, 5, 6, 11)
            psm_modes = [3, 4, 5, 6, 11]
            results = []
            
            logging.info(f"[MULTI-PASS] Trying PSM modes: {psm_modes}")
            
            for psm in psm_modes:
                try:
                    config = f"--oem 3 --psm {psm}"
                    logging.debug(f"[MULTI-PASS-PSM{psm}] Testing with config: {config}")
                    
                    # Extract OCR data with this PSM
                    ocr_data = pytesseract.image_to_data(
                        image, lang=lang, config=config,
                        output_type=pytesseract.Output.DICT
                    )
                    
                    # Extract text
                    text = " ".join([t for t in ocr_data["text"] if t.strip()])
                    
                    # Calculate confidence
                    confs = [int(c) for c in ocr_data["conf"] if int(c) > 0]
                    conf = np.mean(confs) if confs else 0.0
                    
                    # Calculate quality score: balance confidence and text length
                    # Longer text usually = better (more content extracted)
                    # Higher confidence obviously better
                    quality_score = (conf * 0.7) + (min(len(text) / 500, 1.0) * 0.3 * 100)
                    
                    results.append({
                        "psm": psm,
                        "text": text,
                        "conf": conf,
                        "length": len(text),
                        "score": quality_score
                    })
                    
                    logging.info(f"[MULTI-PASS-PSM{psm}] conf={conf:6.1f}% | len={len(text):5d} | score={quality_score:6.1f}")
                    
                except Exception as e:
                    logging.warning(f"[MULTI-PASS-PSM{psm}] Failed: {e}")
                    continue
            
            if not results:
                logging.error(f"[MULTI-PASS-FAILED] All PSM modes failed for {filename}")
                return "", 0.0
            
            # Select best result by score
            best = max(results, key=lambda x: x["score"])
            
            logging.info(f"[MULTI-PASS-WINNER] PSM {best['psm']} selected | score={best['score']:.1f} | "
                        f"conf={best['conf']:.1f}% | len={best['length']}")
            
            # Show runner-up for comparison
            other_results = sorted([r for r in results if r['psm'] != best['psm']], 
                                  key=lambda x: x['score'], reverse=True)
            if other_results:
                runner_up = other_results[0]
                logging.debug(f"[MULTI-PASS-RUNNER-UP] PSM {runner_up['psm']} | score={runner_up['score']:.1f}")
            
            return best["text"], best["conf"]
            
        except Exception as e:
            logging.error(f"[MULTI-PASS-EXCEPTION] Critical error in multi-pass: {e}", exc_info=True)
            return "", 0.0

    # ==================== END TESSERACT OPTIMIZATION ====================

    def ocr_data_to_lines(self, ocr_data: Dict[str, List[Any]]) -> List[Dict[str, Any]]:
        """Convert OCR data dictionary to a list of line dictionaries"""
        try:
            df = pd.DataFrame(ocr_data)
            if df.empty or "text" not in df.columns or "conf" not in df.columns: 
                return []
            
            df["text"] = df["text"].fillna("").astype(str)
            df["conf"] = pd.to_numeric(df["conf"], errors="coerce").fillna(-1).astype(int)
            df = df[(df["text"].str.strip() != "") & (df["conf"] != -1)]
            
            if df.empty: 
                return []
            
            lines: List[Dict[str, Any]] = []
            df = df.sort_values(by=["top", "left"])
            
            for (b, p, l), g in df.groupby(["block_num", "par_num", "line_num"]):
                g = g.sort_values(by=["left"])
                words = g["text"].tolist()
                if not words: 
                    continue
                    
                text = " ".join(words).strip()
                avg_conf = float(np.mean(g["conf"])) if len(g) else None
                left = int(g["left"].min())
                top = int(g["top"].min())
                right = int((g["left"] + g["width"]).max())
                bottom = int((g["top"] + g["height"]).max())
                
                lines.append({
                    "text": text, 
                    "conf": round(avg_conf or 0.0, 2), 
                    "left": left, 
                    "top": top, 
                    "width": right - left, 
                    "height": bottom - top, 
                    "block_num": int(b), 
                    "par_num": int(p), 
                    "line_num": int(l)
                })
            
            lines.sort(key=lambda x: (x["top"], x["left"]))
            for i, line in enumerate(lines, 1): 
                line["seq_line_number"] = i
            return lines
        except Exception as e:
            logging.error(f"OCR data to lines error: {e}")
            return []

    def extract_text_and_confidence_from_image(self, image_path: str, lang: str = None) -> Tuple[str, float, Optional[Dict[str, List[Any]]]]:
        """
        IMPROVED: Extract text and confidence score from an image using OCR.
        
        NEW Features (Expected +25-45% accuracy improvement):
        1. Auto-detect optimal PSM mode based on image type
        2. Multi-pass OCR fallback if confidence is low
        3. Confidence filtering on extracted lines
        4. Dynamic language detection based on file path
        
        Args:
            image_path (str): Path to image
            lang (str): OCR language(s). If None, auto-detect from file path.
            
        Returns:
            Tuple[str, float, Dict]: (extracted_text, confidence, ocr_data)
        """
        try:
            filename = os.path.basename(image_path)
            logging.info(f"[OCR-START] Processing: {filename}")
            
            # Auto-detect language if not provided
            if lang is None:
                lang = self._get_ocr_language_for_path(image_path)
            logging.info(f"[OCR-LANG] Using language '{lang}' for image: {os.path.basename(image_path)}")
            
            data = np.fromfile(image_path, dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if image is None:
                logging.error(f"[OCR-ERROR] Failed to decode image: {filename}")
                return "", 0.0, None
            
            # NEW 1️⃣: Auto-detect optimal PSM mode based on image characteristics
            config = self._get_optimal_tesseract_config(image)
            psm_mode = config.split('--psm')[-1].strip()
            logging.debug(f"[OCR-PSM] Selected PSM mode: {psm_mode} for {filename}")
            
            # Extract text using optimized config
            ocr_data = pytesseract.image_to_data(image, lang=lang, config=config, output_type=pytesseract.Output.DICT)
            line_items = self.ocr_data_to_lines(ocr_data)
            
            logging.debug(f"[OCR-LINES] Extracted {len(line_items)} lines from OCR data for {filename}")
            
            if line_items:
                text_parts, confs = [], []
                filtered_count = 0
                
                for line in line_items:
                    # NEW 2️⃣: Filter by confidence threshold
                    if line.get("conf", 0) >= self.low_conf_threshold:
                        cleaned = TextProcessingUtils.clean_ocr_line(line["text"], remove_stopwords=False)
                        if cleaned and len(cleaned) > 1:
                            text_parts.append(cleaned)
                            if line.get("conf") is not None: 
                                confs.append(float(line["conf"]))
                    else:
                        filtered_count += 1
                        logging.debug(f"[OCR-FILTER] Confidence {line['conf']} < {self.low_conf_threshold}: '{line['text'][:40]}'")
                
                full_text = " ".join(text_parts)
                avg_conf = sum(confs) / len(confs) if confs else 0.0
                logging.info(f"[OCR-PRIMARY] {len(text_parts)} kept, {filtered_count} filtered, "
                           f"avg_conf={avg_conf:.1f}%, text_len={len(full_text)}")
            else:
                logging.warning(f"[OCR-NO-LINES] No line items extracted, using raw text for {filename}")
                raw_text = pytesseract.image_to_string(image, lang=lang, config=config)
                full_text = TextProcessingUtils.clean_ocr_line(raw_text, remove_stopwords=False)
                avg_conf = 0.0
                logging.info(f"[OCR-RAW] Extracted raw text: {len(full_text)} chars, conf=0.0%")
            
            # NEW 3️⃣: Multi-pass OCR fallback if confidence is too low
            multi_pass_used = False
            if avg_conf < 50 and full_text:
                logging.warning(f"[OCR-LOWCONF] Confidence {avg_conf:.1f}% < 50% threshold for {filename}")
                logging.info(f"[OCR-MULTIPASS-START] Triggering multi-pass OCR for {filename}...")
                multi_text, multi_conf = self.extract_text_multi_pass(image_path, lang)
                multi_pass_used = True
                
                if multi_conf > avg_conf:
                    logging.warning(f"[OCR-MULTIPASS-SUCCESS] Improved {avg_conf:.1f}% → {multi_conf:.1f}% for {filename}")
                    full_text = multi_text
                    avg_conf = multi_conf
                else:
                    logging.info(f"[OCR-MULTIPASS-NOCHANGE] No improvement: single={avg_conf:.1f}% vs multi={multi_conf:.1f}% for {filename}")
            elif avg_conf < 50 and not full_text:
                logging.error(f"[OCR-FAILED] No text extracted and low confidence for {filename}")
                logging.info(f"[OCR-MULTIPASS-RESCUE] Attempting multi-pass rescue for {filename}...")
                multi_text, multi_conf = self.extract_text_multi_pass(image_path, lang)
                multi_pass_used = True
                
                if multi_text:
                    logging.warning(f"[OCR-MULTIPASS-RECOVERED] Recovered text from multi-pass for {filename}")
                    full_text = multi_text
                    avg_conf = multi_conf
            else:
                logging.debug(f"[OCR-CONFIDENT] Confidence {avg_conf:.1f}% acceptable, skipping multi-pass for {filename}")
            
            import re
            clean_text = re.sub(r"\s+", " ", full_text).strip()
            
            status = "[OCR-MULTIPASS-USED]" if multi_pass_used else "[OCR-SINGLE-PASS]"
            logging.info(f"{status} FINAL: {filename} | PSM={psm_mode} | conf={avg_conf:.1f}% | "
                        f"text_len={len(clean_text)} chars")
            
            return clean_text, float(avg_conf), ocr_data
        except Exception as e:
            logging.error(f"[OCR-EXCEPTION] Error processing {os.path.basename(image_path)}: {e}", exc_info=True)
            return "", 0.0, None

    def get_pos_tags(self, text: str) -> str:
        """Extract POS (Part-of-Speech) tags from text using spaCy if available"""
        try:
            # Try to load a basic spaCy model for POS tagging
            nlp = spacy.load("es_core_news_sm")
            doc = nlp(text)
            pos_tags = []
            for token in doc:
                # Only include tokens that are alphabetic and at least 2 characters
                if token.is_alpha and len(token.text) >= 2:
                    pos_tags.append(f"{token.text}:{token.pos_}")
            return " | ".join(pos_tags) if pos_tags else "N/A"
        except Exception as e:
            logging.warning(f"Error extracting POS tags: {e}")
            return "N/A"

    # Text Processing Methods  
    def process_image_for_pii(self, image_path: str, lang: str = None) -> Dict[str, Any]:
        """Process an image for PII detection: extract text, clean, embed, tag POS, and extract PII entities"""
        try:
            # Auto-detect language if not provided
            if lang is None:
                lang = self._get_ocr_language_for_path(image_path)
            
            extracted_text, confidence, ocr_data = self.extract_text_and_confidence_from_image(image_path, lang)
            self.last_image_ocr_conf = confidence
            
            if not extracted_text.strip():
                return {
                    "image_path": image_path, 
                    "text": "", 
                    "confidence": 0.0, 
                    "pii_entities": [], 
                    "pii_count": 0, 
                    "success": False
                }
            
            # Generate cleaned text for the Excel report
            cleaned_text = extracted_text
            
            # Apply advanced cleaning if enabled
            if self.use_advanced_cleaning:
                cleaned_text = TextProcessingUtils.advanced_clean_text(cleaned_text)
                
            # Apply stop words removal if enabled
            if self.use_stopwords_removal:
                cleaned_text = self.remove_stopwords(cleaned_text)
            
            # Generate embedding for cleaned text
            embedding = generate_simple_embedding(cleaned_text)
            
            # Always generate POS tags for cleaned text
            pos_tags = self.get_pos_tags(cleaned_text)
            
            # Detect country from image path for identity filtering
            country = self._detect_country_from_path(image_path)
            
            # Extract PII entities using the specific detector implementation
            pii_entities = self.extract_pii_from_text(extracted_text, country=country)
            
            return {
                "image_path": image_path,
                "text": extracted_text,
                "cleaned_text": cleaned_text,
                "embedding": embedding,
                "confidence": confidence,
                "pii_entities": pii_entities,
                "pii_count": len(pii_entities),
                "success": True,
                "ocr_data": ocr_data,
                "pos_tags": pos_tags
            }
        except Exception as e:
            logging.error(f"Error processing image {image_path}: {e}")
            return {
                "image_path": image_path, 
                "text": "", 
                "confidence": 0.0, 
                "pii_entities": [], 
                "pii_count": 0, 
                "success": False, 
                "error": str(e)
            }

    def process_text_file_for_pii(self, text_file_path: str) -> Dict[str, Any]:
        """Process a text file for PII detection: read, clean, embed, tag POS, and extract PII entities"""
        try:
            # Read text file content
            with open(text_file_path, 'r', encoding='utf-8') as f:
                extracted_text = f.read()
            
            if not extracted_text.strip():
                return {
                    "text_file_path": text_file_path, 
                    "text": "", 
                    "confidence": 100.0,  # Text files have perfect "confidence" 
                    "pii_entities": [], 
                    "pii_count": 0, 
                    "success": False,
                    "source_type": "text_file"
                }
            
            # Generate cleaned text for the Excel report
            cleaned_text = extracted_text
            
            # Apply advanced cleaning if enabled
            if self.use_advanced_cleaning:
                cleaned_text = TextProcessingUtils.advanced_clean_text(cleaned_text)
                
            # Apply stop words removal if enabled
            if self.use_stopwords_removal:
                cleaned_text = self.remove_stopwords(cleaned_text)
            
            # Generate embedding for cleaned text
            embedding = generate_simple_embedding(cleaned_text)
            
            # Always generate POS tags for cleaned text
            pos_tags = self.get_pos_tags(cleaned_text)
            
            # Detect country from text file path for identity filtering
            country = self._detect_country_from_path(text_file_path)
            
            # Extract PII entities using the specific detector implementation
            pii_entities = self.extract_pii_from_text(extracted_text, country=country)
            
            return {
                "text_file_path": text_file_path,
                "text": extracted_text,
                "cleaned_text": cleaned_text,
                "confidence": 100.0,  # Text files have perfect extraction confidence
                "pii_entities": pii_entities,
                "pii_count": len(pii_entities),
                "success": True,
                "source_type": "text_file",
                "embedding": embedding,
                "pos_tags": pos_tags
            }
        except Exception as e:
            logging.error(f"Error processing text file {text_file_path}: {e}")
            return {
                "text_file_path": text_file_path, 
                "text": "", 
                "confidence": 0.0, 
                "pii_entities": [], 
                "pii_count": 0, 
                "success": False,
                "source_type": "text_file"
            }

    # Abstract method that must be implemented by specific detectors
    @abstractmethod
    def extract_pii_from_text(self, text: str, country: Optional[str] = None) -> List[Dict[str, Any]]:
        """Extract PII entities from text - must be implemented by subclasses
        
        Args:
            text: Text to extract PII from
            country: Optional country detected from filename for identity filtering
        """
        pass

    def _detect_country_from_path(self, file_path: str) -> Optional[str]:
        """Detect country from file path using pattern matching
        
        Args:
            file_path: Path to the file being processed
            
        Returns:
            Country name ('Chile', 'Brasil', 'Colombia', 'Uruguay') or None
        """
        try:
            # Import here to avoid circular dependency
            from src.process_scripts.S4_pii_orchestrator import CountrySheetDetector
            
            detector = CountrySheetDetector()
            # Extract folder/filename from path
            path_lower = file_path.lower()
            
            # Try folder name first (most reliable)
            folder_parts = file_path.replace('\\', '/').split('/')
            for part in folder_parts:
                country = detector.detect_country(part)
                if country:
                    logging.debug(f"Detected country '{country}' from path: {file_path}")
                    return country
            
            return None
            
        except Exception as e:
            logging.debug(f"Could not detect country from path {file_path}: {e}")
            return None

    def collect_pii_results(self, detection_method: str = "unknown", folder_filter: List[str] = None) -> List[Dict[str, Any]]:
        """
        Collect all PII entities from processing without generating Excel files.
        Used by hybrid mode to gather results for combined reporting.
        
        IMPORTANT: This method now ensures ALL processed folders appear in the final report,
        even those with zero PII entities, to guarantee complete email coverage.
        
        Args:
            detection_method: String indicating the detection method ("regex", "ml", "hybrid")
            folder_filter: Optional list of folder names to process. If None, process all folders.
            
        Returns:
            List of dictionaries containing all PII entities with source attribution
        """
        try:
            all_pii_entities = []
            processed_folders = []
            
            # Get all folders or use filtered list
            if folder_filter is not None:
                folders_to_process = folder_filter
                logging.info(f"Using folder filter: processing {len(folders_to_process)} folders (skipping already-processed)")
            else:
                folders_to_process = [
                    f for f in sorted(os.listdir(self.input_dir))
                    if os.path.isdir(os.path.join(self.input_dir, f)) and not f.startswith('.')
                ]
                logging.info(f"No folder filter: processing all {len(folders_to_process)} folders")
            
            # Process folders
            for folder_name in folders_to_process:
                folder_path = os.path.join(self.input_dir, folder_name)
                if os.path.isdir(folder_path) and not folder_name.startswith('.'):
                    logging.info(f"Collecting PII results from folder: {folder_name}")
                    processed_folders.append(folder_name)
                    folder_results = self._collect_folder_results(folder_path, detection_method)
                    
                    if folder_results:
                        # Folder has PII entities
                        all_pii_entities.extend(folder_results)
                        logging.info(f"  -> Found {len(folder_results)} PII entities in {folder_name}")
                    else:
                        # Folder has NO PII entities - create placeholder entry
                        placeholder_entity = self._create_placeholder_entity(folder_name, detection_method)
                        if placeholder_entity:
                            all_pii_entities.append(placeholder_entity)
                            logging.info(f"  -> No PII found in {folder_name}, added placeholder entry")
            
            logging.info(f"Processed {len(processed_folders)} folders total")
            logging.info(f"Collected {len(all_pii_entities)} total entries (including placeholders) using {detection_method} method")
            return all_pii_entities
            
        except Exception as e:
            logging.error(f"Error collecting PII results: {e}")
            return []

    def _create_placeholder_entity(self, folder_name: str, detection_method: str) -> Dict[str, Any]:
        """
        Create a placeholder entity for folders with no PII entities.
        This ensures ALL processed folders appear in the final Excel report.
        
        Args:
            folder_name: Name of the folder
            detection_method: Detection method used
            
        Returns:
            Dictionary representing a placeholder PII entity
        """
        try:
            import datetime as dt
            
            placeholder = {
                "Detection_Method": detection_method,
                "File_Name": "No PII detected",
                "Folder": folder_name,
                "Source_Type": "folder_placeholder",
                "PII_Type": "NO_PII_DETECTED",
                "PII_Value": "No personal information found in this folder",
                "Confidence": "N/A",
                "start_pos": 0,
                "end_pos": 0,
                "Label": "NoDetection",
                "Source": f"{detection_method}_placeholder",
                "Original_Text": "Folder processed but no PII entities detected",
                "Extraction_Confidence": 100.0,
                "Created_At": dt.datetime.now().isoformat()
            }
            
            return placeholder
            
        except Exception as e:
            logging.error(f"Error creating placeholder entity for {folder_name}: {e}")
            return None

    def _collect_folder_results(self, folder_path: str, detection_method: str) -> List[Dict[str, Any]]:
        """Collect PII entities from a specific folder without generating Excel"""
        try:
            folder_pii_entities = []
            
            # Process images from images/ folder
            images_folder = os.path.join(folder_path, "images")
            if os.path.exists(images_folder):
                enhanced_folder = os.path.join(images_folder, "enhanced")
                images_source = enhanced_folder if os.path.exists(enhanced_folder) else images_folder
                
                image_files = [
                    f for f in os.listdir(images_source)
                    if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif"))
                ]
                
                for image_file in sorted(image_files):
                    image_path = os.path.join(images_source, image_file)
                    result = self.process_image_for_pii(image_path)  # Language auto-detected from path
                    if result.get("success"):
                        # Add source attribution to each PII entity
                        for pii_entity in result["pii_entities"]:
                            pii_entity["Detection_Method"] = detection_method
                            pii_entity["File_Name"] = os.path.basename(image_file)
                            pii_entity["Folder"] = os.path.basename(folder_path)
                            pii_entity["Source_Type"] = "image_ocr"
                            pii_entity["Original_Text"] = result["text"]
                            pii_entity["Extraction_Confidence"] = result["confidence"]
                            folder_pii_entities.append(pii_entity)
            
            # Process text files from extracted_text/ folder
            text_folder = os.path.join(folder_path, "extracted_text")
            if os.path.exists(text_folder):
                text_files = [
                    f for f in os.listdir(text_folder)
                    if f.lower().endswith(".txt")
                ]
                
                for text_file in sorted(text_files):
                    text_path = os.path.join(text_folder, text_file)
                    result = self.process_text_file_for_pii(text_path)
                    if result.get("success"):
                        # Add source attribution to each PII entity
                        for pii_entity in result["pii_entities"]:
                            pii_entity["Detection_Method"] = detection_method
                            pii_entity["File_Name"] = os.path.basename(text_file)
                            pii_entity["Folder"] = os.path.basename(folder_path)
                            pii_entity["Source_Type"] = "text_file"
                            pii_entity["Original_Text"] = result["text"]
                            pii_entity["Extraction_Confidence"] = 100.0  # Perfect for text files
                            folder_pii_entities.append(pii_entity)
            
            return folder_pii_entities
            
        except Exception as e:
            logging.error(f"Error collecting results from folder {folder_path}: {e}")
            return []

    # Excel Export Methods
    def extract_texts_to_excel_from_folder(self, folder_path: str, lang: str = None, output_file: Optional[str] = None) -> bool:
        """Process both images and text files from a folder and export results to Excel"""
        try:
            all_results: List[Dict[str, Any]] = []
            
            # Auto-detect language based on folder path if not provided
            if lang is None:
                lang = self._get_ocr_language_for_path(folder_path)
            
            # Process images from images/ folder
            images_folder = os.path.join(folder_path, "images")
            if os.path.exists(images_folder):
                # Check for enhanced folder first
                enhanced_folder = os.path.join(images_folder, "enhanced")
                images_source = enhanced_folder if os.path.exists(enhanced_folder) else images_folder
                logging.info(f"Using images from: {images_source}")
                
                image_files = [
                    f for f in os.listdir(images_source)
                    if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif"))
                ]
                
                if image_files:
                    logging.info(f"Processing {len(image_files)} images for OCR and PII detection")
                    for image_file in sorted(image_files):
                        image_path = os.path.join(images_source, image_file)
                        result = self.process_image_for_pii(image_path)  # Language auto-detected from path
                        result["source_type"] = "image_ocr"  # Mark as image source
                        all_results.append(result)
                else:
                    logging.info(f"No image files found in: {images_source}")
            
            # Process text files from extracted_text/ folder
            text_folder = os.path.join(folder_path, "extracted_text")
            if os.path.exists(text_folder):
                logging.info(f"Looking for text files in: {text_folder}")
                text_files = [
                    f for f in os.listdir(text_folder)
                    if f.lower().endswith(".txt")
                ]
                
                if text_files:
                    logging.info(f"Processing {len(text_files)} text files for PII detection")
                    for text_file in sorted(text_files):
                        text_path = os.path.join(text_folder, text_file)
                        result = self.process_text_file_for_pii(text_path)
                        all_results.append(result)
                else:
                    logging.info(f"No text files found in: {text_folder}")
            
            # Check if we have any results to process
            if not all_results:
                logging.warning(f"No files to process in folder: {folder_path}")
                return False
            
            # Log summary of what was processed
            image_count = sum(1 for r in all_results if r.get("source_type") == "image_ocr")
            text_count = sum(1 for r in all_results if r.get("source_type") == "text_file")
            logging.info(f"Total processed: {image_count} images, {text_count} text files")
            
            # Create the Excel report
            return self._create_excel_report(all_results, folder_path, output_file)
        except Exception as e:
            logging.error(f"Error extracting texts from folder {folder_path}: {e}")
            return False

    def _create_excel_report(self, results: List[Dict[str, Any]], folder_path: str, output_file: Optional[str] = None) -> bool:
        """Create Excel report with Summary, Text_Results, and PII_Detection sheets"""
        try:
            excel_rows: List[Dict[str, Any]] = []
            pii_rows: List[Dict[str, Any]] = []
            
            for res in results:
                if res.get("success"):
                    # Handle both image and text file sources
                    source_type = res.get("source_type", "image_ocr")
                    if source_type == "image_ocr":
                        file_path = res["image_path"]
                        filename = os.path.basename(file_path)
                        page_number = extract_page_number(filename)
                        confidence = round(float(res["confidence"]), 2)
                    else:  # text_file
                        file_path = res["text_file_path"]
                        filename = os.path.basename(file_path)
                        page_number = extract_page_number(filename)
                        confidence = 100.0  # Text files have perfect extraction confidence
                    
                    cleaned_text = res.get("cleaned_text", res["text"])
                    embedding = res.get("embedding", None)
                    
                    # Tokenize cleaned text (simple whitespace split)
                    tokenized_text = " | ".join(cleaned_text.split())
                    
                    # Get POS tags for cleaned text
                    pos_tags = res.get("pos_tags", "N/A")
                    
                    excel_rows.append({
                        "File": filename,
                        "Source_Type": source_type.replace("_", " ").title(),
                        "Page": page_number,
                        "Text": res["text"],
                        "Cleaned_Text": cleaned_text,
                        "Tokenized_Text": tokenized_text,
                        "POS_Tags": pos_tags,
                        "Text_Length": len(res["text"]),
                        "Extraction_Confidence": confidence,
                        "PII_Count": res["pii_count"],
                        "Embedding": f"[{len(embedding)} dims] " + str(embedding)[:100] + "..." if embedding else "N/A",
                        "Processing_Status": "Success",
                    })
                    
                    for pii in res["pii_entities"]:
                        sensitivity_level = get_sensitivity_level(pii["PII_Type"])
                        pii_rows.append({
                            "File": filename,
                            "Source_Type": source_type.replace("_", " ").title(),
                            "Page": page_number,
                            "Text": res["text"],
                            "PII_Type": pii["PII_Type"],
                            "PII_Value": pii["PII_Value"],
                            "PII_Length": len(pii["PII_Value"]),
                            "Confidence_Score": pii["Confidence"] if pii["Confidence"] is not None else "N/A",
                            "Source": pii["Source"],
                            "Start_Position": pii["start_pos"],
                            "End_Position": pii["end_pos"],
                            "Sensitivity_Level": sensitivity_level,
                            "Pattern": pii.get("pattern", ""),
                            "Label": pii.get("Label", ""),
                        })
                else:
                    # Handle failed processing
                    source_type = res.get("source_type", "image_ocr")
                    if source_type == "image_ocr":
                        file_path = res["image_path"]
                        filename = os.path.basename(file_path)
                        page_number = extract_page_number(filename)
                    else:  # text_file
                        file_path = res["text_file_path"]
                        filename = os.path.basename(file_path)
                        page_number = extract_page_number(filename)
                    
                    excel_rows.append({
                        "File": filename,
                        "Source_Type": source_type.replace("_", " ").title(),
                        "Page": page_number,
                        "Text": "",
                        "Cleaned_Text": "",
                        "Tokenized_Text": "",
                        "POS_Tags": "",
                        "Text_Length": 0,
                        "Extraction_Confidence": 0.0,
                        "PII_Count": 0,
                        "Embedding": "N/A",
                        "Processing_Status": f"Failed: {res.get('error', 'Unknown error')}",
                    })
            
            main_df = pd.DataFrame(excel_rows)
            pii_df = pd.DataFrame(pii_rows)
            summary_stats = self._generate_summary_stats(main_df, pii_df)
            summary_df = pd.DataFrame([summary_stats])
            
            if output_file is None:
                os.makedirs(self.output_dir, exist_ok=True)
                folder_name = os.path.basename(folder_path.rstrip(os.sep))
                timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(self.output_dir, f"OCR_PII_Analysis_{folder_name}_{timestamp}.xlsx")
            
            with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
                summary_df.to_excel(writer, sheet_name="Summary", index=False)
                main_df.to_excel(writer, sheet_name="Text_Results", index=False)
                if not pii_df.empty:
                    pii_df.to_excel(writer, sheet_name="PII_Detection", index=False)
                self._format_excel_sheets(writer, main_df, pii_df, summary_df)
            
            # Count different source types for logging
            image_count = len([r for r in excel_rows if r.get("Source_Type") == "Image Ocr"])
            text_count = len([r for r in excel_rows if r.get("Source_Type") == "Text File"])
            logging.info(f"Excel report created: {output_file}")
            logging.info(f"Report contains: {image_count} images, {text_count} text files, {len(pii_df)} PII entities")
            
            return True
        except Exception as e:
            logging.error(f"Error creating Excel report: {e}")
            return False

    def _generate_summary_stats(self, main_df: pd.DataFrame, pii_df: pd.DataFrame) -> Dict[str, Any]:
        """Generate summary statistics for the Excel report"""
        try:
            stats: Dict[str, Any] = {
                "Report_Generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Total_Images_Processed": int(len(main_df)),
                "Successful_OCR_Extractions": int(len(main_df[main_df["Processing_Status"] == "Success"])),
                "Failed_OCR_Extractions": int(len(main_df[main_df["Processing_Status"] != "Success"])),
                "Total_PII_Entities_Found": int(len(pii_df)) if not pii_df.empty else 0,
                "Average_OCR_Confidence": float(main_df["Extraction_Confidence"].mean()) if not main_df.empty else 0.0,
                "Total_Text_Characters": int(main_df["Text_Length"].sum()) if not main_df.empty else 0,
            }

            if not pii_df.empty:
                for pii_type, count in pii_df["PII_Type"].value_counts().head(10).items():
                    stats[f"PII_Count_{pii_type}"] = int(count)

                for level, count in pii_df["Sensitivity_Level"].value_counts().items():
                    stats[f"{level}_Sensitivity_PII"] = int(count)

                for source, count in pii_df["Source"].value_counts().items():
                    stats[f"Detection_Method_{source}"] = int(count)

            return stats
        except Exception as e:
            logging.error(f"Error generating summary stats: {e}")
            return {"Error": str(e)}

    def _format_excel_sheets(self, writer: pd.ExcelWriter, main_df: pd.DataFrame, pii_df: pd.DataFrame, summary_df: pd.DataFrame) -> None:
        """Apply formatting to Excel sheets"""
        try:
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter

            # Summary sheet formatting
            ws_summary = writer.sheets.get("Summary")
            if ws_summary:
                for col_idx, width in enumerate([30, 22], start=1):
                    ws_summary.column_dimensions[get_column_letter(col_idx)].width = width
                for cell in ws_summary[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="CCCCCC", end_color="CCCCCC", fill_type="solid")
                ws_summary.freeze_panes = "A2"

            # Text_Results sheet formatting
            ws_main = writer.sheets.get("Text_Results")
            if ws_main:
                widths = [25, 8, 60, 60, 80, 100, 15, 18, 12, 40, 20]
                for idx, w in enumerate(widths, start=1):
                    ws_main.column_dimensions[get_column_letter(idx)].width = w
                for cell in ws_main[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
                # Apply wrap text to text columns
                for row in ws_main.iter_rows(min_row=2):
                    for col_letter in ["C", "D", "E", "F", "J"]:
                        ws_main[f"{col_letter}{row[0].row}"].alignment = Alignment(wrap_text=True, vertical="top")
                ws_main.freeze_panes = "A2"

            # PII_Detection sheet formatting
            ws_pii = writer.sheets.get("PII_Detection")
            if ws_pii and not pii_df.empty:
                widths = [25, 8, 80, 28, 18, 14, 14, 16, 16, 16, 18]
                for idx, w in enumerate(widths, start=1):
                    ws_pii.column_dimensions[get_column_letter(idx)].width = w
                for cell in ws_pii[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")

                for row_idx in range(2, len(pii_df) + 2):
                    sensitivity = ws_pii[f"K{row_idx}"].value if ws_pii.max_column >= 11 else None
                    if sensitivity == "High":
                        fill = PatternFill(start_color="FFEEEE", end_color="FFEEEE", fill_type="solid")
                    elif sensitivity == "Medium":
                        fill = PatternFill(start_color="FFFFEE", end_color="FFFFEE", fill_type="solid")
                    else:
                        fill = PatternFill(start_color="EEFFEE", end_color="EEFFEE", fill_type="solid")
                    for col_idx in range(1, ws_pii.max_column + 1):
                        ws_pii.cell(row=row_idx, column=col_idx).fill = fill
                    # Apply wrap text to text columns
                    for col_letter in ["C", "E"]:
                        ws_pii[f"{col_letter}{row_idx}"].alignment = Alignment(wrap_text=True, vertical="top")
                ws_pii.freeze_panes = "A2"

        except Exception as e:
            logging.warning(f"Error formatting Excel sheets: {e}")

    # Main workflow methods
    def process_all_folders(self) -> bool:
        """Process all subfolders under input_dir for PII detection"""
        try:
            logging.info("Starting text processing and PII detection for all folders")
            folders_to_process: List[str] = []
            
            for item in os.listdir(self.input_dir):
                folder_path = os.path.join(self.input_dir, item)
                if os.path.isdir(folder_path) and item != "_file_input":
                    images_folder = os.path.join(folder_path, "images")
                    text_folder = os.path.join(folder_path, "extracted_text")
                    # Include folder if it has either images or extracted text
                    if os.path.exists(images_folder) or os.path.exists(text_folder):
                        folders_to_process.append(folder_path)

            if not folders_to_process:
                logging.warning("No folders with images or extracted text found for processing")
                return False

            logging.info(f"Found {len(folders_to_process)} folders to process")
            success_count = 0
            for folder_path in sorted(folders_to_process):
                try:
                    if self.extract_texts_to_excel_from_folder(folder_path):
                        success_count += 1
                        logging.info(f"Successfully processed folder: {os.path.basename(folder_path)}")
                    else:
                        logging.warning(f"Failed to process folder: {os.path.basename(folder_path)}")
                except Exception as e:
                    logging.error(f"Error processing folder {folder_path}: {e}")

            logging.info(
                f"Text processing and PII detection completed: {success_count}/{len(folders_to_process)} folders processed successfully"
            )
            return success_count > 0
        except Exception as e:
            logging.error(f"Error in process_all_folders: {e}")
            return False

    def create_hybrid_excel_report(self, combined_pii_entities: List[Dict[str, Any]], 
                                  merge_strategy: str = "union") -> bool:
        """
        Generate a single Excel report from combined PII entities (hybrid mode)
        
        Args:
            combined_pii_entities: List of PII entities from multiple detection methods
            merge_strategy: The merge strategy used ("union", "intersection", "ml_priority")
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            if not combined_pii_entities:
                logging.warning("No PII entities to report in hybrid mode")
                return False
            
            # Create Excel rows from combined entities
            pii_rows = []
            for pii_entity in combined_pii_entities:
                # Get page number from filename
                filename = pii_entity.get("File_Name", "unknown")
                page_number = extract_page_number(filename)
                sensitivity_level = get_sensitivity_level(pii_entity["PII_Type"])
                
                pii_rows.append({
                    "File": filename,
                    "Folder": pii_entity.get("Folder", ""),
                    "Source_Type": pii_entity.get("Source_Type", "").replace("_", " ").title(),
                    "Page": page_number,
                    "PII_Type": pii_entity["PII_Type"],
                    "PII_Value": pii_entity["PII_Value"],
                    "PII_Length": len(pii_entity["PII_Value"]),
                    "Confidence_Score": pii_entity.get("Confidence", "N/A"),
                    "Detection_Method": pii_entity.get("Detection_Method", "unknown"),
                    "Source": pii_entity.get("Source", ""),
                    "Start_Position": pii_entity.get("start_pos", ""),
                    "End_Position": pii_entity.get("end_pos", ""),
                    "Sensitivity_Level": sensitivity_level,
                    "Pattern": pii_entity.get("pattern", ""),
                    "Label": pii_entity.get("Label", ""),
                    "Original_Text": pii_entity.get("Original_Text", "")[:100] + "..." if len(pii_entity.get("Original_Text", "")) > 100 else pii_entity.get("Original_Text", ""),
                    "Extraction_Confidence": pii_entity.get("Extraction_Confidence", "N/A")
                })
            
            # Create DataFrames
            pii_df = pd.DataFrame(pii_rows)
            
            # Generate summary statistics for hybrid mode
            hybrid_summary = self._generate_hybrid_summary_stats(pii_df, merge_strategy)
            summary_df = pd.DataFrame([hybrid_summary])
            
            # Generate output filename
            os.makedirs(self.output_dir, exist_ok=True)
            timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_file = os.path.join(self.output_dir, f"OCR_PII_Analysis_HYBRID_{timestamp}.xlsx")
            
            # Create Excel file
            with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
                summary_df.to_excel(writer, sheet_name="Hybrid_Summary", index=False)
                pii_df.to_excel(writer, sheet_name="Combined_PII_Results", index=False)
                
                # Create method breakdown sheets if we have multiple methods
                detection_methods = pii_df["Detection_Method"].unique()
                if len(detection_methods) > 1:
                    for method in detection_methods:
                        method_df = pii_df[pii_df["Detection_Method"] == method]
                        sheet_name = f"{method.upper()}_Results"[:31]  # Excel sheet name limit
                        method_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                # Format the sheets
                self._format_hybrid_excel_sheets(writer, pii_df, summary_df)
            
            logging.info(f"Hybrid Excel report created: {output_file}")
            logging.info(f"Report contains: {len(pii_df)} PII entities from {len(detection_methods)} detection method(s)")
            logging.info(f"Merge strategy used: {merge_strategy}")
            
            return True
            
        except Exception as e:
            logging.error(f"Error creating hybrid Excel report: {e}")
            return False

    def _generate_hybrid_summary_stats(self, pii_df: pd.DataFrame, merge_strategy: str) -> Dict[str, Any]:
        """Generate summary statistics for hybrid mode Excel report"""
        try:
            # Count entities by detection method
            method_counts = pii_df["Detection_Method"].value_counts().to_dict()
            
            # Count by PII type
            pii_type_counts = pii_df["PII_Type"].value_counts().to_dict()
            
            # Count by source type
            source_type_counts = pii_df["Source_Type"].value_counts().to_dict()
            
            stats = {
                "Report_Generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Report_Type": "Hybrid Detection Analysis",
                "Merge_Strategy": merge_strategy,
                "Total_PII_Entities": len(pii_df),
                "Unique_Files_Processed": pii_df["File"].nunique(),
                "Detection_Methods_Used": ", ".join(method_counts.keys()),
                "Regex_Entities": method_counts.get("regex", 0),
                "ML_Entities": method_counts.get("ml", 0),
                "Most_Common_PII_Type": max(pii_type_counts.items(), key=lambda x: x[1])[0] if pii_type_counts else "None",
                "Image_OCR_Entities": source_type_counts.get("Image Ocr", 0),
                "Text_File_Entities": source_type_counts.get("Text File", 0),
                "Average_PII_Length": float(pii_df["PII_Length"].mean()) if not pii_df.empty else 0.0,
            }
            
            return stats
            
        except Exception as e:
            logging.error(f"Error generating hybrid summary stats: {e}")
            return {"Error": str(e)}

    def _format_hybrid_excel_sheets(self, writer, pii_df: pd.DataFrame, summary_df: pd.DataFrame):
        """Format the hybrid Excel report sheets"""
        try:
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils.dataframe import dataframe_to_rows
            
            # Format summary sheet
            summary_ws = writer.sheets["Hybrid_Summary"]
            summary_ws.column_dimensions['A'].width = 25
            summary_ws.column_dimensions['B'].width = 30
            
            # Format main PII results sheet
            pii_ws = writer.sheets["Combined_PII_Results"]
            
            # Set column widths
            pii_ws.column_dimensions['A'].width = 15  # File
            pii_ws.column_dimensions['B'].width = 15  # Folder
            pii_ws.column_dimensions['C'].width = 12  # Source_Type
            pii_ws.column_dimensions['E'].width = 12  # PII_Type
            pii_ws.column_dimensions['F'].width = 25  # PII_Value
            pii_ws.column_dimensions['I'].width = 15  # Detection_Method
            
            # Color code by detection method
            method_colors = {
                "regex": PatternFill(start_color="FFE6E6", end_color="FFE6E6", fill_type="solid"),  # Light red
                "ml": PatternFill(start_color="E6F3FF", end_color="E6F3FF", fill_type="solid"),     # Light blue
            }
            
            for row in pii_ws.iter_rows(min_row=2, max_row=len(pii_df) + 1):
                detection_method = row[8].value  # Detection_Method column
                if detection_method in method_colors:
                    for cell in row:
                        cell.fill = method_colors[detection_method]
                        
        except Exception as e:
            logging.warning(f"Could not format Excel sheets: {e}")

    @abstractmethod
    def get_processing_summary(self) -> Dict[str, Any]:
        """Build a JSON summary of the last run - must be implemented by subclasses"""
        pass

    @abstractmethod 
    def run_flow(self) -> bool:
        """Main workflow - must be implemented by subclasses"""
        pass
