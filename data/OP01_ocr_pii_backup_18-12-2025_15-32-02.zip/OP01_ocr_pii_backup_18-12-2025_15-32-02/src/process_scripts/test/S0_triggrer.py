"""
S0_trigger.py

Phase 4: Trigger iteration for searching for new files or modifications to review.
This script scans the input folder, detects new or modified files, copies them to the destination folder,
and saves metadata about each file in both JSON and Excel formats with comprehensive lifecycle tracking.

Features:
- File lifecycle status tracking (nuevo_archivo, modificado, active_file, file_eliminated)
- Time without modification calculations
- Enhanced metadata with file stability analytics
- Comprehensive logging and monitoring

Usage:
    python S0_triggrer.py

Dependencies:
    - src/utils/fmw_utils.py
    - src/utils/send_exceptions_emails.py
    - src/process_scripts/base_process.py

Author: Andres Vera
Date: [Date]
"""

import os
import sys
import logging
import datetime as dt
from datetime import timedelta
from typing import Dict, List, Optional, Any
import pandas as pd
import json
import shutil
from openpyxl.styles import PatternFill, Font, Alignment

# Add src to path for imports
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.utils.fmw_utils import start_logging, read_config, save_json_file, create_folder, Config, save_excel_file
# from src.utils.send_exceptions_emails import ExceptionEmails
from src.process_scripts.base_process import ProcessBase


class S0_trigger(ProcessBase):
    """
    Main process class for comprehensive file change detection and organization.

    This class scans the input folder for files, detects new or modified files with complete
    lifecycle tracking, copies them to the destination folder, and saves enhanced metadata
    including time without modification analysis in JSON and Excel formats.
    
    Attributes:
        state_name (str): Process identifier
        now (datetime): Current timestamp for calculations
        sharepoint (str): Input folder path from configuration
        destination_folder (str): Destination folder path from configuration
        exception_handler (ExceptionEmails): Error notification handler
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the file organizer with configuration and logging.
        
        Args:
            config (dict, optional): Configuration dictionary from config.jsonc
        """
        super().__init__(config=config) 
        self.state_name = "S0_trigger"
        self.now = dt.datetime.now()
        # self.exception_handler = ExceptionEmails()

        # Load configuration paths
        self.sharepoint = self.config_env["INPUT_FOLDER"]
        self.destination_folder = self.config_env["DOWNLOAD_FOLDER"]
        
    def get_previous_files(self, previous_files_path: str) -> Dict[str, Dict[str, str]]:
        """
        Load the dict of previously seen files with their metadata from a JSON file.
        Supports both old format {file_path: last_modified} and new format {file_path: {last_modified: str, last_reviewed: str}}.
        
        Args:
            previous_files_path (str): Path to previous_files.json
            
        Returns:
            dict: {file_path: {last_modified: str, last_reviewed: str}} mapping of previously seen files
            
        Example:
            previous_files = self.get_previous_files("output/previous_files.json")
        """
        if os.path.exists(previous_files_path):
            try:
                with open(previous_files_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                if not isinstance(data, dict):
                    return {}
                
                # Handle both old and new formats
                normalized_data = {}
                for file_path, value in data.items():
                    if isinstance(value, str):
                        # Old format: {file_path: last_modified}
                        normalized_data[file_path] = {
                            "last_modified": value,
                            "last_reviewed": self.now.isoformat(),  # Use current time as fallback
                            "file_add": None,  # Unknown for old format
                            "size_bytes": None,
                            "creation_time": None  # Unknown for old format
                        }
                    elif isinstance(value, dict) and "last_modified" in value:
                        # New format: {file_path: {last_modified: str, last_reviewed: str, file_add: str, size_bytes: int}}
                        normalized_data[file_path] = {
                            "last_modified": value.get("last_modified"),
                            "last_reviewed": value.get("last_reviewed", self.now.isoformat()),
                            # Keep file_add if present; do not rely on filesystem ctime here
                            "file_add": value.get("file_add"),
                            "size_bytes": value.get("size_bytes"),
                            "creation_time": value.get("creation_time")  # Preserve creation_time if present
                        }
                    else:
                        logging.warning(f"Invalid format for file {file_path} in previous_files.json")
                
                logging.info(f"Loaded {len(normalized_data)} previous files (normalized to new format)")
                return normalized_data
                
            except Exception as e:
                logging.warning(f"Could not load previous files: {e}")
        return {}

    def get_last_review_timestamp(self, last_review_path: str) -> str:
        """
        Load the last review timestamp from a file.
        
        Args:
            last_review_path (str): Path to last_review.txt
            
        Returns:
            str: ISO datetime string of last review, or current time minus 7 days if not found
            
        Example:
            last_reviewed = self.get_last_review_timestamp("output/last_review.txt")
        """
        if os.path.exists(last_review_path):
            try:
                with open(last_review_path, 'r', encoding='utf-8') as f:
                    return f.read().strip()
            except Exception as e:
                logging.warning(f"Could not load last review timestamp: {e}")
        
        # Default to 7 days ago if no previous review found
        default_time = (self.now - timedelta(days=7)).isoformat()
        logging.info(f"No previous review found, defaulting to 7 days ago: {default_time}")
        return default_time

    def save_last_review_timestamp(self, last_review_path: str) -> None:
        """
        Save the current timestamp as the last review time.
        
        Args:
            last_review_path (str): Path to last_review.txt
            
        Raises:
            Exception: If unable to save timestamp file
        """
        try:
            os.makedirs(os.path.dirname(last_review_path), exist_ok=True)
            with open(last_review_path, 'w', encoding='utf-8') as f:
                f.write(self.now.isoformat())
            logging.info(f"Saved last review timestamp to {last_review_path}")
        except Exception as e:
            logging.error(f"Failed to save last review timestamp: {e}")
            raise

    def save_current_files(self, files: List[str], previous_files_path: str, metadata_list: Optional[List[Dict]] = None, previous_files: Optional[Dict[str, Dict[str, Any]]] = None) -> None:
        """
        Save consolidated file tracking to previous_files.json - preserving ALL historical records.
        
        Behavior:
        - NEVER delete entries from previous_files.json (preserve deleted file records permanently)
        - Update last_reviewed only for files present in current run
        - For eliminated files, preserve their last_reviewed (when they were last seen)
        - For new files, set file_add = current time (when first detected)
        - For existing files, preserve original file_add timestamp
        
        Args:
            files (list): List of current file paths
            previous_files_path (str): Path to previous_files.json
            metadata_list (list, optional): List of current file metadata dicts
            previous_files (dict, optional): Previously loaded file records to merge with
            
        Raises:
            Exception: If unable to save consolidated files data
        """
        try:
            os.makedirs(os.path.dirname(previous_files_path), exist_ok=True)
            current_review_time = self.now.isoformat()

            # Start from previous_files to preserve ALL historical entries (including deleted files)
            consolidated_dict: Dict[str, Dict[str, Any]] = {}
            
            # Step 1: Load ALL previous entries (never delete any records)
            if previous_files:
                for file_path, file_data in previous_files.items():
                    # Copy existing entry, preserving all historical data
                    if isinstance(file_data, dict):
                        consolidated_dict[file_path] = dict(file_data)
                    else:
                        # Handle old format
                        consolidated_dict[file_path] = {
                            "last_modified": file_data,
                            "last_reviewed": file_data,  # Keep original as fallback
                            "file_add": None,
                            "size_bytes": None,
                            "creation_time": None  # Unknown for old format
                        }

            # Step 2: Update/add current files (only update last_reviewed for files present now)
            current_file_paths = set(files)
            
            if metadata_list:
                # Use metadata from current run
                for m in metadata_list:
                    file_path = m.get("path")
                    if not file_path:
                        continue
                        
                    existing_entry = consolidated_dict.get(file_path, {})
                    
                    # Preserve original file_add if it exists, otherwise set to current time (new file)
                    file_add_value = existing_entry.get("file_add") or m.get("file_add") or current_review_time
                    
                    consolidated_dict[file_path] = {
                        "last_modified": m.get("last_modified"),
                        "last_reviewed": current_review_time,  # Update only for current files
                        "file_add": file_add_value,
                        "size_bytes": m.get("size_bytes"),
                        "creation_time": existing_entry.get("creation_time") or m.get("creation_time")  # Preserve creation_time
                    }
            else:
                # Fallback: inspect filesystem for current files
                for file_path in files:
                    try:
                        last_modified_ts = os.path.getmtime(file_path)
                        last_modified_str = dt.datetime.fromtimestamp(last_modified_ts).isoformat()
                        try:
                            size_bytes = os.path.getsize(file_path)
                        except Exception:
                            size_bytes = None

                        existing_entry = consolidated_dict.get(file_path, {})
                        file_add_value = existing_entry.get("file_add") or current_review_time

                        consolidated_dict[file_path] = {
                            "last_modified": last_modified_str,
                            "last_reviewed": current_review_time,
                            "file_add": file_add_value,
                            "size_bytes": size_bytes,
                            "creation_time": existing_entry.get("creation_time") or dt.datetime.fromtimestamp(os.path.getctime(file_path)).isoformat()
                        }
                    except Exception as e:
                        logging.warning(f"Could not get file times for {file_path}: {e}")
                        existing_entry = consolidated_dict.get(file_path, {})
                        consolidated_dict[file_path] = {
                            "last_modified": existing_entry.get("last_modified"),
                            "last_reviewed": current_review_time,
                            "file_add": existing_entry.get("file_add") or current_review_time,
                            "size_bytes": existing_entry.get("size_bytes"),
                            "creation_time": existing_entry.get("creation_time")  # Preserve creation_time from existing entry
                        }

            # Step 3: Write consolidated data atomically (preserves all historical records)
            tmp_path = f"{previous_files_path}.tmp"
            with open(tmp_path, 'w', encoding='utf-8') as f:
                json.dump(consolidated_dict, f, ensure_ascii=False, indent=4)
            os.replace(tmp_path, previous_files_path)
            
            current_count = len([p for p in consolidated_dict.keys() if p in current_file_paths])
            historical_count = len(consolidated_dict) - current_count
            
            logging.info(f"Saved consolidated file tracking to {previous_files_path}: "
                        f"{current_count} current files, {historical_count} historical entries, "
                        f"{len(consolidated_dict)} total entries preserved")
        except Exception as e:
            logging.error(f"Failed to save current files: {e}")
            raise

    def get_files_to_process(self) -> List[str]:
        """
        Get a list of DOCX and PDF files to process from the SharePoint folder.

        Only files with .docx or .pdf extension will be included, as required for downstream processing.

        Returns:
            list: A list of DOCX and PDF file paths to process
            
        Raises:
            Exception: If unable to access input directory

        Example:
            files = self.get_files_to_process()
        """
        logging.info(f"Searching for DOCX and PDF files in: {self.sharepoint}")
        files = []
        
        if not os.path.exists(self.sharepoint):
            error_msg = f"Input folder does not exist: {self.sharepoint}"
            logging.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        try:
            # Recursively list all files in the SharePoint folder
            for root, _, filenames in os.walk(self.sharepoint):
                for filename in filenames:
                    if filename.lower().endswith(('.docx', '.pdf')):
                        file_path = os.path.join(root, filename)
                        files.append(file_path)
            
            logging.info(f"Found {len(files)} DOCX/PDF files to process")
            if files:
                logging.debug(f"Files found: {[os.path.basename(f) for f in files]}")
            
        except Exception as e:
            logging.error(f"Error retrieving files from {self.sharepoint}: {e}")
            raise
            
        return files
    
    def _format_time_duration(self, time_delta: timedelta) -> str:
        """
        Format a timedelta into a human-readable string.
        
        Args:
            time_delta (timedelta): Time duration to format
            
        Returns:
            str: Human-readable time duration (e.g., "2 days, 5 hours", "30 minutes", "1 hour")
            
        Example:
            formatted = self._format_time_duration(timedelta(days=2, hours=5, minutes=30))
            # Returns: "2 days and 5 hours"
        """
        try:
            total_seconds = int(time_delta.total_seconds())
            
            if total_seconds < 0:
                return "0 minutes"
            
            days = total_seconds // 86400
            hours = (total_seconds % 86400) // 3600
            minutes = (total_seconds % 3600) // 60
            
            parts = []
            
            if days > 0:
                parts.append(f"{days} {'day' if days == 1 else 'days'}")
            
            if hours > 0:
                parts.append(f"{hours} {'hour' if hours == 1 else 'hours'}")
            
            if minutes > 0 and days == 0:  # Only show minutes if less than a day
                parts.append(f"{minutes} {'minute' if minutes == 1 else 'minutes'}")
            
            if not parts:  # Less than a minute
                return "Less than 1 minute"
            
            # Join with commas, but use "and" for the last part if there are multiple parts
            if len(parts) == 1:
                return parts[0]
            elif len(parts) == 2:
                return f"{parts[0]} and {parts[1]}"
            else:
                return f"{', '.join(parts[:-1])}, and {parts[-1]}"
                
        except Exception as e:
            logging.warning(f"Error formatting time duration: {e}")
            return "Unknown duration"

    def get_files_metadata(self, files: List[str], last_reviewed: Optional[str] = None, previous_files: Optional[Dict[str, Dict[str, str]]] = None) -> List[Dict[str, Any]]:
        """
        Extract metadata for each file, including comprehensive lifecycle tracking and time analysis.
        
        Args:
            files (list): List of file paths
            last_reviewed (str, optional): ISO datetime string of last review
            previous_files (dict, optional): Dict of previously seen file paths and their metadata {file_path: {last_modified: str, last_reviewed: str}}
            
        Returns:
            list: List of dicts with comprehensive file metadata including time_without_modification
            
        Example:
            metadata = self.get_files_metadata(files, last_reviewed, previous_files)
        """
        metadata_list = []
        current_time = dt.datetime.now()
        
        for file_path in files:
            try:
                # Get file system metadata
                last_modified = os.path.getmtime(file_path)
                last_modified_dt = dt.datetime.fromtimestamp(last_modified).isoformat()
                last_modified_dt_obj = dt.datetime.fromtimestamp(last_modified)
                creation_time = os.path.getctime(file_path)
                creation_time_dt = dt.datetime.fromtimestamp(creation_time).isoformat()
                # File size in bytes
                try:
                    size_bytes = os.path.getsize(file_path)
                except Exception:
                    size_bytes = None
                
                # Calculate time without modification (from last modification to now)
                time_since_last_mod = current_time - last_modified_dt_obj
                time_without_modification_days = round(time_since_last_mod.days + (time_since_last_mod.seconds / 86400), 2)
                
                # Base metadata structure
                metadata = {
                    "name": os.path.basename(file_path),
                    "path": file_path,
                    "creation_time": creation_time_dt,
                    "last_modified": last_modified_dt,
                    "size_bytes": size_bytes,
                    "time_without_modification_days": time_without_modification_days,
                    "time_without_modification_readable": self._format_time_duration(time_since_last_mod),
                    "file_add": None,  # Canonical first-seen / added timestamp
                    "actual_review": current_time.isoformat()  # Current process execution timestamp
                }
                
                # Add last reviewed comparison if available
                if last_reviewed:
                    metadata["last_reviewed"] = last_reviewed
                    try:
                        last_reviewed_dt_obj = dt.datetime.fromisoformat(last_reviewed)
                        is_modified = last_modified_dt_obj > last_reviewed_dt_obj
                        metadata["modified_since_last_review"] = is_modified
                    except Exception as e:
                        metadata["modified_since_last_review"] = None
                        logging.warning(f"Could not compare last_modified and last_reviewed for {file_path}: {e}")
                
                # Determine file status based on previous files comparison
                if previous_files is not None:
                    prev_file_data = previous_files.get(file_path)
                    prev_mod = prev_file_data.get("last_modified") if prev_file_data else None
                    prev_file_add = prev_file_data.get("file_add") if prev_file_data else None

                    metadata["is_new_file"] = prev_file_data is None
                    metadata["modified_since_previous_run"] = (prev_mod is not None and last_modified_dt != prev_mod)

                    # Determine status_file based on file lifecycle
                    if prev_file_data is None:
                        metadata["status_file"] = "nuevo_archivo"
                        # New file - mark first-seen as now (consistent auditing)
                        metadata["file_add"] = current_time.isoformat()
                    elif last_modified_dt != prev_mod:
                        metadata["status_file"] = "modificado"
                        # Modified file - preserve original file_add if present
                        metadata["file_add"] = prev_file_add or current_time.isoformat()
                    else:
                        metadata["status_file"] = "active_file"
                        # Active file - preserve original file_add if present
                        metadata["file_add"] = prev_file_add or current_time.isoformat()
                else:
                    # First run - all files are considered new
                    metadata["is_new_file"] = True
                    metadata["modified_since_previous_run"] = False
                    metadata["status_file"] = "nuevo_archivo"
                    # First run - set file_add to the detection time
                    metadata["file_add"] = current_time.isoformat()
                
                metadata_list.append(metadata)
                
            except Exception as e:
                logging.warning(f"Could not get metadata for {file_path}: {e}")
                
        return metadata_list

    def get_eliminated_files_metadata(self, current_files: List[str], previous_files: Dict[str, Dict[str, str]]) -> List[Dict[str, Any]]:
        """
        Detect files that were present in previous run but are missing now.
        
        Args:
            current_files (list): List of current file paths
            previous_files (dict): Dict of previously seen file paths and their metadata {file_path: {last_modified: str, last_reviewed: str}}
            
        Returns:
            list: List of metadata dicts for eliminated files
            
        Example:
            eliminated = self.get_eliminated_files_metadata(current_files, previous_files)
        """
        eliminated_metadata = []
        
        if not previous_files:
            return eliminated_metadata
        
        current_file_set = set(current_files)
        current_time = dt.datetime.now()
        
        for prev_file_path, prev_file_data in previous_files.items():
            if prev_file_path not in current_file_set:
                try:
                    prev_last_modified = prev_file_data.get("last_modified") if prev_file_data else None
                    prev_last_reviewed = prev_file_data.get("last_reviewed") if prev_file_data else None
                    prev_file_add = prev_file_data.get("file_add") if prev_file_data else None
                    prev_size = prev_file_data.get("size_bytes") if prev_file_data else None
                    prev_creation_time = prev_file_data.get("creation_time") if prev_file_data else None

                    # Calculate time since last known modification for eliminated files
                    if prev_last_modified:
                        prev_mod_dt = dt.datetime.fromisoformat(prev_last_modified)
                        time_since_last_mod = current_time - prev_mod_dt
                        time_without_modification_days = round(time_since_last_mod.days + (time_since_last_mod.seconds / 86400), 2)
                        time_readable = self._format_time_duration(time_since_last_mod)
                    else:
                        time_without_modification_days = None
                        time_readable = "Unknown"

                    # File was present before but is missing now
                    eliminated_metadata.append({
                        "name": os.path.basename(prev_file_path),
                        "path": prev_file_path,
                        "creation_time": prev_creation_time,  # Preserve original creation_time from when file was tracked
                        "last_modified": prev_last_modified,
                        "size_bytes": prev_size,
                        "time_without_modification_days": time_without_modification_days,
                        "time_without_modification_readable": time_readable,
                        "last_reviewed": prev_last_reviewed,  # When the file was last seen
                        "file_add": prev_file_add,  # When the file was added to the folder (preserved)
                        "actual_review": current_time.isoformat(),  # Current process execution timestamp
                        "modified_since_last_review": None,
                        "is_new_file": False,
                        "modified_since_previous_run": False,
                        "status_file": "file_eliminated",
                        "moved_to_destination": False,
                        "move_reason": "file_eliminated",
                        "destination_name": None
                    })

                    # Log with last reviewed information
                    if prev_last_reviewed:
                        logging.info(f"Detected eliminated file: {prev_file_path} (last seen: {prev_last_reviewed})")
                    else:
                        logging.info(f"Detected eliminated file: {prev_file_path} (last seen: unknown)")

                except Exception as e:
                    logging.warning(f"Error processing eliminated file {prev_file_path}: {e}")
        
        return eliminated_metadata
    
    def save_files_metadata_json(self, metadata_list: List[Dict[str, Any]], output_path: str) -> bool:
        """
        Save the file metadata list as a JSON file.

        Args:
            metadata_list (list): List of file metadata dicts
            output_path (str): Path to save the JSON file

        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(metadata_list, f, ensure_ascii=False, indent=4)
            logging.info(f"File metadata saved to JSON: {output_path}")
            return True
        except Exception as e:
            logging.error(f"Failed to save file metadata JSON: {e}")
            return False

    def append_audit_event(self, event: Dict[str, Any], events_filename: str = "file_events.jsonl") -> None:
        """
        Append an event as a JSON line to an immutable audit log (JSONL).

        Args:
            event (dict): Event payload to append.
            events_filename (str): Filename for the events log under the configured output folder.
        """
        try:
            events_dir = os.path.join(self.config_env.get("OUTPUT_FOLDER", "output"))
            os.makedirs(events_dir, exist_ok=True)
            events_path = os.path.join(events_dir, events_filename)
            with open(events_path, 'a', encoding='utf-8') as f:
                f.write(json.dumps(event, ensure_ascii=False) + "\n")
            logging.debug(f"Appended audit event: {event.get('event')} for {event.get('path')}")
        except Exception as e:
            logging.warning(f"Failed to append audit event: {e}")
    
    def save_files_metadata_excel(self, metadata_list: List[Dict[str, Any]], output_path: str, last_reviewed: Optional[str] = None) -> bool:
        """
        Save the file metadata list as an Excel file with enhanced formatting.
        Uses the same columns as the JSON output for consistency.
        
        Args:
            metadata_list (list): List of file metadata dicts
            output_path (str): Path to save the Excel file
            last_reviewed (str, optional): Last reviewed timestamp
            
        Returns:
            bool: True if saved successfully, False otherwise
            
        Example:
            success = self.save_files_metadata_excel(metadata_list, 'output/files_metadata.xlsx')
        """
        try:
            # Create DataFrame from metadata list (same as JSON structure)
            df = pd.DataFrame(metadata_list)
            
            # Add last_reviewed column if provided and not already present
            if last_reviewed and "last_reviewed" not in df.columns:
                df["last_reviewed"] = last_reviewed
            
            # Define comprehensive column order to match JSON structure
            # This ensures Excel has all the same columns as JSON
            preferred_column_order = [
                "name", 
                "path", 
                "status_file",
                "creation_time", 
                "last_modified",
                "size_bytes",
                "file_add",              # When file was added to the folder
                "actual_review",         # Current process execution timestamp
                "last_reviewed",         # When file was last seen (different from actual_review)
                "time_without_modification_days", 
                "time_without_modification_readable",
                "modified_since_last_review",
                "is_new_file", 
                "modified_since_previous_run",
                "moved_to_destination", 
                "move_reason", 
                "destination_name"
            ]
            
            # Reorder columns: preferred order first, then any additional columns
            available_columns = [col for col in preferred_column_order if col in df.columns]
            remaining_columns = [col for col in df.columns if col not in preferred_column_order]
            final_column_order = available_columns + remaining_columns
            
            # Apply column ordering
            df = df[final_column_order]
            
            # Log column information for debugging and include literal df.columns
            try:
                logging.info(f"Excel will contain {len(df.columns)} columns: {list(df.columns)}")
                logging.debug(f"df.columns (raw): {df.columns}")
            except Exception:
                logging.debug('Could not log df.columns')
            logging.info(f"Excel will contain {len(df)} rows of data")
            
            # Use pandas directly to ensure all data is preserved
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            # Normalize datetime-like columns to ISO strings for better Excel display
            try:
                for col in df.columns:
                    try:
                        if pd.api.types.is_datetime64_any_dtype(df[col]):
                            df[col] = df[col].apply(lambda x: x.isoformat() if pd.notnull(x) else "")
                    except Exception:
                        # If dtype check fails for an odd column, skip it
                        continue
            except Exception:
                # Non-fatal: if anything goes wrong normal saving will still proceed
                logging.debug('Datetime normalization for Excel failed or skipped')

            # Prepare a small debug sheet listing all columns and their dtypes
            try:
                cols_info = pd.DataFrame({
                    'column': list(df.columns),
                    'dtype': [str(df[col].dtype) for col in df.columns]
                })
            except Exception:
                cols_info = pd.DataFrame({'column': list(df.columns)})

            # Save with pandas and openpyxl for full compatibility
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Files_Metadata', index=False)
                # Write columns + dtypes sheet for quick inspection of df.columns
                try:
                    cols_info.to_excel(writer, sheet_name='Columns', index=False)
                except Exception:
                    # If writing the extra sheet fails, continue without failing the whole save
                    logging.debug('Could not write Columns debug sheet')
                # Also write a raw representation of df.columns (literal pandas Index) so you can see `df.columns` exactly
                try:
                    raw_cols_df = pd.DataFrame({'df_columns': [str(df.columns)]})
                    raw_cols_df.to_excel(writer, sheet_name='Columns_Raw', index=False)
                except Exception:
                    logging.debug('Could not write Columns_Raw debug sheet')
                
                # Auto-adjust column widths
                worksheet = writer.sheets['Files_Metadata']
                # Style header for the 'name' column: blue fill, bold white font
                try:
                    cols = list(df.columns)
                    # Apply consistent header styling to all columns: bold white font on blue background
                    for idx, col_name in enumerate(cols):
                        header_cell = worksheet.cell(row=1, column=idx + 1)
                        header_cell.font = Font(bold=True, color='FFFFFF')
                        header_cell.fill = PatternFill(start_color='0070C0', end_color='0070C0', fill_type='solid')
                        try:
                            # Center-align header text for readability
                            header_cell.alignment = Alignment(horizontal='center', vertical='center')
                        except Exception:
                            # Alignment is non-fatal; continue if unavailable
                            pass
                except Exception:
                    # Non-fatal: styling failures shouldn't break the export
                    logging.debug('Could not apply header styling for name column')
                for idx, col in enumerate(df.columns):
                    max_len = max(df[col].astype(str).map(len).max(), len(str(col))) + 2
                    max_len = min(max_len, 50)  # Cap at 50 characters
                    worksheet.column_dimensions[worksheet.cell(row=1, column=idx+1).column_letter].width = max_len
            
            logging.info(f"File metadata saved to Excel with complete data: {output_path}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to save file metadata Excel: {e}")
            return False

    def run_flow(self) -> bool:
        """
        Enhanced main workflow for file change detection and organization with comprehensive lifecycle tracking.

        Steps:
            1. Get all current files to process from input folder.
            2. Load last reviewed timestamp (from file or default to 7 days ago).
            3. Load previous files for comprehensive status tracking.
            4. Extract metadata for current files with time calculations.
            5. Detect eliminated files (present before but missing now).
            6. Combine current and eliminated files metadata.
            7. Process file movements (only for current files that need moving).
            8. Save comprehensive metadata to JSON file.
            9. Save comprehensive metadata to Excel file.
            10. Save current files for next run.
            11. Update last review timestamp.

        Returns:
            bool: True if both JSON and Excel metadata saved successfully, False otherwise.
            
        Raises:
            Exception: If any critical step fails, logs error and raises exception.
        """
        try:
            logging.info(f"----- Starting S0: Search for changes in files -----")

            # Step 1: Get all current files to process
            files = self.get_files_to_process()
            logging.info(f"Found {len(files)} current files to process")

            # Step 2: Get last reviewed datetime
            last_review_path = os.path.join(self.config_env.get("OUTPUT_FOLDER", "output"), "last_review.txt")
            last_reviewed_dt = self.get_last_review_timestamp(last_review_path)
            logging.info(f"Last reviewed datetime: {last_reviewed_dt}")

            # Step 3: Load previous files for comprehensive status tracking
            previous_files_path = os.path.join(self.config_env.get("OUTPUT_FOLDER", "output"), "previous_files.json")
            previous_files = self.get_previous_files(previous_files_path)
            logging.info(f"Loaded {len(previous_files)} previous files for comparison")

            # Step 4: Extract metadata for current files with enhanced time tracking
            current_metadata = self.get_files_metadata(files, last_reviewed=last_reviewed_dt, previous_files=previous_files)
            logging.info(f"Extracted metadata for {len(current_metadata)} current files")

            # Step 5: Detect eliminated files (present before but missing now)
            eliminated_metadata = self.get_eliminated_files_metadata(files, previous_files)
            logging.info(f"Detected {len(eliminated_metadata)} eliminated files")

            # Step 6: Combine current and eliminated files metadata
            all_metadata = current_metadata + eliminated_metadata
            
            # Log status distribution and time statistics for monitoring
            status_counts = {}
            time_stats = {"stable_files_1day": 0, "stable_files_7days": 0, "stable_files_30days": 0}
            
            for item in all_metadata:
                status = item.get("status_file", "unknown")
                status_counts[status] = status_counts.get(status, 0) + 1
                
                # Count files by stability duration
                days_stable = item.get("time_without_modification_days", 0)
                if days_stable and isinstance(days_stable, (int, float)):
                    if days_stable >= 30:
                        time_stats["stable_files_30days"] += 1
                    elif days_stable >= 7:
                        time_stats["stable_files_7days"] += 1
                    elif days_stable >= 1:
                        time_stats["stable_files_1day"] += 1
            
            logging.info(f"File status distribution: {status_counts}")
            logging.info(f"File stability distribution: {time_stats}")

            # Step 7: Process file movements (only for current files that need moving)
            files_moved = 0
            for file_info in current_metadata:  # Only process current files, not eliminated ones
                # Initialize movement fields
                file_info["moved_to_destination"] = False
                file_info["move_reason"] = None
                file_info["destination_name"] = None
                
                # Only copy if file is new or modified
                should_move = file_info.get("status_file") in ["nuevo_archivo", "modificado"]
                
                if should_move:
                    try:
                        original_name = os.path.basename(file_info["path"])
                        name_without_ext, ext = os.path.splitext(original_name)
                        
                        # Add suffix based on status
                        if file_info["status_file"] == "nuevo_archivo":
                            new_name = f"{name_without_ext}__nuevo_archivo{ext}"
                            file_info["move_reason"] = "nuevo_archivo"
                        elif file_info["status_file"] == "modificado":
                            new_name = f"{name_without_ext}__modificado{ext}"
                            file_info["move_reason"] = "modificado"
                        else:
                            new_name = original_name
                            file_info["move_reason"] = file_info["status_file"]

                        dest_path = os.path.join(self.destination_folder, new_name)
                        
                        # Check if file already exists with same modification time.
                        # Previously we skipped copying if destination mtime == source last_modified.
                        # Change: always copy when file is a newly detected file ("nuevo_archivo").
                        if os.path.exists(dest_path):
                            dest_mtime = dt.datetime.fromtimestamp(os.path.getmtime(dest_path)).isoformat()
                            # If mtimes match and this is NOT a newly detected file, skip copy
                            if dest_mtime == file_info["last_modified"] and file_info.get("status_file") != "nuevo_archivo":
                                logging.info(f"File {file_info['name']} already exists with same modification time, skipping copy")
                                continue
                        
                        # Ensure destination folder exists
                        os.makedirs(self.destination_folder, exist_ok=True)
                        
                        # Copy file
                        shutil.copy2(file_info["path"], dest_path)
                        file_info["moved_to_destination"] = True
                        file_info["destination_name"] = new_name
                        files_moved += 1
                        logging.info(f"Moved file {file_info['path']} to {dest_path}")
                        
                    except Exception as e:
                        logging.error(f"Failed to move file {file_info['path']}: {e}")

            logging.info(f"Moved {files_moved} files to destination folder")

            # Step 8: Save comprehensive metadata to JSON
            json_output_path = os.path.join(self.config_env.get("OUTPUT_FOLDER", "output"), "files_metadata.json")
            json_saved = self.save_files_metadata_json(all_metadata, json_output_path)

            # Step 9: Save comprehensive metadata to Excel
            excel_output_path = os.path.join(self.config_env.get("OUTPUT_FOLDER", "output"), "files_metadata.xlsx")
            excel_saved = self.save_files_metadata_excel(all_metadata, excel_output_path, last_reviewed=last_reviewed_dt)

            # Step 8.5: Append audit events for each current file (immutable JSONL)
            try:
                for item in current_metadata:
                    evt = {
                        "ts": self.now.isoformat(),
                        "event": item.get("status_file", "unknown"),
                        "path": item.get("path"),
                        "name": item.get("name"),
                        "file_add": item.get("file_add"),
                        "last_modified": item.get("last_modified"),
                        "size_bytes": item.get("size_bytes")
                    }
                    self.append_audit_event(evt)
            except Exception as e:
                logging.warning(f"Could not append audit events: {e}")

            # Step 10: Save consolidated file tracking (preserves ALL historical entries including deleted files)
            self.save_current_files(files, previous_files_path, metadata_list=current_metadata, previous_files=previous_files)

            # Step 11: Update last review timestamp
            self.save_last_review_timestamp(last_review_path)

            # Final status summary
            logging.info(f"=== FILE LIFECYCLE SUMMARY ===")
            for status, count in status_counts.items():
                logging.info(f"  {status}: {count} files")
            logging.info(f"  Files moved to destination: {files_moved}")
            for stat_name, count in time_stats.items():
                logging.info(f"  {stat_name}: {count} files")
            logging.info(f"================================")

            success = json_saved and excel_saved
            logging.info(f"S0 workflow completed successfully: {success}")
            return success

        except Exception as e:
            logging.error(f"S0 workflow failed: {e}")
            # self.exception_handler.send_system_exception(str(e))
            raise


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = S0_trigger(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")