import re
from src.utils.pii_utils import PIIPatterns, TextProcessingUtils, ExclusionLists

def debug_name_detection(text: str, name: str):
    """Debug why a specific name isn't being detected"""
    
    print(f"Debugging detection for: '{name}'")
    print(f"Full text: '{text}'")
    print("-" * 50)
    
    # 1. Check if name exists in text
    if name in text:
        print("✓ Name found in text")
        start_pos = text.find(name)
        end_pos = start_pos + len(name)
        context = text[max(0, start_pos-20):end_pos+20]
        print(f"Context: '{context}'")
    else:
        print("✗ Name NOT found in text")
        # Check for partial matches
        name_words = name.split()
        for i in range(len(name_words)):
            partial = " ".join(name_words[i:])
            if partial in text:
                print(f"Found partial match: '{partial}'")
                start_pos = text.find(partial)
                context = text[max(0, start_pos-20):start_pos+len(partial)+20]
                print(f"Partial context: '{context}'")
        return
    
    # 2. Find what the system actually detected
    print("\n=== What the system detected ===")
    patterns_to_test = {
        "SpanishName": PIIPatterns.PATTERNS["SpanishName"],
        "ChileanFullName": PIIPatterns.PATTERNS["ChileanFullName"],
    }
    
    for pattern_name, pattern in patterns_to_test.items():
        matches = list(pattern.finditer(text))
        print(f"{pattern_name}: {len(matches)} matches")
        for match in matches:
            matched_text = match.group()
            start, end = match.span()
            context = text[max(0, start-10):end+10]
            print(f"  - '{matched_text}' at position {start}-{end}")
            print(f"    Context: '{context}'")
            
            # Check if this overlaps with our target name
            target_start = text.find(name) if name in text else -1
            if target_start != -1:
                target_end = target_start + len(name)
                if start <= target_end and end >= target_start:
                    print(f"    *** OVERLAPS with target name! ***")

# Add a function to test improved patterns
def test_improved_patterns(text: str):
    """Test improved patterns that might catch the full name"""
    
    print("\n=== Testing Improved Patterns ===")
    
    # Pattern 1: More flexible name pattern
    flexible_pattern = re.compile(
        r'\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}){1,4}\b',
        re.IGNORECASE | re.UNICODE
    )
    
    # Pattern 2: Name pattern that stops at RUT
    name_before_rut = re.compile(
        r'\b(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}\s+){2,5}(?=\d{7,8}[-‐‑–—\s]\s*[\dkK])',
        re.IGNORECASE | re.UNICODE
    )
    
    # Pattern 3: Test the exact problematic patterns
    spanish_name_pattern = re.compile(
        r"(?<![@])\b"
        r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"
        r"(?:\s+(?:de|del|la|las|los|y)\s+)?"
        r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"
        r"(?:\s+(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-Z ÁÉÍÓÚÑ]{1,})){0,3}\b",
        re.IGNORECASE | re.UNICODE
    )
    
    patterns = {
        "Flexible": flexible_pattern,
        "Before RUT": name_before_rut,
        "Spanish Name (Current)": spanish_name_pattern
    }
    
    for name, pattern in patterns.items():
        matches = list(pattern.finditer(text))
        print(f"{name} pattern: {len(matches)} matches")
        for match in matches:
            matched_text = match.group().strip()
            start, end = match.span()
            context = text[max(0, start-10):end+10]
            print(f"  - '{matched_text}' at {start}-{end}")
            print(f"    Context: '{context}'")

def test_case_sensitivity(text: str, name: str):
    """Test if case sensitivity is causing issues"""
    print(f"\n=== Case Sensitivity Test ===")
    print(f"Original name: '{name}'")
    print(f"Name in text (exact): {name in text}")
    print(f"Name in text (case insensitive): {name.lower() in text.lower()}")
    
    # Find all potential matches with different cases
    import re
    name_pattern = re.escape(name).replace(r'\ ', r'\s+')
    case_insensitive_pattern = re.compile(name_pattern, re.IGNORECASE)
    matches = list(case_insensitive_pattern.finditer(text))
    
    print(f"Case-insensitive matches: {len(matches)}")
    for match in matches:
        matched_text = match.group()
        start, end = match.span()
        context = text[max(0, start-10):end+10]
        print(f"  - Found: '{matched_text}' at {start}-{end}")
        print(f"    Context: '{context}'")

# Test with your specific case
text = "A B C D E F G Rut Agente Sucursal AC Agente Somete Pago Bono Retención 14,50 Pago líquido . ete . Antofagasta RAMIREZ VASQUEZ GUILLERMO 16852649-0 3.678.472 533.378 3.145.094 : Arica JORQUERA GUTIERREZ JIMENA 13949619-1 2.782.218 403.422 2.378.796 ] Calama Villablanca Henriquez Felipe Eduardo 17332365-4 S 724464 S 105.047 S 619.417 ' Concepción KUNCAR HIRMAS CECILIA MARGARITA 7960750-9_ S 2.935.574 425.658 9 2.509.916 . BERTERINI VAZQUEZ MONICA MARCELA 17947250-3 laulaue VEGA TORO MARGARITA CRISTINA 10707417-K 21278 109 AA RIGIS I 1N119791"

name = "Villablanca Henriquez Felipe Eduardo"
debug_name_detection(text, name)
test_case_sensitivity(text, name)
test_improved_patterns(text)

# Also test what's actually being detected
print("\n=== Current Detection Analysis ===")
print("Looking at the text, I can see:")
print("- 'Villablanca Henriquez Felipe Eduardo' starts with lowercase 'v'")
print("- The patterns expect names to start with uppercase letters")
print("- This explains why it's not being detected!")