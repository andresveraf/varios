#!/usr/bin/env python3
"""
Check the latest Excel reports to verify version control column
"""

import pandas as pd
import os

def check_excel_reports():
    """Check if version control column appears in the latest Excel reports"""
    
    output_dir = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output"
    
    # Check the latest resume report
    resume_file = os.path.join(output_dir, "Resumen_Archivos_PII_20251009_133620.xlsx")
    
    if os.path.exists(resume_file):
        print("=== CHECKING RESUME REPORT ===")
        print(f"File: {resume_file}")
        
        # Check Resumen Archivos sheet
        try:
            df_resumen = pd.read_excel(resume_file, sheet_name="Resumen Archivos")
            print(f"\n'Resumen Archivos' sheet:")
            print(f"Shape: {df_resumen.shape}")
            print(f"Columns: {list(df_resumen.columns)}")
            
            if "Control de version" in df_resumen.columns:
                print("✅ 'Control de version' column found!")
                print("Version control values:")
                for idx, row in df_resumen.iterrows():
                    archivo = row.get('Archivo', 'Unknown')
                    version = row.get('Control de version', 'None')
                    print(f"  - {archivo}: {version}")
            else:
                print("❌ 'Control de version' column not found")
                
        except Exception as e:
            print(f"Error reading 'Resumen Archivos' sheet: {e}")
        
        # Check Consolidado PII sheet
        try:
            df_consolidado = pd.read_excel(resume_file, sheet_name="Consolidado PII")
            print(f"\n'Consolidado PII' sheet:")
            print(f"Shape: {df_consolidado.shape}")
            print(f"Columns: {list(df_consolidado.columns)}")
            
            if "Control de version" in df_consolidado.columns:
                print("✅ 'Control de version' column found!")
                version_values = df_consolidado["Control de version"].value_counts()
                print("Version control distribution:")
                for version, count in version_values.items():
                    print(f"  - {version}: {count} entities")
            else:
                print("❌ 'Control de version' column not found")
                
        except Exception as e:
            print(f"Error reading 'Consolidado PII' sheet: {e}")
            
    else:
        print(f"Resume file not found: {resume_file}")
    
    # Check the latest hybrid report
    hybrid_file = os.path.join(output_dir, "OCR_PII_Analysis_HYBRID_20251009_133617.xlsx")
    
    if os.path.exists(hybrid_file):
        print("\n=== CHECKING HYBRID REPORT ===")
        print(f"File: {hybrid_file}")
        
        try:
            df_hybrid = pd.read_excel(hybrid_file, sheet_name="Combined_PII_Results")
            print(f"Shape: {df_hybrid.shape}")
            print(f"Has 'Control de version' column: {'Control de version' in df_hybrid.columns}")
            
            if "Control de version" in df_hybrid.columns:
                print("✅ Version control column found in hybrid report!")
                version_values = df_hybrid["Control de version"].value_counts()
                print("Version control distribution:")
                for version, count in version_values.items():
                    print(f"  - {version}: {count} entities")
            else:
                print("❌ Version control column not found in hybrid report")
                
        except Exception as e:
            print(f"Error reading hybrid report: {e}")
    else:
        print(f"Hybrid file not found: {hybrid_file}")

if __name__ == "__main__":
    check_excel_reports()