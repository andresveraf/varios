#!/usr/bin/env python3
"""
Script to examine the files_metadata.xlsx structure
"""

import pandas as pd
import os

# Read the metadata file
metadata_path = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output\_others\files_metadata.xlsx"

if os.path.exists(metadata_path):
    try:
        df = pd.read_excel(metadata_path)
        print("=== FILES_METADATA.XLSX STRUCTURE ===")
        print(f"Shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        print("\n=== SAMPLE ROWS ===")
        print(df.head())
        
        # Check for specific columns we're interested in
        if 'Nombre del Archivo Original' in df.columns:
            print(f"\n=== SAMPLE FILENAMES ===")
            for i, filename in enumerate(df['Nombre del Archivo Original'].head()):
                print(f"{i+1}: {filename}")
                
        if 'Control de version' in df.columns:
            print(f"\n=== VERSION CONTROL COLUMN ===")
            print(df['Control de version'].head())
        else:
            print(f"\n=== NO VERSION CONTROL COLUMN FOUND ===")
            
    except Exception as e:
        print(f"Error reading metadata: {e}")
else:
    print(f"Metadata file not found: {metadata_path}")