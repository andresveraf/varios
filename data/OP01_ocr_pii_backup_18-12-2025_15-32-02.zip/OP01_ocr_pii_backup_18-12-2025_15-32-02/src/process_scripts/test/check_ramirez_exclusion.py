#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Check why RAMIREZ VASQUEZ GUILLERMO is excluded
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.utils.pii_utils import ExclusionLists, TextProcessingUtils

name = "RAMIREZ VASQUEZ GUILLERMO"

print(f"Checking: {name}")
print("=" * 60)

# Check full phrase
is_excluded = ExclusionLists.is_excluded_phrase(name)
print(f"Full phrase excluded: {is_excluded}")

# Check individual words
words = name.split()
for word in words:
    is_word_excluded = ExclusionLists.is_excluded_word(word)
    reason = ExclusionLists.get_exclusion_reason(word)
    print(f"  '{word}': excluded={is_word_excluded}, reason={reason}")

# Check normalized
normalized = TextProcessingUtils.strip_accents(name.lower())
print(f"\nNormalized: {normalized}")
print(f"Normalized excluded: {ExclusionLists.is_excluded_phrase(normalized)}")
