#!/usr/bin/env python3
"""Debug Employee Database Loading"""

import os
import sys
import pandas as pd

def debug_employee_database():
    """Debug what's actually loaded from the employee database"""
    
    # Get the employees file path (same logic as the main code)
    project_root = os.path.dirname(os.path.abspath(__file__))
    employees_file = os.path.join(project_root, "input", "employees.xlsx")
    
    print(f"Employee file path: {employees_file}")
    print(f"File exists: {os.path.exists(employees_file)}")
    
    if not os.path.exists(employees_file):
        print("❌ Employee file not found!")
        return
    
    try:
        # Read the Excel file
        df_employees = pd.read_excel(employees_file)
        print(f"✅ Excel file loaded successfully")
        print(f"Columns: {list(df_employees.columns)}")
        print(f"Total rows: {len(df_employees)}")
        
        if 'Display Name' not in df_employees.columns:
            print("❌ 'Display Name' column not found!")
            return
        
        # Look for Carolina specifically
        carolina_employees = df_employees[df_employees['Display Name'].str.contains('Carolina', case=False, na=False)]
        print(f"\nCarolina employees found: {len(carolina_employees)}")
        
        for idx, row in carolina_employees.iterrows():
            display_name = row['Display Name']
            normalized = str(display_name).strip().lower()
            print(f"  Original: '{display_name}' -> Normalized: '{normalized}'")
        
        # Test the exact normalization process used in the main code
        employee_names = set()
        variations_created = 0
        
        for name in df_employees['Display Name'].dropna():
            normalized_name = str(name).strip().lower()
            if normalized_name:
                # Add the full name
                employee_names.add(normalized_name)
                
                # Add name variations for partial matching
                words = normalized_name.split()
                if len(words) >= 3:  # Has at least 3 parts
                    # Add "first last" variation (skip middle names)
                    first_last = f"{words[0]} {words[-1]}"
                    employee_names.add(first_last)
                    variations_created += 1
                    
                    # Add "first middle" variation
                    first_middle = f"{words[0]} {words[1]}"
                    employee_names.add(first_middle)
                    variations_created += 1
                
                elif len(words) == 2:  # Two-part names
                    first_name = words[0]
                    last_name = words[1]
                    if len(first_name) >= 3:
                        employee_names.add(first_name)
                        variations_created += 1
                    if len(last_name) >= 3:
                        employee_names.add(last_name)
                        variations_created += 1
        
        print(f"\nTotal employee names (with variations): {len(employee_names)}")
        print(f"Variations created: {variations_created}")
        
        # Check for specific Carolina names
        carolina_names = [name for name in employee_names if "carolina" in name]
        print(f"\nCarolina names in final set: {carolina_names}")
        
        # Test the specific case
        target_name = "carolina margarita cepeda"
        exact_match = target_name in employee_names
        print(f"\nExact match for '{target_name}': {exact_match}")
        
        # Show close matches
        import difflib
        close_matches = difflib.get_close_matches(
            "carolina margarita ccepeda", list(employee_names), n=5, cutoff=0.7
        )
        print(f"Close matches for 'carolina margarita ccepeda': {close_matches}")
        
        close_matches2 = difflib.get_close_matches(
            "carolina margarita", list(employee_names), n=5, cutoff=0.7
        )
        print(f"Close matches for 'carolina margarita': {close_matches2}")
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    debug_employee_database()