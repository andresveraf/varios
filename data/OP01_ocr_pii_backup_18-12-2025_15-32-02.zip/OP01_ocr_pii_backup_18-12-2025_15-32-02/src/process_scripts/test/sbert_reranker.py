from __future__ import annotations

from typing import Dict, List, Any
import numpy as np
import sys
import os
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) )  # move to modules 


try:
    from sentence_transformers import SentenceTransformer
    import torch
    SBERT_AVAILABLE = True
except Exception:
    SBERT_AVAILABLE = False
    SentenceTransformer = None  # type: ignore
    torch = None  # type: ignore


def _l2norm(x: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(x, axis=-1, keepdims=True) + 1e-9
    return x / n


class EmbeddingReranker:
    """
    Semantic reranker for PII detections using sentence-transformer embeddings.

    - Reclassifies ambiguous numeric runs: Phone vs NumberSequence (optionally Account if you want).
    - Filters weak person detections when nearby text is heading-like (e.g., 'renta', 'póliza', 'cotización').

    It works on short local context windows around each detection to keep it fast and focused.
    """

    def __init__(
        self,
        model_name: str = "intfloat/multilingual-e5-small",
        device: str = "cuda" if (torch and torch.cuda.is_available()) else "cpu",
        phone_threshold: float = 0.28,
        account_threshold: float = 0.28,
        heading_minus_person_margin: float = 0.20,
        heading_min_score: float = 0.35,
        encode_batch_size: int = 64,
        rerank_top_k: int = 5,
        rerank_similarity_threshold: float = 0.6,
    ) -> None:
        if not SBERT_AVAILABLE:
            raise RuntimeError("sentence-transformers not installed. pip install -U sentence-transformers torch")

        self.model_name = model_name
        self.model = SentenceTransformer(model_name, device=device)
        self.device = device
        self.is_e5 = "e5" in model_name.lower()

        # Thresholds
        self.phone_threshold = phone_threshold
        self.account_threshold = account_threshold
        self.heading_minus_person_margin = heading_minus_person_margin
        self.heading_min_score = heading_min_score

        # Encoding / rerank tuning (configurable)
        self.encode_batch_size = int(encode_batch_size or 64)
        self.rerank_top_k = int(rerank_top_k or 5)
        self.rerank_similarity_threshold = float(rerank_similarity_threshold or 0.6)

        # Spanish prototypes per class (short phrases representing each context)
        self.prototypes: Dict[str, List[str]] = {
            # phone context
            "phone_ctx": [
                "teléfono", "número de teléfono", "celular", "móvil", "whatsapp",
                "llamar", "contacto", "anexo", "extensión", "fono",
            ],
            # bank/account context
            "account_ctx": [
                "número de cuenta", "cuenta corriente", "cuenta vista", "cta cte", "banco",
                "transferencia bancaria", "detalle de cuenta", "código de cliente",
            ],
            # rut/id context
            "rut_ctx": [
                "RUT", "RUN", "rol único tributario", "cédula de identidad", "documento de identidad",
            ],
            # headings/bad context for names
            "heading_ctx": [
                "renta mensual", "póliza", "cotización", "validación", "saldo", "beneficiarios",
                "periodo garantizado", "diferido", "intermediario", "oferta", "reporte",
            ],
            # good person-context labels
            "person_ctx": [
                "nombre", "titular", "afiliado", "cliente", "asegurado", "cónyuge",
            ],
        }

        # Encode prototype phrases, average and L2-normalize to get class centroids
        self.proto_centroids: Dict[str, np.ndarray] = self._build_proto_centroids(self.prototypes)

        # Heuristic: whether to prefix "query:" / "passage:" for E5 models
        lname = (getattr(self.model, "model_name_or_path", "") or "").lower()
        self.is_e5 = "e5" in lname

    def _build_proto_centroids(self, protos: Dict[str, List[str]]) -> Dict[str, np.ndarray]:
        centroids: Dict[str, np.ndarray] = {}
        for key, phrases in protos.items():
            emb = self._encode(phrases, is_query=False)  # shape (n, d)
            if emb.size == 0:
                # fallback zero vector if something odd happened
                centroids[key] = np.zeros((self.model.get_sentence_embedding_dimension(),), dtype=np.float32)
            else:
                centroids[key] = _l2norm(emb.mean(axis=0, keepdims=True))[0]
        return centroids

    def _prefix(self, texts: List[str], is_query: bool) -> List[str]:
        if not self.is_e5:
            return texts
        prefix = "query:" if is_query else "passage:"
        return [f"{prefix} {t}" for t in texts]

    def _encode(self, texts: List[str], is_query: bool = False) -> np.ndarray:
        if not texts:
            return np.zeros((0, self.model.get_sentence_embedding_dimension()), dtype=np.float32)
        texts = self._prefix(texts, is_query=is_query)
        embs = self.model.encode(
            texts,
            batch_size=self.encode_batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,  # produce unit vectors to use dot-product as cosine
        )
        return embs.astype(np.float32)

    def _score_batch(self, ctx_embs: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Compute cosine similarities (dot products since vectors are normalized)
        between context embeddings and prototype centroids.
        Returns a dict of class -> scores array (len = num contexts).
        """
        scores: Dict[str, np.ndarray] = {}
        for key, centroid in self.proto_centroids.items():
            # dot product with centroid
            scores[key] = (ctx_embs @ centroid.reshape(-1, 1)).squeeze(-1)
        return scores

    def rerank(self, full_text: str, results: List[Dict[str, Any]], context_window: int = 48) -> List[Dict[str, Any]]:
        """
        Reclassify/Filter detections using semantic context.

        - Phone vs NumberSequence: use phone_ctx vs account_ctx.
        - Person names: drop if heading_ctx clearly dominates person_ctx.

        Returns a new list (does not mutate input).
        """
        if not results:
            return results

        # Build contexts in one pass
        n = len(full_text)
        contexts: List[str] = []
        for r in results:
            s = int(r.get("start_pos", 0))
            e = int(r.get("end_pos", 0))
            cs = max(0, s - context_window)
            ce = min(n, e + context_window)
            contexts.append(full_text[cs:ce])

        # Encode contexts in batch
        ctx_embs = self._encode(contexts, is_query=False)  # normalized

        # Score against class centroids
        scores = self._score_batch(ctx_embs)
        phone_scores = scores.get("phone_ctx", np.zeros(len(results), dtype=np.float32))
        acct_scores = scores.get("account_ctx", np.zeros(len(results), dtype=np.float32))
        head_scores = scores.get("heading_ctx", np.zeros(len(results), dtype=np.float32))
        pers_scores = scores.get("person_ctx", np.zeros(len(results), dtype=np.float32))
        # rut_scores currently not used for gating; kept for future use
        # rut_scores = scores.get("rut_ctx", np.zeros(len(results), dtype=np.float32))

        out: List[Dict[str, Any]] = []

        for i, r in enumerate(results):
            rtype = r.get("PII_Type", "")
            value = str(r.get("PII_Value", ""))
            # Normalize digits helper
            digits = "".join(ch for ch in value if ch.isdigit())

            if rtype in {"Phone", "NumberSequence"}:
                p = float(phone_scores[i])
                a = float(acct_scores[i])
                h = float(head_scores[i])

                # Keep as Phone if phone context is strongest and above threshold
                if p >= max(a, h) and p >= self.phone_threshold:
                    r2 = dict(r)
                    r2["PII_Type"] = "Phone"
                    r2["PII_Value"] = digits or value
                    out.append(r2)
                    continue

                # If account-like wins, you may map to Account; conservative: keep NumberSequence
                if a >= max(p, h) and a >= self.account_threshold:
                    r2 = dict(r)
                    r2["PII_Type"] = "NumberSequence"
                    r2["PII_Value"] = digits or value
                    out.append(r2)
                    continue

                # Default: NumberSequence
                r2 = dict(r)
                r2["PII_Type"] = "NumberSequence"
                r2["PII_Value"] = digits or value
                out.append(r2)
                continue

            if rtype in {"TransformerPerson", "SpanishName", "PER"}:
                head = float(head_scores[i])
                pers = float(pers_scores[i])
                if (head - pers) >= self.heading_minus_person_margin and head >= self.heading_min_score:
                    # Drop as heading-like
                    continue
                out.append(r)
                continue

            # Default: no change
            out.append(r)

        return out