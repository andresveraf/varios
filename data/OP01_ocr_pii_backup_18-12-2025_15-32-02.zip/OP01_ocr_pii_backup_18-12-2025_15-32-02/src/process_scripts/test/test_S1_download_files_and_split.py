#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S1: Download Files and Split
Purpose: Document organization, PDF conversion, image extraction, and page-by-page text extraction

This script handles:
- Document file organization (Word/PDF)
- Word to PDF conversion
- Image extraction from documents
- Page-by-page text extraction from PDFs
- Folder structure creation
- File management utilities

Compatible with Python 3.13.4
Created: 2025-08-17
Modified: 2025-08-21 - Added Word to PDF conversion, page-by-page text extraction, and image extraction
Author: AI Assistant
"""

import os
import sys
import shutil
import logging
import datetime as dt
import zipfile
import fitz  # PyMuPDF
from pathlib import Path
import win32com.client as win32
from PIL import ImageGrab
from typing import Optional, List, Dict, Any
import re
import threading
import time

# Try to import pdfplumber for enhanced PDF text extraction
try:
    import pdfplumber
    PDFPLUMBER_AVAILABLE = True
except ImportError:
    PDFPLUMBER_AVAILABLE = False
    logging.warning("pdfplumber not available, will use PyMuPDF only for PDF text extraction")

# Add Windows-specific imports for dialog handling
try:
    import win32gui
    import win32con
    import win32api
    WINDOWS_AUTOMATION_AVAILABLE = True
except ImportError:
    WINDOWS_AUTOMATION_AVAILABLE = False
    logging.warning("win32gui not available for dialog handling - install with: pip install pywin32")

# Import framework utilities
from src.utils.fmw_utils import start_logging, read_config, save_json_file, create_folder, Config
from src.utils.send_exceptions_emails import ExceptionEmails
from src.process_scripts.base_process import ProcessBase
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) )  # move to modules 

class S1_FileOrganizer(ProcessBase):
    """
    S1: File organization, image extraction, and page-by-page text extraction processor.
    
    Handles document processing with Word to PDF conversion, image extraction, and page-by-page text extraction.
    Creates organized folder structures for downstream processing.
    """
    
    def __init__(self, config=None):
        """
        Initialize the file organizer with configuration and logging.
        
        Args:
            config (dict, optional): Configuration dictionary from config.jsonc
        """
        ProcessBase.__init__(self, config=config) 
        self.state_name = "S1_FileOrganizer"
        self.now = dt.datetime.now()
        
        # Dialog handling configuration
        self.auto_handle_dialogs = self.config.get('word_processing', {}).get('auto_handle_dialogs', True)
        self.dialog_timeout = self.config.get('word_processing', {}).get('dialog_timeout_seconds', 15)
        
        # Initialize exception handler
        # self.exception_handler = ExceptionEmails()
        
        # Text extraction configuration
        self.save_individual_pages = self.config.get('text_extraction', {}).get('save_individual_pages', True)
        
        # Get paths from configuration
        self.input_dir = self.config_env["DOWNLOAD_FOLDER"]
        self.output_dir = self.config_env["OUTPUT_FOLDER"]
        self.process_data_dir = self.config_env["DOWNLOAD_FOLDER"]
            
        # Ensure directories exist
        create_folder(self.input_dir)
        create_folder(self.output_dir)
        create_folder(self.process_data_dir)
        
        if self.auto_handle_dialogs:
            logging.info("Word dialog auto-handling is enabled")
        
        logging.info(f"S1 File Organizer initialized")
        logging.info(f"Input directory: {self.input_dir}")
        logging.info(f"Output directory: {self.output_dir}")
        logging.info(f"Process data directory: {self.process_data_dir}")
        
    def _clean_extracted_text(self, text: str) -> str:
        """
        Enhanced text cleaning for extracted content.
        
        Args:
            text (str): Raw extracted text
            
        Returns:
            str: Cleaned text
        """
        if not text:
            return ""
        
        # Remove control characters except newlines and tabs
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        
        # Replace multiple whitespace with single space (preserve newlines)
        text = re.sub(r'[ \t]+', ' ', text)
        
        # Replace multiple newlines with double newline
        text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
        
        # Remove trailing/leading whitespace from each line
        lines = [line.strip() for line in text.split('\n')]
        text = '\n'.join(lines)
        
        # Remove excessive empty lines at start/end
        text = text.strip()
        
        return text
        
    def _handle_word_security_dialog(self, timeout_seconds: int = 15) -> bool:
        """
        Automatically handle Microsoft Word security dialog about linked files.
        
        Args:
            timeout_seconds (int): Maximum time to wait for dialog
            
        Returns:
            bool: True if dialog handler was started, False if not available
        """
        if not WINDOWS_AUTOMATION_AVAILABLE or not self.auto_handle_dialogs:
            return False
            
        def find_and_click_no():
            """Find Word security dialog and click 'No' button"""
            try:
                # Wait for dialog to appear
                dialog_titles = [
                    "Microsoft Word",
                    "Word",
                    "Seguridad de Microsoft Word"  # Spanish version
                ]
                
                dialog_hwnd = None
                start_time = time.time()
                
                while time.time() - start_time < timeout_seconds:
                    for title in dialog_titles:
                        dialog_hwnd = win32gui.FindWindow(None, title)
                        if dialog_hwnd:
                            break
                    if dialog_hwnd:
                        break
                    time.sleep(0.1)
                
                if not dialog_hwnd:
                    return False
                
                # Look for the "No" button
                def enum_child_windows(hwnd, lparam):
                    button_texts = ["No", "Cancel", "Cancelar", "&No"]
                    try:
                        window_text = win32gui.GetWindowText(hwnd)
                        class_name = win32gui.GetClassName(hwnd)
                        
                        # Check if it's a button with the right text
                        if class_name == "Button" and any(btn_text.lower() in window_text.lower() for btn_text in button_texts):
                            # Click the button
                            win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, 0, 0)
                            win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, 0)
                            logging.info(f"Clicked Word dialog button: {window_text}")
                            return False  # Stop enumeration
                    except Exception as enum_err:
                        logging.debug(f"Error checking window {hwnd}: {enum_err}")
                    return True
                
                win32gui.EnumChildWindows(dialog_hwnd, enum_child_windows, 0)
                return True
                
            except Exception as e:
                logging.debug(f"Error handling Word dialog: {e}")
                return False
        
        # Run dialog handler in background thread
        dialog_thread = threading.Thread(target=find_and_click_no, daemon=True)
        dialog_thread.start()
        logging.debug(f"Started Word dialog handler thread (timeout: {timeout_seconds}s)")
        return True
        
    def organize_files(self) -> bool:
        """
        Organize input files, extract images, and extract text page by page.
        
        Processes Word documents (converts to PDF) and PDFs to extract images and text page by page.
        Creates organized folder structures.
        
        Returns:
            bool: True if successful, False otherwise
            
        Raises:
            Exception: For system-level errors that should be reported
        """
        try:
            logging.info("Starting file organization process")
            
            # Get list of files to process
            input_files_dir = self.input_dir
            if not os.path.exists(input_files_dir):
                logging.warning(f"Input files directory not found: {input_files_dir}")
                return False
                
            files_to_process = []
            for file in os.listdir(input_files_dir):
                if file.lower().endswith(('.docx', '.doc', '.pdf', '.zip')):
                    files_to_process.append(os.path.join(input_files_dir, file))
            
            if not files_to_process:
                logging.warning("No files found to process")
                return False
                
            logging.info(f"Found {len(files_to_process)} files to process")
            
            # Process each file
            success_count = 0
            for file_path in files_to_process:
                try:
                    if self._process_single_file(file_path):
                        success_count += 1
                        logging.info(f"Successfully processed: {os.path.basename(file_path)}")
                    else:
                        logging.warning(f"Failed to process: {os.path.basename(file_path)}")
                except Exception as e:
                    logging.error(f"Error processing {file_path}: {e}")
                    # Don't fail entire process for single file errors
                    
            logging.info(f"File organization completed: {success_count}/{len(files_to_process)} files processed successfully")
            return success_count > 0
            
        except Exception as e:
            logging.error(f"Error in file organization: {e}")
            self.exception_handler.send_system_exception(str(e))
            raise
    
    def _process_single_file(self, file_path: str) -> bool:
        """
        Process a single file - extract images, convert Word to PDF if needed, and extract text page by page.
        
        Args:
            file_path (str): Path to the file to process
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            file_name = os.path.basename(file_path)
            file_name_no_ext = os.path.splitext(file_name)[0]
            original_file_path = file_path
            
            # Log if this is a Word file that might trigger dialogs
            if file_path.lower().endswith(('.docx', '.doc')):
                logging.info(f"Processing Word document: {file_name} - dialog handler will be active")
            
            # Create output folder for this file
            output_folder = os.path.join(self.input_dir, file_name_no_ext)
            create_folder(output_folder)
            create_folder(os.path.join(output_folder, 'images'))
            create_folder(os.path.join(output_folder, 'extracted_text'))
            
            # Move original file to output folder
            moved_file_path = os.path.join(output_folder, file_name)
            shutil.move(file_path, moved_file_path)
            
            # Process based on file type
            success_images = False
            success_text = False
            pdf_path = moved_file_path
            
            if moved_file_path.lower().endswith('.pdf'):
                # Extract images from PDF
                success_images = self._extract_images_from_pdf(moved_file_path, output_folder)
                # Extract text page by page from PDF
                success_text = self._extract_text_from_pdf_page_by_page(moved_file_path, output_folder)
                
            elif moved_file_path.lower().endswith(('.docx', '.doc')):
                # Extract images from Word document
                success_images = self._extract_images_from_word_win32com(moved_file_path, output_folder)
                # Convert Word to PDF
                pdf_path = self._convert_word_to_pdf(moved_file_path, output_folder)
                if pdf_path:
                    # Extract text page by page from converted PDF
                    success_text = self._extract_text_from_pdf_page_by_page(pdf_path, output_folder)
                    logging.info(f"Successfully converted Word file to PDF and extracted text: {pdf_path}")
                else:
                    logging.error(f"Failed to convert Word file to PDF: {moved_file_path}")
                    
            elif moved_file_path.lower().endswith('.zip'):
                # Extract images from ZIP
                success_images = self._extract_images_from_zip(moved_file_path, output_folder)
                
            else:
                logging.warning(f"Unsupported file type: {moved_file_path}")
                return False
            
            # Return True if either images or text extraction succeeded
            return success_images or success_text
                
        except Exception as e:
            logging.error(f"Error processing single file {original_file_path if 'original_file_path' in locals() else file_path}: {e}")
            return False
    
    def _convert_word_to_pdf(self, word_path: str, output_folder: str) -> Optional[str]:
        """
        Convert Word document to PDF using win32com with dialog handling.
        
        Args:
            word_path (str): Path to Word file
            output_folder (str): Output folder for PDF file
            
        Returns:
            Optional[str]: Path to created PDF file, None if failed
        """
        word_app = None
        doc = None
        
        try:
            logging.info(f"Converting Word document to PDF: {word_path}")
            
            # Start dialog handler before opening Word
            dialog_handler_started = self._handle_word_security_dialog(self.dialog_timeout)
            if dialog_handler_started:
                logging.debug("Word dialog handler started for PDF conversion")
            
            # Launch Word application via COM
            word_app = win32.Dispatch("Word.Application")
            word_app.Visible = False
            
            # Add small delay to let dialog handler get ready
            time.sleep(0.5)
            
            doc = word_app.Documents.Open(word_path)
            
            # Create PDF path
            file_name_no_ext = os.path.splitext(os.path.basename(word_path))[0]
            pdf_path = os.path.join(output_folder, f"{file_name_no_ext}.pdf")
            
            # Export as PDF (format 17 = wdExportFormatPDF)
            doc.ExportAsFixedFormat(OutputFileName=pdf_path, ExportFormat=17)
            
            logging.info(f"Successfully converted to PDF: {pdf_path}")
            return pdf_path
            
        except Exception as e:
            logging.error(f"Error converting Word to PDF {word_path}: {e}")
            return None
        finally:
            # Clean up COM objects
            try:
                if doc:
                    doc.Close(False)
                if word_app:
                    word_app.Quit()
            except Exception as cleanup_error:
                logging.warning(f"Error during COM cleanup: {cleanup_error}")
    
    def _extract_text_from_pdf_page_by_page(self, pdf_path: str, output_folder: str) -> bool:
        """
        Extract text from PDF page by page with individual page files and combined file.
        
        Args:
            pdf_path (str): Path to PDF file
            output_folder (str): Output folder for extracted text
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            logging.info(f"Extracting text from PDF page by page: {pdf_path}")
            
            # Create extracted_text folder
            text_folder = os.path.join(output_folder, 'extracted_text')
            create_folder(text_folder)
            
            # Get file name without extension for output files
            file_name_no_ext = os.path.splitext(os.path.basename(pdf_path))[0]
            
            # Extract text page by page
            page_texts = self._extract_pages_from_pdf(pdf_path)
            
            if not page_texts:
                logging.warning(f"No text content extracted from PDF: {pdf_path}")
                return False
            
            # Process pages and create files
            pages_with_content = 0
            combined_parts = []
            
            for page_num in sorted(page_texts.keys()):
                page_text = page_texts[page_num]
                
                # Enhanced text cleaning
                cleaned_text = self._clean_extracted_text(page_text) if page_text else ""
                
                # Save individual page file if requested
                if self.save_individual_pages:
                    page_file_path = os.path.join(text_folder, f"page_{page_num}_{file_name_no_ext}.txt")
                    with open(page_file_path, 'w', encoding='utf-8') as page_file:
                        page_file.write(cleaned_text)
                    logging.debug(f"Page {page_num} saved individually ({len(cleaned_text)} characters)")

                # Add to combined content if has text
                if cleaned_text.strip():
                    combined_parts.append(cleaned_text.strip())
                    pages_with_content += 1
                    logging.debug(f"Page {page_num} has content ({len(cleaned_text)} characters)")
                else:
                    logging.debug(f"Page {page_num} is empty or has no extractable text")
            
            # Create combined file with pages separated by " / "
            if combined_parts:
                combined_text = " / ".join(combined_parts)
                output_text_path = os.path.join(text_folder, f"{file_name_no_ext}_all_pages.txt")
                
                with open(output_text_path, 'w', encoding='utf-8') as text_file:
                    text_file.write(combined_text)
                    
                # Remove the combined file immediately 
                try:
                    if os.path.exists(output_text_path):
                        os.remove(output_text_path)
                        logging.debug(f"Removed temporary combined file: {output_text_path}")
                except Exception as remove_err:
                    logging.warning(f"Failed to remove temporary combined file {output_text_path}: {remove_err}")
                
                logging.info(f"Text extraction completed for PDF:")
                logging.info(f"  - Total pages in document: {len(page_texts)}")
                logging.info(f"  - Pages with content: {pages_with_content}")
                logging.info(f"  - Combined file: {output_text_path}")
                logging.info(f"  - Individual files created: {len(page_texts) if self.save_individual_pages else 'Disabled'}")
                return True
            else:
                logging.warning(f"No text content found after cleaning in PDF: {pdf_path}")
                return False
                    
        except Exception as e:
            logging.error(f"Error extracting text from PDF {pdf_path}: {e}")
            return False
    
    def _extract_pages_from_pdf(self, pdf_path: str) -> Dict[int, str]:
        """
        Extract text from PDF page by page using best available method.
        
        Args:
            pdf_path (str): Path to PDF file
            
        Returns:
            Dict[int, str]: Dictionary with page numbers as keys and text content as values
        """
        try:
            page_texts = {}
            
            # Try pdfplumber first for better text extraction
            if PDFPLUMBER_AVAILABLE:
                try:
                    logging.debug("Using pdfplumber for PDF text extraction")
                    with pdfplumber.open(pdf_path) as pdf:
                        for page_num, page in enumerate(pdf.pages, 1):
                            try:
                                page_text = page.extract_text()
                                page_texts[page_num] = page_text or ""
                                logging.debug(f"Extracted text from PDF page {page_num} using pdfplumber")
                            except Exception as page_error:
                                logging.warning(f"Error extracting text from PDF page {page_num} with pdfplumber: {page_error}")
                                page_texts[page_num] = ""
                    
                    if page_texts:
                        logging.info(f"Successfully extracted {len(page_texts)} pages using pdfplumber")
                        return page_texts
                        
                except Exception as plumber_error:
                    logging.warning(f"pdfplumber extraction failed: {plumber_error}")
            
            # Fallback to PyMuPDF
            logging.debug("Using PyMuPDF for PDF text extraction")
            doc = fitz.open(pdf_path)
            
            for page_num in range(len(doc)):
                try:
                    page = doc.load_page(page_num)
                    page_text = page.get_text()
                    page_texts[page_num + 1] = page_text or ""  # Convert to 1-based indexing
                    logging.debug(f"Extracted text from PDF page {page_num + 1} with PyMuPDF")
                except Exception as page_error:
                    logging.warning(f"Error extracting text from PDF page {page_num + 1} with PyMuPDF: {page_error}")
                    page_texts[page_num + 1] = ""
            
            doc.close()
            
            if page_texts:
                logging.info(f"Successfully extracted {len(page_texts)} pages using PyMuPDF")
                return page_texts
            else:
                logging.warning("No text extracted from any pages")
                return {}
            
        except Exception as e:
            logging.error(f"Error extracting pages from PDF {pdf_path}: {e}")
            return {}
    
    def _extract_images_from_pdf(self, pdf_path: str, output_folder: str) -> bool:
        """
        Extract images from PDF using PyMuPDF.
        
        Args:
            pdf_path (str): Path to PDF file
            output_folder (str): Output folder for extracted images
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            logging.info(f"Extracting images from PDF: {pdf_path}")
            
            doc = fitz.open(pdf_path)
            image_count = 0
            
            for page_num in range(len(doc)):
                page = doc.load_page(page_num)
                image_list = page.get_images(full=True)
                
                for img_index, img in enumerate(image_list):
                    xref = img[0]
                    pix = fitz.Pixmap(doc, xref)
                    
                    if pix.n - pix.alpha < 4:  # GRAY or RGB
                        img_name = f"page_{page_num+1}_image_{img_index+1}.png"
                        img_path = os.path.join(output_folder, 'images', img_name)
                        pix.save(img_path)
                        image_count += 1
                        logging.debug(f"Extracted image: {img_name}")
                    
                    pix = None
            
            doc.close()
            logging.info(f"Extracted {image_count} images from PDF")
            return image_count > 0
            
        except Exception as e:
            logging.error(f"Error extracting images from PDF {pdf_path}: {e}")
            return False
    
    def _extract_images_from_word_win32com(self, word_path: str, output_folder: str) -> bool:
        """
        Extract images from Word document using win32com API with dialog handling.
        Iterates over the inline shapes in the document, copies each as a picture,
        retrieves the image from the clipboard, and saves it with proper naming.
        
        Args:
            word_path (str): Path to Word file
            output_folder (str): Output folder for extracted images
            
        Returns:
            bool: True if successful, False otherwise
        """
        word_app = None
        doc = None
        
        try:
            logging.info(f"Extracting images from Word document using win32com: {word_path}")
            
            # Create images folder
            images_folder = os.path.join(output_folder, 'images')
            create_folder(images_folder)
            
            # Start dialog handler before opening Word
            dialog_handler_started = self._handle_word_security_dialog(self.dialog_timeout)
            if dialog_handler_started:
                logging.debug("Word dialog handler started for image extraction")
            
            # Launch Word application via COM
            word_app = win32.Dispatch("Word.Application")
            word_app.Visible = False
            
            # Add small delay to let dialog handler get ready
            time.sleep(0.5)
            
            doc = word_app.Documents.Open(word_path)
            
            image_count = 0
            page_image_counts = {}  # Track images per page
            
            # Only process InlineShapes in the main story range (body text)
            main_story = doc.StoryRanges(1)  # 1 = wdMainTextStory
            for shape in main_story.InlineShapes:
                try:
                    # Get the page number where the shape appears using Word constant 3 (wdActiveEndPageNumber)
                    page_number = shape.Range.Information(3)
                    
                    # Track image count per page
                    if page_number not in page_image_counts:
                        page_image_counts[page_number] = 0
                    page_image_counts[page_number] += 1
                    image_number_in_page = page_image_counts[page_number]
                    
                    # Select the shape and copy it as a picture
                    shape.Select()
                    word_app.Selection.CopyAsPicture()

                    # Grab the image from clipboard
                    img = ImageGrab.grabclipboard()
                    if img is None:
                        logging.warning(f"Failed to grab image from clipboard at page {page_number}, image {image_number_in_page}")
                        continue
                    
                    # Save the image with correct naming convention
                    final_filename = f"page_{page_number}_image_{image_number_in_page}.png"
                    final_path = os.path.join(images_folder, final_filename)
                    img.save(final_path, "PNG")
                    
                    image_count += 1
                    logging.debug(f"Extracted image saved as {final_filename}")
                    
                except Exception as shape_error:
                    logging.warning(f"Error processing shape: {shape_error}")
                    continue

            logging.info(f"Extracted {image_count} images from Word document")
            return image_count > 0
            
        except Exception as e:
            logging.error(f"Error extracting images from Word using win32com {word_path}: {e}")
            return False
        finally:
            # Clean up COM objects
            try:
                if doc:
                    doc.Close(False)
                if word_app:
                    word_app.Quit()
            except Exception as cleanup_error:
                logging.warning(f"Error during COM cleanup: {cleanup_error}")
    
    def _extract_images_from_zip(self, zip_path: str, output_folder: str) -> bool:
        """
        Extract images from ZIP file.
        
        Args:
            zip_path (str): Path to ZIP file
            output_folder (str): Output folder for extracted images
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            logging.info(f"Extracting images from ZIP: {zip_path}")
            
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                image_count = 0
                
                for file_info in zip_ref.infolist():
                    if any(file_info.filename.lower().endswith(ext) 
                          for ext in ['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff']):
                        
                        # Extract image file
                        img_data = zip_ref.read(file_info.filename)
                        img_name = os.path.basename(file_info.filename)
                        img_path = os.path.join(output_folder, 'images', img_name)
                        
                        with open(img_path, 'wb') as img_file:
                            img_file.write(img_data)
                        
                        image_count += 1
                        logging.debug(f"Extracted image: {img_name}")
                
                logging.info(f"Extracted {image_count} images from ZIP")
                return image_count > 0
                
        except Exception as e:
            logging.error(f"Error extracting images from ZIP {zip_path}: {e}")
            return False
    
    def get_processing_summary(self) -> Dict[str, Any]:
        """
        Get summary of file processing results.
        
        Returns:
            Dict[str, Any]: Summary information following framework patterns
        """
        summary = {
            'script_name': 'S1_download_files_and_split',
            'state_name': self.state_name,
            'timestamp': dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'input_directory': self.input_dir,
            'output_directory': self.output_dir,
            'process_data_directory': self.process_data_dir
        }
        
        # Count processed folders
        processed_folders = []
        try:
            for item in os.listdir(self.input_dir):
                folder_path = os.path.join(self.input_dir, item)
                if os.path.isdir(folder_path) and item != '_file_input':
                    images_folder = os.path.join(folder_path, 'images')
                    text_folder = os.path.join(folder_path, 'extracted_text')
                    
                    image_count = 0
                    text_count = 0
                    combined_text_files = 0
                    individual_page_files = 0
                    pdf_count = 0
                    
                    # Count images
                    if os.path.exists(images_folder):
                        image_count = len([f for f in os.listdir(images_folder) 
                                         if f.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff'))])
                    
                    # Count PDF files
                    pdf_files = [f for f in os.listdir(folder_path) if f.lower().endswith('.pdf')]
                    pdf_count = len(pdf_files)
                    
                    # Count text files
                    if os.path.exists(text_folder):
                        all_text_files = [f for f in os.listdir(text_folder) if f.lower().endswith('.txt')]
                        text_count = len(all_text_files)
                        # Count combined text files (ending with _all_pages.txt)
                        combined_text_files = len([f for f in all_text_files if f.endswith('_all_pages.txt')])
                        # Count individual page files
                        individual_page_files = len([f for f in all_text_files if f.startswith('page_') and not f.endswith('_all_pages.txt')])
                    
                    processed_folders.append({
                        'folder': item,
                        'image_count': image_count,
                        'pdf_count': pdf_count,
                        'text_files_count': text_count,
                        'combined_text_files': combined_text_files,
                        'individual_page_files': individual_page_files
                    })
        except Exception as e:
            logging.warning(f"Error collecting summary statistics: {e}")
        
        summary['processed_folders'] = processed_folders
        summary['total_folders'] = len(processed_folders)
        summary['total_images'] = sum(folder['image_count'] for folder in processed_folders)
        summary['total_pdfs'] = sum(folder['pdf_count'] for folder in processed_folders)
        summary['total_text_files'] = sum(folder['text_files_count'] for folder in processed_folders)
        summary['total_combined_text_files'] = sum(folder['combined_text_files'] for folder in processed_folders)
        summary['total_individual_page_files'] = sum(folder['individual_page_files'] for folder in processed_folders)
        
        return summary
    
    def run_flow(self) -> bool:
        """
        Execute the main S1 workflow following framework patterns.
        
        Returns:
            bool: True if successful, False otherwise
            
        Raises:
            Exception: For system-level errors that should be reported
        """
        try:
            logging.info(f"----- Starting S1: File Organization, Image Extraction, and Page-by-Page Text Extraction -----")
            
            # Execute file organization
            success = self.organize_files()
            
            if success:
                # Log and save summary using framework utilities
                summary = self.get_processing_summary()
                logging.info(f"S1 Processing Summary:")
                logging.info(f"  - Total folders processed: {summary['total_folders']}")
                logging.info(f"  - Total images extracted: {summary['total_images']}")
                logging.info(f"  - Total PDFs created/processed: {summary['total_pdfs']}")
                logging.info(f"  - Total text files extracted: {summary['total_text_files']}")
                logging.info(f"  - Total combined text files: {summary['total_combined_text_files']}")
                logging.info(f"  - Total individual page files: {summary['total_individual_page_files']}")
                
                # Save summary to process_data using framework utility
                summary_path = os.path.join(self.process_data_dir, 'S1_summary.json')
                save_json_file(summary, summary_path)
                
                logging.info(f"S1 completed successfully")
                return True
            else:
                logging.error(f"S1 failed during file organization")
                return False
                
        except Exception as e:
            logging.error(f"S1 workflow failed: {e}")
            self.exception_handler.send_system_exception(str(e))
            raise
        
if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = S1_FileOrganizer(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")