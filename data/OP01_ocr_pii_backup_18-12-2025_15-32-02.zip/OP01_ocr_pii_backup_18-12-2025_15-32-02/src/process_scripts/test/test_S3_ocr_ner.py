#!/usr/bin/env python3
## ...existing code...
from __future__ import annotations
import hashlib
import re
import ssl
import traceback
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
S3: Text Processing and PII Detection

Enhanced to process both:
- OCR text extraction from images
- Direct text analysis from extracted Word document text files

Adds:
- Optional spaCy lemmatization for context normalization (person/domain/phone).
- Stemming fallback (always enabled in code).
- RUT compact digits-only context gating.
- Phone context gating + NumberSequence PII type.
- Optional sentence-transformer reranker to semantically reclassify ambiguous numbers
    and filter heading-like person detections.

Config keys (via self.config_env):
- USE_SPACY_LEMMAS: bool (default False)
- LEMMA_MODEL: str (default "es_core_news_sm")
- STRICT_RUT_DIGITS_ONLY: bool (default True)
- USE_EMBED_RERANK: bool (default True)
- EMBED_MODEL: str (default "intfloat/multilingual-e5-small")
"""


import os
import logging
import datetime as dt
import re
import unicodedata
from typing import Optional, List, Dict, Tuple, Iterable, Any

import cv2
import numpy as np
import pandas as pd
import pytesseract
import spacy



# Project imports
from src.utils.fmw_utils import start_logging, read_config, save_json_file
from src.process_scripts.base_process import ProcessBase

# Optional stemmer (always enabled if present)
try:
    import snowballstemmer  # pip install snowballstemmer
    STEMMING_AVAILABLE = True
    _SPANISH_STEMMER = snowballstemmer.stemmer("spanish")
except Exception as e:
    STEMMING_AVAILABLE = False
    _SPANISH_STEMMER = None
    logging.error(f"SnowballStemmer import error: {e}\n{traceback.format_exc()}")

# Optional embedding reranker : embeddings to semantically re-rank and filter detected PII entities. Compares the context of each detected entity to its embedding.
try:
    from process_scripts.test.sbert_reranker import EmbeddingReranker
    EMBED_RERANK_AVAILABLE = True
except Exception as _emb_err:
    EMBED_RERANK_AVAILABLE = False
    EmbeddingReranker = None  # type: ignore
    logging.warning(f"Embedding reranker unavailable: {_emb_err}. Install sentence-transformers to enable.")
    logging.error(f"Exception: {_emb_err}\n{traceback.format_exc()}")

# Transformers (HuggingFace)
try:
    from transformers import pipeline
    TRANSFORMERS_AVAILABLE = True
except ImportError as e:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("transformers library not available. Install with: pip install transformers torch")
    logging.error(f"ImportError: {e}\n{traceback.format_exc()}")

try:
    import torch
    HAS_CUDA = torch.cuda.is_available()
except Exception as e:
    HAS_CUDA = False
    logging.error(f"Torch import or CUDA check error: {e}\n{traceback.format_exc()}")

device_id = 0 if HAS_CUDA else -1

# spaCy NER (NER-only)
# nlp = spacy.load(f"C:\\RPA\\repositorio\\OPS\\OP01_ocr_pii\\model_spacy\\model-best")
NER_AVAILABLE = False
try:
    # nlp = spacy.load("es_core_news_lg", disable=["lemmatizer", "attribute_ruler"], )
    nlp = spacy.load(rf"C:\RPA\repositorio\OPS\OP01_ocr_pii\model_spacy\model-last")
    nlp.max_length = max(getattr(nlp, "max_length", 1_000_000), 2_000_000)
    NER_AVAILABLE = True
    logging.info("Spanish NER model loaded: es_core_news_lg (NER-only)")
except OSError as e:
    try:
        # nlp = spacy.load("es_core_news_md", disable=["lemmatizer", "attribute_ruler"], )
        nlp = spacy.load(rf"C:\RPA\repositorio\OPS\OP01_ocr_pii\model_spacy\model-last")
        nlp.max_length = max(getattr(nlp, "max_length", 1_000_000), 2_000_000)
        NER_AVAILABLE = True
        logging.info("Spanish NER model loaded: es_core_news_md (NER-only)")
    except OSError as e2:
        logging.warning("Spanish NER model not found. Install: python -m spacy download es_core_news_lg")
        logging.error(f"OSError: {e2}\n{traceback.format_exc()}")

# Load spaCy model for stop words (small model is sufficient)
STOP_WORDS_AVAILABLE = False
SPANISH_STOP_WORDS = set()
try:
    nlp_stopwords = spacy.load("es_core_news_sm")
    SPANISH_STOP_WORDS = nlp_stopwords.Defaults.stop_words
    STOP_WORDS_AVAILABLE = True
    logging.info(f"Spanish stop words loaded: {len(SPANISH_STOP_WORDS)} words")
except OSError as e:
    logging.warning("spaCy stop words model not found. Using manual Spanish stop words fallback.")
    logging.error(f"OSError: {e}\n{traceback.format_exc()}")
    # Fallback: manual Spanish stop words
    SPANISH_STOP_WORDS = {
        "el", "la", "de", "que", "y", "a", "en", "un", "es", "se", "no", "te", "lo", "le", "da", "su", "por", "son", 
        "con", "para", "al", "una", "del", "los", "las", "si", "mi", "tu", "yo", "él", "me", "nos", "ya", "muy",
        "pero", "más", "todo", "esta", "está", "este", "tiene", "sus", "fue", "ser", "han", "sin", "sobre", "año",
        "años", "hasta", "puede", "como", "bien", "tras", "dos", "tres", "donde", "hacer", "cada", "vez", "desde",
        "era", "así", "entre", "hay", "había", "sido", "será", "hecho", "mismo", "otra", "otro", "algunos", "tan",
        "tanto", "solo", "sólo", "también", "también", "ni", "o", "pero", "porque", "cuando", "antes", "después"
    }
    STOP_WORDS_AVAILABLE = True
    logging.info(f"[INFO] Using fallback Spanish stop words: {len(SPANISH_STOP_WORDS)} words")
    NER_AVAILABLE = False

# Transformer pipeline or pseudo-fallback
transformer_ner = None
TRANSFORMER_NER_AVAILABLE = False

if TRANSFORMERS_AVAILABLE:
    try:
        import warnings
        warnings.filterwarnings("ignore", message=".*pooler.*")

        cache_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "models")
        os.makedirs(cache_dir, exist_ok=True)
        os.environ["TRANSFORMERS_CACHE"] = cache_dir
        os.environ["HF_HOME"] = cache_dir
        os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

        local_model_paths = [
            os.path.join(cache_dir, "mrm8488", "bert-spanish-cased-finetuned-ner"),
            os.path.join(cache_dir, "PlanTL-GOB-ES", "roberta-large-bne-capitel-ner"),
            os.path.join(cache_dir, "PlanTL-GOB-ES", "roberta-base-bne-capitel-ner"),
        ]

        for model_path in local_model_paths:
            if os.path.exists(model_path) and os.path.exists(os.path.join(model_path, "config.json")):
                try:
                    transformer_ner = pipeline(
                        "ner",
                        model=model_path,
                        tokenizer=model_path,
                        aggregation_strategy="simple",
                        device=device_id,
                    )
                    TRANSFORMER_NER_AVAILABLE = True
                    logging.info(f"[SUCCESS] Loaded local transformer NER: {os.path.basename(model_path)}")
                    break
                except Exception as e:
                    logging.warning(f"Failed to load local model {model_path}: {e}")

        if not TRANSFORMER_NER_AVAILABLE:
            model_options = [
                "PlanTL-GOB-ES/roberta-large-bne-capitel-ner",
                "PlanTL-GOB-ES/roberta-base-bne-capitel-ner",
                "mrm8488/bert-spanish-cased-finetuned-ner",
            ]
            for name in model_options:
                try:
                    transformer_ner = pipeline(
                        "ner",
                        model=name,
                        tokenizer=name,
                        aggregation_strategy="simple",
                        device=device_id,
                    )
                    TRANSFORMER_NER_AVAILABLE = True
                    logging.info(f"[SUCCESS] Downloaded transformer NER: {name}")
                    break
                except Exception as e:
                    logging.warning(f"Download failed for {name}: {e}")


        if not TRANSFORMER_NER_AVAILABLE:
            TRANSFORMER_NER_AVAILABLE = True  # enable pseudo below
    except Exception as e:
        TRANSFORMER_NER_AVAILABLE = True  # enable pseudo below
        logging.warning(f"[WARNING] Transformer init failed, using pseudo-fallback: {e}")
else:
    TRANSFORMER_NER_AVAILABLE = False

    

# PseudoTransformer (fallback)
class PseudoTransformerNER:
    def __init__(self) -> None:
        self.confidence_base = 0.85

    def __call__(self, text: str) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        try:
            # PER
            pat = r"\b([A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,}(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,}){1,3})\b"
            for m in re.finditer(pat, text):
                out.append({"entity_group": "PER", "word": m.group(1), "score": 0.85, "start": m.start(1), "end": m.end(1)})
        except Exception as e:
            logging.warning(f"Pseudo NER error: {e}")
        return out

if TRANSFORMER_NER_AVAILABLE and transformer_ner is None:
    transformer_ner = PseudoTransformerNER()
    logging.info("[INFO] Using pseudo-transformer NER fallback")

# Regex and helpers
FLAGS = re.IGNORECASE | re.UNICODE

def _luhn_check(number: str) -> bool:
    logging.info(f"Initialization <_luhn_check>")
    digits = [int(c) for c in re.sub(r"\D+", "", number)]  # Remove all non-digit characters
    if not (13 <= len(digits) <= 19):
        return False
    checksum = 0
    parity = (len(digits) - 2) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d = d * 2 - (9 if d * 2 > 9 else 0)
        checksum += d
    return checksum % 10 == 0

def _rut_calc_dv(num: str) -> str:
    # logging.info(f"Initialization <_rut_calc_dv>")
    s = 0
    factor = 2
    for d in map(int, reversed(num)):
        s += d * factor
        factor = 2 if factor == 7 else factor + 1
    r = 11 - (s % 11)
    return "0" if r == 11 else ("K" if r == 10 else str(r))

def normalize_rut(raw: str) -> Optional[str]:
    # logging.info(f"Initialization <normalize_rut>")
    if not raw:
        return None
    s = re.sub(r"[^0-9kK]", "", raw)  # Keep only digits and 'k'/'K'
    if len(s) < 2 or not s[:-1].isdigit():
        return None
    return f"{s[:-1]}-{s[-1].upper()}"

def validate_rut(raw: str) -> bool:
    # logging.info(f"Initialization <validate_rut>")
    n = normalize_rut(raw)
    if not n:
        return False
    num, dv = n.split("-")
    return _rut_calc_dv(num) == dv

def is_valid_credit_card(candidate: str) -> bool:
    # logging.info(f"Initialization <is_valid_credit_card>")
    return _luhn_check(candidate)

def sanitize_account(value: str) -> str:
    # logging.info(f"Initialization <sanitize_account>")
    return re.sub(r"[^\d]", "", value or "")  # Remove all non-digit characters

PII_PATTERNS: Dict[str, re.Pattern] = {
    "RUT": re.compile(r"\b(?:\d{1,3}(?:[., ]\d{3}){1,2}|\d{7,8})[-‐‑–—\s]\s*[\dkK]\b", FLAGS),  # Match Chilean RUT numbers
    "RUT_Context": re.compile(
        r"\b(?:rut|run|rol\s+u[́']?nico\s+tributario)(?:\s+(?:es|is|:))?\s*[:#-]?\s*(?:\d{1,3}(?:[., ]\d{3}){1,2}|\d{7,8})[-‐‑–—\s]\s*[\dkK]\b",
        FLAGS,
    ),  # Match RUT with context keywords
    "RUT_Comma": re.compile(r"\b\d{1,3}(?:[, ]\d{3}){1,2}[-‐‑–—\s]\s*[0-9Kk]\b", FLAGS),  # Match RUT with comma/space separators
    "PartialRUT_Context": re.compile(r"\b(?:rut|run)\s*[:#-]?\s*(\d{8})\b", FLAGS),  # Match partial RUTs with context

    # --- Country-specific enterprise/service phone number patterns ---
    # Chile: 600 XXX XXXX (enterprise/service hotlines)
    "Phone_Chile_Service": re.compile(r"600[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),  # Match Chilean service phone numbers
    # Argentina: 0800 XXX XXXX (toll-free), 0810 XXX XXXX (shared-cost)
    "Phone_Argentina_Service": re.compile(r"0(800|810)[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),  # Match Argentinian service phone numbers
    # Brazil: 0800 XXX XXXX (toll-free), 0300 XXX XXXX (shared-cost)
    "Phone_Brazil_Service": re.compile(r"0(800|300)[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),  # Match Brazilian service phone numbers
    # Uruguay: 0800 XXXX (toll-free, 7 digits), 0900 XXXX (premium rate)
    "Phone_Uruguay_Service": re.compile(r"0(800|900)[\s\-]?\d{4}", FLAGS),  # Match Uruguayan service phone numbers
    # Mexico: 800 XXX XXXX (toll-free, 10 digits)
    "Phone_Mexico_Service": re.compile(r"800[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),  # Match Mexican service phone numbers
    # --- General phone patterns for each country (existing) ---
    # Chile (9 digits), Mexico (10 digits), Uruguay (8/9 digits), Brazil (10/11 digits), Argentina (10 digits)
    "Phone": re.compile(r"\b(?:\+?56[\s\-]?)?\d{9}\b|\b(?:\+?52[\s\-]?)?\d{10}\b|\b(?:\+?598[\s\-]?)?\d{8,9}\b|\b(?:\+?55[\s\-]?)?\d{10,11}\b|\b(?:\+?54[\s\-]?)?\d{10}\b", FLAGS),  # Match general phone numbers for supported countries
    "Phone_Context": re.compile(
        r"\b(?:tel(?:e?f(?:o|ó)no)?|cel(?:ular)?|m[oó]vil|whatsapp)\s*[:#-]?\s*(?:\+?56[\s\-]?)?(?:9|2|3|4|5|6|7)(?:[\s\-]?\d){8}\b",
        FLAGS,
    ),  # Match phone numbers with context keywords

    "SpanishName": re.compile(
        r"(?<![@])\b"                                   # Not an email
        r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"      # First name
        r"(?:\s+(?:de|del|la|las|los|y)\s+)?"           # Optional connector
        r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"      # Second name
        r"(?:\s+(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-Z ÁÉÍÓÚÑ]{1,})){1,3}\b",  # Require 1 or 2 more words (total 3 or 4) 1,3 for 3-5
        
        # r"(?<![@])\b"  # Negative lookbehind for email
        # r"(?![A-Z]{2,}\s+[A-Z]{2,}\s+[A-Z]{2,})"  # Avoid ALL CAPS sequences
        # r"(?!(?:DATOS|RENTA|VALOR|FECHA|TIPO|ESTADO|NUMERO|SISTEMA|CONTROL|PROCESO|VALIDACION|RESULTADO)\b)"  # Avoid common system words
        # r"([A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,14})"  # First word (max 15 chars)
        # r"(?:\s+(?:de|del|la|las|los|y|da|do|dos)\s+)?"  # Optional connectors
        # r"(?:\s+([A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,14})){1,3}"  # 1-3 additional words
        # r"(?!\s+(?:DE\s+)?(?:SEGUROS|COTIZACIÓN|PENSIÓN|VALIDACIÓN|SISTEMA|DATOS|AFP|UF|PÓLIZA|NÚMERO))"  # Negative lookahead
        # r"\b",
        FLAGS,
    ),  # Match Spanish full names
    "Person_Context": re.compile(
        r"\b(?:nombre|titular|afiliado|cliente|asegurado|cónyuge|conyuge)\s*[:#-]?\s*"
        r"((?:[A-ZÁÉÍÓÚÑa-záéíóúñA-ZÁÉÍÓÚÑ]{2,}\s+){1,3}[A-ZÁÉÍÓÚÑa-záéíóúñ]{2,})\b",
        FLAGS,
    ),  # Match person names with context keywords

    "Account": re.compile(
        r"\b(?:cuenta(?:\s+(?:vista|corriente))?|cta(?:\.|\s+)?(?:cte|vista)?|c[/\.]\s*c|c[/\.]\s*cte"
        r"|n[°º#]\s*de\s*cuenta|nro\.?\s*cuenta|account(?:\s*no\.?)?)\s*[:#-]?\s*"
        r"([0-9][0-9\.\-\s]{4,23}[0-9])\b",
        FLAGS,
    ),  # Match bank account numbers with context
    # "Email": re.compile(r"\b[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,24}\b", FLAGS),
    "Email": re.compile(r"\b[a-z0-9._%+\-]+@(?!metlife|provida|metlifeexternos|providaexternos)[a-z0-9.\-]+\.[a-z]{2,24}\b", FLAGS
),
    "Health": re.compile(r"\b(salud|m[eé]dico|cl[ií]nico|hospital|biometr[ií]a|enfermedad|diagn[oó]stico|tratamiento|paciente|doctor|receta|examen|isapre|fonasa)\b", FLAGS),
    "Sex": re.compile(r"\b(sexual|sexo|orientaci[oó]n\s+sexual|identidad\s+de\s+g[eé]nero|g[eé]nero|lgbt\+?)\b", FLAGS),

    "Address_StreetNum": re.compile(
        r"\b(?:av(?:\.|enida)?|calle|cll|pasaje|psje|cam(?:\.|ino)?|ruta|carretera)\s+"
        r"[a-z0-9áéíóúñ\.\- ]{2,}\s+(?:n[°º#]\s*)?\d{1,5}\b",
        FLAGS,
    ),
    "Address_Keywords": re.compile(
        r"\b(direcci[oó]n|domicilio|residencia|ciudad|comuna|piso|depto|dpto\.?|departamento|torre|block|villa|condominio|lote|manzana)\b",
        FLAGS,
    ),

    "Date": re.compile(
        r"(?:^|[^\d])"  # Allow non-digit/noisy prefix
        r"(?:0?[1-9]|[12]\d|3[01])[/-](?:0?[1-9]|1[0-2])[/-](?:\d{2}|\d{4})"
        r"|"
        r"(?:^|[^\d])"  # Allow non-digit/noisy prefix
        r"(?:0[1-9]|[12]\d|3[01])(?:0[1-9]|1[0-2])\d{4}"
        r"|"
        r"(?:^|[^\d])"  # Allow non-digit/noisy prefix
        r"\d{4}-\d{2}-\d{2}"
        r"|"
        r"(?:^|[^\d])"  # Allow non-digit/noisy prefix
        r"(?:0?[1-9]|[12]\d|3[01])\s+(?:ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic|enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)\s+\d{2,4}",
        FLAGS,
    ),
    "Date": re.compile(
        r"\b\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
        r"|"
        r"\b(?:0?[1-9]|[12]\d|3[01])[/-](?:0?[1-9]|1[0-2])[/-](?:\d{2}|\d{4})(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
        r"|"
        r"\b(?:0[1-9]|[12]\d|3[01])(?:0[1-9]|1[0-2])\d{4}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
        r"|"
        r"\b(?:0?[1-9]|[12]\d|3[01])\s+(?:ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic|enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre)\s+\d{2,4}\b",
        FLAGS,
    ),
    "Passport_Context": re.compile(r"\b(?:pasaporte|passport)\s*[:#-]?\s*([A-Z0-9]{7,9})\b", FLAGS),
    "Patente_Context": re.compile(r"\bpatente\s*[:#-]?\s*(?:[A-Z]{2}\s?\d{4}|[A-Z]{2}\s?[A-Z]{2}\s?\d{2})\b", FLAGS),

    # Generic numeric runs: last to avoid overshadowing specific patterns
    "NumberSequence": re.compile(r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])(?:\d[ \-]?){6,12}\b(?![\d,\.\-])", FLAGS),
    
    # Example: 1.234,56 or $1.234,56
    "Amount": re.compile(r"\b\$?\d{1,3}(?:\.\d{3})*(?:,\d{2})?\b", FLAGS),
}

SPANISH_NAME_EXCLUDE = {
    "RELACIÓN", "INVALIDEZ", "FECHA", "NACIMIENTO", "RENTA", "CONYUGE", "HIJOS", "FEMENINO", "MASCULINO",
    "COTIZADOR", "ESTUDIO", "PRODUCCION", "OPERACION", "APELLIDO", "NOMBRE", "PATERNO", "MATERNO",
    "ESTADO", "CIVIL", "SOLTERO", "CASADO", "VIUDO", "DIVORCIADO", "SEPARADO", "CONVIVIENTE", "SEGURO",
    "POLIZA", "DOCUMENTO", "CEDULA", "PASAPORTE", "TELEFONO", "DIRECCION", "DOMICILIO", "EMPRESA",
    "COMPAÑIA", "SOCIEDAD", "BANCO", "CUENTA", "TARJETA", "CAMPOS", "POLIZAS", "BENEFICIARIOS",
    "CONTROL", "ARCHIVO", "AYUDA", "REGISTROS", "VENTANA", "TRASPASO", "VALIDACION", "COTIZACION",
    "GESTIÓN COTIZADOR", "RENTAS VITALICIAS", "SCOMP", "BORRADOR", "SCOMP", "UF", "TIPO DE PENSIÓN",
    "MODALIDAD DE PENSION", "PERIODO GARANTIZADO", "FECHA DE COTIZACION", "RESULTADOS PROCESOS", "CARGA POLIZAS",
    "PROCESOS CARGA DE POLIZAS NUEVAS", "DATOS DEL AFILIADO", "DATOS DE LOS BENEFICIARIOS", "FIRMADA",
    "FONASA", "AFP", "CUPRUM", "POLICY LOANS", "ENDOSOS RENTA VITALICIA", "ORDENAMOS",
    "VALIDAR CON EL BORRADOR", "TODO DEBE VENIR EN EL ORDEN DEL CHECK LIST", "INFO AREA",
    "CREACIÓN PÓLIZAS RV", "RESULTADOS PROCESOS CARGAPOLIZAS", "PEANUTS", "NA", "MA", "CI", "CM",
    "ELD", "FATCA", "BICE", "CORONEL", "AC", "ACJUAN", "IVERAGUA", "LA ACEPTACION SON", "DAR NRO",
    "SORAYA CUMPLIDO", "RUT", "AFILIADO", "VALOR UF", "VALIDA HASTA",
    "FECHA DE PAGO DE RENTA VITALICIA", "RENTA MENSUAL", "LUEGO DE REVISADO LOS DATOS MAS LOS DOCUMENOS PROCEDEMOS",
    "Sistema SCOMP", "Archivo Edición"
}


def _conditionally_set_tesseract_paths(tesseract_cmd: Optional[str], tessdata_prefix: Optional[str]) -> None:
    try:
        if tesseract_cmd and os.path.exists(tesseract_cmd):
            pytesseract.pytesseract.tesseract_cmd = tesseract_cmd
        if tessdata_prefix and os.path.exists(tessdata_prefix):
            os.environ["TESSDATA_PREFIX"] = tessdata_prefix
    except Exception as e:
        logging.warning(f"Could not set Tesseract paths: {e}")

class S3_OCRandNER(ProcessBase):
    def basic_clean_ocr_text(self, text: str) -> str:
        """
        Perform basic cleaning of OCR text by normalizing whitespace and removing non-printable characters.
        Args:
            text (str): Raw OCR text.
        Returns:
            str: Cleaned text.
        """
        import re
        text = re.sub(r'\s+', ' ', text)
        text = ''.join(c for c in text if c.isprintable())
        return text.strip()

    def aggressive_clean_text(self, text: str) -> str:
        """
        Aggressively clean text by splitting into words and optionally removing stopwords.
        Args:
            text (str): Input text.
        Returns:
            str: Aggressively cleaned text.
        """
        words = text.split()
        if hasattr(self, 'stopwords'):
            words = [w for w in words if w.lower() not in self.stopwords]
        return ' '.join(words)
    
    DEFAULT_TESSERACT_CONFIG = r"--oem 3 --psm 6"
    OCR_LOW_CONF_THRESHOLD_DEFAULT = 45
    PERSON_MIN_CONF_DEFAULT = 0.60
    STRICT_MODE_DEFAULT = True
    STRICT_RUT_DIGITS_ONLY_DEFAULT = True

    MAX_PERSON_CHARS = 40
    MAX_PERSON_TOKENS = 5

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config=config)

        self.state_name = "Workflow"
        self.now = dt.datetime.now()

        self.input_dir = self.config_env["DOWNLOAD_FOLDER"]
        self.output_dir = self.config_env["OUTPUT_FOLDER"]
        self.process_data_dir = self.config_env["DOWNLOAD_FOLDER"]

        cfg_tess_cmd = self.config_env["TESSERACT_CMD"]
        cfg_tessdata = self.config_env["TESSDATA_PREFIX"]
        _conditionally_set_tesseract_paths(cfg_tess_cmd, cfg_tessdata)

        self.tesseract_config = self.config_global.get("TESSERACT_CONFIG", self.DEFAULT_TESSERACT_CONFIG)
        self.low_conf_threshold = int(self.config_global.get("OCR_LOW_CONF_THRESHOLD", self.OCR_LOW_CONF_THRESHOLD_DEFAULT))
        self.strict_mode = bool(self.config_global.get("STRICT_MODE", self.STRICT_MODE_DEFAULT))
        self.person_min_conf = float(self.config_global.get("PERSON_MIN_CONF", self.PERSON_MIN_CONF_DEFAULT))
        self.strict_rut_digits_only = bool(self.config_global.get("STRICT_RUT_DIGITS_ONLY", self.STRICT_RUT_DIGITS_ONLY_DEFAULT))

        self.last_image_ocr_conf: Optional[float] = None

        # Normalization toggles
        self.use_lemmas: bool = bool(self.config_env.get("USE_SPACY_LEMMAS", False))
        self.lemma_model_name: str = self.config_env.get("LEMMA_MODEL", "es_core_news_sm")
        self.use_stemming: bool = True  # Always on in code
        self.use_stopwords_removal: bool = bool(self.config_env.get("USE_STOPWORDS_REMOVAL", True))

        # Advanced text cleaning toggle
        self.use_advanced_cleaning: bool = bool(self.config_global.get("USE_ADVANCED_CLEANING", True)) # Default False

        # Text embedding toggles
        self.use_text_embedding: bool = bool(self.config_env.get("USE_TEXT_EMBEDDING", True))
        self.text_embedding_model_name: str = self.config_env.get("TEXT_EMBEDDING_MODEL", "intfloat/multilingual-e5-small")
        self.text_embedding_model = None
        if self.use_text_embedding:
            try:
                # Fix SSL issues for model downloading
                import ssl
                ssl._create_default_https_context = ssl._create_unverified_context
                
                from sentence_transformers import SentenceTransformer
                # Try primary model first, fallback to simpler model
                try:
                    self.text_embedding_model = SentenceTransformer(self.text_embedding_model_name)
                    logging.info(f"[SUCCESS] Text embedding model loaded: {self.text_embedding_model_name}")
                except Exception as primary_error:
                    logging.warning(f"[WARNING] Primary model failed ({self.text_embedding_model_name}): {primary_error}")
                    # Fallback to simpler model
                    fallback_model = "all-MiniLM-L6-v2"
                    self.text_embedding_model = SentenceTransformer(fallback_model)
                    logging.info(f"[SUCCESS] Fallback text embedding model loaded: {fallback_model}")
            except Exception as e:
                logging.warning(f"[WARNING] Could not load any text embedding model: {e}")
                self.text_embedding_model = None

        # Embedding reranker toggles
        self.use_embed_rerank: bool = bool(self.config_env.get("USE_EMBED_RERANK", True))
        self.embed_model_name: str = self.config_env.get("EMBED_MODEL", "intfloat/multilingual-e5-small")
        self._embed_reranker = None
        if self.use_embed_rerank and EMBED_RERANK_AVAILABLE:
            try:
                self._embed_reranker = EmbeddingReranker(self.embed_model_name)
                logging.info(f"[SUCCESS] Embedding reranker loaded: {self.embed_model_name}")
            except Exception as e:
                logging.warning(f"[WARNING] Could not initialize embedding reranker: {e}")

        # Lemma pipeline
        self.nlp_lemma = None
        if self.use_lemmas:
            self._init_lemma_pipeline(self.lemma_model_name)

        self._stemmer = _SPANISH_STEMMER if (STEMMING_AVAILABLE and self.use_stemming) else None

        # Context word sets
        self.good_ctx_words = {"nombre", "titular", "afiliado", "asegurado", "cliente", "conyuge", "cónyuge"}
        self.bad_ctx_words = {"renta", "mensual", "poliza", "póliza", "cotizacion", "cotización", "oferta", "scomp", "uf", "saldo"}
        self.phone_ctx_words = {"tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext"}

        # Domain terms for person rejection
        self.financial_terms = {
                                "vitalicias", "vitalicia", "poliza", "polizas", "renta", "mensual", "pension", "seguro", "seguros",
                                "validacion", "beneficiarios", "traspaso", "cotizacion", "afiliado", "prima", "uf", "superintendencia",
                                "fonasa", "isapre", "afp", "cuprum", "habitat", "provida", "planvital", "modelo", "capital", "uno",
                                "chile", "ips", "scomp", "compañia", "aseguradora", "diferido", "intermediario", "garantizado",
                                "solicitud", "endosos", "clausula", "articulo", "modalidad", "periodo", "fecha", "valor", "tasa",
                                "descuento", "cierre", "casos", "cerrados", "recupera", "reporte", "exporta", "termina", "ready",
                                "procesar", "imprime", "concluido", "direccion", "comuna", "ciudad", "estado", "civil", "nacimiento",
                                "masculino", "femenino", "casado", "soltero", "viudo", "divorciado", "sistema", "salud", "invalidez",
                                "relacion", "conyuge", "hijo", "hija", "padre", "madre", "certificado", "saldo", "emitido", "imprimir",
                                "zoom", "cerrar", "borrador", "importante", "acepte", "ofrecimientos", "dinero", "incentivos",
                                "contratar", "prohibido", "perjudica", "pensionados", "denuncie", "valores", "folio", "oferta",
                                "externa", "tipo", "vejez", "anticipada", "meses", "marcar", "corresponde", "primer", "pago",
                                "depende", "traipato", "efectuara", "transcurrido", "plazo", "convenido", "contado", "datos",
                                "villa", "hermosa", "coronel", "sexo", "ecedente", "libre", "cliposicion", "maximo", "omecida",
                                "porta", "sobrevivencia", "talecimiento", "anilado", "sin", "hijos", "calculo", "combio", "ahomo",
                                "sevo", "fochs", "tioo", "agerte", "participe", "cortificado", "ofesta", "sordenar", "refrescar",
                                "excel", "ver", "maroar", "witalicia", "ciferida", "ciemo", "oficing", "plza", "nuevas", "jomne",
                                "eoe", "previRed", "cotizante", "multifondos", "subsidio", "bonificación", "reliquidación",
                                "pilar solidario", "retiro programado", "cuenta individual", "cuenta de ahorro",
                                "cuenta de capitalización", "cotización voluntaria", "cotización obligatoria",
                                "bonificación estatal", "subsidio previsional", "reliquidación de pensión", "anses", "jubilación",
                                "moratoria", "haber previsional", "aporte", "monotributo", "autónomo", "cuil", "prestación básica",
                                "prestación compensatoria", "prestación adicional", "pami", "sipa", "puam", "inss", "previdência",
                                "aposentadoria", "benefício", "contribuição", "cadastro", "cpf", "cnis", "segurado", "dependente",
                                "beneficiário", "pensão por morte", "auxílio doença", "salário maternidade", "imss", "issste",
                                "curp", "afores", "sura", "principal", "inbursa", "azteca", "banorte", "coppel", "retiro",
                                "aportaciones", "estado de cuenta", "registro", "clave", "modalidad 40", "bps", "pasividad",
                                "prestación", "cedula", "fondo de ahorro previsional", "seguro de invalidez",
                                "seguro de sobrevivencia", "certificado de ingresos", "historial laboral", "formulario",
                                "documentación", "identificación", "trámite", "proceso", "estado", "aprobado", "rechazado",
                                "pendiente", "vigente", "vencido", "inicio", "término", "retroactivo", "simulación", "historial",
                                "registro", "actualización", "modificación", "cambio", "respuesta", "revisión", "evaluación",
                                "consulta", "reclamo", "confirmación", "verificación", "autenticación", "certificación", "emisión",
                                "renovación", "cancelación", "transferencia", "depósito", "cuota", "rendimiento", "rentabilidad",
                                "capitalización", "inversión", "riesgo", "perfil", "beneficio", "garantía", "protección", "cobertura"
                                }

        # Precompute normalized sets
        self.good_ctx_lemmas = self._normalize_wordset(self.good_ctx_words, use_lemma=True)
        self.bad_ctx_lemmas = self._normalize_wordset(self.bad_ctx_words, use_lemma=True)
        self.financial_terms_lemmas = self._normalize_wordset(self.financial_terms, use_lemma=True)
        self.phone_ctx_lemmas = self._normalize_wordset(self.phone_ctx_words, use_lemma=True)

        self.good_ctx_stems = self._normalize_wordset(self.good_ctx_words, use_stem=True)
        self.bad_ctx_stems = self._normalize_wordset(self.bad_ctx_words, use_stem=True)
        self.financial_terms_stems = self._normalize_wordset(self.financial_terms, use_stem=True)
        self.phone_ctx_stems = self._normalize_wordset(self.phone_ctx_words, use_stem=True)

        self.rut_regex = r"\d{1,3}(?:,\d{3}){1,2}-[0-9Kk]"

        logging.info(
            f"Init done | transformer={TRANSFORMER_NER_AVAILABLE} | spacy_ner={NER_AVAILABLE} | "
            f"lemmas={'ON' if (self.use_lemmas and self.nlp_lemma) else 'OFF'} | "
            f"stemming={'ON' if self._stemmer else 'OFF'} | "
            f"stopwords={'ON' if (self.use_stopwords_removal and STOP_WORDS_AVAILABLE) else 'OFF'} | "
            f"rerank={'ON' if self._embed_reranker else 'OFF'}"
        )

    # Lemma/stem utils
    def _init_lemma_pipeline(self, model_name: str) -> None:
        """
        Initialize spaCy lemma pipeline for Spanish language processing.
        Args:
            model_name (str): spaCy model name.
        """
        try:
            # Only disable 'ner' for lemma pipeline, keep 'parser' for POS tagging
            nlp_lemma = spacy.load(model_name, disable=["ner"])
            nlp_lemma.max_length = max(getattr(nlp_lemma, "max_length", 1_000_000), 2_000_000)
            _ = [t.lemma_ for t in nlp_lemma("cotizaciones pólizas clientes")]
            self.nlp_lemma = nlp_lemma
            logging.info(f"[SUCCESS] Lemma pipeline loaded: {model_name}")
        except Exception as e:
            self.nlp_lemma = None
            self.use_lemmas = False
            logging.warning(f"[WARNING] Lemma pipeline init failed: {e}")

    @staticmethod
    def _strip_accents(s: str) -> str:
        """
        Remove accents from a string for normalization.
        Args:
            s (str): Input string.
        Returns:
            str: String without accents.
        """
        try:
            return unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode("ascii")
        except Exception:
            return s

    def _ctx_tokens(self, text: str) -> List[str]:
        """
        Tokenize context text into alphabetic tokens, including Spanish accented characters.
        Args:
            text (str): Input text.
        Returns:
            List[str]: List of tokens.
        """
        return re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", text or "")

    def _lemma_tokens(self, tokens: List[str]) -> List[str]:
        """
        Lemmatize tokens using spaCy if available, otherwise return normalized tokens.
        Args:
            tokens (List[str]): List of tokens.
        Returns:
            List[str]: Lemmatized or normalized tokens.
        """
        if not tokens:
            return []
        base = [self._strip_accents(t.lower()) for t in tokens]
        if self.use_lemmas and self.nlp_lemma:
            try:
                doc = self.nlp_lemma(" ".join(base))
                return [self._strip_accents(t.lemma_.lower()) for t in doc if t.lemma_]
            except Exception:
                return base
        return base

    def _stem_tokens(self, tokens: List[str]) -> List[str]:
        """
        Stem tokens using the Spanish stemmer if available, otherwise return normalized tokens.
        Args:
            tokens (List[str]): List of tokens.
        Returns:
            List[str]: Stemmed or normalized tokens.
        """
        if not tokens:
            return []
        base = [self._strip_accents(t.lower()) for t in tokens]
        if self._stemmer:
            try:
                return self._stemmer.stemWords(base)
            except Exception:
                return base
        return base

    def _normalize_wordset(self, words: Iterable[str], use_lemma: bool = False, use_stem: bool = False) -> set:
        """
        Normalize a set of words using lemma or stem if enabled.
        Args:
            words (Iterable[str]): Words to normalize.
            use_lemma (bool): Whether to use lemma normalization.
            use_stem (bool): Whether to use stemming.
        Returns:
            set: Normalized set of words.
        """
        words = list(words or [])
        if not words:
            return set()
        folded = [self._strip_accents(w.lower()) for w in words]
        if use_lemma and self.use_lemmas and self.nlp_lemma:
            return set(self._lemma_tokens(folded))
        if use_stem and self._stemmer:
            return set(self._stem_tokens(folded))
        return set(folded)

    def remove_stopwords(self, text: str) -> str:
        """
        Remove Spanish stop words from text to improve PII detection accuracy.
        Args:
            text (str): Input text to clean
        Returns:
            str: Text with stop words removed
        """
        if not self.use_stopwords_removal or not STOP_WORDS_AVAILABLE:
            return text
            
        try:
            # Split text into words, preserving some punctuation for context
            words = re.findall(r'\b\w+\b', text)
            filtered_words = []
            
            for word in words:
                word_lower = word.lower()
                # Keep the word if it's not a stop word
                if word_lower not in SPANISH_STOP_WORDS:
                    filtered_words.append(word)
                    
            return " ".join(filtered_words)
        except Exception as e:
            logging.warning(f"Error removing stop words: {e}")
            return text

    def advanced_clean_text(self, text: str) -> str:
        """
        Apply advanced text cleaning for better PII detection.
        Removes non-printable characters, normalizes whitespace, fixes OCR errors, removes codes, and applies stopword removal if enabled.
        Args:
            text: Input text to clean
        Returns:
            str: Advanced cleaned text
        """
        """
        Apply advanced text cleaning for better PII detection.
        
        Args:
            text: Input text to clean
            
        Returns:
            str: Advanced cleaned text
        """
        try:
            import re
            # Remove non-printable characters
            text = ''.join(c for c in text if c.isprintable())
            # Normalize whitespace
            text = re.sub(r'\s+', ' ', text)
            # Remove leading/trailing symbols
            text = re.sub(r'^[\]\[\)\(]+|[\]\[\)\(]+$', '', text)
            # Remove common code patterns (e.g., ##O, ##F VN)
            text = re.sub(r'##[A-Z0-9 ]{1,10}', ' ', text)
            # Fix common OCR errors for numbers (be careful with RUTs)
            # Only apply to isolated characters to avoid breaking RUTs
            text = re.sub(r'\b0\b', 'O', text)  # Only isolated zeros
            text = re.sub(r'\bl\b', '1', text)  # Only isolated l's
            # Remove isolated short tokens (likely codes or OCR artifacts)
            text = re.sub(r'\b[A-Z0-9]{1,3}\b', ' ', text)
            # Remove repeated characters (but preserve double letters in names)
            text = re.sub(r'(.)\1{3,}', r'\1\1', text)  # Keep max 2 repeated chars
            # Clean up punctuation spacing
            text = re.sub(r'\s*([.,;:!?])\s*', r'\1 ', text)
            # text = re.sub(r'\b\S+@\S+\.\S+\b', ' ', text)  # Remove emails
            text = re.sub(r'https?://\S+', ' ', text)     # Remove URLs
            # Remove repeated characters (but preserve double letters in names)
            # text = re.sub(r'(.)\1{3,}', r'\1\1', text)  # Keep max 2 repeated chars
            # Remove extra spaces again after all cleaning
            text = re.sub(r'\s+', ' ', text)
            # Remove stopwords if enabled
            if self.use_stopwords_removal:
                text = self.remove_stopwords(text)
            return text.strip()
        except Exception as e:
            logging.warning(f"Error in advanced text cleaning: {e}")
            return text

    def generate_simple_embedding(self, text: str) -> list:
        """
        Generate a simple text embedding when sentence-transformers is not available.
        Creates a basic vector representation based on text characteristics such as length, word count, diversity, and hash features.
        Args:
                    import re
        Returns:
            list: 32-dimensional embedding vector.
        """
        # logging.info("Initializing function: generate_simple_embedding")
        try:
            # Basic text features
            features = []
            # Text length (normalized)
            features.append(min(len(text) / 1000.0, 1.0))
            # Word count (normalized)
            words = text.split()
            features.append(min(len(words) / 100.0, 1.0))
            # Character diversity (unique chars / total chars)
            if len(text) > 0:
                features.append(len(set(text.lower())) / len(text))
            else:
                features.append(0.0)
            # Digit ratio
            digit_count = sum(1 for c in text if c.isdigit())
            features.append(digit_count / max(len(text), 1))
            # Uppercase ratio
            upper_count = sum(1 for c in text if c.isupper())
            features.append(upper_count / max(len(text), 1))
            # Punctuation ratio
            punct_count = sum(1 for c in text if not c.isalnum() and not c.isspace())
            features.append(punct_count / max(len(text), 1))
            # Hash-based features for semantic similarity
            text_hash = hashlib.md5(text.lower().encode()).hexdigest()
            hash_features = [int(text_hash[i:i+2], 16) / 255.0 for i in range(0, 32, 2)]
            features.extend(hash_features[:16])  # Take first 16 hash features
            # Pad to make vector length consistent (32 dimensions)
            while len(features) < 32:
                features.append(0.0)
            return features[:32]  # Ensure exactly 32 dimensions
        except Exception as e:
            logging.warning(f"Error generating simple embedding: {e}")
            return [0.0] * 32  # Return zero vector on error

    def get_pos_tags(self, text: str) -> str:
        """
        Extract POS (Part-of-Speech) tags from text using spaCy.
        Only include tokens that are alphabetic and at least 2 characters long.
        Args:
            text (str): Input text to analyze
        Returns:
            str: POS tags formatted as "word:POS | word:POS | ..."
        """
        # logging.info("Initializing function: get_pos_tags")
        if not NER_AVAILABLE or not nlp:
            return "N/A"
        try:
            doc = nlp(text)
            pos_tags = []
            for token in doc:
                # Only include tokens that are alphabetic and at least 2 characters
                if token.is_alpha and len(token.text) >= 2:
                    pos_tags.append(f"{token.text}:{token.pos_}")
            return " | ".join(pos_tags) if pos_tags else "N/A"
        except Exception as e:
            logging.warning(f"Error extracting POS tags: {e}")
    # Small utils
    def _iter_ner_chunks(self, text: str, max_chars: int = 512, overlap: int = 200) -> Iterable[Tuple[int, str]]:
        """
        Split text into overlapping chunks for NER processing.
        Args:
            text: Input text to chunk
            max_chars: Maximum characters per chunk (800 for better accuracy)
            overlap: Overlap between chunks (100 to avoid missing entities at boundaries)
        """
        # logging.info("Initializing function: _iter_ner_chunks")
        n = len(text)
        start = 0
        while start < n:
            end = min(n, start + max_chars)
            yield start, text[start:end]
            if end == n:
                break
            start = end - overlap

    @staticmethod
    def _norm_value_for_key(value: str) -> str:
        """
        Normalize a value for deduplication by lowercasing and stripping whitespace.
        Args:
            value (str): Input value.
        Returns:
            str: Normalized value.
        """
        return re.sub(r"\s+", " ", value or "").strip().lower()

    def _local_context(self, text: str, start: int, end: int, window: int = 40) -> str:
        """
        Extract local context around a span in text for entity validation.
        Args:
            text (str): Full text.
            start (int): Start position.
            end (int): End position.
            window (int): Number of characters before and after.
        Returns:
            str: Context string.
        """
        s = max(0, start - window); e = min(len(text), end + window)
        return text[s:e].lower()

    @staticmethod
    def _looks_like_heading(ctx: str) -> bool:
        """
        Heuristic to check if a context string looks like a heading (mostly uppercase tokens).
        Args:
            ctx (str): Context string.
        Returns:
            bool: True if looks like heading.
        """
        tokens = [t for t in re.split(r"\W+", ctx) if t]
        if not tokens: return False
        upp = sum(1 for t in tokens if t.isupper() and len(t) > 2)
        return upp / len(tokens) >= 0.7

    def _person_context_ok(self, ctx: str) -> bool:
        """
        Check if context is suitable for a person entity using lemmas, stems, or normalized words.
        Args:
            ctx (str): Context string.
        Returns:
            bool: True if context is good for person entity.
        """
        toks = self._ctx_tokens(ctx)
        if self.use_lemmas and self.nlp_lemma:
            lemmas = set(self._lemma_tokens(toks))
            has_good = bool(lemmas & self.good_ctx_lemmas)
            has_bad = bool(lemmas & self.bad_ctx_lemmas)
            return has_good or not has_bad
        if self._stemmer:
            stems = set(self._stem_tokens(toks))
            has_good = bool(stems & self.good_ctx_stems)
            has_bad = bool(stems & self.bad_ctx_stems)
            return has_good or not has_bad
        folded = self._strip_accents(ctx.lower())
        has_good = any(g in folded for g in self._normalize_wordset(self.good_ctx_words))
        has_bad = any(b in folded for b in self._normalize_wordset(self.bad_ctx_words))
        return has_good or not has_bad

    def _rut_context_ok(self, ctx: str) -> bool:
        """
        Check if context is suitable for a RUT entity using regex and keywords.
        Args:
            ctx (str): Context string.
        Returns:
            bool: True if context is good for RUT entity.
        """
        folded = self._strip_accents(ctx.lower())
        if re.search(r"\b(rut|r\.?u\.?t\.?)\b", folded): return True
        if re.search(r"\b(run|r\.?u\.?n\.?)\b", folded): return True
        if "rol unico" in folded and "tributario" in folded: return True
        if re.search(r"\b(cedula|identidad|dni)\b", folded): return True
        return False

    def _normalize_digits(self, s: str) -> str:
        """
        Remove all non-digit characters from a string.
        Args:
            s (str): Input string.
        Returns:
            str: Digits only.
        """
        return re.sub(r"\D", "", s or "")

    def _phone_context_ok(self, ctx: str) -> bool:
        """
        Check if context is suitable for a phone entity using lemmas, stems, or normalized words.
        Args:
            ctx (str): Context string.
        Returns:
            bool: True if context is good for phone entity.
        """
        toks = self._ctx_tokens(ctx)
        if self.use_lemmas and self.nlp_lemma:
            lemmas = set(self._lemma_tokens(toks))
            return bool(lemmas & self.phone_ctx_lemmas)
        if self._stemmer:
            stems = set(self._stem_tokens(toks))
            return bool(stems & self.phone_ctx_stems)
        folded = self._strip_accents(ctx.lower())
        return any(w in folded for w in self._normalize_wordset(self.phone_ctx_words))

    def _is_plausible_person_span(self, value: str) -> bool:
        """
        Heuristic to check if a string is a plausible person name span.
        Args:
            value (str): Candidate name string.
        Returns:
            bool: True if plausible.
        """
        val = (value or "").strip()
        if not val: return False
        if len(val) > self.MAX_PERSON_CHARS: return False
        if len(val.split()) > self.MAX_PERSON_TOKENS: return False
        return True

    # Dedupe
    def _dedupe_entities(self, entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Deduplicate overlapping or duplicate PII entities, preferring higher-priority sources and longer spans.
        Args:
            entities (List[Dict[str, Any]]): List of entity dicts.
        Returns:
            List[Dict[str, Any]]: Deduplicated entities.
        """
        # Sort entities by start position, length, and source priority
        pref = {"transformer": 3, "regex": 2, "spaCy": 1}
        def norm_key(e: Dict[str, Any]) -> Tuple[str, str]:
            return (e.get("PII_Type", "").lower(), self._norm_value_for_key(e.get("PII_Value", "")))

        entities_sorted = sorted(
            entities,
            key=lambda e: (
                e.get("start_pos", 0),
                -(e.get("end_pos", 0) - e.get("start_pos", 0)),
                -pref.get(e.get("Source"), 0),
            ),
        )
        out: List[Dict[str, Any]] = []
        for e in entities_sorted:
            e_key = norm_key(e)
            e_range = (e.get("start_pos", 0), e.get("end_pos", 0))
            replaced = False
            to_remove: List[int] = []
            for i, o in enumerate(out):
                o_key = norm_key(o)
                o_range = (o.get("start_pos", 0), o.get("end_pos", 0))
                overlaps = not (e_range[1] <= o_range[0] or e_range[0] >= o_range[1])
                contains = e_range[0] <= o_range[0] and e_range[1] >= o_range[1]
                same_value = e_key == o_key
                same_type = e.get("PII_Type") == o.get("PII_Type")
                if overlaps:
                    if same_value:
                        if pref.get(e.get("Source"), 0) > pref.get(o.get("Source"), 0):
                            out[i] = e
                        replaced = True; break
                    elif same_type and contains:
                        if pref.get(e.get("Source"), 0) >= pref.get(o.get("Source"), 0):
                            to_remove.append(i)
                        else:
                            replaced = True; break
            for idx in reversed(to_remove): out.pop(idx)
            if not replaced: out.append(e)
        out.sort(key=lambda x: (x.get("start_pos", 0), x.get("end_pos", 0)))
        return out

    # Name cleaning and validation (unchanged from previous full code; trimmed for brevity)
    def clean_entity_boundaries(self, entity_text: str, entity_type: str, original_text: str, start_pos: int, end_pos: int) -> Tuple[Optional[str], int, int]:
        """
        Clean and expand entity boundaries for person and miscellaneous types, removing prefixes and validating plausibility.
        Args:
            entity_text (str): Raw entity text.
            entity_type (str): Entity type label.
            original_text (str): Full text.
            start_pos (int): Start position.
            end_pos (int): End position.
        Returns:
            Tuple[Optional[str], int, int]: Cleaned entity text and new boundaries.
        """
        try:
            etype = (entity_type or "").upper()
            try_expand = etype in {"PER", "PERSON"} or (etype in {"MISC", "MISCELLANEOUS"} and len(entity_text.split()) <= 2 and entity_text.isalpha())
            if try_expand:
                s = start_pos
                while s > 0 and (original_text[s - 1].isalpha() or original_text[s - 1].isspace()): s -= 1
                while s < len(original_text) and not original_text[s].isalpha(): s += 1
                e = end_pos
                while e < len(original_text) and (original_text[e].isalpha() or original_text[e].isspace()): e += 1
                expanded = original_text[s:e].strip()
                words = expanded.split()
                if 2 <= len(words) <= 4 and all(len(w) >= 2 and w.isalpha() for w in words) and len(expanded) >= 6 and self._is_plausible_person_span(expanded):
                    return expanded, s, e
            cleaned = entity_text.strip()
            if etype in {"PER", "PERSON"}:
                prefix_words = {"nombre", "name", "sr", "sra", "señor", "señora", "don", "doña"}
                tokens = cleaned.split()
                while tokens and tokens[0].lower() in prefix_words: tokens = tokens[1:]
                if not tokens: return None, start_pos, end_pos
                cleaned = " ".join(tokens)
                cleaned = re.sub(r"^[\d\s]+", "", cleaned); cleaned = re.sub(r"[\d\s]+$", "", cleaned)
                tokens = cleaned.split()
                if not tokens or not all(t.isalpha() for t in tokens): return None, start_pos, end_pos
            if len(cleaned.strip()) < 2: return None, start_pos, end_pos
            return cleaned, start_pos, end_pos
        except Exception as e:
            logging.warning(f"Error cleaning entity boundaries: {e}")
            return entity_text, start_pos, end_pos

    def _assess_name_confidence(self, words: List[str]) -> float:
        """
        Assess confidence that a list of words is a valid Spanish person name using common names and heuristics.
        Args:
            words (List[str]): List of words.
        Returns:
            float: Confidence score between 0 and 1.
        """
        if not words or len(words) < 2: return 0.0
        conf = 0.0

        # Most common first names  189
        common_first = {
                        "AGUSTÍN", "ALEJANDRO", "ALONSO", "ÁLVARO", "ANDRÉS", "ÁXEL", "BAUTISTA", "BENJAMÍN", "BRUNO", "CALEB",
                        "CAMILO", "CARLOS", "CRISTÓBAL", "CRISTIAN", "DAMIÁN", "DANIEL", "DAVID", "DIEGO", "EDUARDO", "ELÍAS",
                        "EMILIANO", "EMMANUEL", "ENRIQUE", "ESTEBAN", "ETHAN", "FEDERICO", "FERNANDO", "FRANCISCO", "GABRIEL",
                        "GAEL", "GASPAR", "GERMÁN", "GUSTAVO", "HERNÁN", "IAN", "IGNACIO", "ISIDORO", "IVÁN", "JAIR", "JAIRO",
                        "JASON", "JEREMY", "JHON", "JOAQUÍN", "JORGE", "JUAN", "JULIÁN", "KEVIN", "KIAN", "LEÓN", "LEONARDO",
                        "LIAM", "LORENZO", "LUCCA", "LUIS", "MARCELO", "MARCO", "MARTÍN", "MATÍAS", "MATEO", "MAURICIO",
                        "MAXIMILIANO", "MIGUEL", "NICOLÁS", "OLIVER", "OMAR", "ORLANDO", "PATRICIO", "PAULO", "PEDRO", "RAFAEL",
                        "RAMIRO", "RICARDO", "ROBERTO", "RODRIGO", "RUBÉN", "SAMUEL", "SANTIAGO", "SEBASTIÁN", "SIMÓN", "THIAGO",
                        "TOBÍAS", "TOMÁS", "VALENTINO", "VÍCTOR", "VICENTE", "WALTER", "XANDER", "ZAHIR",
                        "AGUSTINA", "AINHOA", "AITANA", "ALBA", "ALEJANDRA", "ALEXA", "ALEXANDRA", "ALMENDRA", "AMANDA", "AMELIA",
                        "ANAÍS", "ANTONELLA", "ANTONIA", "ARANTXA", "ARIADNA", "AROHA", "AZUL", "BELÉN", "BLANCA", "BRISA",
                        "CAMILA", "CARLA", "CAROLINA", "CATALINA", "CELIA", "CLARA", "CLAUDIA", "CONSTANZA", "DANIELA", "DÉBORA",
                        "DIANA", "DOMINIQUE", "ELISA", "ELIZABETH", "EMILIA", "EMMA", "ESMERALDA", "ESTEFANÍA", "FERNANDA",
                        "FLORENCIA", "FRANCISCA", "GABRIELA", "GIOVANNA", "ISABELLA", "IVANNA", "JAVIERA", "JIMENA", "JOSEFINA",
                        "JUANITA", "JULIETA", "KARINA", "KARLA", "KATIA", "KIARA", "LARA", "LAURA", "LAYLA", "LILA", "LUCIANA",
                        "LUISA", "LUNA", "MACARENA", "MAGDALENA", "MANUELA", "MARÍA", "MARTINA", "MATILDA", "MÍA", "MILA",
                        "MIREYA", "NATALIA", "NEREA", "NICOLE", "NOELIA", "OLIVIA", "PALOMA", "PAOLA", "PAULINA", "PAZ",
                        "PENÉLOPE", "RENATA", "ROCÍO", "ROMINA", "ROSARIO", "SALOMÉ", "SAMANTHA", "SARA", "SOFÍA", "SOL",
                        "TAMARA", "VALENTINA", "VALERIA", "VANIA", "VERÓNICA", "VICTORIA", "VIOLETA", "XIMENA", "YASNA",
                        "YOLANDA", "ZOE"
                        }


        # Most common surnames  108
        common_surn = {
                        "GONZÁLEZ", "MUÑOZ", "ROJAS", "DÍAZ", "PÉREZ", "SOTO", "CONTRERAS", "SILVA", "MARTÍNEZ", "SEPÚLVEDA",
                        "MORALES", "RODRÍGUEZ", "LÓPEZ", "ARAYA", "FUENTES", "HERNÁNDEZ", "TORRES", "ESPINOZA", "FLORES",
                        "CASTILLO", "REYES", "VALENZUELA", "VARGAS", "RAMÍREZ", "GUTIÉRREZ", "HERRERA", "ÁLVAREZ", "VÁSQUEZ",
                        "TAPIA", "SÁNCHEZ", "FERNÁNDEZ", "CARRASCO", "CORTÉS", "GÓMEZ", "JARA", "VERGARA", "RIVERA", "NÚÑEZ",
                        "BRAVO", "FIGUEROA", "RIQUELME", "MOLINA", "VERA", "SANDOVAL", "GARCÍA", "VEGA", "MIRANDA", "ROMERO",
                        "ORTIZ", "SALAZAR", "CAMPOS", "ORELLANA", "OLIVARES", "GARRIDO", "PARRA", "GALLARDO", "SAAVEDRA",
                        "ALARCON", "AGUILERA", "PEÑA", "ZÚÑIGA", "RUIZ", "MEDINA", "GUZMÁN", "ESCOBAR", "NAVARRO", "PIZARRO",
                        "GODOY", "CÁCERES", "HENRÍQUEZ", "ARAVENA", "MORENO", "LEIVA", "SALINAS", "VIDAL", "LAGOS", "VALDÉS",
                        "RAMOS", "MALDONADO", "JIMÉNEZ", "YÁÑEZ", "BUSTOS", "ORTEGA", "PALMA", "CARVAJAL", "PINO", "ALVARADO",
                        "PAREDES", "GUERRERO", "MORA", "POBLETE", "SÁEZ", "VENEGAS", "SANHUEZA", "BUSTAMANTE", "TORO",
                        "NAVARRETE", "CÁRDENAS", "DA SILVA", "DOS SANTOS", "DE SOUZA", "RODRIGUES", "COSTA", "SANTOS", "SOUSA",
                        "OLIVEIRA", "LIMA", "PEREIRA"
                        }


        if words[0].upper() in common_first: conf += 0.4
        elif words[0][0].isupper() and len(words[0]) >= 3: conf += 0.2
        for w in words[1:]:
            if w.upper() in common_surn: conf += 0.3
            elif w[0].isupper() and len(w) >= 3: conf += 0.1
        if 2 <= len(words) <= 4: conf += 0.1
        if any(len(w) > 15 for w in words): conf -= 0.2
        return min(max(conf, 0.0), 1.0)

    def is_valid_person_name(self, text: str) -> bool:
        """
        Validate if a string is a plausible Spanish person name using length, word count, and domain terms.
        Args:
            text (str): Candidate name string.
        Returns:
            bool: True if valid person name.
        """
        if not text or len(text.strip()) < 2: return False
        
        # Early exclusions for obvious non-names
        text_upper = text.upper()
        
        # Exclude form field descriptions and demographic terms
        form_field_patterns = [
            "CONYUGE", "CONYUGUE", "HIJOS", "FEMENINO", "MASCULINO", 
            "SOLTERO", "CASADO", "DIVORCIADO", "VIUDO", "ESTADO CIVIL",
            "BENEFICIARIOS", "TITULAR", "ASEGURADO", "COTIZANTE"
        ]
        if any(pattern in text_upper for pattern in form_field_patterns):
            return False
        
        # Exclude if contains multiple negation/status words
        status_words = {"SIN", "NO", "SI", "CON", "TIENE", "ES", "SON"}
        status_count = sum(1 for word in text_upper.split() if word in status_words)
        if status_count >= 2:  # Multiple status words indicate form fields
            return False
        
        # Exclude obvious system/UI terms
        ui_terms = {
            "BIENVENIDOS", "GESTIÓN", "COTIZADOR", "BACKOFFICE", "ADMINISTRADOR",
            "PRODUCCIÓN", "SISTEMA", "USUARIO", "AMBIENTE", "CONSULTA", "FILTRO",
            "REFRESCAR", "EXCEL", "CERRAR", "PREVIEW", "BORRADOR", "IMPORTANTE",
            "METLIFE", "MOTOR", "CLIENTE", "READY", "PROCESO", "RESULTADOS",
            "DATOS", "CONTROL", "VALIDACIÓN", "NÚMERO", "FECHA", "VALOR",
            "ESTADO", "TIPO", "MODALIDAD", "SOLICITUD", "OFERTA", "FOLIO",
            # Additional terms based on false positives
            "PROCESOS", "CARGA", "POLIZAS", "PÓLIZAS", "CREACIÓN", "ENDOSOS",
            "RENTA", "VITALICIA", "RENTAS", "VITALICIAS", "SCOMP", "CORONEL",
            "FONASA", "SOLLCITADO", "BENEFICIARIOS", "CONYUGE", "HIJOS", "FEMENINO",
            "SALDO", "SEGURA", "CRODRIGUEZ", "DOCX", "PDF", "XLSX", "ZIP",
            "MENSUAL", "OFRECIDA", "AFILIADO", "ELIAS", "VILLA", "HERMOSA", "SWAGER",
            "FIJA", "MINMO", "OMECIDA", "SIN", "NO", "SI", "ECHA", "COTIZACIÓN",
            "COTIZACION", "AFECHA", "PENSIÓN", "PENSION", "PAGO", "DEL", "SOLICITUD"
        }
        
        if any(term in text_upper for term in ui_terms): return False
        
        # Enhanced check for multiple UI terms in single text (form field descriptions)
        ui_term_matches = sum(1 for term in ui_terms if term in text_upper)
        if ui_term_matches >= 3:  # Multiple UI terms suggest business terminology
            return False
        
        
        # Exclude if any word is in SPANISH_NAME_EXCLUDE
        words = text_upper.split()
        if any(w in SPANISH_NAME_EXCLUDE for w in words):
            return False
        
        # Exclude if contains obvious technical patterns
        if re.search(r'\b(?:HTTP|WWW|\.COM|\.CL)\b', text_upper): return False
        if re.search(r'\b(?:XML|PDF|DOC|XLSX?|DOCX)\b', text_upper): return False
        if re.search(r'\b(?:CTRL|ALT|SHIFT|ENTER)\b', text_upper): return False
        
        # Exclude document patterns and file extensions
        if re.search(r'\.(?:PDF|DOCX?|XLSX?|ZIP|TXT)(?:\s|$)', text_upper): return False
        
        # Exclude if contains numbers mixed with text (likely codes/IDs)
        if re.search(r'\d.*[A-Z]|[A-Z].*\d', text_upper): return False
        
        # Exclude if contains specific business patterns
        if re.search(r'\b(?:VN|VA|SL|NO|SI|UF|RV|AC|VER|DIF|INM)\b', text_upper): return False
        
        # Exclude if too many uppercase words (likely headings/labels)
        words = text.split()
        if len(words) >= 2:
            uppercase_ratio = sum(1 for w in words if w.isupper() and len(w) > 2) / len(words)
            if uppercase_ratio > 0.6: return False
        
        #####################
        if not text or len(text.strip()) < 2: return False
        words = text.strip().split()
        prefix_words = {"nombre", "name", "sr", "sra", "señor", "señora", "don", "doña"}

        ## Quantity of words to be considered
        while words and words[0].lower() in prefix_words: words = words[1:]
        if len(words) <= 2 or len(words) > 5: return False  # Only accept names with 3 or 4 words
        # if len(words) < 2 or len(words) > 4: return False
        
        if any((not w.isalpha()) or len(w) < 2 for w in words): return False
        if self.use_lemmas and self.nlp_lemma:
            norm_tokens = set(self._lemma_tokens(words)); domain_set = self.financial_terms_lemmas
        elif self._stemmer:
            norm_tokens = set(self._stem_tokens(words)); domain_set = self.financial_terms_stems
        else:
            norm_tokens = set(self._strip_accents(w.lower()) for w in words); domain_set = self._normalize_wordset(self.financial_terms)
        if len(norm_tokens & domain_set) >= 2: return False
        remaining = self._strip_accents(" ".join(words).lower())
        
        # Check for substring matches with financial terms (avoid false positives with short terms)
        if any(term in remaining for term in domain_set if len(term) >= 4): return False
        
        # Multi-word phrase exclusion (keep separate for phrases not in financial_terms)
        financial_phrases = [
            "renta vitalicia", "renta mensual", "validación de", "traspaso de", "beneficiarios",
            "periodo garantizado", "diferido intermediario", "rut cotizante", "rut afiliado", "rut empleador",
            "nombre del cotizante", "nombres y apellidos", "datos personales", "información personal",
            "número de", "fecha de", "fecha de nacimiento", "fecha de ingreso", "fecha de egreso",
            "tipo de contrato", "duración del periodo", "valor cuota", "fondo acumulado", "cuenta individual",
            "cuenta de ahorro", "cuenta de capitalización", "cotización voluntaria", "cotización obligatoria",
            "bonificación estatal", "subsidio previsional", "reliquidación de pensión", "retiro programado",
            "depósito mensual", "fecha de vencimiento", "inicio de cobertura", "término de contrato",
            "retroactivo previsional", "solicitud de pensión", "formulario de traspaso", "validación de identidad",
            "tipo de fondo", "nombre de la AFP", "aseguradora contratada", "póliza vigente", "número póliza",
            "número cotización", "certificado de afiliación", "certificado de saldo", "estado de cuenta",
            "saldo acumulado", "monto disponible", "tasa de descuento", "tipo de pensión", "modalidad de pensión",
            "seguro de renta", "seguro de vejez", "vejez anticipada", "prima única", "policy loans",
            "pago preliminar", "primer pago", "fecha de pago", "estado civil", "sistema salud", "empleado público",
            "gestión cotizador", "backoffice administrador", "ambiente de producción", "consulta de cotizaciones",
            "filtro sordenar", "refrescar datos", "valores y seguros", "folio oferta", "valor uf", "fecha cotización",
            "válida hasta", "datos del afiliado", "compañía de seguros", "portal metlife", "sistema scomp",
            "resultados procesos", "procesos carga", "carga pólizas", "control tipo campos", "validación de pólizas",
            "traspaso beneficiarios", "emisión creación", "creación pólizas", "creación póliza", "rentas vitalicias",
            "check list", "primera hoja", "asesor previsional", "gestión de negocios", "sistema gestión",
            "consulta producción", "datos a validar", "ingreso documentos", "carga de pólizas", "módulo rvt",
            "despacho de pólizas", "pólizas electrónicas", "respaldo despacho", "control tipo", "corregir datos",
            "modificación de beneficiarios", "cambio de modalidad", "cálculo de pensión", "simulación de renta",
            "historial de cotizaciones", "registro previsional", "trámite en curso", "estado pendiente",
            "proceso aprobado", "proceso rechazado", "plazo de respuesta", "documentación requerida",
            "casos cerrados", "todos los derechos", "copyright metlife"
        ]


        if any(phrase in remaining for phrase in financial_phrases): return False
        
        # For short candidate names (<=2 words), be more strict with financial term fragments
        if len(words) <= 2:
            # Use financial terms as fragments for short names, but only medium-length terms
            financial_fragments = {term for term in domain_set if 4 <= len(term) <= 8}
            if any(fragment in remaining for fragment in financial_fragments): return False
        return True

    # Transformer NER
    def extract_transformer_ner(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract named entities from text using a transformer-based NER model, clean boundaries, and map labels.
        Args:
            text (str): Input text.
        Returns:
            List[Dict[str, Any]]: List of extracted entities.
        """
        # Iterate over text chunks and extract entities using transformer NER
        results: List[Dict[str, Any]] = []
        if not TRANSFORMER_NER_AVAILABLE: return results
        try:
            for offset, chunk in self._iter_ner_chunks(text, max_chars=512, overlap=200):
                entities = transformer_ner(chunk)
                for ent in entities:
                    entity_text = ent.get("word", ""); entity_label = ent.get("entity_group") or ent.get("entity", "UNKNOWN")
                    score = float(ent.get("score", 0.0)); start = int(ent.get("start", 0)) + offset; end = int(ent.get("end", 0)) + offset
                    cleaned_text, new_start, new_end = self.clean_entity_boundaries(entity_text, entity_label, text, start, end)
                    if not cleaned_text or len(cleaned_text.strip()) < 2: continue
                    label_map = {"PER": "TransformerPerson", "PERSON": "TransformerPerson", "ORG": "TransformerOrganization", "ORGANIZATION": "TransformerOrganization", "LOC": "TransformerLocation", "LOCATION": "TransformerLocation", "MISC": "TransformerMiscellaneous", "MISCELLANEOUS": "TransformerMiscellaneous"}
                    pii_type = label_map.get((entity_label or "").upper(), f"Transformer{entity_label}")
                    if pii_type == "TransformerPerson":
                        if not self._is_plausible_person_span(cleaned_text): continue
                        if not self.is_valid_person_name(cleaned_text): continue
                        ctx = self._local_context(text, new_start, new_end)
                        if (self.last_image_ocr_conf is not None and self.last_image_ocr_conf < self.low_conf_threshold and not self._person_context_ok(ctx)): continue
                        if self._looks_like_heading(ctx) and not self._person_context_ok(ctx): continue
                    if cleaned_text.strip().isdigit() or len(cleaned_text.strip()) == 1: continue
                    results.append({"PII_Type": pii_type, "PII_Value": cleaned_text, "Confidence": round(score, 4), "Source": "transformer", "start_pos": new_start, "end_pos": new_end, "pattern": None, "label": entity_label})
        except Exception as e:
            logging.error(f"Transformer NER error: {e}")
        return results

    # OCR cleaning and extraction (unchanged; trimmed here)
    def clean_ocr_line(self, text: str, remove_stopwords: bool = False) -> str:
        """
        Clean a single OCR line by normalizing, removing artifacts, and optionally removing stopwords.
        Args:
            text (str): OCR line text.
            remove_stopwords (bool): Whether to remove stopwords.
        Returns:
            str: Cleaned line.
        """
        try:
            text = unicodedata.normalize("NFKC", text)
            text = re.sub(r"-\s*\n\s*", "", text)  # Remove hyphen at end of line (word split)
            text = re.sub(r"-\s+(?=[a-záéíóúñ])", "", text, flags=re.IGNORECASE)  # Remove hyphen before lowercase letter (word split)
            text = re.sub(r"[^\w\s@.\-/+()[\],;:'\"áéíóúüñÁÉÍÓÚÜÑ-]", " ", text)  # Remove unwanted punctuation/symbols
            text = re.sub(r"\s*@\s*", "@", text)  # Remove spaces around '@' in emails
            text = re.sub(r"(\w)\s*\.\s*(\w)", r"\1.\2", text)  # Remove spaces around periods in abbreviations/emails
            text = re.sub(r"(\d)\s*-\s*([kK\d])", r"\1-\2", text)  # Remove spaces around hyphen in RUTs
            text = re.sub(r"\(\s*(\d{1,4})\s*\)", r"(\1)", text)  # Remove spaces inside parentheses (numbers)
            text = re.sub(r"\s{2,}", " ", text)  # Collapse multiple spaces into a single space
            cleaned_text = re.sub(r"\s+", " ", text).strip()  # Final whitespace normalization
            
            # Apply stop words removal if requested
            if remove_stopwords:
                cleaned_text = self.remove_stopwords(cleaned_text)
                
            return cleaned_text
        except Exception:
            return text

    def ocr_data_to_lines(self, ocr_data: Dict[str, List[Any]]) -> List[Dict[str, Any]]:
        """
        Convert OCR data dictionary to a list of line dictionaries with text, confidence, and bounding box info.
        Args:
            ocr_data (Dict[str, List[Any]]): OCR output data.
        Returns:
            List[Dict[str, Any]]: List of line dicts.
        """
        try:
            df = pd.DataFrame(ocr_data)
            if df.empty or "text" not in df.columns or "conf" not in df.columns: return []
            df["text"] = df["text"].fillna("").astype(str)
            df["conf"] = pd.to_numeric(df["conf"], errors="coerce").fillna(-1).astype(int)
            df = df[(df["text"].str.strip() != "") & (df["conf"] != -1)]
            if df.empty: return []
            lines: List[Dict[str, Any]] = []
            df = df.sort_values(by=["top", "left"])
            for (b, p, l), g in df.groupby(["block_num", "par_num", "line_num"]):
                g = g.sort_values(by=["left"]); words = g["text"].tolist()
                if not words: continue
                text = " ".join(words).strip()
                avg_conf = float(np.mean(g["conf"])) if len(g) else None
                left = int(g["left"].min()); top = int(g["top"].min()); right = int((g["left"] + g["width"]).max()); bottom = int((g["top"] + g["height"]).max())
                lines.append({"text": text, "conf": round(avg_conf or 0.0, 2), "left": left, "top": top, "width": right - left, "height": bottom - top, "block_num": int(b), "par_num": int(p), "line_num": int(l)})
            lines.sort(key=lambda x: (x["top"], x["left"]))
            for i, line in enumerate(lines, 1): line["seq_line_number"] = i
            return lines
        except Exception as e:
            logging.error(f"OCR data to lines error: {e}")
            return []

    def extract_text_and_confidence_from_image(self, image_path: str, lang: str = "spa+eng") -> Tuple[str, float, Optional[Dict[str, List[Any]]]]:
        """
        Extract text and confidence score from an image using OCR, returning cleaned text and OCR data.
        Args:
            image_path (str): Path to image file.
            lang (str): OCR language(s).
        Returns:
            Tuple[str, float, Optional[Dict[str, List[Any]]]]: (text, confidence, OCR data)
        """
        try:
            data = np.fromfile(image_path, dtype=np.uint8)
            image = cv2.imdecode(data, cv2.IMREAD_COLOR)
            if image is None: return "", 0.0, None
            # Here is the process to extract the text
            ocr_data = pytesseract.image_to_data(image, lang=lang, config=self.tesseract_config, output_type=pytesseract.Output.DICT)
            line_items = self.ocr_data_to_lines(ocr_data)
            if line_items:
                text_parts, confs = [], []
                for line in line_items:
                    # Clean the line first without stop words removal
                    cleaned = self.clean_ocr_line(line["text"], remove_stopwords=False)
                    if cleaned and len(cleaned) > 1:
                        text_parts.append(cleaned)
                        if line.get("conf") is not None: confs.append(float(line["conf"]))
                full_text = " ".join(text_parts); avg_conf = sum(confs) / len(confs) if confs else 0.0
            else:
                raw_text = pytesseract.image_to_string(image, lang=lang, config=self.tesseract_config)
                full_text = self.clean_ocr_line(raw_text, remove_stopwords=False); avg_conf = 0.0
            clean_text = re.sub(r"\s+", " ", full_text).strip()
            return clean_text, float(avg_conf), ocr_data
        except Exception as e:
            logging.error(f"OCR extraction error for {image_path}: {e}")
            return "", 0.0, None

    # PII extraction
    def extract_pii_from_text(self, text: str) -> List[Dict[str, Any]]:
        """
        Extract PII entities from text using regex, spaCy NER, transformer NER, and post-processing filters.
        Args:
            text (str): Input text.
        Returns:
            List[Dict[str, Any]]: List of detected PII entities.
        """
        # 1. Basic cleaning
        # 2. Regex extraction for all patterns
        # 3. Aggressive and advanced cleaning for NER
        # 4. spaCy NER extraction
        # 5. Transformer NER extraction
        # 6. Merge and deduplicate results
        # 7. Embedding rerank (semantic)
        # 8. Strict post-filter for person-like entities
        # 9. Context-aware post-filtering and priority suppression
        # 10. Assign labels and group entity types
        results: List[Dict[str, Any]] = []
        try:
            # 1. Basic cleaning
            basic_cleaned_text = self.basic_clean_ocr_text(text)

            # 2. Regex extraction (all patterns)
            regex_results: List[Dict[str, Any]] = []
            country_map = {
                "Phone_Chile_Service": "Chile",
                "Phone_Argentina_Service": "Argentina",
                "Phone_Brazil_Service": "Brazil",
                "Phone_Uruguay_Service": "Uruguay",
                "Phone_Mexico_Service": "Mexico",
            }
            for ptype, pattern in PII_PATTERNS.items():
                for m in pattern.finditer(basic_cleaned_text):
                    value = m.group(1) if m.lastindex else m.group(0)
                    # Expand date matches if more digits follow (e.g., 12/11/20 + 14 = 12/11/2014)
                    if ptype == "Date":
                        end_pos = m.end(1) if m.lastindex else m.end(0)
                        # Check for more digits immediately after the match
                        extra_digits = ""
                        i = end_pos
                        while i < len(basic_cleaned_text) and basic_cleaned_text[i].isdigit():
                            extra_digits += basic_cleaned_text[i]
                            i += 1
                        if extra_digits:
                            value += extra_digits
                            end_pos += len(extra_digits)
                    if ptype.startswith("RUT"):
                        norm = normalize_rut(value)
                        is_valid = validate_rut(value)
                        if is_valid and norm:
                            regex_results.append({
                                "PII_Type": "RUT",
                                "PII_Value": norm,
                                "Confidence": None,
                                "Source": "regex",
                                "start_pos": m.start(1) if m.lastindex else m.start(0),
                                "end_pos": m.end(1) if m.lastindex else m.end(0),
                                "pattern": pattern.pattern,
                                "label": ptype,
                                "Valid": True
                            })
                        else:
                            continue  # Skip invalid RUTs
                    elif ptype in country_map or ptype.startswith("Phone_"):
                        # Tag all Phone_*_Service as Phone, annotate country if available
                        entity = {
                            "PII_Type": "Phone",
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": m.start(1) if m.lastindex else m.start(0),
                            "end_pos": m.end(1) if m.lastindex else m.end(0),
                            "pattern": pattern.pattern,
                            "label": ptype
                        }
                        if ptype in country_map:
                            entity["Country"] = country_map[ptype]
                        regex_results.append(entity)
                    else:
                        regex_results.append({
                            "PII_Type": ptype,
                            "PII_Value": value,
                            "Confidence": None,
                            "Source": "regex",
                            "start_pos": m.start(1) if m.lastindex else m.start(0),
                            "end_pos": m.end(1) if m.lastindex else m.end(0),
                            "pattern": pattern.pattern,
                            "label": ptype
                        })

            # 3. Aggressive cleaning for NER
            ner_text = self.aggressive_clean_text(basic_cleaned_text) # Drop stopwords
            
            # 3b. Advanced cleaning for transformer NER
            transformer_ner_text = self.advanced_clean_text(basic_cleaned_text)
            
            # 3c. Pre-filter obvious non-person patterns from NER text
            import re
            # Remove obvious system/document patterns that shouldn't be processed by NER
            ner_text = re.sub(r'\b(?:GESTIÓN|PROCESOS?|CARGA|PÓLIZAS?|POLIZAS?|CREACIÓN|RESULTADOS?)\s+[A-Z\s]{5,50}', ' ', ner_text, flags=re.IGNORECASE)
            ner_text = re.sub(r'\b[A-Z]{1,3}\s+[A-Z]{1,3}\s+[A-Z]{1,3}\b', ' ', ner_text)  # Remove code-like patterns
            ner_text = re.sub(r'\.[A-Z]{3,4}\b', ' ', ner_text)  # Remove file extensions
            

            # 4. spaCy NER Extraction
            spacy_results: List[Dict[str, Any]] = []
            if NER_AVAILABLE:
                try:
                    doc = nlp(ner_text)
                    for ent in doc.ents:
                        # Clean entity boundaries of the text 
                        cleaned_text, new_start, new_end = self.clean_entity_boundaries(ent.text, ent.label_, ner_text, ent.start_char, ent.end_char)
                        if cleaned_text is None: continue
                        
                        # Apply validation for person entities
                        person_labels = {"PER", "PERSON", "PERSONA", "SpanishName"}
                        if ent.label_ in person_labels:
                            # Apply comprehensive person name validation
                            if not self.is_valid_person_name(cleaned_text):
                                continue
                            # Apply additional plausibility check
                            if not self._is_plausible_person_span(cleaned_text):
                                continue
                        
                        spacy_results.append({
                            "PII_Type": ent.label_,
                            "PII_Value": cleaned_text,
                            "Confidence": None,
                            "Source": "spaCy",
                            "start_pos": new_start,
                            "end_pos": new_end,
                            "pattern": None,
                            "label": ent.label_
                        })
                except Exception as e:
                    logging.warning(f"spaCy NER failed: {e}")

            # 5. Transformer NER Extraction
            transformer_results: List[Dict[str, Any]] = []
            if TRANSFORMER_NER_AVAILABLE:
                try:
                    ner_results = self.extract_transformer_ner(transformer_ner_text) # transformer_ner_text , default: ner_text
                    transformer_results.extend(ner_results)
                except Exception as e:
                    logging.warning(f"Transformer NER failed: {e}")

            # 6. Merge and deduplicate
            all_results = regex_results + spacy_results + transformer_results
            results = self._dedupe_entities(all_results)

            # 7. Embedding rerank (semantic)
            if self._embed_reranker:
                try:
                    results = self._embed_reranker.rerank(ner_text, results, context_window=48)
                except Exception as e:
                    logging.warning(f"Embedding rerank failed: {e}")

            # 8. Strict post-filter
            if self.strict_mode and results:
                filtered: List[Dict[str, Any]] = []
                for e in results:
                    e_type = e.get("PII_Type", "")
                    value = e.get("PII_Value", "")
                    start, end = e.get("start_pos", 0), e.get("end_pos", 0)
                    person_like = e_type in {"TransformerPerson", "SpanishName", "PER", "PERSON", "PERSONA"}
                    if person_like:
                        if not self._is_plausible_person_span(value): continue
                        words = value.split(); name_conf = self._assess_name_confidence(words) if words else 0.0
                        ctx = self._local_context(text, start, end)
                        norm_val = self._norm_value_for_key(value)
                        same_value_sources = {x["Source"] for x in results if x is not e and self._norm_value_for_key(x.get("PII_Value", "")) == norm_val}
                        has_consensus = len(same_value_sources) >= 1
                        from_person_context = e.get("label") == "Person_Context"
                        good_context = self._person_context_ok(ctx)
                        if has_consensus or good_context or name_conf >= self.person_min_conf or from_person_context:
                            if (self.last_image_ocr_conf is not None and self.last_image_ocr_conf < self.low_conf_threshold and self._looks_like_heading(ctx) and not good_context):
                                continue
                            filtered.append(e)
                        else:
                            continue
                    else:
                        filtered.append(e)
                results = filtered

            # --- Context-aware post-filtering and priority suppression (after results assigned) ---
            try:
                phone_context_words = {"tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext"}
                def has_phone_context(value):
                    idx = text.find(value)
                    if idx == -1:
                        return False
                    ctx_window = text[max(0, idx-40):idx].lower()
                    return any(w in ctx_window for w in phone_context_words)

                # If a NumberSequence or Amount is near phone context, reclassify as Phone ONLY if value length >= 10
                for entity in results:
                    if entity.get("PII_Type") in {"NumberSequence", "Amount"}:
                        v = entity.get("PII_Value")
                        if has_phone_context(v) and len(v.replace(' ', '').replace('-', '')) >= 10:
                            entity["PII_Type"] = "Phone"

                # Suppress lower-priority types for same value (priority logic)
                priority = {"Date": 3, "DateTime": 3, "Time": 3, "Phone": 2, "NumberSequence": 1, "Amount": 1}
                value_groups = {}
                for entity in results:
                    v = entity.get("PII_Value")
                    t = entity.get("PII_Type")
                    p = priority.get(t, 0)
                    if v not in value_groups or p > priority.get(value_groups[v]["PII_Type"], 0):
                        value_groups[v] = entity
                results = list(value_groups.values())
            except Exception as e:
                logging.error(f"Error in context-aware post-filtering: {e}")

            # Assign Label for every entity

            # Group DateTime and Date as Date
            for entity in results:
                if entity.get("PII_Type") == "DateTime":
                    entity["PII_Type"] = "Date"

            # Group Time as Date
            for entity in results:
                if entity.get("PII_Type") == "Time":
                    entity["PII_Type"] = "Date"


            # Group LOC and TransformerLocation as LOC
            for entity in results:
                if entity.get("PII_Type") in ["TransformerLocation", "LOC"]:
                    entity["PII_Type"] = "LOC"

            # Group MISC and TransformerMiscellaneous as MISC
            for entity in results:
                if entity.get("PII_Type") in ["TransformerMiscellaneous", "MISC"]:
                    entity["PII_Type"] = "MISC"

            # Group ORG and TransformerOrganization as ORG
            for entity in results:
                if entity.get("PII_Type") in ["TransformerOrganization", "ORG"]:
                    entity["PII_Type"] = "ORG"

            # Group all Phone_*_Service types as Phone
            phone_types = [
                "Phone_Chile_Service",
                "Phone_Argentina_Service",
                "Phone_Brazil_Service",
                "Phone_Uruguay_Service",
                "Phone_Mexico_Service"
            ]
            for entity in results:
                if entity.get("PII_Type") in phone_types:
                    entity["PII_Type"] = "Phone"

            numeric_types = {"RUT", "Amount", "CreditCard", "Account", "Phone", "Date", "NumberSequence","SEQ_NUMBER","PHONE_NUMBER","DATE","AMOUNT"}
            for entity in results:
                if entity.get("PII_Type") in numeric_types:
                    entity["Label"] = "SequenceNumber"
                else:
                    entity["Label"] = "TextData"

            results.sort(key=lambda r: (r.get("start_pos", 0), r.get("end_pos", 0)))
        except Exception as e:
            logging.error(f"Error extracting PII: {e}")
        return results


    def process_image_for_pii(self, image_path: str, lang: str = "spa") -> Dict[str, Any]:
        """
        Process an image for PII detection: extract text, clean, embed, tag POS, and extract PII entities.
        Args:
            image_path (str): Path to image file.
            lang (str): OCR language.
        Returns:
            Dict[str, Any]: Results including text, cleaned text, embedding, confidence, PII entities, and POS tags.
        """
        try:
            extracted_text, confidence, ocr_data = self.extract_text_and_confidence_from_image(image_path, lang)
            self.last_image_ocr_conf = confidence
            if not extracted_text.strip():
                return {"image_path": image_path, "text": "", "confidence": 0.0, "pii_entities": [], "pii_count": 0, "success": False}
            
            # Generate cleaned text for the Excel report
            cleaned_text = extracted_text
            
            # Apply advanced cleaning if enabled
            if self.use_advanced_cleaning:
                cleaned_text = self.advanced_clean_text(cleaned_text)
                
            # Apply stop words removal if enabled
            if self.use_stopwords_removal:
                cleaned_text = self.remove_stopwords(cleaned_text)
            # Generate embedding for cleaned text
            embedding = None
            if self.use_text_embedding:
                try:
                    if self.text_embedding_model is not None:
                        # Use sentence-transformers model if available
                        embedding = self.text_embedding_model.encode(cleaned_text).tolist()
                    else:
                        # Use simple fallback embedding
                        embedding = self.generate_simple_embedding(cleaned_text)
                        logging.debug(f"Using simple embedding (model not available)")
                except Exception as e:
                    logging.warning(f"[WARNING] Text embedding failed: {e}")
                   
                    # Fallback to simple embedding
                    try:
                        embedding = self.generate_simple_embedding(cleaned_text)
                        logging.debug(f"Using simple embedding fallback")
                    except Exception as fallback_error:
                        logging.warning(f"[WARNING] Simple embedding also failed: {fallback_error}")
                        embedding = None
            
            # Always generate POS tags for cleaned text
            try:
                pos_tags = self.get_pos_tags(cleaned_text)
            except Exception as e:
                logging.warning(f"Failed to generate POS tags for image {image_path}: {e}")
                pos_tags = "N/A"
            
            pii_entities = self.extract_pii_from_text(extracted_text)
            return {
                "image_path": image_path,
                "text": extracted_text,
                "cleaned_text": cleaned_text,
                "embedding": embedding,
                "confidence": confidence,
                "pii_entities": pii_entities,
                "pii_count": len(pii_entities),
                "success": True,
                "ocr_data": ocr_data,
                "pos_tags": pos_tags
            }
        except Exception as e:
            logging.error(f"Error processing image {image_path}: {e}")
            return {"image_path": image_path, "text": "", "confidence": 0.0, "pii_entities": [], "pii_count": 0, "success": False, "error": str(e)}
    
    
    def process_text_file_for_pii(self, text_file_path: str) -> Dict[str, Any]:
        """
        Process a text file for PII detection: read, clean, embed, tag POS, and extract PII entities.
        Args:
            text_file_path (str): Path to text file.
        Returns:
            Dict[str, Any]: Results similar to process_image_for_pii.
        """
        try:
            # Read text file content
            with open(text_file_path, 'r', encoding='utf-8') as f:
                extracted_text = f.read()
            
            if not extracted_text.strip():
                return {
                    "text_file_path": text_file_path, 
                    "text": "", 
                    "confidence": 100.0,  # Text files have perfect "confidence" 
                    "pii_entities": [], 
                    "pii_count": 0, 
                    "success": False,
                    "source_type": "text_file"
                }
            
            # Generate cleaned text for the Excel report
            cleaned_text = extracted_text
            
            # Apply advanced cleaning if enabled
            if self.use_advanced_cleaning:
                cleaned_text = self.advanced_clean_text(cleaned_text)
                
            # Apply stop words removal if enabled
            if self.use_stopwords_removal:
                cleaned_text = self.remove_stopwords(cleaned_text)
            
            # Generate embedding for cleaned text
            embedding = None
            if self.use_text_embedding:
                try:
                    embedding = self.generate_simple_embedding(cleaned_text)
                except Exception as e:
                    logging.warning(f"Failed to generate embedding for text file {text_file_path}: {e}")
                    embedding = None
            
            # Always generate POS tags for cleaned text
            try:
                pos_tags = self.get_pos_tags(cleaned_text)
            except Exception as e:
                logging.warning(f"Failed to generate POS tags for text file {text_file_path}: {e}")
                pos_tags = "N/A"
            
            # Extract PII entities
            pii_entities = self.extract_pii_from_text(extracted_text)
            
            # Debug logging for test file
            if 'test_rut_document' in text_file_path:
                logging.info(f"DEBUG: Processing test_rut_document.txt")
                logging.info(f"DEBUG: Text content: '{extracted_text}'")
                logging.info(f"DEBUG: Found {len(pii_entities)} PII entities")
                for entity in pii_entities:
                    logging.info(f"DEBUG: PII - {entity.get('PII_Type', 'Unknown')}: {entity.get('PII_Value', 'Unknown')}")
            
            # Build result
            result = {
                "text_file_path": text_file_path,
                "text": extracted_text,
                "cleaned_text": cleaned_text,
                "confidence": 100.0,  # Text files have perfect extraction confidence
                "pii_entities": pii_entities,
                "pii_count": len(pii_entities),
                "success": True,
                "source_type": "text_file",
                "embedding": embedding,
                "pos_tags": pos_tags
            }
            
            logging.debug(f"Processed text file: {text_file_path} - Found {len(pii_entities)} PII entities")
            return result
            
        except Exception as e:
            logging.error(f"Error processing text file {text_file_path}: {e}")
            return {
                "text_file_path": text_file_path, 
                "text": "", 
                "confidence": 0.0, 
                "pii_entities": [], 
                "pii_count": 0, 
                "success": False,
                "source_type": "text_file"
            }

    # Reporting helpers (unchanged from your previous version; omitted here for brevity)
    def _get_sensitivity_level(self, pii_type: str) -> str:
        """
        Get sensitivity level for a given PII type (High, Medium, Low).
        Args:
            pii_type (str): PII type string.
        Returns:
            str: Sensitivity level.
        """
        high = {"RUT", "PartialRUT", "TransformerPerson", "SpanishName", "CreditCard", "Account", "Passport_Context"}
        medium = {"Phone", "Phone_Context", "Amount", "Date", "DateTime", "Address", "Address_StreetNum", "Address_Keywords", "TransformerOrganization", "TransformerLocation", "Email"}
        low = {"NumberSequence"}
        if pii_type in high: return "High"
        if pii_type in medium: return "Medium"
        if pii_type in low: return "Low"
        return "Low"

    def _extract_page_number(self, filename: str) -> int:
        """
        Extract page number from filename using patterns like 'page_N_' or first number found.
        Args:
            filename (str): Filename string.
        Returns:
            int: Extracted page number (default 1 if not found).
        """
        """
        Extract page number from filenames like:
        - page_3_image_2.png -> returns 3
        - page_3_2. SOP Emision-Creacion Poliza RV.txt -> returns 3
        - page_10_2. SOP Emision-Creacion Poliza RV.txt -> returns 10
        """
        try:
            import re
            
            # Debug logging to see what we're working with
            logging.debug(f"Extracting page number from filename: {filename}")
            
            # Match 'page_N_' pattern first
            match = re.search(r'page_(\d+)_', filename)
            if match:
                page_num = int(match.group(1))
                logging.debug(f"Found page number using pattern 'page_(\\d+)_': {page_num}")
                return page_num
            # Fallback: get first number in filename  
            numbers = re.findall(r'\d+', filename)
            if numbers:
                page_num = int(numbers[0])
                logging.debug(f"Using first number found: {page_num}")
                return page_num
                
            logging.debug("No page number found, defaulting to 1")
            return 1
            
        except Exception as e:
            logging.error(f"Error extracting page number from {filename}: {e}")
            return 1
    # ... keep your Excel export and run_flow methods from the previous full code ...
    # -------------------------------------------------------------------------
    # Folder scanning + Excel export
    # -------------------------------------------------------------------------

    def extract_texts_to_excel_from_folder(self, folder_path: str, lang: str = "spa+eng", output_file: Optional[str] = None) -> bool:
        """
        Process both images and text files from a folder and export results to Excel.
        Looks for images in 'images/' subfolder and text files in 'extracted_text/' subfolder.
        Args:
            folder_path (str): Path to folder.
            lang (str): OCR language(s).
            output_file (Optional[str]): Output Excel file path.
        Returns:
            bool: True if export succeeded, False otherwise.
        """
        try:
            all_results: List[Dict[str, Any]] = []
            # Process images from images/ folder
            images_folder = os.path.join(folder_path, "images")
            if os.path.exists(images_folder):
                # Check for enhanced folder first
                enhanced_folder = os.path.join(images_folder, "enhanced")
                images_source = enhanced_folder if os.path.exists(enhanced_folder) else images_folder
                logging.info(f"Using images from: {images_source}")
                image_files = [
                    f for f in os.listdir(images_source)
                    if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif"))
                ]
                if image_files:
                    logging.info(f"Processing {len(image_files)} images for OCR and PII detection")
                    for image_file in sorted(image_files):
                        image_path = os.path.join(images_source, image_file)
                        result = self.process_image_for_pii(image_path, lang)
                        result["source_type"] = "image_ocr"  # Mark as image source
                        all_results.append(result)
                else:
                    logging.info(f"No image files found in: {images_source}")
            # Process text files from extracted_text/ folder
            text_folder = os.path.join(folder_path, "extracted_text")
            if os.path.exists(text_folder):
                logging.info(f"Looking for text files in: {text_folder}")
                text_files = [
                    f for f in os.listdir(text_folder)
                    if f.lower().endswith(".txt")
                ]
                if text_files:
                    logging.info(f"Processing {len(text_files)} text files for PII detection")
                    for text_file in sorted(text_files):
                        text_path = os.path.join(text_folder, text_file)
                        result = self.process_text_file_for_pii(text_path)
                        all_results.append(result)
                else:
                    logging.info(f"No text files found in: {text_folder}")
            # Check if we have any results to process
            if not all_results:
                logging.warning(f"No files to process in folder: {folder_path}")
                return False
            # Log summary of what was processed
            image_count = sum(1 for r in all_results if r.get("source_type") == "image_ocr")
            text_count = sum(1 for r in all_results if r.get("source_type") == "text_file")
            logging.info(f"Total processed: {image_count} images, {text_count} text files")
            # Only create the main Excel report, do not generate PII_extraction.xlsx
            return self._create_excel_report(all_results, folder_path, output_file)
        except Exception as e:
            logging.error(f"Error extracting texts from folder {folder_path}: {e}")
            return False
    def _create_excel_report(self, results: List[Dict[str, Any]], folder_path: str, output_file: Optional[str] = None) -> bool:
        """
        Combine text processing and PII detections into a single Excel file with:
        - Summary: counts by type/method/sensitivity
        - Text_Results: one row per processed file (image or text)
        - PII_Detection: one row per detected PII entity
        Args:
            results (List[Dict[str, Any]]): List of processing results.
            folder_path (str): Source folder path.
            output_file (Optional[str]): Output Excel file path.
        Returns:
            bool: True if report created successfully, False otherwise.
        """
        logging.info("Starting function: _create_excel_report")
        try:
            excel_rows: List[Dict[str, Any]] = []
            pii_rows: List[Dict[str, Any]] = []
            for res in results:
                if res.get("success"):
                    # Handle both image and text file sources
                    source_type = res.get("source_type", "image_ocr")
                    if source_type == "image_ocr":
                        file_path = res["image_path"]
                        filename = os.path.basename(file_path)
                        page_number = self._extract_page_number(filename)
                        confidence = round(float(res["confidence"]), 2)
                    else:  # text_file
                        file_path = res["text_file_path"]
                        filename = os.path.basename(file_path)
                        page_number = self._extract_page_number(filename)  # Extract page number from text file name
                        confidence = 100.0  # Text files have perfect extraction confidence
                    cleaned_text = res.get("cleaned_text", res["text"])  # Use cleaned text if available
                    embedding = res.get("embedding", None)  # Get embedding if available
                    # Tokenize cleaned text (simple whitespace split)
                    tokenized_text = " | ".join(cleaned_text.split())
                    # Get POS tags for cleaned text
                    pos_tags = self.get_pos_tags(cleaned_text) # res.get("pos_tags") or self.get_pos_tags(cleaned_text)
                    excel_rows.append(
                        {
                            "File": filename,
                            "Source_Type": source_type.replace("_", " ").title(),
                            "Page": page_number,
                            "Text": res["text"],
                            "Cleaned_Text": cleaned_text,
                            "Tokenized_Text": tokenized_text,
                            "POS_Tags": pos_tags,
                            "Text_Length": len(res["text"]),
                            "Extraction_Confidence": confidence,
                            "PII_Count": res["pii_count"],
                            "Embedding": f"[{len(embedding)} dims] " + str(embedding)[:100] + "..." if embedding else "N/A",
                            "Processing_Status": "Success",
                        }
                    )
                    for pii in res["pii_entities"]:
                        sensitivity_level = self._get_sensitivity_level(pii["PII_Type"])
                        pii_rows.append(
                            {
                                "File": filename,
                                "Source_Type": source_type.replace("_", " ").title(),
                                "Page": page_number,
                                "Text": res["text"],
                                "PII_Type": pii["PII_Type"],
                                "PII_Value": pii["PII_Value"],
                                "PII_Length": len(pii["PII_Value"]),
                                "Confidence_Score": pii["Confidence"] if pii["Confidence"] is not None else "N/A",
                                "Source": pii["Source"],
                                "Start_Position": pii["start_pos"],
                                "End_Position": pii["end_pos"],
                                "Sensitivity_Level": sensitivity_level,
                                "Pattern": pii.get("pattern", ""),
                                "Label": pii.get("Label", ""),
                            }
                        )
                else:
                    # Handle failed processing
                    source_type = res.get("source_type", "image_ocr")
                    if source_type == "image_ocr":
                        file_path = res["image_path"]
                        filename = os.path.basename(file_path)
                        page_number = self._extract_page_number(filename)
                    else:  # text_file
                        file_path = res["text_file_path"]
                        filename = os.path.basename(file_path)
                        page_number = self._extract_page_number(filename)
                    excel_rows.append(
                        {
                            "File": filename,
                            "Source_Type": source_type.replace("_", " ").title(),
                            "Page": page_number,
                            "Text": "",
                            "Cleaned_Text": "",
                            "Tokenized_Text": "",
                            "POS_Tags": "",
                            "Text_Length": 0,
                            "Extraction_Confidence": 0.0,
                            "PII_Count": 0,
                            "Embedding": "N/A",
                            "Processing_Status": f"Failed: {res.get('error', 'Unknown error')}",
                        }
                    )
            main_df = pd.DataFrame(excel_rows)
            pii_df = pd.DataFrame(pii_rows)
            summary_stats = self._generate_summary_stats(main_df, pii_df)
            summary_df = pd.DataFrame([summary_stats])
            if output_file is None:
                os.makedirs(self.output_dir, exist_ok=True)
                folder_name = os.path.basename(folder_path.rstrip(os.sep))
                timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
                output_file = os.path.join(self.output_dir, f"OCR_PII_Analysis_{folder_name}_{timestamp}.xlsx")
            with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
                summary_df.to_excel(writer, sheet_name="Summary", index=False)
                main_df.to_excel(writer, sheet_name="Text_Results", index=False)
                if not pii_df.empty:
                    pii_df.to_excel(writer, sheet_name="PII_Detection", index=False)
                self._format_excel_sheets(writer, main_df, pii_df, summary_df)
            # Count different source types for logging
            image_count = len([r for r in excel_rows if r.get("Source_Type") == "Image Ocr"])
            text_count = len([r for r in excel_rows if r.get("Source_Type") == "Text File"])
            logging.info(f"Excel report created: {output_file}")
            # logging.info(f"POS_Tags head: {main_df['POS_Tags'].head().to_list()}")
            logging.info(f"Report contains: {image_count} images, {text_count} text files, {len(pii_df)} PII entities")
            return True
        except Exception as e:
            logging.error(f"Error creating Excel report: {e}")
            return False

    # -------------------------------------------------------------------------
    # Excel helpers
    # -------------------------------------------------------------------------
    def _generate_summary_stats(self, main_df: pd.DataFrame, pii_df: pd.DataFrame) -> Dict[str, Any]:
        """Produce a one-row summary sheet with key metrics and breakdowns."""
        try:
            stats: Dict[str, Any] = {
                "Report_Generated": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Total_Images_Processed": int(len(main_df)),
                "Successful_OCR_Extractions": int(len(main_df[main_df["Processing_Status"] == "Success"])),
                "Failed_OCR_Extractions": int(len(main_df[main_df["Processing_Status"] != "Success"])),
                "Total_PII_Entities_Found": int(len(pii_df)) if not pii_df.empty else 0,
                "Average_OCR_Confidence": float(main_df["Extraction_Confidence"].mean()) if not main_df.empty else 0.0,
                "Total_Text_Characters": int(main_df["Text_Length"].sum()) if not main_df.empty else 0,
            }

            if not pii_df.empty:
                for pii_type, count in pii_df["PII_Type"].value_counts().head(10).items():
                    stats[f"PII_Count_{pii_type}"] = int(count)

                for level, count in pii_df["Sensitivity_Level"].value_counts().items():
                    stats[f"{level}_Sensitivity_PII"] = int(count)

                for source, count in pii_df["Source"].value_counts().items():
                    stats[f"Detection_Method_{source}"] = int(count)

            return stats
        except Exception as e:
            logging.error(f"Error generating summary stats: {e}")
            return {"Error": str(e)}

    def _format_excel_sheets(
        self, writer: pd.ExcelWriter, main_df: pd.DataFrame, pii_df: pd.DataFrame, summary_df: pd.DataFrame
    ) -> None:
        """Apply simple widths, header styling, and wrap text for readability."""
        try:
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter

            # Summary
            ws_summary = writer.sheets.get("Summary")
            if ws_summary:
                for col_idx, width in enumerate([30, 22], start=1):
                    ws_summary.column_dimensions[get_column_letter(col_idx)].width = width
                for cell in ws_summary[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="CCCCCC", end_color="CCCCCC", fill_type="solid")
                ws_summary.freeze_panes = "A2"

            # OCR_Results - Updated for all new columns
            ws_main = writer.sheets.get("OCR_Results")
            if ws_main:
                # Column widths for: Image, Page, Text, Cleaned_Text, Tokenized_Text, POS_Tags, Text_Length, OCR_Confidence, PII_Count, Embedding, Processing_Status
                widths = [25, 8, 60, 60, 80, 100, 15, 18, 12, 40, 20]
                for idx, w in enumerate(widths, start=1):
                    ws_main.column_dimensions[get_column_letter(idx)].width = w
                for cell in ws_main[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
                # Apply wrap text to text columns (C, D, E, F, J)
                for row in ws_main.iter_rows(min_row=2):
                    for col_letter in ["C", "D", "E", "F", "J"]:
                        ws_main[f"{col_letter}{row[0].row}"].alignment = Alignment(wrap_text=True, vertical="top")
                ws_main.freeze_panes = "A2"

            # PII_Detection - Updated for new Page column
            ws_pii = writer.sheets.get("PII_Detection")
            if ws_pii and not pii_df.empty:
                # Column widths for: Image, Page, Text, PII_Type, PII_Value, PII_Length, Confidence_Score, Source, Start_Position, End_Position, Sensitivity_Level
                widths = [25, 8, 80, 28, 18, 14, 14, 16, 16, 16, 18]
                for idx, w in enumerate(widths, start=1):
                    ws_pii.column_dimensions[get_column_letter(idx)].width = w
                for cell in ws_pii[1]:
                    cell.font = Font(bold=True)
                    cell.fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")

                for row_idx in range(2, len(pii_df) + 2):
                    sensitivity = ws_pii[f"K{row_idx}"].value if ws_pii.max_column >= 11 else None  # Updated column reference
                    if sensitivity == "High":
                        fill = PatternFill(start_color="FFEEEE", end_color="FFEEEE", fill_type="solid")
                    elif sensitivity == "Medium":
                        fill = PatternFill(start_color="FFFFEE", end_color="FFFFEE", fill_type="solid")
                    else:
                        fill = PatternFill(start_color="EEFFEE", end_color="EEFFEE", fill_type="solid")
                    for col_idx in range(1, ws_pii.max_column + 1):
                        ws_pii.cell(row=row_idx, column=col_idx).fill = fill
                    # Apply wrap text to text columns (C, E)
                    for col_letter in ["C", "E"]:
                        ws_pii[f"{col_letter}{row_idx}"].alignment = Alignment(wrap_text=True, vertical="top")

                ws_pii.freeze_panes = "A2"

        except Exception as e:
            logging.warning(f"Error formatting Excel sheets: {e}")

    # -------------------------------------------------------------------------
    # Batch entrypoints + summary
    # -------------------------------------------------------------------------
    def process_all_folders(self) -> bool:
        """
        Process all subfolders under input_dir (excluding '_file_input'),
        searching for './images' and './extracted_text' directories to analyze.
        """
        try:
            logging.info("Starting text processing and PII detection for all folders")
            folders_to_process: List[str] = []
            for item in os.listdir(self.input_dir):
                folder_path = os.path.join(self.input_dir, item)
                if os.path.isdir(folder_path) and item != "_file_input":
                    images_folder = os.path.join(folder_path, "images")
                    text_folder = os.path.join(folder_path, "extracted_text")
                    # Include folder if it has either images or extracted text
                    if os.path.exists(images_folder) or os.path.exists(text_folder):
                        folders_to_process.append(folder_path)

            if not folders_to_process:
                logging.warning("No folders with images or extracted text found for processing")
                return False

            logging.info(f"Found {len(folders_to_process)} folders to process")
            success_count = 0
            for folder_path in sorted(folders_to_process):
                try:
                    if self.extract_texts_to_excel_from_folder(folder_path):
                        success_count += 1
                        logging.info(f"Successfully processed folder: {os.path.basename(folder_path)}")
                    else:
                        logging.warning(f"Failed to process folder: {os.path.basename(folder_path)}")
                except Exception as e:
                    logging.error(f"Error processing folder {folder_path}: {e}")

            logging.info(
                f"Text processing and PII detection completed: {success_count}/{len(folders_to_process)} folders processed successfully"
            )
            return success_count > 0
        except Exception as e:
            logging.error(f"Error in process_all_folders: {e}")
            return False

    def get_processing_summary(self) -> Dict[str, Any]:
        """
        Build a small JSON-summary of the last run:
        - Paths
        - Model availability
        - Normalization toggles
        - Number of generated reports (and last 5 file names)
        """
        summary = {
            "script_name": "S3_ocr_ner",
            "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "input_directory": self.input_dir,
            "output_directory": self.output_dir,
            "transformer_available": TRANSFORMER_NER_AVAILABLE,
            "spacy_available": NER_AVAILABLE,
            "lemmas_enabled": bool(self.use_lemmas and self.nlp_lemma),
            "stemming_enabled": bool(self._stemmer is not None),
            "strict_rut_digits_only": bool(self.strict_rut_digits_only),
        }
        try:
            excel_files = [
                f for f in os.listdir(self.output_dir) if f.startswith("OCR_PII_Analysis_") and f.endswith(".xlsx")
            ]
        except Exception:
            excel_files = []
        summary["excel_reports_generated"] = len(excel_files)
        summary["latest_reports"] = excel_files[-5:] if excel_files else []
        return summary

    def run_flow(self) -> bool:
        """
        Main workflow:
        - Process all folders (images and text files)
        - Save summary JSON
        - Log availability of NER methods
        """
        try:
            logging.info("----- Starting S3: Text Processing and PII Detection -----")
            success = self.process_all_folders()
            if success:
                summary = self.get_processing_summary()
                logging.info("S3 Processing Summary:")
                logging.info(f"  - Excel reports generated: {summary['excel_reports_generated']}")
                logging.info(f"  - Transformer NER available: {summary['transformer_available']}")
                logging.info(f"  - spaCy NER available: {summary['spacy_available']}")
                logging.info(f"  - Lemmas enabled: {summary['lemmas_enabled']} | Stemming enabled: {summary['stemming_enabled']}")
                logging.info(f"  - Strict RUT digits-only: {summary['strict_rut_digits_only']}")
                summary_path = os.path.join(self.process_data_dir, "S3_summary.json")
                save_json_file(summary, summary_path)
                logging.info("S3 completed successfully")
                return True
            else:
                logging.error("S3 failed during text processing and PII detection")
                return False
        except Exception as e:
            logging.error(f"S3 workflow failed: {e}")
            return False


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")
    state = S3_OCRandNER(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")