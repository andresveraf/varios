#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick test to verify adaptive enhancement in worker processes.
"""

import logging
import sys
import os

# Setup logging to see detection messages
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s [%(levelname)-8s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

# Add to path
sys.path.insert(0, r'c:\RPA\repositorio\OPS\OP01_ocr_pii')

from src.utils.fmw_utils import read_config, start_logging
from src.process_scripts.S2_preprocessing_images import S2_ImagePreprocessor

def test_adaptive_enhancement():
    """Test that adaptive enhancement is being used."""
    
    logging.info("=" * 80)
    logging.info("Testing Adaptive Enhancement System")
    logging.info("=" * 80)
    
    # Load config
    config = read_config()
    
    # Create preprocessor
    preprocessor = S2_ImagePreprocessor(config=config)
    
    # Test with a folder
    test_folder = r"c:\RPA\repositorio\OPS\OP01_ocr_pii\input\chile_path"
    
    if os.path.isdir(test_folder):
        logging.info(f"\nTesting enhancement on: {test_folder}")
        result = preprocessor.improve_images_in_folder(test_folder)
        logging.info(f"\nTest result: {result}")
    else:
        logging.warning(f"Test folder not found: {test_folder}")
        # Try another path
        test_folder = r"c:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input"
        if os.path.isdir(test_folder):
            logging.info(f"\nTesting enhancement on: {test_folder}")
            # Find first subfolder with images
            for item in os.listdir(test_folder):
                item_path = os.path.join(test_folder, item)
                if os.path.isdir(item_path):
                    logging.info(f"Testing on subfolder: {item}")
                    result = preprocessor.improve_images_in_folder(item_path)
                    logging.info(f"Test result: {result}")
                    break
    
    logging.info("\n" + "=" * 80)
    logging.info("Test Complete - Check logs above for adaptive enhancement detection")
    logging.info("=" * 80)

if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    test_adaptive_enhancement()
