#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test SurnameFirst_AllCaps pattern in actual detection pipeline
"""
import sys
import os
import logging
import re

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s - %(message)s'
)

from src.utils.pii_utils import PIIPatterns, ExclusionLists, TextProcessingUtils

# Test text
test_text = """
A B C D E F G Rut Agente Sucursal AC Agente Somete Pago Bono Retención 14,50 Pago líquido . ete . Antofagasta RAMIREZ VASQUEZ GUILLERMO 16852649-0 3.678.472 533.378 3.145.094 : Arica JORQUERA GUTIERREZ JIMENA 13949619-1 2.782.218 403.422 2.378.796 ] Calama Villablanca Henriquez Felipe Eduardo 17332365-4 S 724464 S 105.047 S 619.417 ' Concepción KUNCAR HIRMAS CECILIA MARGARITA 7960750-9_ S 2.935.574 425.658 9 2.509.916 . BERTERINI VAZQUEZ MONICA MARCELA 17947250-3 laulaue VEGA TORO MARGARITA CRISTINA 10707417-K 21278 109 AA RIGIS I 1N119791
"""

print("=" * 80)
print("Testing SurnameFirst_AllCaps pattern")
print("=" * 80)

# Check if pattern exists
if "SurnameFirst_AllCaps" not in PIIPatterns.PATTERNS:
    print("❌ ERROR: SurnameFirst_AllCaps pattern NOT FOUND!")
    sys.exit(1)

print("✅ Pattern 'SurnameFirst_AllCaps' exists in PIIPatterns.PATTERNS")

# Get the pattern
pattern = PIIPatterns.PATTERNS["SurnameFirst_AllCaps"]

# Run detection on test text
results = []
for match in pattern.finditer(test_text):
    name_candidate = match.group(1).strip()
    
    # Check exclusions
    is_excluded = ExclusionLists.is_excluded_phrase(name_candidate)
    
    results.append({
        "name": name_candidate,
        "position": f"{match.start(1)}-{match.end(1)}",
        "excluded": is_excluded,
        "word_count": len(name_candidate.split())
    })

print(f"\n✅ Total names detected by pattern: {len(results)}")
print("\n" + "=" * 80)
print("ALL-CAPS NAMES DETECTED:")
print("=" * 80)

for idx, result in enumerate(results, 1):
    status = "❌ EXCLUDED" if result["excluded"] else "✅ VALID"
    print(f"\n{idx}. {result['name']}")
    print(f"   Status: {status}")
    print(f"   Words: {result['word_count']}")
    print(f"   Position: {result['position']}")

# Check specifically for VEGA TORO MARGARITA CRISTINA
print("\n" + "=" * 80)
print("SPECIFIC CHECK: VEGA TORO MARGARITA CRISTINA")
print("=" * 80)

vega_found = any("VEGA TORO MARGARITA CRISTINA" in r["name"] for r in results)
if vega_found:
    print("✅ SUCCESS: 'VEGA TORO MARGARITA CRISTINA' WAS DETECTED!")
    vega_result = [r for r in results if "VEGA TORO MARGARITA CRISTINA" in r["name"]][0]
    print(f"   Excluded: {vega_result['excluded']}")
    print(f"   Words: {vega_result['word_count']}")
    
    if vega_result['excluded']:
        print("   ⚠️  WARNING: Name was detected but EXCLUDED by filters")
    else:
        print("   ✅ Name would appear in final PII output!")
else:
    print("❌ FAILED: 'VEGA TORO MARGARITA CRISTINA' WAS NOT DETECTED")

print("\n" + "=" * 80)
