#!/usr/bin/env python3
"""Test Employee Detection with Fixed Code"""

import os
import sys

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator

def test_employee_detection():
    """Test the fixed employee detection"""
    
    print("=== TESTING FIXED EMPLOYEE DETECTION ===")
    
    # Initialize orchestrator
    orchestrator = S3PIIOrchestrator()
    
    # Load employee database
    employee_names = orchestrator._load_employee_list()
    print(f"Employee database loaded: {len(employee_names)} names")
    
    # Test Carolina cases
    test_cases = [
    "javier alejandro jofré castro",
    "javier alejandro jofre castro",  # without accent
    "javier castro",  # first + last
    "alejandro castro"  # middle + last
    ]
    
    print("\n=== TESTING INDIVIDUAL CASES ===")
    for pii_value in test_cases:
        result = orchestrator._check_if_employee(pii_value, employee_names)
        print(f"'{pii_value}' → Employee: {result}")
    
    print("\n=== TESTING SIMULATED PII ENTITY ===")
    # Simulate a PII entity like the one in your system
    test_entities = [
        {
            "PII_Type": "CUSTOMER_NAME",
            "PII_Value": "Carolina Margarita CCepeda",
            "File_Name": "test_file.pdf",
            "Folder": "test_folder",
            "Source_Type": "OCR",
            "Confidence": 0.8,
            "Detection_Method": "hybrid"
        },
        {
            "PII_Type": "CUSTOMER_NAME", 
            "PII_Value": "Carolina Margarita",
            "File_Name": "test_file.pdf",
            "Folder": "test_folder",
            "Source_Type": "OCR",
            "Confidence": 0.8,
            "Detection_Method": "hybrid"
        }
    ]
    
    # Test the filtering logic
    excluded_count = 0
    for entity in test_entities:
        name_pii_types = {
            "CUSTOMER_NAME", "SpanishName", "ContextualPersonName", 
            "TitledPersonName", "ChileanFullName", "CompoundSpanishName", 
            "PatronymicName", "Name_With_Role"
        }
        
        if entity["PII_Type"] in name_pii_types:
            employee_status = orchestrator._check_if_employee(entity["PII_Value"], employee_names)
            print(f"Entity: '{entity['PII_Value']}' → Employee Status: {employee_status}")
            
            if employee_status == "Yes":
                print(f"  ✅ WOULD BE EXCLUDED from PII report")
                excluded_count += 1
            else:
                print(f"  ❌ WOULD APPEAR in PII report")
    
    print(f"\n=== SUMMARY ===")
    print(f"Total test entities: {len(test_entities)}")
    print(f"Would be excluded: {excluded_count}")
    print(f"Would appear in report: {len(test_entities) - excluded_count}")
    
    if excluded_count == len(test_entities):
        print("✅ SUCCESS: All Carolina entities would be excluded!")
    else:
        print("❌ ISSUE: Some Carolina entities would still appear in report")

if __name__ == "__main__":
    test_employee_detection()