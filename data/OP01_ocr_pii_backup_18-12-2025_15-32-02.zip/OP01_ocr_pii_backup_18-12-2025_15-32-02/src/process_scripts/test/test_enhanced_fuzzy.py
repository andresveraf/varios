#!/usr/bin/env python3
"""Test enhanced fuzzy matching functionality with difflib fallback"""

import sys
import os
import difflib

# Add the src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

try:
    from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator
    
    # Test cases from your examples
    test_cases = [
        ("Andres Morales", ["andres mauricio morales", "andres felipe morales"]),
        ("Andres Morales Orhbremuros", ["andres mauricio morales", "andres felipe morales"]),
        ("Carolina Margarita CCepeda", ["carolina margarita cepeda"]),
        ("Carolina Margarita", ["carolina margarita cepeda"]),
        ("Gabriel Moreau", ["gabriela fernanda moreau"]),
        ("Alvaro Montalva", ["alvaro israel montalva"]),
        ("Celinda Fonseca Fernández", ["celinda ester fonseca"]),
        ("Diego Ignacio Castillo", ["diego ignacio castillo", "diego mauro castillo flores"]),
    ]
    
    print("Enhanced Employee Fuzzy Matching Test Results:")
    print("=" * 60)
    
    # Create orchestrator instance to test the method
    orchestrator = S3PIIOrchestrator()
    
    for pii_value, employee_names_list in test_cases:
        print(f"\nTesting PII: '{pii_value}'")
        print(f"Against employees: {employee_names_list}")
        
        # Convert to set as expected by the method
        employee_names_set = set(employee_names_list)
        
        # Test our enhanced method
        result = orchestrator._check_if_employee(pii_value, employee_names_set)
        
        print(f"Result: {result}")
        
        # Also test with difflib directly for comparison
        pii_normalized = pii_value.strip().lower()
        
        # Test exact match
        exact_match = pii_normalized in employee_names_set
        
        # Test difflib close matches
        close_matches = difflib.get_close_matches(
            pii_normalized, list(employee_names_set), n=3, cutoff=0.75
        )
        
        # Test individual word matching
        pii_words = pii_normalized.split()
        word_matches = []
        for emp_name in employee_names_list:
            emp_words = emp_name.split()
            for pii_word in pii_words:
                for emp_word in emp_words:
                    similarity = difflib.SequenceMatcher(None, pii_word, emp_word).ratio()
                    if similarity >= 0.8:
                        word_matches.append((pii_word, emp_word, f"{similarity:.2%}"))
        
        print(f"  - Exact match: {exact_match}")
        print(f"  - Close matches: {close_matches}")
        print(f"  - Word matches: {word_matches}")
        print("-" * 60)

except ImportError as e:
    print(f"Import error: {e}")
    print("Testing difflib functionality directly...")
    
    # Fallback test with just difflib
    test_pairs = [
        ("andres morales", "andres mauricio morales"),
        ("carolina margarita", "carolina margarita cepeda"),
        ("gabriel moreau", "gabriela fernanda moreau"),
    ]
    
    for pii, emp in test_pairs:
        similarity = difflib.SequenceMatcher(None, pii, emp).ratio()
        close_matches = difflib.get_close_matches(pii, [emp], n=1, cutoff=0.75)
        print(f"'{pii}' vs '{emp}': {similarity:.2%} similarity, close_matches: {close_matches}")

except Exception as e:
    print(f"Error running tests: {e}")
    import traceback
    traceback.print_exc()