#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for comparing different image enhancement methods in S2_preprocessing_images.py

This script:
1. Tests all enhancement methods on sample images
2. Compares quality and performance metrics
3. Generates comparison report with output images
4. Helps identify the best enhancement method for your use case

Run with: python test_enhancement_comparison.py
"""

import os
import sys
import logging
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.utils.fmw_utils import start_logging, read_config, create_folder
from src.process_scripts.test.test_S2_preprocessing_images import S2_ImagePreprocessor


def main():
    """
    Run enhancement comparison tests.
    """
    # Initialize logging
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=True)
    
    # Read configuration
    config = read_config()
    
    # Initialize preprocessor
    preprocessor = S2_ImagePreprocessor(config=config)
    
    logging.info("=" * 80)
    logging.info("S2 IMAGE ENHANCEMENT COMPARISON TEST")
    logging.info("=" * 80)
    
    # Find test images
    input_dir = preprocessor.input_dir
    test_images = []
    
    # Look for images in input directories
    for folder in os.listdir(input_dir):
        folder_path = os.path.join(input_dir, folder)
        if os.path.isdir(folder_path):
            images_path = os.path.join(folder_path, 'images')
            if os.path.isdir(images_path):
                for file in os.listdir(images_path):
                    if file.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
                        full_path = os.path.join(images_path, file)
                        test_images.append(full_path)
                        if len(test_images) >= 1:  # Test with first image found
                            break
        if test_images:
            break
    
    if not test_images:
        logging.warning("No test images found in input directory")
        logging.info("Please ensure images are in: input/<folder>/images/")
        return False
    
    # Run comparison test on first image found
    test_image = test_images[0]
    logging.info(f"\nTesting with image: {test_image}")
    logging.info("-" * 80)
    
    comparison_results = preprocessor.test_enhancement_methods_comparison(test_image)
    
    if comparison_results:
        logging.info("\n" + "=" * 80)
        logging.info("COMPARISON TEST COMPLETED SUCCESSFULLY")
        logging.info("=" * 80)
        logging.info(f"\nResults saved to: {preprocessor.output_dir}/enhancement_comparison/")
        logging.info("\nNext steps:")
        logging.info("1. Review the enhanced images in the output directory")
        logging.info("2. Compare visual quality and clarity")
        logging.info("3. Check processing times")
        logging.info("4. Update improve_images_in_folder() to use best method:")
        logging.info("   - improve_image_quality_basic()  (fastest, moderate quality)")
        logging.info("   - improve_image_quality_test()   (balanced speed/quality)")
        logging.info("   - improve_image_quality_enhanced() (slowest, best quality)")
        return True
    else:
        logging.error("Comparison test failed")
        return False


def test_all_enhancement_methods():
    """
    Alternative test that processes multiple images with each method.
    """
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=True)
    config = read_config()
    preprocessor = S2_ImagePreprocessor(config=config)
    
    logging.info("=" * 80)
    logging.info("TESTING ALL ENHANCEMENT METHODS ON MULTIPLE IMAGES")
    logging.info("=" * 80)
    
    # Test individual methods
    methods = [
        ('basic', 'improve_image_quality_basic', 'Basic (Gaussian blur + unsharp mask)'),
        ('test', 'improve_image_quality_test', 'Test (CLAHE + advanced sharpening)'),
        ('enhanced', 'improve_image_quality_enhanced', 'ULTRA-Enhanced (Morphology + Skew + Gamma + etc.)'),
    ]
    
    # Find a test image
    input_dir = preprocessor.input_dir
    for folder in os.listdir(input_dir):
        folder_path = os.path.join(input_dir, folder)
        if os.path.isdir(folder_path):
            images_path = os.path.join(folder_path, 'images')
            if os.path.isdir(images_path):
                images = [f for f in os.listdir(images_path) 
                         if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff'))]
                if images:
                    test_image = os.path.join(images_path, images[0])
                    
                    logging.info(f"\nTest image: {os.path.basename(test_image)}")
                    logging.info("-" * 80)
                    
                    for method_id, method_name, method_desc in methods:
                        logging.info(f"\n📋 Testing: {method_desc}")
                        method = getattr(preprocessor, method_name)
                        
                        # Make a copy for testing
                        import shutil
                        import tempfile
                        with tempfile.NamedTemporaryFile(suffix=os.path.splitext(test_image)[1], 
                                                        delete=False) as tmp:
                            tmp_path = tmp.name
                        
                        try:
                            shutil.copy(test_image, tmp_path)
                            
                            import datetime as dt
                            start = dt.datetime.now()
                            method(tmp_path)
                            elapsed = (dt.datetime.now() - start).total_seconds()
                            
                            # Copy result to output
                            output_name = f"test_{method_id}_{images[0]}"
                            output_path = os.path.join(preprocessor.output_dir, output_name)
                            shutil.copy(tmp_path, output_path)
                            
                            logging.info(f"✅ {method_desc}")
                            logging.info(f"   Time: {elapsed:.2f}s")
                            logging.info(f"   Output: {output_path}")
                        
                        except Exception as e:
                            logging.error(f"❌ {method_desc} failed: {e}")
                        finally:
                            if os.path.exists(tmp_path):
                                os.remove(tmp_path)
                    
                    return True
    
    logging.warning("No images found for testing")
    return False


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Run main comparison test
    success = main()
    
    # Uncomment to also test individual methods
    # success = test_all_enhancement_methods()
    
    sys.exit(0 if success else 1)
