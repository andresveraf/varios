#!/usr/bin/env python3
"""Test Enhanced Employee Matching with difflib"""

import difflib

def test_difflib_matching():
    """Test the difflib-based matching logic"""
    
    # Test cases from your examples
    test_cases = [
        ("Carolina Margarita CCepeda", "Carolina Margarita"),
        ("Andres Morales Orhbremuros", "Andres Mauricio Morales"),  # OCR error case
        ("Carolina Margarita CCepeda", "Carolina Margarita Cepeda"),  # OCR error
        ("Carolina Margarita", "Carolina Margarita Cepeda"),
        ("Gabriel Moreau", "Gabriela Fernanda Moreau"),  # Gender variation
        ("Alvaro Montalva", "Alvaro Israel Montalva"),
        ("Celinda Fonseca Fernández", "Celinda Ester Fonseca"),
        ("Diego Ignacio Castillo", "DIEGO MAURO CASTILLO FLORES"),
    ]
    
    print("Enhanced Employee Matching Test Results:")
    print("=" * 60)
    
    # Simulate employee database
    employee_names = {
        "Carolina Margarita Cepeda", "andres felipe morales",
        "carolina margarita cepeda", "gabriela fernanda moreau",
        "alvaro israel montalva", "celinda ester fonseca",
        "diego ignacio castillo", "diego mauro castillo flores"
    }
    
    for pii_value, expected_employee in test_cases:
        normalized_pii = pii_value.lower().strip()
        
        print(f"Testing: '{pii_value}'")
        print(f"Expected match: '{expected_employee}'")
        
        # Test 1: Exact match
        exact_match = normalized_pii in employee_names
        print(f"  Exact match: {'YES' if exact_match else 'NO'}")
        
        if not exact_match:
            # Test 2: Difflib close matches
            close_matches = difflib.get_close_matches(
                normalized_pii, list(employee_names), n=3, cutoff=0.7
            )
            
            if close_matches:
                best_match = close_matches[0]
                similarity = difflib.SequenceMatcher(None, normalized_pii, best_match).ratio()
                print(f"  Difflib match: '{best_match}' (score: {similarity:.2%})")
                result = "YES"
            else:
                # Test 3: Enhanced partial matching
                result = test_partial_matching(normalized_pii, employee_names)
                print(f"  Partial matching: {result}")
        else:
            result = "YES"
        
        print(f"  FINAL RESULT: {result}")
        print("-" * 40)

def test_partial_matching(normalized_pii, employee_names):
    """Test the enhanced partial matching logic"""
    import difflib
    
    pii_words = normalized_pii.split()
    common_words = {'de', 'del', 'la', 'las', 'los', 'y', 'e', 'da', 'do', 'dos', 'das', 'von', 'van'}
    
    # Remove common words but keep meaningful parts
    meaningful_pii_words = [word for word in pii_words if word not in common_words and len(word) >= 2]
    
    if len(meaningful_pii_words) >= 2:  # At least 2 meaningful words
        for employee_name in employee_names:
            employee_words = employee_name.split()
            meaningful_employee_words = [word for word in employee_words if word not in common_words and len(word) >= 2]
            
            # Count matches using fuzzy matching for individual words
            matches = 0
            total_pii_words = len(meaningful_pii_words)
            matched_pairs = []
            
            for pii_word in meaningful_pii_words:
                # Use difflib to find similar words
                word_matches = difflib.get_close_matches(pii_word, meaningful_employee_words, n=1, cutoff=0.8)
                if word_matches:
                    matches += 1
                    matched_pairs.append(f"{pii_word}->{word_matches[0]}")
            
            # If most PII words match employee words
            match_percentage = matches / total_pii_words
            if match_percentage >= 0.7:  # 70% of words should match
                print(f"    Match found: '{employee_name}' ({matches}/{total_pii_words} words: {matched_pairs})")
                return "YES"
    
    # Handle single word cases
    elif len(meaningful_pii_words) == 1:
        single_word = meaningful_pii_words[0]
        if len(single_word) >= 3:  # Only meaningful single names
            for employee_name in employee_names:
                employee_words = [word for word in employee_name.split() if len(word) >= 3]
                # Use difflib for single word matching
                word_matches = difflib.get_close_matches(single_word, employee_words, n=1, cutoff=0.85)
                if word_matches:
                    print(f"    Single word match: '{single_word}' -> '{word_matches[0]}' in '{employee_name}'")
                    return "YES"
    
    # Check for first + last name combinations
    if len(pii_words) >= 2:
        first_last_combo = f"{pii_words[0]} {pii_words[-1]}"
        
        # Create first+last combinations from employee names
        for employee_name in employee_names:
            emp_words = employee_name.split()
            if len(emp_words) >= 2:
                emp_first_last = f"{emp_words[0]} {emp_words[-1]}"
                similarity = difflib.SequenceMatcher(None, first_last_combo, emp_first_last).ratio()
                if similarity >= 0.85:  # 85% similarity
                    print(f"    First-last combo: '{first_last_combo}' -> '{emp_first_last}' from '{employee_name}' (score: {similarity:.2%})")
                    return "YES"
    
    return "NO"


import difflib
similarity = difflib.SequenceMatcher(None, "carolina margarita ccepeda", "carolina margarita cepeda").ratio()
print(f"Similarity: {similarity:.3f}")  # Should be around 0.96 (96%)


def test_carolina_specific():
    """Test the specific Carolina case"""
    
    # Simulate your exact scenario
    employee_names = {"carolina margarita cepeda"}  # What should be in your DB
    pii_values = ["Carolina Margarita CCepeda", "Carolina Margarita"]
    
    for pii in pii_values:
        normalized_pii = pii.lower().strip()
        print(f"\nTesting: '{pii}' -> '{normalized_pii}'")
        
        # Test difflib matching
        close_matches = difflib.get_close_matches(
            normalized_pii, list(employee_names), n=3, cutoff=0.75
        )
        
        if close_matches:
            best_match = close_matches[0]
            similarity = difflib.SequenceMatcher(None, normalized_pii, best_match).ratio()
            print(f"Match found: '{best_match}' (score: {similarity:.2%})")
        else:
            print("No match found")

# Run the specific test
test_carolina_specific()



if __name__ == "__main__":
    test_difflib_matching()