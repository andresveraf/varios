#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script to verify logo rendering in email headers.
Tests both URL-based and Base64-based logo implementations.
"""

import sys
import os
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))

from src.process_scripts.S4_pii_orchestrator import EmailTemplateManager
import logging

logging.basicConfig(level=logging.INFO)

def test_logo_rendering():
    """Test that both logo methods render correctly without errors."""
    
    print("\n" + "="*80)
    print("LOGO RENDERING TEST")
    print("="*80 + "\n")
    
    try:
        template_manager = EmailTemplateManager()
        print("[✓] EmailTemplateManager initialized successfully")
        
        # Test 1: URL-based logo header
        print("\n[TEST 1] Testing URL-based logo header (get_email_header_html)...")
        url_header = template_manager.get_email_header_html()
        
        if url_header and "metlife.com" in url_header:
            print("[✓] URL-based logo header contains MetLife URL")
            print(f"    Header length: {len(url_header)} characters")
        else:
            print("[✗] URL-based logo header missing MetLife URL")
            return False
        
        # Test 2: Base64-based logo header
        print("\n[TEST 2] Testing Base64-based logo header (get_email_header_with_logo_base64)...")
        base64_header = template_manager.get_email_header_with_logo_base64()
        
        if base64_header and "data:image/png;base64," in base64_header:
            print("[✓] Base64-based logo header contains Base64 data URI")
            print(f"    Header length: {len(base64_header)} characters")
            
            # Count base64 string length
            import re
            base64_match = re.search(r'base64,([A-Za-z0-9+/=]+)', base64_header)
            if base64_match:
                base64_data = base64_match.group(1)
                print(f"    Base64 data length: {len(base64_data)} characters")
            else:
                print("[!] Warning: Could not extract base64 data")
        else:
            print("[✗] Base64-based logo header missing data URI")
            return False
        
        # Test 3: Verify Base64 data decoding
        print("\n[TEST 3] Verifying Base64 data can be decoded...")
        try:
            base64_match = re.search(r'base64,([A-Za-z0-9+/=]+)', base64_header)
            if base64_match:
                base64_data = base64_match.group(1)
                import base64
                decoded = base64.b64decode(base64_data)
                print(f"[✓] Base64 data decoded successfully ({len(decoded)} bytes)")
                
                # Check PNG signature
                if decoded.startswith(b'\x89PNG'):
                    print("[✓] Decoded data has valid PNG signature")
                else:
                    print("[!] Warning: Decoded data may not be a valid PNG")
            else:
                print("[✗] Could not extract base64 data for decoding")
                return False
        except Exception as e:
            print(f"[✗] Base64 decoding failed: {e}")
            return False
        
        # Test 4: Verify HTML structure
        print("\n[TEST 4] Verifying HTML structure in both headers...")
        
        for header_name, header_html in [
            ("URL-based", url_header),
            ("Base64-based", base64_header)
        ]:
            if "<table" in header_html and "MetLife" in header_html:
                print(f"[✓] {header_name} header has proper table structure with MetLife branding")
            else:
                print(f"[✗] {header_name} header missing required HTML elements")
                return False
        
        print("\n" + "="*80)
        print("ALL TESTS PASSED ✓")
        print("="*80)
        print("\nSummary:")
        print("  • URL-based logo header: Working correctly (uses external URL)")
        print("  • Base64-based logo header: Working correctly (embedded data URI)")
        print("  • Both logos render with proper MetLife branding")
        print("  • Base64 logo is reliably embedded for email clients")
        print("\n")
        
        return True
        
    except Exception as e:
        print(f"\n[✗] Test failed with exception: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_logo_rendering()
    sys.exit(0 if success else 1)
