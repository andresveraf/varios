#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script to verify transformer ensemble integration into S3_pii_orchestrator.py
"""

import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.utils.fmw_utils import read_config

def test_orchestrator_integration():
    """Test that orchestrator correctly loads transformer ensemble"""
    
    print("\n" + "="*70)
    print("TESTING TRANSFORMER INTEGRATION IN ORCHESTRATOR")
    print("="*70 + "\n")
    
    # Load config
    config = read_config()
    
    # Check transformer config
    transformer_config = (
        config.get("TRANSFORMER_CONFIG", {}) or 
        config.get("GLOBAL", {}).get("TRANSFORMER_CONFIG", {})
    )
    print(f"1. TRANSFORMER_CONFIG found: {bool(transformer_config)}")
    print(f"   - enabled: {transformer_config.get('enabled', False)}")
    print(f"   - use_ensemble: {transformer_config.get('use_ensemble', False)}")
    print(f"   - model: {transformer_config.get('model_name', 'N/A')[:50]}...")
    
    # Test orchestrator initialization
    print("\n2. Testing Orchestrator Initialization:")
    try:
        from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator
        orchestrator = S3PIIOrchestrator(config=config)
        print("   ✓ Orchestrator created successfully")
    except Exception as e:
        print(f"   ✗ Failed to create orchestrator: {e}")
        return False
    
    # Test ML detector loading
    print("\n3. Testing ML Detector Loading:")
    try:
        ml_detector = orchestrator._get_ml_detector()
        detector_type = type(ml_detector).__name__
        print(f"   ✓ ML detector loaded: {detector_type}")
        
        # Check which detector was loaded
        if "S2_TransformerPII" in detector_type:
            print("   ✓ Using NEW transformer ensemble (S2_TransformerPII)")
            print("\n4. Checking Transformer Ensemble Features:")
            
            # Check if ensemble is loaded
            if hasattr(ml_detector, 'ensemble'):
                print(f"   ✓ Ensemble loaded: {ml_detector.ensemble is not None}")
                if ml_detector.ensemble:
                    stats = ml_detector.ensemble.get_stats()
                    print(f"   - Models loaded: {stats.get('models_loaded', 'N/A')}")
                    print(f"   - Device: {stats.get('device', 'N/A')}")
                    print(f"   - Cache enabled: {stats.get('cache_enabled', False)}")
            else:
                print("   ⚠ Ensemble attribute not found")
                
        elif "S3_MachineLearningNER" in detector_type:
            print("   ℹ Using LEGACY spaCy-based detector (S3_MachineLearningNER)")
            print("   ℹ To enable transformers, set TRANSFORMER_CONFIG.enabled = true")
        else:
            print(f"   ⚠ Unknown detector type: {detector_type}")
            
    except Exception as e:
        print(f"   ✗ Failed to load ML detector: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Test regex detector (should still work)
    print("\n5. Testing Regex Detector (backward compatibility):")
    try:
        regex_detector = orchestrator._get_regex_detector()
        print(f"   ✓ Regex detector loaded: {type(regex_detector).__name__}")
    except Exception as e:
        print(f"   ✗ Failed to load regex detector: {e}")
        return False
    
    # Summary
    print("\n" + "="*70)
    print("INTEGRATION TEST RESULTS")
    print("="*70)
    
    if transformer_config.get('enabled', False):
        if "S2_TransformerPII" in detector_type:
            print("✅ SUCCESS: Transformer ensemble is ACTIVE in orchestrator")
            print("   The system will use Spanish-optimized NER models with ensemble voting")
        else:
            print("⚠️  WARNING: Transformers enabled but spaCy loaded instead")
            print("   Check import errors or model availability")
    else:
        print("ℹ️  INFO: Transformers NOT enabled in config.jsonc")
        print("   Using legacy spaCy detector (S3_MachineLearningNER)")
        print("   To enable: Set TRANSFORMER_CONFIG.enabled = true in config.jsonc")
    
    print("\n" + "="*70 + "\n")
    return True


if __name__ == "__main__":
    test_orchestrator_integration()
