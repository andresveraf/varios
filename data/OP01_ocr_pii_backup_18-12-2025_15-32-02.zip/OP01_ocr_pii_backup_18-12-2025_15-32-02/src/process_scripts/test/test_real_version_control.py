#!/usr/bin/env python3
"""
Test script for the updated version control extraction functionality
"""

import sys
import os
import pandas as pd

# Add the src directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator

def test_version_control_with_real_data():
    """Test the version control extraction functionality with real file structure"""
    
    # Create orchestrator instance with debug mode
    config = {
        "ENVIRONMENT": {
            "DEBUG_MODE": True
        },
        "paths": {
            "input": "input",
            "output": "output",
            "process_data": "process_data"
        }
    }
    
    orchestrator = S3PIIOrchestrator(config)
    
    # Set the metadata path manually for testing
    metadata_path = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output\_others\files_metadata.xlsx"
    orchestrator.files_metadata_path = metadata_path
    
    print("=== TESTING VERSION CONTROL WITH REAL DATA ===")
    print(f"Metadata path: {metadata_path}")
    
    # Test the updated method
    print("\n=== UPDATING METADATA WITH VERSION CONTROL ===")
    orchestrator.update_metadata_with_version_control()
    
    # Check if the update worked
    print("\n=== CHECKING RESULTS ===")
    if os.path.exists(metadata_path):
        df = pd.read_excel(metadata_path)
        if 'Control de version' in df.columns:
            print("✅ 'Control de version' column exists!")
            print("Version control values found:")
            for idx, row in df.iterrows():
                filename = row.get('original_filename', 'Unknown')
                version = row.get('Control de version', 'None')
                print(f"  - {filename}: {version}")
        else:
            print("❌ 'Control de version' column not found")
    else:
        print("❌ Metadata file not found")

if __name__ == "__main__":
    test_version_control_with_real_data()