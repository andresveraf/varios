#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick test for SurnameFirst_AllCaps pattern
"""
import re

# Test the pattern - STRICT (no IGNORECASE, only UNICODE)
pattern = re.compile(
    r"(?<!\w)"
    r"("  # Capture group for the full name
    r"(?:[A-ZÁÉÍÓÚÑÜ]{3,}\s+){1,3}"   # 1-3 ALL-CAPS words, each 3+ chars (surnames)
    r"[A-ZÁÉÍÓÚÑÜ]{3,}"               # Final ALL-CAPS word 3+ chars (last name/surname)
    r")"
    r"(?!\w)",
    re.UNICODE  # No IGNORECASE - must be truly uppercase
)

test_text = """
A B C D E F G Rut Agente Sucursal AC Agente Somete Pago Bono Retención 14,50 Pago líquido . ete . Antofagasta RAMIREZ VASQUEZ GUILLERMO 16852649-0 3.678.472 533.378 3.145.094 : Arica JORQUERA GUTIERREZ JIMENA 13949619-1 2.782.218 403.422 2.378.796 ] Calama Villablanca Henriquez Felipe Eduardo 17332365-4 S 724464 S 105.047 S 619.417 ' Concepción KUNCAR HIRMAS CECILIA MARGARITA 7960750-9_ S 2.935.574 425.658 9 2.509.916 . BERTERINI VAZQUEZ MONICA MARCELA 17947250-3 laulaue VEGA TORO MARGARITA CRISTINA 10707417-K 21278 109 AA RIGIS I 1N119791
"""

print("Testing SurnameFirst_AllCaps pattern:\n")
print("=" * 80)

matches = pattern.finditer(test_text)
for match in matches:
    full_match = match.group(0).strip()
    captured = match.group(1).strip() if len(match.groups()) > 0 else full_match
    print(f"Found: '{captured}'")
    print(f"  Position: {match.start()}-{match.end()}")
    print(f"  Context: ...{test_text[max(0, match.start()-20):match.end()+20]}...")
    print()

print("=" * 80)
print("\nSpecific test for 'VEGA TORO MARGARITA CRISTINA':")
if "VEGA TORO MARGARITA CRISTINA" in test_text:
    match = pattern.search("VEGA TORO MARGARITA CRISTINA")
    if match:
        print(f"✓ PATTERN MATCHES: '{match.group(1).strip()}'")
    else:
        print("✗ PATTERN DOES NOT MATCH")
else:
    print("✗ Text not found in test string")
