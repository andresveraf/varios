"""
Test transformer-based PII detection with real Chilean text
"""
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent))

from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator
from src.utils.fmw_utils import read_config

def test_detection():
    """Test transformer detection on real Chilean names"""
    
    print("=" * 70)
    print("TESTING TRANSFORMER-BASED PII DETECTION")
    print("=" * 70)
    
    # Load config
    config = read_config()
    
    # Create orchestrator (will use transformers if enabled)
    orchestrator = S3PIIOrchestrator(config=config)
    
    # Test texts with Chilean names
    test_cases = [
        {
            "text": "El empleado Juan Carlos Pérez González trabaja en Santiago.",
            "expected": ["Juan Carlos Pérez González"]
        },
        {
            "text": "María de los Ángeles Ramírez Vega es la gerente del departamento.",
            "expected": ["María de los Ángeles Ramírez Vega"]
        },
        {
            "text": "Contact: jose.martinez@company.cl, phone +56 9 8765 4321",
            "expected": ["jose.martinez@company.cl", "+56 9 8765 4321"]
        },
        {
            "text": "RUT: 12.345.678-9 belongs to Pedro Silva",
            "expected": ["12.345.678-9", "Pedro Silva"]
        }
    ]
    
    print("\n1. Testing Individual Detections:\n")
    
    for i, case in enumerate(test_cases, 1):
        text = case["text"]
        expected = case["expected"]
        
        print(f"\nTest {i}: {text}")
        print(f"Expected: {expected}")
        
        # Detect PII
        results = orchestrator.detect_pii(text)
        
        # Extract detected values
        detected = []
        for entity_type, entities in results.items():
            if entity_type == "metadata":
                continue
            for entity in entities:
                detected.append(entity.get("text", ""))
        
        print(f"Detected: {detected}")
        print(f"✓ SUCCESS" if len(detected) > 0 else "✗ FAILED - No detections")
    
    # Test metadata
    print("\n" + "=" * 70)
    print("2. Testing Detection Metadata:\n")
    
    test_text = "María González trabaja con Pedro Silva en Santiago."
    results = orchestrator.detect_pii(test_text)
    
    print(f"Text: {test_text}")
    print(f"\nDetection Results:")
    for entity_type, entities in results.items():
        if entity_type == "metadata":
            print(f"\nMetadata:")
            for key, value in entities.items():
                print(f"  {key}: {value}")
        else:
            print(f"\n{entity_type} ({len(entities)} detected):")
            for entity in entities[:3]:  # Show first 3
                print(f"  - {entity.get('text', '')} (confidence: {entity.get('confidence', 0):.2f}, source: {entity.get('source', '')})")
    
    print("\n" + "=" * 70)
    print("✅ TRANSFORMER DETECTION TEST COMPLETE")
    print("=" * 70)

if __name__ == "__main__":
    test_detection()
