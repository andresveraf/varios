#!/usr/bin/env python3
"""
Test script for version control extraction functionality
"""

import sys
import os

# Add the src directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator

def test_version_control_extraction():
    """Test the version control extraction functionality"""
    
    # Create orchestrator instance
    config = {
        "ENVIRONMENT": {
            "DEBUG_MODE": True
        },
        "paths": {
            "input": "input",
            "output": "output",
            "process_data": "process_data"
        }
    }
    
    orchestrator = S3PIIOrchestrator(config)
    
    # Test version control extraction from sample file
    test_file = os.path.join("process_data", "sample_document.txt")
    
    print(f"Testing version control extraction from: {test_file}")
    
    if not os.path.exists(test_file):
        print(f"Test file not found: {test_file}")
        return False
    
    # Extract version control info
    version_info = orchestrator.extract_version_control_info(test_file)
    
    if version_info:
        print("✅ Version control extraction successful!")
        print(f"Version: {version_info['version']}")
        print(f"User: {version_info['user']}")
        print(f"Date: {version_info['date']}")
        print(f"Formatted Date: {version_info['formatted_date']}")
        print(f"Observations: {version_info['observations']}")
        return True
    else:
        print("❌ Version control extraction failed")
        return False

if __name__ == "__main__":
    test_version_control_extraction()