#!/usr/bin/env python3
"""
Test the fixed version control mapping
"""

import sys
import os
import pandas as pd

# Add the src directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from process_scripts.S4_pii_orchestrator import S3PIIOrchestrator

def test_version_control_mapping():
    """Test the version control mapping with debug output"""
    
    # Create orchestrator instance with debug mode
    config = {
        "ENVIRONMENT": {
            "DEBUG_MODE": True
        }
    }
    
    orchestrator = S3PIIOrchestrator(config)
    
    # Set the metadata path
    metadata_path = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output\_others\files_metadata.xlsx"
    orchestrator.files_metadata_path = metadata_path
    
    # Create a sample DataFrame like the PII data
    sample_pii_data = pd.DataFrame({
        'Folder': [
            'Brasil - Procedimiento Convenios Dentales (Dental Digital) - 2024',
            'Chile - 2. SOP Emision-Creacion Poliza RV'
        ],
        'PII_Type': ['CUSTOMER_NAME', 'CUSTOMER_NAME'],
        'PII_Value': ['Test Name 1', 'Test Name 2']
    })
    
    print("=== TESTING VERSION CONTROL MAPPING ===")
    print(f"Sample PII data:")
    print(sample_pii_data)
    
    # Test the mapping
    result_df = orchestrator._add_version_control_from_metadata(sample_pii_data)
    
    print(f"\n=== RESULT ===")
    print(f"Result DataFrame:")
    print(result_df)
    
    if 'Control de version' in result_df.columns:
        print(f"\n✅ Version control values:")
        for idx, row in result_df.iterrows():
            folder = row['Folder']
            version = row['Control de version']
            print(f"  - {folder}: {version}")
    else:
        print(f"\n❌ Version control column not found")

if __name__ == "__main__":
    test_version_control_mapping()