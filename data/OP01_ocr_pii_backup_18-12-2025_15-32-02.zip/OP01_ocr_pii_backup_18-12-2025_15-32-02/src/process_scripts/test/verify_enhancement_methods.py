#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick verification that all new enhancement methods were added correctly.
"""

import inspect
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.process_scripts.test.test_S2_preprocessing_images import S2_ImagePreprocessor

def verify_methods():
    """Check that all new methods exist and are callable."""
    
    print("=" * 70)
    print("VERIFICATION: S2 Image Enhancement Methods")
    print("=" * 70)
    
    # We can't initialize preprocessor without config, so just check the class
    # For a more complete test, see test_enhancement_comparison.py
    
    # Import to verify no syntax errors
    try:
        from src.utils.fmw_utils import read_config
        config = read_config()
        preprocessor = S2_ImagePreprocessor(config=config)
    except Exception as e:
        print(f"\n⚠️  Note: Could not initialize preprocessor with config: {e}")
        print("   (This is normal in testing - methods still exist in the class)")
        preprocessor = None
    
    # Check new methods exist
    new_methods = [
        '_enhance_with_morphology',
        '_correct_skew',
        '_enhance_blur_removal',
        '_apply_gamma_correction',
        'improve_image_quality_enhanced',
        'test_enhancement_methods_comparison'
    ]
    
    print("\n✅ CHECKING NEW METHODS:")
    print("-" * 70)
    
    all_exist = True
    for method_name in new_methods:
        if hasattr(S2_ImagePreprocessor, method_name):
            method = getattr(S2_ImagePreprocessor, method_name)
            if callable(method):
                # Get docstring
                doc = inspect.getdoc(method)
                first_line = doc.split('\n')[0] if doc else "No documentation"
                print(f"✓ {method_name:<45} {first_line[:20]}...")
            else:
                print(f"✗ {method_name:<45} NOT CALLABLE")
                all_exist = False
        else:
            print(f"✗ {method_name:<45} NOT FOUND")
            all_exist = False
    
    print("\n✅ CHECKING EXISTING METHODS (should still work):")
    print("-" * 70)
    
    existing_methods = [
        'improve_image_quality_basic',
        'improve_image_quality_test',
        'improve_image_quality',
        'improve_images_in_folder',
        'process_all_folders'
    ]
    
    for method_name in existing_methods:
        if hasattr(S2_ImagePreprocessor, method_name):
            method = getattr(S2_ImagePreprocessor, method_name)
            if callable(method):
                print(f"✓ {method_name:<45} OK")
            else:
                print(f"✗ {method_name:<45} NOT CALLABLE")
                all_exist = False
        else:
            print(f"✗ {method_name:<45} NOT FOUND")
            all_exist = False
    
    print("\n✅ CHECKING DOCUMENTATION FILES:")
    print("-" * 70)
    
    doc_files = [
        'ENHANCEMENT_METHODS_GUIDE.md',
        'ENHANCEMENT_METHODS_SUMMARY.md',
        'test_enhancement_comparison.py'
    ]
    
    for file_name in doc_files:
        file_path = os.path.join(os.path.dirname(__file__), file_name)
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            print(f"✓ {file_name:<45} ({size:,} bytes)")
        else:
            print(f"✗ {file_name:<45} NOT FOUND")
            all_exist = False
    
    print("\n" + "=" * 70)
    
    if all_exist:
        print("✅ ALL VERIFICATIONS PASSED!")
        print("\nNext steps:")
        print("1. Run: python test_enhancement_comparison.py")
        print("2. Check output in: output/enhancement_comparison/")
        print("3. Read: ENHANCEMENT_METHODS_GUIDE.md")
        return True
    else:
        print("❌ VERIFICATION FAILED - Some methods are missing!")
        return False
    
    print("=" * 70)


if __name__ == "__main__":
    success = verify_methods()
    sys.exit(0 if success else 1)
