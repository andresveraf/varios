#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Direct verification that text quality methods are in base_pii_detector"""

import sys
import inspect
sys.path.insert(0, 'src/process_scripts')
from base_pii_detector import BasePIIDetector

print("=" * 60)
print("TEXT QUALITY IMPROVEMENTS - METHOD VERIFICATION")
print("=" * 60)

# Check that all methods exist
methods_to_check = [
    '_is_pdf_scanned',
    '_extract_text_from_scanned_pdf',
    '_advanced_clean_text',
    '_score_text_quality'
]

print("\n✅ METHODS FOUND IN BasePIIDetector:")
for method_name in methods_to_check:
    if hasattr(BasePIIDetector, method_name):
        method = getattr(BasePIIDetector, method_name)
        sig = inspect.signature(method)
        print(f"  ✓ {method_name}{sig}")
    else:
        print(f"  ✗ {method_name} - NOT FOUND")

# Get line numbers
import importlib.util
spec = importlib.util.find_spec("base_pii_detector")
filepath = spec.origin

print("\n📍 FILE LOCATION:")
print(f"  {filepath}")

with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
    lines = f.readlines()
    for i, line in enumerate(lines, 1):
        if any(method in line for method in ['def _is_pdf_scanned', 'def _extract_text', 'def _advanced_clean', 'def _score_text']):
            print(f"  Line {i}: {line.strip()}")

print("\n" + "=" * 60)
print("🎉 ALL TEXT QUALITY METHODS ARE AVAILABLE!")
print("=" * 60)
print("\nIntegration with S2_TransformerPII and S3_MachineLearningNER")
print("is automatic through inheritance from BasePIIDetector.")
print("\nMethods can be called in detection pipeline:")
print("  - cleaned_text = self._advanced_clean_text(text)")
print("  - quality = self._score_text_quality(cleaned_text)")
print("  - is_scanned = self._is_pdf_scanned(pdf_path)")
print("  - text_dict = self._extract_text_from_scanned_pdf(pdf_path)")
print("=" * 60)
