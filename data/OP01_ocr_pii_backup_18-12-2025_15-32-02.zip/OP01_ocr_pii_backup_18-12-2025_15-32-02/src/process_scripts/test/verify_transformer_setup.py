#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick test to verify transformer ensemble setup
"""

import logging
import json

logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s - %(message)s'
)

print("=" * 80)
print("TRANSFORMER ENSEMBLE SETUP VERIFICATION")
print("=" * 80)

# 1. Check config
print("\n1. Checking config.jsonc...")
try:
    with open('config.jsonc', 'r', encoding='utf-8') as f:
        content = '\n'.join(line.split('//')[0] for line in f.readlines())
        config = json.loads(content)
    
    transformer_config = config.get("GLOBAL", {}).get("TRANSFORMER_CONFIG", {})
    
    if transformer_config:
        print("   ✓ TRANSFORMER_CONFIG found in config.jsonc")
        print(f"   - Enabled: {transformer_config.get('enabled', False)}")
        print(f"   - Primary model: {transformer_config.get('model_name', 'N/A')}")
        print(f"   - Use ensemble: {transformer_config.get('use_ensemble', False)}")
        print(f"   - Caching: {transformer_config.get('enable_caching', False)}")
    else:
        print("   ✗ TRANSFORMER_CONFIG not found in config.jsonc")
except Exception as e:
    print(f"   ✗ Error reading config: {e}")

# 2. Check transformer_ensemble.py
print("\n2. Checking transformer_ensemble.py module...")
try:
    from src.utils.transformer_ensemble import TransformerEnsemble, TransformerCache
    print("   ✓ transformer_ensemble.py module found")
    print("   ✓ TransformerEnsemble class available")
    print("   ✓ TransformerCache class available")
except Exception as e:
    print(f"   ✗ Error importing: {e}")

# 3. Check S2_transformer_pii.py
print("\n3. Checking S2_transformer_pii.py...")
try:
    from process_scripts.S3_transformer_pii import S2_TransformerPII
    print("   ✓ S2_transformer_pii.py module found")
    print("   ✓ S2_TransformerPII class available")
except Exception as e:
    print(f"   ✗ Error importing: {e}")

# 4. Check transformers library
print("\n4. Checking transformers library...")
try:
    import transformers
    import torch
    print(f"   ✓ transformers {transformers.__version__} installed")
    print(f"   ✓ torch {torch.__version__} installed")
    print(f"   - CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"   - GPU: {torch.cuda.get_device_name(0)}")
except ImportError as e:
    print(f"   ✗ Missing library: {e}")
    print("   → Run: pip install transformers torch")

print("\n" + "=" * 80)
print("SETUP SUMMARY")
print("=" * 80)
print("""
✓ Config updated with TRANSFORMER_CONFIG
✓ TransformerEnsemble class created with:
  - Multi-model ensemble voting
  - Spanish-optimized primary model
  - Caching for performance
  - Weighted predictions

✓ S2_TransformerPII detector created with:
  - Ensemble integration
  - Entity validation
  - Batch processing support
  
MODELS CONFIGURED:
  1. Primary: PlanTL-GOB-ES/roberta-base-bne-capitel-ner-plus (Spanish)
  2. Secondary: Davlan/xlm-roberta-base-ner-hrl (Multilingual)
  3. Tertiary: dslim/bert-base-NER-uncased (English fallback)

NEXT STEPS:
  1. Test with: py src/process_scripts/S2_transformer_pii.py
  2. Models will download on first run (~500MB total)
  3. Subsequent runs will use cached models
  4. Check cache stats in logs
""")
print("=" * 80)
