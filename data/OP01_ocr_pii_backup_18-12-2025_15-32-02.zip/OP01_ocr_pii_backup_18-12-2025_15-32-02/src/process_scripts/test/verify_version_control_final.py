#!/usr/bin/env python3
"""
Verification script to check version control data in final Excel reports
"""

import pandas as pd
import os

def check_version_control_in_excel():
    """Check if version control data appears correctly in Excel reports"""
    
    # Find the most recent Excel reports
    output_dir = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\output"
    
    # Check main PII analysis report
    pii_files = [f for f in os.listdir(output_dir) if f.startswith("OCR_PII_Analysis_HYBRID_") and f.endswith(".xlsx")]
    if pii_files:
        pii_files.sort(reverse=True)  # Most recent first
        latest_pii_file = os.path.join(output_dir, pii_files[0])
        
        print(f"🔍 Checking main PII report: {pii_files[0]}")
        
        try:
            # Read all sheets
            excel_data = pd.read_excel(latest_pii_file, sheet_name=None)
            
            for sheet_name, df in excel_data.items():
                print(f"\n📋 Sheet: {sheet_name}")
                
                if 'Control de version' in df.columns:
                    print(f"   ✅ 'Control de version' column found!")
                    
                    # Check for actual data
                    version_data = df['Control de version'].dropna()
                    if len(version_data) > 0:
                        print(f"   ✅ Version control data found: {len(version_data)} entries")
                        print(f"   📊 Sample values: {list(version_data.unique())}")
                    else:
                        print(f"   ⚠️  'Control de version' column exists but is empty")
                        
                    # Check if there are files from Brasil (should have "07-2025")
                    if 'Folder' in df.columns:
                        brasil_files = df[df['Folder'].str.contains('Brasil', na=False)]
                        if len(brasil_files) > 0:
                            brasil_versions = brasil_files['Control de version'].dropna()
                            print(f"   🇧🇷 Brasil files version control: {list(brasil_versions.unique())}")
                            
                        chile_files = df[df['Folder'].str.contains('Chile', na=False)]
                        if len(chile_files) > 0:
                            chile_versions = chile_files['Control de version'].dropna()
                            print(f"   🇨🇱 Chile files version control: {list(chile_versions.unique())}")
                else:
                    print(f"   ❌ 'Control de version' column NOT found")
                    print(f"   📊 Available columns: {list(df.columns)}")
                    
        except Exception as e:
            print(f"❌ Error reading Excel file: {e}")
    
    # Check summary reports
    summary_files = [f for f in os.listdir(output_dir) if f.startswith("Resumen_Archivos_PII_") and f.endswith(".xlsx")]
    if summary_files:
        summary_files.sort(reverse=True)  # Most recent first
        latest_summary_file = os.path.join(output_dir, summary_files[0])
        
        print(f"\n🔍 Checking summary report: {summary_files[0]}")
        
        try:
            # Read all sheets
            excel_data = pd.read_excel(latest_summary_file, sheet_name=None)
            
            for sheet_name, df in excel_data.items():
                print(f"\n📋 Sheet: {sheet_name}")
                
                if 'Control de version' in df.columns:
                    print(f"   ✅ 'Control de version' column found!")
                    
                    # Check for actual data
                    version_data = df['Control de version'].dropna()
                    if len(version_data) > 0:
                        print(f"   ✅ Version control data found: {len(version_data)} entries")
                        print(f"   📊 Sample values: {list(version_data.unique())}")
                    else:
                        print(f"   ⚠️  'Control de version' column exists but is empty")
                        
                else:
                    print(f"   ❌ 'Control de version' column NOT found")
                    
        except Exception as e:
            print(f"❌ Error reading summary Excel file: {e}")

if __name__ == "__main__":
    print("=" * 60)
    print("🔍 FINAL VERSION CONTROL VERIFICATION")
    print("=" * 60)
    
    check_version_control_in_excel()
    
    print("\n" + "=" * 60)
    print("✅ Verification complete!")
    print("=" * 60)