#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Encrypted credentials handling utilities template
Compatible with Python 3.13.4
file_name: credentials_utils.py
"""

import os
import sys
import logging
import datetime as dt
import pandas as pd
from cryptography.fernet import Fernet
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 


class Credentials:
    """
    Class to initiate encripted credentials
    cred_config_name: Name of item in config that indicates column in credentials excel, must be in env config level
    Initiates credentials, if you want to call it use the object.creds that returns the decripted value
    For config the followin prarmeter is necessery in config_env level:
    "CRED_EXCEL": "C:\\Users\\UserName\\MetLife\\Acelerar Transformación - OPS - Documentos\\Metlife\\credenciales\\credenciales_bots.xlsx",
    """
    def __init__(self, config:dict, cred_config_name:str):
        self.state_name    = "Workflow"  # Change with the class name      
        self.config        = config
        self.environment   = self.config["METADATA"]["ENVIRONMENT"].upper()
        self.config_env    = self.config[self.environment]
        # Get class parameters from config
        self.cred_excel_path = self.config_env["CREDENTIALS_FILE_PATH"]
        self.cred_name       = self.config_env[cred_config_name]
        self.inti_desiered_credentials()
    
    def decrypt_msg(self, encrypted_msg:str, key:str) -> str:
        fernet        = Fernet(key)
        decrypted_msg = fernet.decrypt(encrypted_msg).decode()
        return decrypted_msg

    def inti_desiered_credentials(self):
        logging.info(f"--- Reading credentials for {self.cred_name} ---")
        # Run script after this
        if os.path.exists(self.cred_excel_path):
            cred_excel = pd.read_excel(self.cred_excel_path, sheet_name="base")
            cred_excel.set_index(keys="Parameter", drop=True, inplace=True)
            #print(f"credenciales: {cred_excel}") ##Para mostrar las credenciales por consola
            try:
                if self.cred_name in cred_excel.index: 
                    logging.info(f"Found credentials for {self.cred_name}")
                    self.desiered_creds_dict = {
                        "USER": cred_excel["User"][self.cred_name],
                        "KEY": cred_excel["Key"][self.cred_name],
                        "ENCRYPTED_STRING": cred_excel["Encrypted string"][self.cred_name]
                    }
                    self.creds = self.decrypt_msg(encrypted_msg=self.desiered_creds_dict["ENCRYPTED_STRING"], key=self.desiered_creds_dict["KEY"])
                    logging.info("Succesfully aquiered credentials")
                else: 
                    logging.warning(f"Credentials named: '{self.cred_name}' could not be found on credentials file")
            except Exception as e:
                logging.info(f"{e}")
        else:
            raise Exception(f"Credentials excel could not be found on path: {self.cred_excel_path}")
