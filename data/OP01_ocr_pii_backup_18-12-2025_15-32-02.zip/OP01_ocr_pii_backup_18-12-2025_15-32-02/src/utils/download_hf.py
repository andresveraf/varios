from huggingface_hub import snapshot_download
import os

# Models to download
models = [
    "samuelalvarez034/PlanTL-GOB-ES-roberta-base-bne-ner", #Download complete!
    "dslim/bert-base-NER" # downloaded
]

# Base directory
base_dir = r"C:\RPA\repositorio\OPS\OP01_ocr_pii\models"
os.makedirs(base_dir, exist_ok=True)

for model in models:
    print(f"\n{'='*60}")
    print(f"Downloading: {model}")
    print(f"{'='*60}")
    
    try:
        local_path = snapshot_download(
            repo_id=model,
            cache_dir=base_dir,
            resume_download=True,
            force_download=False
        )
        print(f"✓ Downloaded to: {local_path}")
    except Exception as e:
        print(f"✗ Error downloading {model}: {e}")

print(f"\n{'='*60}")
print("Download complete!")
print(f"{'='*60}")