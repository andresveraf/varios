#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Excel file manipulation utilities template
Compatible with Python 3.13.4
created_on:  2025-07-23 ; matias.aravena
modified_on: 2025-07-23 ; matias.aravena
"""

import os
import sys
import time
import logging
import datetime as dt
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 

import xlwings as xw
import pandas as pd
from xlwings import constants

"""
notas_fmw.py - Utilidades para Excel con xlwings
===============================================

Módulo de utilidades para automatización y manipulación de archivos Excel
usando xlwings y pandas. Incluye funciones para manejo de datos, formato,
tablas dinámicas, capturas de pantalla y más.

FUNCIONES DISPONIBLES (15 total):
=================================

📊 MANIPULACIÓN DE DATOS:
  • convert_columns_to_numeric()     - Convierte columnas de texto a formato numérico
  • create_dataframe_from_excel()    - Crea DataFrame desde Excel con rango dinámico
  • get_cell_value()                 - Obtiene valor de una celda específica
  • paste_dataframe_to_sheet()       - Pega DataFrame en hoja Excel
  • copy_formula_down()              - Copia fórmulas a un rango

🔧 TABLAS DINÁMICAS:
  • create_pivot_table()             - Crea tablas dinámicas
  • filter_pivot_table()             - Filtra elementos en tablas dinámicas
  • update_pivot_table_source_data() - Actualiza fuente de datos de tablas dinámicas

🎨 FORMATO Y VISUALIZACIÓN:
  • colored_cell_by_text()           - Colorea celdas por texto específico
  • merge_cells()                    - Combina celdas y centra texto
  • apply_number_format()            - Aplica formato numérico a rangos

📸 CAPTURAS DE PANTALLA:
  • take_range_screenshot()          - Toma captura de pantalla de un rango
  • take_multiple_range_screenshots() - Captura múltiples rangos

📝 UTILIDADES GENERALES:
  • insert_column_at_range()         - Inserta columna en posición específica
  • clear_range()                    - Limpia contenido de rangos

DEPENDENCIAS:
=============
- xlwings
- pandas
- os, datetime (para algunas funciones)

AUTOR: Aravena, Matias
FECHA: 09/07/2025
VERSIÓN: 1.0
"""


def convert_columns_to_numeric(workbook: xw.Book, sheet_name: str, reference_column: str, target_columns: list) -> None:
    """
    Convert specified columns from text to numeric format in an Excel worksheet.
    
    Args:
        workbook (xw.Book): The xlwings workbook object
        sheet_name (str): Name of the worksheet to modify
        reference_column (str): Column letter to determine the last row with data
        target_columns (list): List of column letters to convert to numeric format
        
    Raises:
        ValueError: If sheet_name doesn't exist in the workbook
        AttributeError: If reference_column or target_columns are invalid
    """
    try:
        worksheet = workbook.sheets[sheet_name]
    except KeyError:
        raise ValueError(f"Sheet '{sheet_name}' not found in workbook")
    
    # Find last row with data using the reference column
    last_row = worksheet.range(f'{reference_column}{worksheet.cells.last_cell.row}').end('up').row
    
    # Convert each specified column to numeric format
    for column_letter in target_columns:
        if not isinstance(column_letter, str) or not column_letter.isalpha():
            raise AttributeError(f"Invalid column letter: {column_letter}")
            
        column_range = worksheet.range(f'{column_letter}2:{column_letter}{last_row}')
        column_range.api.TextToColumns(
            Destination=column_range.api,
            DataType=1  # xlDelimited
        )
    return 0

def create_dataframe_from_excel(file_path: str, sheet_name: str, reference_column: str, start_column: str, end_column: str, visible: bool = False) -> pd.DataFrame:
    """
    Create a DataFrame from an Excel sheet with dynamic range.
    
    Args:
        file_path (str): Path to the Excel file
        sheet_name (str): Name of the worksheet to read from
        reference_column (str): Column letter to determine the last row with data
        start_column (str): Starting column letter for the range
        end_column (str): Ending column letter for the range
        visible (bool): Whether to make Excel visible during operation
        
    Returns:
        pd.DataFrame: DataFrame containing the data from the specified range
        
    Raises:
        FileNotFoundError: If the Excel file doesn't exist
        ValueError: If sheet_name doesn't exist in the workbook
    """
    app = xw.App(visible=visible)
    try:
        book = app.books.open(file_path, update_links=False)
        sheet = book.sheets(sheet_name)
        last_row = sheet.range(reference_column + str(sheet.cells.last_cell.row)).end('up').row
        df = sheet.range(f'{start_column}2:{end_column}{last_row}').options(pd.DataFrame, header=1, index=False).value
        return df
    except Exception as e:
        raise e
    finally:
        book.close()
        app.quit()

def get_cell_value(file_path: str, sheet_name: str, cell_reference: str, visible: bool = False) -> any:
    """
    Get the value from a specific cell in an Excel worksheet.
    
    Args:
        file_path (str): Path to the Excel file
        sheet_name (str): Name of the worksheet to read from
        cell_reference (str): Cell reference (e.g., 'A3', 'B10', 'C1')
        visible (bool): Whether to make Excel visible during operation
        
    Returns:
        any: The value from the specified cell
        
    Raises:
        FileNotFoundError: If the Excel file doesn't exist
        ValueError: If sheet_name doesn't exist in the workbook
        AttributeError: If cell_reference is invalid
    """
    app = xw.App(visible=visible)
    try:
        book = app.books.open(file_path, update_links=False)
        sheet = book.sheets(sheet_name)
        
        if not isinstance(cell_reference, str):
            raise AttributeError(f"Invalid cell reference: {cell_reference}")
        
        cell_value = sheet.range(cell_reference).value
        
        return cell_value
    except KeyError:
        raise ValueError(f"Sheet '{sheet_name}' not found in workbook")
    except Exception as e:
        raise e
    finally:
        book.close()
        app.quit()

def create_pivot_table(file_path: str, source_sheet: str, pivot_sheet: str, pivot_name: str, 
                      row_fields: list, data_fields: list, visible: bool = False) -> None:
    """
    Create a pivot table in an Excel workbook.
    
    Args:
        file_path (str): Path to the Excel file
        source_sheet (str): Name of the source worksheet
        pivot_sheet (str): Name of the pivot table worksheet (will be created)
        pivot_name (str): Name for the pivot table
        row_fields (list): List of field names to add as row fields
        data_fields (list): List of dictionaries with field info [{'name': 'field_name', 'function': xlSum}]
        visible (bool): Whether to make Excel visible during operation
        
    Raises:
        FileNotFoundError: If the Excel file doesn't exist
        ValueError: If source_sheet doesn't exist in the workbook
    """
    app = xw.App(visible=visible)
    try:
        book = app.books.open(file_path, update_links=False)
        
        # Create new sheet for pivot table
        book.sheets.add(pivot_sheet)
        ws = book.sheets(pivot_sheet)
        ws_origen = book.sheets(source_sheet)
        
        # Get data range
        num_col = ws_origen.range('A2').end('right').column
        num_row = ws_origen.range('A2').end('down').row
        PivotSourceRange = ws_origen.range((2,1),(num_row, num_col))
        
        # Create pivot table
        table_range = ws.range('A1')
        PivotCache = book.api.PivotCaches().Create(
            SourceType=constants.PivotTableSourceType.xlDatabase,
            SourceData=PivotSourceRange.api,
            Version=constants.PivotTableVersionList.xlPivotTableVersion14
        )
        PivotTable = PivotCache.CreatePivotTable(
            TableDestination=table_range.api,
            TableName=pivot_name,
            DefaultVersion=constants.PivotTableVersionList.xlPivotTableVersion14
        )
        
        # Add row fields
        for field in row_fields:
            DataField = PivotTable.AddDataField(PivotTable.PivotFields(field))
            DataField.Orientation = constants.PivotFieldOrientation.xlRowField
        
        # Add data fields
        for field_info in data_fields:
            DataField = PivotTable.AddDataField(PivotTable.PivotFields(field_info['name']))
            DataField.Function = field_info.get('function', constants.TotalsCalculation.xlTotalsCalculationNone)
            DataField.Orientation = constants.PivotFieldOrientation.xlDataField
        
        book.save()
        
    except KeyError:
        raise ValueError(f"Sheet '{source_sheet}' not found in workbook")
    except Exception as e:
        raise e
    finally:
        book.close()
        app.quit()

    return 0

def filter_pivot_table(book: xw.Book, sheet_name: str, pivot_table_name: str, field_name: str, item_name: str, visible: bool = False) -> None:
    """
    Filter a pivot table by hiding/showing specific items in a field.
    
    Args:
        book (xw.Book): The xlwings workbook object
        sheet_name (str): Name of the worksheet containing the pivot table
        pivot_table_name (str): Name of the pivot table
        field_name (str): Name of the field to filter
        item_name (str): Name of the item to hide/show
        visible (bool): Whether to make the item visible (True) or hidden (False)
        
    Raises:
        ValueError: If sheet_name or pivot_table_name doesn't exist
        KeyError: If field_name or item_name doesn't exist
    """
    try:
        ws = book.sheets(sheet_name)
        tabla_dinamica = ws.api.PivotTables(pivot_table_name)
        pivot_field = tabla_dinamica.PivotFields(field_name)
        pivot_field.PivotItems(item_name).Visible = visible
    except KeyError as e:
        raise ValueError(f"Sheet '{sheet_name}', pivot table '{pivot_table_name}', field '{field_name}', or item '{item_name}' not found")
    except Exception as e:
        raise e
    
    return 0

def copy_formula_down(sheet:xw.Sheet, source_cell: str, target_range: str) -> None:
    """
    Copy a formula from a source cell to a target range.
    
    Args:
        sheet: The xlwings worksheet object
        source_cell (str): Cell reference containing the formula (e.g., 'BL11')
        target_range (str): Range where to paste the formula (e.g., 'BL11:BL100')
    """
    formula = sheet.range(source_cell).formula
    sheet.range(target_range).formula = formula
    return 0

def paste_dataframe_to_sheet(sheet, df: pd.DataFrame, start_cell: str = 'A1', include_header: bool = True, include_index: bool = False) -> None:
    """
    Paste a DataFrame to an Excel sheet at the specified location.
    
    Args:
        sheet: The xlwings worksheet object
        df (pd.DataFrame): DataFrame to paste
        start_cell (str): Starting cell reference (e.g., 'A1', 'I2')
        include_header (bool): Whether to include column headers
        include_index (bool): Whether to include row index
        
    Raises:
        ValueError: If df is not a pandas DataFrame
        AttributeError: If start_cell is invalid
    """
    if not isinstance(df, pd.DataFrame):
        raise ValueError("Input must be a pandas DataFrame")
    
    if not isinstance(start_cell, str):
        raise AttributeError(f"Invalid start_cell reference: {start_cell}")
    
    sheet.range(start_cell).options(index=include_index, header=include_header).value = df

    return 0

def insert_column_at_range(sheet:xw.Sheet, cell_reference: str) -> None:
    """
    Insert a column at a specific cell reference.
    
    Args:
        sheet: The xlwings worksheet object
        cell_reference (str): Cell reference where to insert the column (e.g., 'A1', 'B2', 'C5')
    """
    sheet.range(cell_reference).api.EntireColumn.Insert()
    return 0

def clear_range(sheet:xw.Sheet, start_cell: str, end_column: str, reference_column: str = 'A') -> None:
    """
    Clear contents from a specific range in an Excel worksheet.
    
    Args:
        sheet: The xlwings worksheet object
        start_cell (str): Starting cell reference (e.g., 'BL11', 'A1')
        end_column (str): Column letter for the end of the range (e.g., 'BL', 'A')
        reference_column (str): Column letter to determine the last row with data (default: 'A')
    """
    last_row = sheet.range(reference_column + str(sheet.cells.last_cell.row)).end('up').row
    sheet.range(f'{start_cell}:{end_column}{last_row}').clear_contents()
    return 0


def update_pivot_table_source_data(book: xw.Book, base_sheet_name: str, pivot_configs: dict, 
                                 reference_column: str = 'A', start_row: int = 1, 
                                 start_column: int = 1, end_column: int = 64) -> None:
    """
    Update the source data range for multiple pivot tables across different sheets.
    
    Args:
        book (xw.Book): The xlwings workbook object
        base_sheet_name (str): Name of the base sheet containing the source data
        pivot_configs (dict): Dictionary with sheet names as keys and pivot table names as values
                             e.g., {'Sheet1': 'PivotTable1', 'Sheet2': ['PivotTable1', 'PivotTable2']}
        reference_column (str): Column letter to determine the last row with data (default: 'A')
        start_row (int): Starting row for the source data range (default: 1)
        start_column (int): Starting column for the source data range (default: 1)
        end_column (int): Ending column for the source data range (default: 64)
    
    Raises:
        ValueError: If base_sheet_name or any sheet in pivot_configs doesn't exist
        KeyError: If any pivot table name doesn't exist in its respective sheet
    """
    try:
        sheet_base = book.sheets(base_sheet_name)
        last_row = sheet_base.range(reference_column + str(sheet_base.cells.last_cell.row)).end('up').row
        
        for sheet_name, pivot_tables in pivot_configs.items():
            sheet = book.sheets(sheet_name)
            
            # Handle both single pivot table name (string) and multiple names (list)
            if isinstance(pivot_tables, str):
                pivot_tables = [pivot_tables]
            
            for pivot_table_name in pivot_tables:
                try:
                    tabla_dinamica = sheet.api.PivotTables(pivot_table_name)
                    tabla_dinamica.SourceData = f"'{base_sheet_name}'!R{start_row}C{start_column}:R{last_row}C{end_column}"
                except Exception as e:
                    raise KeyError(f"Pivot table '{pivot_table_name}' not found in sheet '{sheet_name}'")
                    
    except KeyError as e:
        raise ValueError(f"Sheet not found: {e}")
    except Exception as e:
        raise e
    return 0

def take_range_screenshot(sheet: xw.Sheet, range_ref: str, save_path: str) -> str:
    """
    Take a screenshot of a specific range and save it as PNG.
    
    Args:
        sheet: The xlwings worksheet object
        range_ref (str): Range reference (e.g., 'A1:E10')
        save_path (str): Full path where to save the image (e.g., 'C:/screenshots/range.png')
        
    Returns:
        str: Path to the saved screenshot
        
    Raises:
        OSError: If save_path directory doesn't exist or is not writable
        ValueError: If range_ref is invalid
    """
    import os
    
    # Ensure directory exists
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    
    # Take screenshot using xlwings built-in method
    sheet.range(range_ref).to_png(save_path)
    
    return save_path

def take_multiple_range_screenshots(sheet: xw.Sheet, ranges_config: dict, base_path: str) -> dict:
    """
    Take screenshots of multiple ranges and save them with custom names.
    
    Args:
        sheet: The xlwings worksheet object
        ranges_config (dict): Dictionary with range names as keys and range references as values
                             e.g., {'summary': 'A1:E10', 'details': 'G1:M20'}
        base_path (str): Base directory path for saving images
        
    Returns:
        dict: Dictionary with range names as keys and saved file paths as values
        
    Raises:
        OSError: If base_path directory cannot be created
    """
    import os
    from datetime import datetime
    
    # Create base directory
    os.makedirs(base_path, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    saved_files = {}
    
    for range_name, range_ref in ranges_config.items():
        filename = f"{range_name}_{timestamp}.png"
        full_path = os.path.join(base_path, filename)
        
        sheet.range(range_ref).to_png(full_path)
        saved_files[range_name] = full_path
    
    return saved_files

def colored_cell_by_text(sheet: xw.Sheet, rango: str, texto: str, color: str) -> dict:
    """
    Colorea celdas que contengan un texto específico en un rango dado.
    
    Args:
        sheet: La hoja de xlwings
        rango (str): Rango de celdas (e.g., 'A2:B100')
        texto (str): Texto a buscar (e.g., 'COLOR ROJO')
        color (str): Color para aplicar (e.g., 'rojo', 'verde', 'azul')
        
    Returns:
        dict: Estadísticas de las celdas coloreadas
    """
    
    # Mapeo de colores en español
    color_map = {
        'rojo': (255, 0, 0),
        'verde': (0, 255, 0),
        'azul': (0, 0, 255),
        'amarillo': (255, 255, 0),
        'naranja': (255, 165, 0),
        'rosa': (255, 192, 203),
        'gris': (128, 128, 128),
        'morado': (128, 0, 128),
        'celeste': (173, 216, 230),
        'verde_claro': (144, 238, 144)
    }
    
    rgb_color = color_map.get(color.lower(), (255, 255, 0))  # Amarillo por defecto
    cell_range = sheet.range(rango)
    
    # Estadísticas
    stats = {
        'celdas_revisadas': 0,
        'celdas_coloreadas': 0,
        'texto_buscado': texto,
        'color_aplicado': color
    }
    
    # Procesar cada celda en el rango
    for cell in cell_range:
        stats['celdas_revisadas'] += 1
        cell_value = str(cell.value).strip() if cell.value is not None else ""
        
        if not cell_value:  # Saltar celdas vacías
            continue
            
        # Buscar el texto (sin distinguir mayúsculas/minúsculas)
        if texto.lower() in cell_value.lower():
            cell.color = rgb_color
            stats['celdas_coloreadas'] += 1
    
    return stats

def merge_cells(sheet: xw.Sheet, rango: str, center_text: bool = True) -> None:
    """
    Merge cells in a range and optionally center the text.
    
    Args:
        sheet: The xlwings worksheet object
        rango (str): Range to merge (e.g., 'A1:C1')
        center_text (bool): Whether to center the text in merged cell
    """
    cell_range = sheet.range(rango)
    cell_range.api.Merge()
    
    if center_text:
        cell_range.api.HorizontalAlignment = -4108  # xlCenter
    
    return 0

def apply_number_format(sheet: xw.Sheet, rango: str, format_type: str) -> None:
    """
    Apply number formatting to a range.
    
    Args:
        sheet: The xlwings worksheet object
        rango (str): Range to format (e.g., 'A1:B10')
        format_type (str): Format type ('currency', 'percentage', 'date', 'number', 'text')
    """
    format_codes = {
        'currency': '$#,##0.00',
        'percentage': '0.00%',
        'date': 'dd/mm/yyyy',
        'number': '#,##0.00',
        'text': '@',
        'integer': '#,##0'
    }
    
    format_code = format_codes.get(format_type, '#,##0.00')
    sheet.range(rango).number_format = format_code
    return 0
