#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PII Detection Utilities and Validators

This module provides:
- Entity validation functions (RUT, phone, email, etc.)
- Text cleaning and normalization utilities
- Entity deduplication logic
- Context analysis helpers
- Common patterns and exclusion lists
- Confidence scoring utilities
"""

import re
import logging
import unicodedata
from typing import Optional, List, Dict, Tuple, Any, Set, Iterable
import hashlib


# ============================================================================
# PII Configuration
# ============================================================================
class PIIConfig:
    """
    Configuration for PII detection behavior.
    
    Centralized settings for controlling detection sensitivity, feature flags,
    and validation thresholds across all PII detection utilities.
    """
    
    # Pattern sensitivity levels
    STRICT_MODE = 1      # High precision, low recall - fewer false positives
    BALANCED_MODE = 2    # Default - balance between precision and recall
    LENIENT_MODE = 3     # High recall, low precision - catch more potential PII
    
    # Current mode (can be changed at runtime)
    CURRENT_MODE = BALANCED_MODE
    
    # Feature flags
    USE_CONTEXT_ANALYSIS = True       # Use context words to validate entities
    USE_GEOGRAPHIC_EXCLUSION = True   # Exclude geographic terms from person names
    USE_LEMMATIZATION = False         # Use spaCy lemmatization (requires model)
    USE_STEMMING = False              # Use Spanish stemming
    
    # Validation thresholds
    MIN_NAME_LENGTH = 3               # Minimum characters for valid name
    MIN_CONFIDENCE_SCORE = 0.5        # Minimum confidence to accept entity
    MAX_ENTITIES_PER_DOCUMENT = 1000  # Limit entities per document
    
    # RUT validation
    MIN_RUT_LENGTH = 8                # Minimum RUT length (7 digits + DV)
    MAX_RUT_LENGTH = 12               # Maximum RUT length with separators
    
    # Language support
    SUPPORTED_LANGUAGES = ['es', 'pt', 'en']
    DEFAULT_LANGUAGE = 'es'
    
    @classmethod
    def set_mode(cls, mode: int) -> None:
        """Set detection mode (STRICT_MODE, BALANCED_MODE, or LENIENT_MODE)"""
        if mode in (cls.STRICT_MODE, cls.BALANCED_MODE, cls.LENIENT_MODE):
            cls.CURRENT_MODE = mode
        else:
            logging.warning(f"Invalid mode {mode}, keeping current: {cls.CURRENT_MODE}")
    
    @classmethod
    def is_strict(cls) -> bool:
        """Check if running in strict mode"""
        return cls.CURRENT_MODE == cls.STRICT_MODE
    
    @classmethod
    def is_lenient(cls) -> bool:
        """Check if running in lenient mode"""
        return cls.CURRENT_MODE == cls.LENIENT_MODE


# Validation Functions
class PIIValidators:
    """Collection of PII validation functions"""
    
    @staticmethod
    def _luhn_check(number: str) -> bool:
        """Validate credit card numbers using Luhn algorithm"""
        digits = [int(c) for c in re.sub(r"\D+", "", number)]
        if not (13 <= len(digits) <= 19):
            return False
        checksum = 0
        parity = (len(digits) - 2) % 2
        for i, d in enumerate(digits):
            if i % 2 == parity:
                d *= 2
                if d > 9:
                    d -= 9
            checksum += d
        return checksum % 10 == 0

    @staticmethod
    def _rut_calc_dv(num: str) -> str:
        """Calculate RUT verification digit"""
        s = 0
        factor = 2
        for d in map(int, reversed(num)):
            s += d * factor
            factor = 2 if factor == 7 else factor + 1
        r = 11 - (s % 11)
        return "0" if r == 11 else ("K" if r == 10 else str(r))

    @staticmethod
    def normalize_rut(raw: str) -> Optional[str]:
        """Normalize RUT format"""
        if not raw:
            return None
        s = re.sub(r"[^0-9kK]", "", raw)
        if len(s) < 2 or not s[:-1].isdigit():
            return None
        return f"{s[:-1]}-{s[-1].upper()}"

    @staticmethod
    def validate_rut(raw: str) -> bool:
        """
        Validate Chilean RUT with comprehensive error handling.
        
        Args:
            raw: RUT string in any format (with/without dots, dashes)
            
        Returns:
            bool: True if RUT is valid, False otherwise
        """
        if not raw or not isinstance(raw, str):
            return False
        
        try:
            normalized = PIIValidators.normalize_rut(raw)
            if not normalized:
                return False
            
            # Split and validate structure
            parts = normalized.split("-")
            if len(parts) != 2:
                return False
            
            num, dv = parts
            if not num or len(num) < 1 or not num.isdigit():
                return False
            
            # Validate verification digit
            return PIIValidators._rut_calc_dv(num) == dv
            
        except (ValueError, AttributeError, IndexError) as e:
            logging.debug(f"RUT validation error for '{raw}': {e}")
            return False

    @staticmethod
    def validate_cpf(cpf: str) -> bool:
        """
        Validate Brazilian CPF (Cadastro de Pessoas Físicas) with checksum algorithm.
        
        Format: XXX.XXX.XXX-XX (11 digits)
        Uses mod-11 algorithm with two check digits.
        
        Args:
            cpf: CPF string in any format (with/without dots, dashes)
            
        Returns:
            bool: True if CPF is valid, False otherwise
        """
        if not cpf or not isinstance(cpf, str):
            return False
        
        try:
            # Remove formatting characters
            cpf_digits = re.sub(r'[^\d]', '', cpf)
            
            # Must have exactly 11 digits
            if len(cpf_digits) != 11:
                return False
            
            # Check for known invalid CPFs (all same digit)
            if cpf_digits == cpf_digits[0] * 11:
                return False
            
            # Calculate first check digit
            sum1 = sum(int(cpf_digits[i]) * (10 - i) for i in range(9))
            check1 = (sum1 * 10) % 11
            if check1 == 10:
                check1 = 0
            
            # Calculate second check digit
            sum2 = sum(int(cpf_digits[i]) * (11 - i) for i in range(10))
            check2 = (sum2 * 10) % 11
            if check2 == 10:
                check2 = 0
            
            # Validate both check digits
            return cpf_digits[9] == str(check1) and cpf_digits[10] == str(check2)
            
        except (ValueError, AttributeError, IndexError) as e:
            logging.debug(f"CPF validation error for '{cpf}': {e}")
            return False

    @staticmethod
    def validate_cnpj(cnpj: str) -> bool:
        """
        Validate Brazilian CNPJ (Cadastro Nacional da Pessoa Jurídica) with checksum algorithm.
        
        Format: XX.XXX.XXX/XXXX-XX (14 digits)
        Uses mod-11 algorithm with two check digits.
        
        Args:
            cnpj: CNPJ string in any format (with/without dots, slashes, dashes)
            
        Returns:
            bool: True if CNPJ is valid, False otherwise
        """
        if not cnpj or not isinstance(cnpj, str):
            return False
        
        try:
            # Remove formatting characters
            cnpj_digits = re.sub(r'[^\d]', '', cnpj)
            
            # Must have exactly 14 digits
            if len(cnpj_digits) != 14:
                return False
            
            # Check for known invalid CNPJs (all same digit)
            if cnpj_digits == cnpj_digits[0] * 14:
                return False
            
            # First check digit calculation
            weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
            sum1 = sum(int(cnpj_digits[i]) * weights1[i] for i in range(12))
            check1 = sum1 % 11
            check1 = 0 if check1 < 2 else 11 - check1
            
            # Second check digit calculation
            weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
            sum2 = sum(int(cnpj_digits[i]) * weights2[i] for i in range(13))
            check2 = sum2 % 11
            check2 = 0 if check2 < 2 else 11 - check2
            
            # Validate both check digits
            return cnpj_digits[12] == str(check1) and cnpj_digits[13] == str(check2)
            
        except (ValueError, AttributeError, IndexError) as e:
            logging.debug(f"CNPJ validation error for '{cnpj}': {e}")
            return False

    @staticmethod
    def is_valid_for_country(pii_type: str, country: str) -> bool:
        """
        Check if a PII type is valid for a given country.
        
        This method validates whether an identity number type belongs to
        the specified country based on the COUNTRY_IDENTITY_MAP.
        
        Args:
            pii_type: Identity type (e.g., 'CPF', 'RUT', 'CC', 'CI')
            country: Country name (e.g., 'Brasil', 'Chile', 'Colombia', 'Uruguay')
        
        Returns:
            bool: True if identity type is valid for country, False otherwise
            
        Example:
            >>> PIIValidators.is_valid_for_country('CPF', 'Brasil')  # True
            >>> PIIValidators.is_valid_for_country('CPF', 'Chile')   # False
            >>> PIIValidators.is_valid_for_country('RUT', 'Chile')   # True
        """
        if not pii_type or not country:
            return True  # If country unknown, allow all types (permissive default)
        
        # Import here to avoid circular dependency
        from src.utils.pii_utils import PIIPatterns
        
        valid_types = PIIPatterns.COUNTRY_IDENTITY_MAP.get(country, set())
        return pii_type in valid_types if valid_types else True

    @staticmethod
    def is_valid_credit_card(candidate: str) -> bool:
        """Validate credit card using Luhn algorithm"""
        return PIIValidators._luhn_check(candidate)

    @staticmethod
    def sanitize_account(value: str) -> str:
        """Remove non-digit characters from account numbers"""
        return re.sub(r"[^\d]", "", value or "")

# Text Processing Utilities
class TextProcessingUtils:
    """Text cleaning and normalization utilities"""
    
    @staticmethod
    def strip_accents(s: str) -> str:
        """Remove accents from Spanish text"""
        try:
            return unicodedata.normalize("NFD", s).encode("ascii", "ignore").decode("ascii")
        except Exception:
            return s

    @staticmethod
    def basic_clean_text(text: str) -> str:
        """Basic text cleaning - normalize whitespace and remove non-printables"""
        text = re.sub(r'\s+', ' ', text)
        text = ''.join(c for c in text if c.isprintable())
        return text.strip()

    @staticmethod
    def aggressive_clean_text(text: str, stopwords: Optional[Set[str]] = None) -> str:
        """Aggressively clean text by removing stopwords and normalizing"""
        words = text.split()
        if stopwords:
            words = [w for w in words if w.lower() not in stopwords]
        return ' '.join(words)

    @staticmethod
    def normalize_digits(s: str) -> str:
        """Normalize digit sequences for comparison"""
        return re.sub(r'[\s\-\.]', '', s)

    @staticmethod
    def clean_ocr_line(text: str, remove_stopwords: bool = False, stopwords: Optional[Set[str]] = None) -> str:
        """
        Clean a single OCR line by normalizing, removing artifacts, and optionally removing stopwords.
        """
        try:
            text = unicodedata.normalize("NFKC", text)
            text = re.sub(r"-\s*\n\s*", "", text)  # Remove hyphen at end of line (word split)
            text = re.sub(r"-\s+(?=[a-záéíóúñ])", "", text, flags=re.IGNORECASE)  # Remove hyphen before lowercase letter (word split)
            text = re.sub(r"[^\w\s@.\-/+()[\],;:'\"áéíóúüñÁÉÍÓÚÜÑ-]", " ", text)  # Remove unwanted punctuation/symbols
            text = re.sub(r"\s*@\s*", "@", text)  # Remove spaces around '@' in emails
            text = re.sub(r"(\w)\s*\.\s*(\w)", r"\1.\2", text)  # Remove spaces around periods in abbreviations/emails
            text = re.sub(r"(\d)\s*-\s*([kK\d])", r"\1-\2", text)  # Remove spaces around hyphen in RUTs
            text = re.sub(r"\(\s*(\d{1,4})\s*\)", r"(\1)", text)  # Remove spaces inside parentheses (numbers)
            text = re.sub(r"\s{2,}", " ", text)  # Collapse multiple spaces into a single space
            cleaned_text = re.sub(r"\s+", " ", text).strip()  # Final whitespace normalization
            
            # Apply stop words removal if requested
            if remove_stopwords and stopwords:
                words = re.findall(r'\b\w+\b', cleaned_text)
                filtered_words = [w for w in words if w.lower() not in stopwords]
                cleaned_text = " ".join(filtered_words)
                
            return cleaned_text
        except Exception:
            return text

    @staticmethod
    def advanced_clean_text(text: str) -> str:
        """
        Apply advanced text cleaning for better PII detection.
        Removes non-printable characters, normalizes whitespace, fixes OCR errors, removes codes.
        """
        try:
            # Remove non-printable characters
            text = ''.join(c for c in text if c.isprintable())
            # Normalize whitespace
            text = re.sub(r'\s+', ' ', text)
            # Remove leading/trailing symbols
            text = re.sub(r'^[\]\[\)\(]+|[\]\[\)\(]+$', '', text)
            # Remove common code patterns (e.g., ##O, ##F VN)
            text = re.sub(r'##[A-Z0-9 ]{1,10}', ' ', text)
            # Fix common OCR errors for numbers (be careful with RUTs)
            # Only apply to isolated characters to avoid breaking RUTs
            text = re.sub(r'\b0\b', 'O', text)  # Only isolated zeros
            text = re.sub(r'\bl\b', '1', text)  # Only isolated l's
            # Remove isolated short tokens (likely codes or OCR artifacts)
            text = re.sub(r'\b[A-Z0-9]{1,3}\b', ' ', text)
            # Remove repeated characters (but preserve double letters in names)
            text = re.sub(r'(.)\1{3,}', r'\1\1', text)  # Keep max 2 repeated chars
            # Clean up punctuation spacing
            text = re.sub(r'\s*([.,;:!?])\s*', r'\1 ', text)
            text = re.sub(r'https?://\S+', ' ', text)     # Remove URLs
            # Remove extra spaces again after all cleaning
            text = re.sub(r'\s+', ' ', text)
            return text.strip()
        except Exception as e:
            logging.warning(f"Error in advanced text cleaning: {e}")
            return text

# Entity Processing Utilities
class EntityUtils:
    """Entity deduplication and processing utilities"""
    
    @staticmethod
    def dedupe_entities(entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Deduplicate overlapping entities, keeping highest priority.
        
        Strategy:
        - When two entities overlap, prefer the one from the higher-priority source
        - Source priority: transformer (3) > regex (2) > spaCy (1)
        - When same type/value, replace with higher priority source
        - When same type but different value, keep larger entity if higher priority
        
        Overlap Detection:
        - Two entities overlap if: NOT(e_end <= o_start OR e_start >= o_end)
        - This checks if neither entity comes completely before/after the other
        - Containment: e_range contains o_range if e_start <= o_start AND e_end >= o_end
        """
        if not entities:
            return []
        
        # Source priority mapping (higher number = higher priority)
        pref = {"transformer": 3, "regex": 2, "spaCy": 1}
        
        def norm_key(e: Dict[str, Any]) -> Tuple[str, str]:
            """Create normalized key for entity comparison (type, value)"""
            return (e.get("PII_Type", "").lower(), EntityUtils._norm_value_for_key(e.get("PII_Value", "")))
        
        # Sort entities by position, then by length (descending), then by source priority
        entities_sorted = sorted(
            entities,
            key=lambda e: (
                e.get("start_pos", 0),
                -(e.get("end_pos", 0) - e.get("start_pos", 0)),
                -pref.get(e.get("Source"), 0),
            ),
        )
        
        out: List[Dict[str, Any]] = []
        for e in entities_sorted:
            e_key = norm_key(e)
            e_range = (e.get("start_pos", 0), e.get("end_pos", 0))
            replaced = False
            to_remove: List[int] = []
            
            for i, o in enumerate(out):
                o_key = norm_key(o)
                o_range = (o.get("start_pos", 0), o.get("end_pos", 0))
                
                # Check if entities overlap: neither comes completely before/after the other
                overlaps = not (e_range[1] <= o_range[0] or e_range[0] >= o_range[1])
                
                # Check if current entity (e) completely contains existing entity (o)
                contains = e_range[0] <= o_range[0] and e_range[1] >= o_range[1]
                
                same_value = e_key == o_key
                same_type = e.get("PII_Type") == o.get("PII_Type")
                
                if overlaps:
                    if same_value:
                        # Same PII found by different sources: keep higher priority
                        if pref.get(e.get("Source"), 0) > pref.get(o.get("Source"), 0):
                            out[i] = e
                        replaced = True
                        break
                    elif same_type and contains:
                        # Same type but different value: keep larger span if higher priority
                        if pref.get(e.get("Source"), 0) >= pref.get(o.get("Source"), 0):
                            to_remove.append(i)
                        else:
                            replaced = True
                            break
            
            # Remove marked duplicates
            for idx in reversed(to_remove):
                out.pop(idx)
            
            # Add new entity if not replaced
            if not replaced:
                out.append(e)
        
        # Sort output by position
        out.sort(key=lambda x: (x.get("start_pos", 0), x.get("end_pos", 0)))
        return out

    @staticmethod
    def extract_local_context(text: str, start: int, end: int, window: int = 40) -> str:
        """Extract local context around an entity"""
        ctx_start = max(0, start - window)
        ctx_end = min(len(text), end + window)
        return text[ctx_start:ctx_end].strip().lower()

    @staticmethod
    def clean_entity_boundaries(entity_text: str, entity_type: str, 
                               original_text: str, start_pos: int, end_pos: int) -> Tuple[Optional[str], int, int]:
        """Clean entity boundaries by removing leading/trailing artifacts"""
        try:
            etype = (entity_type or "").upper()
            try_expand = etype in {"PER", "PERSON"} or (etype in {"MISC", "MISCELLANEOUS"} and len(entity_text.split()) <= 2 and entity_text.isalpha())
            
            if try_expand:
                s = start_pos
                while s > 0 and (original_text[s - 1].isalpha() or original_text[s - 1].isspace()): 
                    s -= 1
                while s < len(original_text) and not original_text[s].isalpha(): 
                    s += 1
                e = end_pos
                while e < len(original_text) and (original_text[e].isalpha() or original_text[e].isspace()): 
                    e += 1
                expanded = original_text[s:e].strip()
                words = expanded.split()
                if 2 <= len(words) <= 4 and all(len(w) >= 2 and w.isalpha() for w in words) and len(expanded) >= 6:
                    return expanded, s, e
            
            cleaned = entity_text.strip()
            if etype in {"PER", "PERSON"}:
                prefix_words = {"nombre", "name", "sr", "sra", "señor", "señora", "don", "doña"}
                tokens = cleaned.split()
                while tokens and tokens[0].lower() in prefix_words: 
                    tokens = tokens[1:]
                if not tokens: 
                    return None, start_pos, end_pos
                cleaned = " ".join(tokens)
                cleaned = re.sub(r"^[\d\s]+", "", cleaned)
                cleaned = re.sub(r"[\d\s]+$", "", cleaned)
                tokens = cleaned.split()
                if not tokens or not all(t.isalpha() for t in tokens): 
                    return None, start_pos, end_pos
            
            if len(cleaned.strip()) < 2: 
                return None, start_pos, end_pos
            return cleaned, start_pos, end_pos
        except Exception as e:
            logging.warning(f"Error cleaning entity boundaries: {e}")
            return entity_text, start_pos, end_pos

    @staticmethod
    def _norm_value_for_key(value: str) -> str:
        """Normalize a value for deduplication by lowercasing and stripping whitespace"""
        return re.sub(r"\s+", " ", value or "").strip().lower()

# Context Analysis
class ContextAnalyzer:
    """Context analysis for entity validation"""
    
    def __init__(self, use_lemmas: bool = False, use_stemming: bool = False, 
                 nlp_lemma=None, stemmer=None):
        self.use_lemmas = use_lemmas
        self.use_stemming = use_stemming
        self.nlp_lemma = nlp_lemma
        self.stemmer = stemmer
        
        # Consolidated Spanish + Portuguese context words (include accented and unaccented forms)
        self.good_ctx_words = {
            "nombre", "titular", "afiliado", "asegurado", "cliente", "conyuge", "cónyuge",
            # Portuguese
            "nome", "titular", "afiliado", "segurado", "cliente", "conjuge", "cônjuge",
        }

        self.bad_ctx_words = {
            "renta", "mensual", "poliza", "póliza", "cotizacion", "cotización", "oferta", "scomp", "uf", "saldo",
            # Portuguese
            "renda", "mensal", "apolice", "apólice", "cotizacao", "cotização",
        }

        self.phone_ctx_words = {
            "tel", "telefono", "teléfono", "cel", "celular", "movil", "móvil", "whatsapp", "fono", "llamar", "llamadas", "contacto", "anexo", "ext",
            # Portuguese variants
            "telefone", "fone", "movel", "móvel", "ligar", "ligacoes", "ligações", "chamadas", "chamada", "contato", "ramal",
        }
        
        # Financial domain terms for person name rejection (Spanish + Portuguese consolidated)
        self.financial_terms = {
            # Spanish
            "vitalicias", "vitalicia", "poliza", "polizas", "renta", "mensual", "pension", "seguro", "seguros",
            "validacion", "beneficiarios", "traspaso", "cotizacion", "afiliado", "prima", "uf", "superintendencia",
            "fonasa", "isapre", "afp", "cuprum", "habitat", "provida", "planvital", "modelo", "capital", "uno",
            "chile", "ips", "scomp", "compañia", "aseguradora", "diferido", "intermediario", "garantizado",
            "solicitud", "endosos", "clausula", "articulo", "modalidad", "periodo", "fecha", "valor", "tasa",
            "descuento", "cierre", "casos", "cerrados", "recupera", "reporte", "exporta", "termina", "ready",
            "procesar", "imprime", "concluido", "direccion", "comuna", "ciudad", "estado", "civil", "nacimiento",
            "masculino", "femenino", "casado", "soltero", "viudo", "divorciado", "sistema", "salud", "invalidez",
            "relacion", "conyuge", "hijo", "hija", "padre", "madre", "certificado", "saldo", "emitido", "imprimir",
            # Portuguese
            "vitalicia", "vitalício", "apolice", "apolices", "apólice", "apólices", "renda", "mensal", "pensao", "pensão", "seguro", "seguros",
            "validacao", "validação", "beneficiarios", "beneficiários", "transferencia", "transferência", "cotizacao", "cotização", "afiliado", "premio", "prêmio", "superintendencia", "superintendência",
            "caixa", "inss", "cuprum", "habitat", "provida", "planvital", "modelo", "capital", "um",
            "brasil", "ips", "scomp", "companhia", "seguradora", "diferido", "intermediario", "intermediário", "garantido",
            "solicitacao", "solicitação", "endosso", "clausula", "cláusula", "artigo", "modalidade", "periodo", "período", "data", "valor", "taxa",
            "desconto", "encerramento", "casos", "encerrados", "recupera", "relatorio", "relatório", "exporta", "termina", "pronto",
            "processar", "imprime", "concluido", "concluído", "endereco", "endereço", "municipio", "município", "estado", "civil", "nascimento",
            "masculino", "feminino", "casado", "solteiro", "viuvo", "divorciado", "sistema", "saude", "saúde", "invalidez",
            "relacao", "relação", "conjuge", "cônjuge", "filho", "filha", "pai", "mae", "mãe", "certificado", "saldo", "emitido", "imprimir",
        }

        # Precompute normalized sets
        self.good_ctx_lemmas = self._normalize_wordset(self.good_ctx_words, use_lemma=True)
        self.bad_ctx_lemmas = self._normalize_wordset(self.bad_ctx_words, use_lemma=True)
        self.financial_terms_lemmas = self._normalize_wordset(self.financial_terms, use_lemma=True)
        self.phone_ctx_lemmas = self._normalize_wordset(self.phone_ctx_words, use_lemma=True)

        self.good_ctx_stems = self._normalize_wordset(self.good_ctx_words, use_stem=True)
        self.bad_ctx_stems = self._normalize_wordset(self.bad_ctx_words, use_stem=True)
        self.financial_terms_stems = self._normalize_wordset(self.financial_terms, use_stem=True)
        self.phone_ctx_stems = self._normalize_wordset(self.phone_ctx_words, use_stem=True)

    def _ctx_tokens(self, text: str) -> List[str]:
        """Tokenize context text into alphabetic tokens, including Spanish accented characters"""
        return re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", text or "")

    def _lemma_tokens(self, tokens: List[str]) -> List[str]:
        """Lemmatize tokens using spaCy if available, otherwise return normalized tokens"""
        if not tokens:
            return []
        base = [TextProcessingUtils.strip_accents(t.lower()) for t in tokens]
        if self.use_lemmas and self.nlp_lemma:
            try:
                doc = self.nlp_lemma(" ".join(base))
                return [TextProcessingUtils.strip_accents(t.lemma_.lower()) for t in doc if t.lemma_]
            except Exception:
                return base
        return base

    def _stem_tokens(self, tokens: List[str]) -> List[str]:
        """Stem tokens using the Spanish stemmer if available, otherwise return normalized tokens"""
        if not tokens:
            return []
        base = [TextProcessingUtils.strip_accents(t.lower()) for t in tokens]
        if self.stemmer:
            try:
                return self.stemmer.stemWords(base)
            except Exception:
                return base
        return base

    def _normalize_wordset(self, words: Iterable[str], use_lemma: bool = False, use_stem: bool = False) -> set:
        """Normalize a set of words using lemma or stem if enabled"""
        words = list(words or [])
        if not words:
            return set()
        folded = [TextProcessingUtils.strip_accents(w.lower()) for w in words]
        if use_lemma and self.use_lemmas and self.nlp_lemma:
            return set(self._lemma_tokens(folded))
        if use_stem and self.stemmer:
            return set(self._stem_tokens(folded))
        return set(folded)

    def person_context_ok(self, ctx: str) -> bool:
        """Check if context is appropriate for person name"""
        toks = self._ctx_tokens(ctx)
        if self.use_lemmas and self.nlp_lemma:
            lemmas = set(self._lemma_tokens(toks))
            has_good = bool(lemmas & self.good_ctx_lemmas)
            has_bad = bool(lemmas & self.bad_ctx_lemmas)
            return has_good or not has_bad
        if self.stemmer:
            stems = set(self._stem_tokens(toks))
            has_good = bool(stems & self.good_ctx_stems)
            has_bad = bool(stems & self.bad_ctx_stems)
            return has_good or not has_bad
        folded = TextProcessingUtils.strip_accents(ctx.lower())
        has_good = any(g in folded for g in self._normalize_wordset(self.good_ctx_words))
        has_bad = any(b in folded for b in self._normalize_wordset(self.bad_ctx_words))
        return has_good or not has_bad

    def rut_context_ok(self, ctx: str) -> bool:
        """Check if context is appropriate for RUT"""
        folded = TextProcessingUtils.strip_accents(ctx.lower())
        if re.search(r"\b(rut|r\.?u\.?t\.?)\b", folded): return True
        if re.search(r"\b(run|r\.?u\.?n\.?)\b", folded): return True
        if "rol unico" in folded and "tributario" in folded: return True
        if re.search(r"\b(cedula|identidad|dni)\b", folded): return True
        return False

    def phone_context_ok(self, ctx: str) -> bool:
        """Check if context is appropriate for phone number"""
        toks = self._ctx_tokens(ctx)
        if self.use_lemmas and self.nlp_lemma:
            lemmas = set(self._lemma_tokens(toks))
            return bool(lemmas & self.phone_ctx_lemmas)
        if self.stemmer:
            stems = set(self._stem_tokens(toks))
            return bool(stems & self.phone_ctx_stems)
        folded = TextProcessingUtils.strip_accents(ctx.lower())
        return any(w in folded for w in self._normalize_wordset(self.phone_ctx_words))

    @staticmethod
    def looks_like_heading(ctx: str) -> bool:
        """Heuristic to check if a context string looks like a heading (mostly uppercase tokens)"""
        tokens = [t for t in re.split(r"\W+", ctx) if t]
        if not tokens: 
            return False
        upp = sum(1 for t in tokens if t.isupper() and len(t) > 2)
        return upp / len(tokens) >= 0.7

# Confidence Scoring
class ConfidenceScorer:
    """Assign confidence scores to detected entities"""
    
    @staticmethod
    def calculate_consensus_confidence(entity: Dict[str, Any], sources: List[str]) -> float:
        """Calculate confidence based on source consensus"""
        source_weights = {
            'transformer': 0.4,
            'spacy': 0.3,
            'regex': 0.3
        }
        
        confidence = 0.0
        for source in sources:
            confidence += source_weights.get(source, 0.1)
        
        # Bonus for multiple sources
        if len(sources) > 1:
            confidence += 0.1 * (len(sources) - 1)
        
        return min(1.0, confidence)

    @staticmethod
    def apply_validation_bonus(entity: Dict[str, Any], is_valid: bool) -> float:
        """Apply validation bonus/penalty to confidence"""
        base_confidence = entity.get('confidence', 0.5)
        
        if is_valid:
            return min(1.0, base_confidence + 0.15)
        else:
            return max(0.0, base_confidence - 0.25)

# Pattern Collections
class PIIPatterns:
    """Collection of regex patterns for PII detection"""
    
    FLAGS = re.IGNORECASE | re.UNICODE
    
    PATTERNS = {
        ################### identity numbers ###################
        # CHILE - RUT (Rol Único Tributario)
        "RUT": re.compile(r"\b(?:\d{1,3}(?:[., ]\d{3}){1,2}|\d{7,8})[-‐‑–—\s]\s*[\dkK]\b", FLAGS),
        "RUT_Context": re.compile(
            r"\b(?:rut|run|rol\s+u[́']?nico\s+tributario)(?:\s+(?:es|is|:))?\s*[:#-]?\s*(?:\d{1,3}(?:[., ]\d{3}){1,2}|\d{7,8})[-‐‑–—\s]\s*[\dkK]\b",
            FLAGS,
        ),
        "RUT_Comma": re.compile(r"\b\d{1,3}(?:[, ]\d{3}){1,2}[-‐‑–—\s]\s*[0-9Kk]\b", FLAGS),
        "PartialRUT_Context": re.compile(r"\b(?:rut|run)\s*[:#-]?\s*(\d{8})\b", FLAGS),
        
        # BRASIL - CPF (Cadastro de Pessoas Físicas)
        "CPF": re.compile(r"\b\d{3}\.?\d{3}\.?\d{3}[-\s]?\d{2}\b", FLAGS),
        "CPF_Context": re.compile(r"\b(?:cpf|cpf:)\s*[:#-]?\s*(\d{3}\.?\d{3}\.?\d{3}[-\s]?\d{2})\b", FLAGS),
        
        # BRASIL - CNPJ (Cadastro Nacional da Pessoa Jurídica)
        "CNPJ": re.compile(r"\b\d{2}\.?\d{3}\.?\d{3}/?0001[-\s]?\d{2}\b", FLAGS),
        "CNPJ_Context": re.compile(r"\b(?:cnpj|cnpj:)\s*[:#-]?\s*(\d{2}\.?\d{3}\.?\d{3}/?0001[-\s]?\d{2})\b", FLAGS),
        
        # COLOMBIA - CC (Cédula de Ciudadanía)
        "CC": re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}[-\s]?\d{1}\b", FLAGS),
        "CC_Context": re.compile(r"\b(?:cc|c\.c\.|cedula|cédula)\s*[:#-]?\s*(\d{1,2}\.?\d{3}\.?\d{3}[-\s]?\d{1})\b", FLAGS),
        
        # URUGUAY - CI (Cédula de Identidad)
        "CI": re.compile(r"\b\d{1,2}\.?\d{3}\.?\d{3}[-\s]?\d{1}\b", FLAGS),
        "CI_Context": re.compile(r"\b(?:ci|c\.i\.|cedula|cédula|ci:)\s*[:#-]?\s*(\d{1,2}\.?\d{3}\.?\d{3}[-\s]?\d{1})\b", FLAGS),
        #######################################################
        
        # Phone patterns
        "Phone_Chile_Service": re.compile(r"600[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),
        # "Phone_Argentina_Service": re.compile(r"0(800|810)[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),
        "Phone_Argentina_Service": re.compile(r"\b0(?:800|810)(?:[\s\-]?\d){7}\b", FLAGS),
        "Phone_Brazil_Service": re.compile(r"0(800|300)[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),
        "Phone_Uruguay_Service": re.compile(r"0(800|900)[\s\-]?\d{4}", FLAGS),
        "Phone_Mexico_Service": re.compile(r"800[\s\-]?\d{3}[\s\-]?\d{4}", FLAGS),
        "Phone": re.compile(r"\b(?:\+?56[\s\-]?)?\d{9}\b|\b(?:\+?52[\s\-]?)?\d{10}\b|\b(?:\+?598[\s\-]?)?\d{8,9}\b|\b(?:\+?55[\s\-]?)?\d{10,11}\b|\b(?:\+?54[\s\-]?)?\d{10}\b", FLAGS),
        "Phone_Context": re.compile(
            r"\b(?:tel(?:e?f(?:o|ó)no)?|cel(?:ular)?|m[oó]vil|whatsapp)\s*[:#-]?\s*(?:\+?56[\s\-]?)?(?:9|2|3|4|5|6|7)(?:[\s\-]?\d){8}\b",
            FLAGS,
        ),

        # "SpanishName": re.compile(
        #     r"(?<![@])\b"
        #     r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"
        #     r"(?:\s+(?:de|del|la|las|los|y)\s+)?"
        #     r"(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"
        #     r"(?:\s+(?:[A-ZÁÉÍÓÚÑ][a-záéíóúñA-Z ÁÉÍÓÚÑ]{1,})){1,3}\b",
        #     FLAGS,
        "SpanishName": re.compile(
            r"(?<![@])\b"
            r"(?:[A-Za-záéíóúñÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"  # Allow both upper and lowercase first letter
            r"(?:\s+(?:de|del|la|las|los|y)\s+)?"
            r"(?:[A-Za-záéíóúñÁÉÍÓÚÑ][a-záéíóúñA-ZÁÉÍÓÚÑ]{1,})"  # Allow both upper and lowercase first letter
            r"(?:\s+(?:[A-Za-záéíóúñÁÉÍÓÚÑ][a-záéíóúñA-Z ÁÉÍÓÚÑ]{1,})){0,3}\b",  # Allow both cases
            FLAGS,
        ),
        
        "Person_Context": re.compile(
            r"\b(?:nombre|titular|afiliado|cliente|asegurado|cónyuge|conyuge)\s*[:#-]?\s*"
            r"((?:[A-ZÁÉÍÓÚÑa-záéíóúñA-ZÁÉÍÓÚÑ]{2,}\s+){1,3}[A-ZÁÉÍÓÚÑa-záéíóúñ]{2,})\b",
            FLAGS,
        ),

        # Enhanced name detection patterns - FIXED VERSION with stricter validation
        "ContextualPersonName": re.compile(
            r"(?:nombre|titular|afiliado|asegurado|cliente|beneficiario|cónyuge|solicitante)[\s:]*"  
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}(?:\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}){0,2})"  # Minimum 2 words, each 3+ chars
            r"(?=\s|$|,|\.|\n)",
            FLAGS
        ),
        
        "TitledPersonName": re.compile(
            r"(?:Sr\.?|Sra\.?|Don|Doña|Dr\.?|Dra\.?|Ing\.?|Prof\.?)\s+"
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}(?:\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}){0,2})"  # Minimum 2 words, each 3+ chars
            r"(?=\s|$|,|\.|\n)",
            FLAGS
        ),
        

        
        "ChileanFullName": re.compile(
            r"(?<!\w)"  # Word boundary start
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})"  # First name (3+ chars)
            r"\s+"  # Required space
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})"  # Last name 1 (3+ chars)
            r"(?:\s+([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}))?"  # Optional last name 2 (3+ chars)
            r"(?:\s+([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}))?"  # Optional last name 3 (3+ chars)
            r"(?!\w)",  # Word boundary end
            FLAGS
        ),
        
        # Surname-first ALL-CAPS names (e.g., "VEGA TORO MARGARITA CRISTINA")
        # Matches 2-4 consecutive words where EACH word is ALL CAPS and 3+ chars
        "SurnameFirst_AllCaps": re.compile(
            r"(?<!\w)"
            # Negative lookahead to exclude city names at start (ALL CAPS cities)
            r"(?!(?:ARICA|IQUIQUE|ANTOFAGASTA|CALAMA|CONCEPCIÓN|VALPARAÍSO|SANTIAGO|TEMUCO|VALDIVIA|OSORNO)\b)"
            r"("  # Capture group for the full name
            # r"(?:[A-ZÁÉÍÓÚÑÜ]{3,}\s+){1,3}"   # 1-3 ALL-CAPS words, each 3+ chars (surnames)
            r"(?:[A-ZÁÉÍÓÚÑÜ]{3,}\s+){1,4}"   # 1-4 ALL-CAPS words, each " 
            r"[A-ZÁÉÍÓÚÑÜ]{3,}"               # Final ALL-CAPS word 3+ chars (last name/surname)
            r")"
            r"(?!\w)",
            re.UNICODE  # Use re.UNICODE instead of FLAGS to avoid matching mixed case
        ),
        "CompoundSpanishName": re.compile(
            r"(?<!\w)"
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}-[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})"  # Both parts 3+ chars
            r"(?:\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,}){1,2}"  # + surnames (3+ chars each)
            r"(?!\w)",
            FLAGS
        ),
        
        "PatronymicName": re.compile(
            r"(?<!\w)"
            # Negative lookahead to exclude city names at start
            r"(?!(?:Arica|Iquique|Antofagasta|Calama|Concepción|Valparaíso|Santiago|Temuco|Valdivia|Osorno)\s)"
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})\s+"  # First name (3+ chars)
            r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{3,}(?:ez|iz))"  # Patronymic (4+ chars total)
            r"(?:\s+[A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})?"  # Optional second surname (3+ chars)
            r"(?!\w)",
            FLAGS
        ),
        
        # Double-barrel surnames with first names (e.g., "Villablanca Henriquez Felipe Eduardo")
        # Handles compound surnames in Title Case followed by first names
        # All 4 words must be in the same case pattern (either all Title Case or all CAPS)
        "DoubleSurnameWithFirstNames": re.compile(
            r"(?<!\w)"
            # Negative lookahead to exclude city names at start
            r"(?!(?:Arica|Iquique|Antofagasta|Calama|Concepción|Valparaíso|Santiago|Temuco|Valdivia|Osorno|Pago|Bono)\s)"
            r"(?:"
                # Option 1: All Title Case (Villablanca Henriquez Felipe Eduardo)
                r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{3,})\s+"  # First surname (4+ chars, Title Case)
                r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{3,})\s+"  # Second surname (4+ chars, Title Case)
                r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})\s+"  # First name (3+ chars, Title Case)
                r"([A-ZÁÉÍÓÚÑÜ][a-záéíóúñü]{2,})"     # Second first name (3+ chars, Title Case)
            r"|"
                # Option 2: All UPPERCASE (VILLABLANCA HENRIQUEZ FELIPE EDUARDO)
                r"([A-ZÁÉÍÓÚÑÜ]{4,})\s+"  # First surname (4+ chars, ALL CAPS)
                r"([A-ZÁÉÍÓÚÑÜ]{4,})\s+"  # Second surname (4+ chars, ALL CAPS)
                r"([A-ZÁÉÍÓÚÑÜ]{3,})\s+"  # First name (3+ chars, ALL CAPS)
                r"([A-ZÁÉÍÓÚÑÜ]{3,})"     # Second first name (3+ chars, ALL CAPS)
            r")"
            r"(?!\w)",
            re.UNICODE
        ),

        "Account": re.compile(
            r"\b(?:cuenta(?:\s+(?:vista|corriente))?|cta(?:\.|\s+)?(?:cte|vista)?|c[/\.]\s*c|c[/\.]\s*cte"
            r"|n[°º#]\s*de\s*cuenta|nro\.?\s*cuenta|account(?:\s*no\.?)?)\s*[:#-]?\s*"
            r"([0-9][0-9\.\-\s]{4,23}[0-9])\b",
            FLAGS,
        ),
        
        "Email": re.compile(r"\b[a-z0-9._%+\-]+@(?!metlife|provida|metlifeexternos|providaexternos)[a-z0-9.\-]+\.[a-z]{2,24}\b", FLAGS),
        "Health": re.compile(r"\b(salud|m[eé]dico|cl[ií]nico|hospital|biometr[ií]a|enfermedad|diagn[oó]stico|tratamiento|paciente|doctor|receta|examen|isapre|fonasa)\b", FLAGS),
        "Sex": re.compile(r"\b(?:sexo|género)\s*[:#-]?\s*(masculino|femenino|hombre|mujer)\b", FLAGS),
        "Address_StreetNum": re.compile(
            r"\b(?:av(?:\.|enida)?|calle|cll|pasaje|psje|cam(?:\.|ino)?|ruta|carretera)\s+"
            r"[a-z0-9áéíóúñ\.\- ]{2,}\s+(?:n[°º#]\s*)?\d{1,5}\b",
            FLAGS,
        ),
        "Address_Keywords": re.compile(
            r"\b(direcci[oó]n|domicilio|residencia|ciudad|comuna|piso|depto|dpto\.?|departamento|torre|block|villa|condominio|lote|manzana)\b",
            FLAGS,
        ),

        "Date": re.compile(
            r"\b\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
            r"|"
            r"\b(?:0?[1-9]|[12]\d|3[01])[/-](?:0?[1-9]|1[0-2])[/-](?:\d{2}|\d{4})(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
            r"|"
            r"\b(?:0[1-9]|[12]\d|3[01])(?:0[1-9]|1[0-2])\d{4}(?:[ T]\d{2}:\d{2}(?::\d{2})?)?\b"
            r"|"
            r"\b(?:0?[1-9]|[12]\d|3[01])\s+(?:ene|feb|mar|abr|may|jun|jul|ago|sep|oct|nov|dic|enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|septiembre|octubre|noviembre|diciembre|janeiro|fevereiro|marco|março|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro)\s+\d{2,4}\b",
            FLAGS,
        ),
        "Passport_Context": re.compile(r"\b(?:pasaporte|passport)\s*[:#-]?\s*([A-Z0-9]{7,9})\b", FLAGS),
        "Patente_Context": re.compile(r"\bpatente\s*[:#-]?\s*(?:[A-Z]{2}\s?\d{4}|[A-Z]{2}\s?[A-Z]{2}\s?\d{2})\b", FLAGS),

        # Generic numeric runs: last to avoid overshadowing specific patterns
        # "NumberSequence": re.compile(r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])(?:\d[ \-]?){6,12}\b(?![\d,\.\-])", FLAGS),
        

        # NumberSequence": re.compile(r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])(?:\d[ \-]?){6,12}\b(?![\d,\.\-])", FLAGS),
        # 123456789      # 9 consecutive digits
        # 12 34 56 78    # Digits with spaces
        # 123-456-789    # Digits with hyphens
        # 1234 5678      # Mixed spacing
        # 987654321012   # 12 digits (maximum)
        # 123456         # 6 digits (minimum)

        # "NumberSequence": re.compile(r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])(?:\d[ \-]?){6,12}\b(?![\d,\.\-])", FLAGS), # Simplified to just 6-12 consecutive digits without spaces
        "NumberSequence": re.compile(r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])\d{6,12}\b(?![\d\.,\-])",FLAGS,) ,# No spaces or hyphens allowed, 
        # "CreditCard_Full": re.compile(r"\b(?:4\d{15}|5[1-5]\d{14}|3[47]\d{13}|6011\d{12})\b", FLAGS), # Visa, MasterCard, Amex, Discover Luhn algorithm
        # a checksum formula used to validate a variety of identification numbers, such as credit card and IMEI numbers
        
        # "NumberSequence": re.compile(
        #     r"\b(?!\d{1,3}(?:[., ]\d{3}){1,2}[-‐‑–—\s][0-9Kk])"   # exclude RUT-like forms
        #     r"(?=(?:.*\d){6,20})"                                # require 6..20 digits total
        #     r"\d+(?:-\d+)*\b",                                   # digits with optional internal hyphens, no spaces >> "36621-0000013932"
        #     FLAGS,
        # ),
        
        "Amount": re.compile(r"\b\$?(?:\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{2})?|\d{4,}(?:[.,]\d{2}))\b", FLAGS),
        # "Amount": re.compile(r"\b\$?(?:\d{1,3}(?:\.\d{3})+(?:,\d{2})?|\d{1,3}(?:,\d{3})+(?:\.\d{2})?|\d{4,}(?:[.,]\d{2}))\b", FLAGS),

        

        # 3.125,63        # Dots for thousands, comma for decimals (Chilean format)
        # 2,703.59        # Comma for thousands, dot for decimals (US format)
        # 1.924,74        # Mixed format with dots
        # 7,582.16        # Mixed format with commas
        # 1.891,13        # Standard Chilean format
        # 10.336,75       # Large amounts with proper formatting
        # $5.000.000      # Currency with dots
        # $2,500,000      # Currency with commas
        # 15000,50        # Large amounts with mandatory decimals
        
        # "ccosto": re.compile(r"\b(32|31)\d{6}\b", FLAGS), # 32126971 31916001
        # # "Numero_cuentas": re.compile(r"\b\d{10}\b", FLAGS), # 10 consecutive digits 9999999901 3201101000 3103910301
        # "Numero_cuentas": re.compile(r"\b(?:3[1-6]|4[014]|5[12]|6[67]|99)\d{8}\b", FLAGS), #  strict with structure
        # # "Numero_cuentas": re.compile(r"\b(?:31|32|33|34|35|36|41|44|51|52|66|67|99)\d{8}\b", FLAGS), # Based on the examples provided
    }
    
    # ============================================================================
    # Country-to-Identity Number Mapping
    # Maps countries to their valid identity number types for filtering
    # ============================================================================
    COUNTRY_IDENTITY_MAP = {
        'Brasil': {'CPF', 'CPF_Context', 'CNPJ', 'CNPJ_Context'},
        'Chile': {'RUT', 'RUT_Context', 'RUT_Comma', 'PartialRUT_Context'},
        'Colombia': {'CC', 'CC_Context'},
        'Uruguay': {'CI', 'CI_Context'}
    }
    
    # Reverse mapping: Identity type -> Country (for quick lookups)
    IDENTITY_TO_COUNTRY = {}
    for _country, _identity_types in COUNTRY_IDENTITY_MAP.items():
        for _identity_type in _identity_types:
            IDENTITY_TO_COUNTRY[_identity_type] = _country
    
    # Comprehensive Latin American/Spanish first names for validation
    # This unified list includes first names and names commonly used as second/middle names.
    COMMON_NAMES = {
    # Masculine names (normalized to lowercase for matching)
    "aaron", "abel", "adolfo", "adrian", "agustín", "agustin", "alan", "alberto", "alejandro", "alonso", 
    "álvaro", "alvaro", "andrés", "andres", "ángel", "angel", "antonio", "ariel", "armando", "arturo", 
    "áxel", "axel", "bautista", "benjamín", "benjamin", "benito", "bernardo", "bruno", "bryan", "caleb", 
    "camilo", "carlos", "césar", "cesar", "claudio", "cristian", "cristián", "cristóbal", "cristobal", 
    "damián", "damian", "daniel", "dante", "darío", "dario", "david", "demian", "diego", "dylan", 
    "eduardo", "elías", "elias", "emiliano", "emilio", "emmanuel", "enrique", "enzo", "eric", "ernesto", 
    "esteban", "ethan", "eugenio", "ezequiel", "fabián", "fabian", "fabricio", "federico", "felipe", 
    "fermin", "fernando", "francisco", "franco", "gabriel", "gael", "gaspar", "gastón", "gaston", 
    "gerardo", "germán", "german", "gonzalo", "gregorio", "guillermo", "gustavo", "héctor", "hector", 
    "hernán", "hernan", "horacio", "hugo", "ian", "ignacio", "iker", "isaac", "isidoro", "ismael", 
    "iván", "ivan", "jacobo", "jaime", "jair", "jairo", "jason", "javier", "jeremy", "jerónimo", "jeronimo",
    "jesús", "jesus", "jhon", "joaquín", "joaquin", "joel", "jorge", "josé", "jose", "josué", "josue", 
    "juan", "julián", "julian", "julio", "kevin", "kian", "lautaro", "lázaro", "lazaro", "leandro", 
    "león", "leon", "leonardo", "liam", "lorenzo", "lucas", "lucca", "luciano", "luis", "manuel", 
    "marcelo", "marco", "marcos", "mariano", "mario", "martín", "martin", "mateo", "matías", "matias", 
    "mauricio", "maximiliano", "máximo", "maximo", "miguel", "nahuel", "nicolás", "nicolas", "noah", 
    "octavio", "oliver", "omar", "orlando", "óscar", "oscar", "osvaldo", "pablo", "patricio", "paulo", 
    "pedro", "rafael", "ramiro", "ramón", "ramon", "raúl", "raul", "renato", "ricardo", "roberto", 
    "rodrigo", "rogelio", "román", "roman", "rubén", "ruben", "salvador", "samuel", "santiago", 
    "saúl", "saul", "sebastián", "sebastian", "sergio", "silvestre", "simón", "simon", "thiago", 
    "thiago", "tobías", "tobias", "tomás", "tomas", "valentino", "valentin", "vicente", "víctor", "victor", 
    "walter", "wilson", "xabier", "xander", "xavier", "zacarías", "zacarias", "zahir",
    
    # Most common Brazilian masculine names (90% coverage)
    "josé", "jose", "joão", "joao", "antônio", "antonio", "francisco", "carlos", "paulo", "pedro",
    "miguel", "andré", "andre", "rafael", "fernando", "bruno", "daniel", "lucas", "marcos", "mateus",
    "gabriel", "felipe", "gonçalo", "goncalo", "gustavo", "diego", "rodrigo", "ricardo", "márcio", "marcio",
    "luiz", "luis", "vítor", "vitor", "clemente", "manuel", "joaquim", "amaro", "amâncio", "amancio",
    "álvaro", "alvaro", "amilton", "amparo", "anatole", "angelo", "antenor", "antero", "aristeu",
    "arley", "arnaldo", "arnobil", "arnoldo", "artur", "arturzinho", "ascânio", "ascanio",

    # Feminine names (normalized to lowercase for matching)
    "abigail", "abril", "adriana", "agustina", "ainhoa", "aitana", "alba", "alejandra", "alexa", 
    "alexandra", "alma", "almendra", "amanda", "amparo", "ana", "anaís", "anais", "andrea", "ángela", 
    "angela", "angélica", "angelica", "antonella", "antonia", "arantxa", "ariadna", "ariana", "aroha", 
    "astrid", "aurora", "azul", "bárbara", "barbara", "beatriz", "belén", "belen", "bianca", "blanca", 
    "brisa", "camila", "candela", "carla", "carlota", "carmen", "carolina", "catalina", "cecilia", 
    "celeste", "celia", "clara", "claudia", "constanza", "cristina", "daniela", "danna", "daphne", 
    "débora", "debora", "denisse", "diana", "dolores", "dominique", "dulce", "elena", "elisa", 
    "elizabeth", "eloisa", "elsa", "emilia", "emma", "esmeralda", "esperanza", "estefanía", "estefania", 
    "estela", "ester", "esther", "eugenia", "eva", "fabiola", "fátima", "fatima", "fernanda", "florencia", 
    "francisca", "frida", "gabriela", "genny", "génesis", "genesis", "gimena", "giovanna", "gisela", 
    "gloria", "graciela", "guadalupe", "helena", "indira", "inés", "ines", "irene", "iris", "isabel", 
    "isabella", "isidora", "ivanna", "jacinta", "javiera", "jazmín", "jazmin", "jenifer", "jennifer", 
    "jimena", "josefa", "josefina", "juana", "juanita", "judith", "julia", "julieta", "karina", 
    "karla", "katia", "kiara", "lara", "laura", "layla", "leire", "leonor", "leticia", "lila", "lilia", 
    "liliana", "lina", "lola", "lorena", "lourdes", "lucía", "lucia", "luciana", "luisa", "luna", 
    "luz", "macarena", "magdalena", "maia", "maite", "manuela", "marcela", "margarita", "maría", "maria",
    "mariana", "maribel", "marina", "marisol", "marta", "martina", "matilda", "maya", "mercedes", 
    "mía", "mia", "micaela", "mila", "milagros", "mireya", "miriam", "mónica", "monica", "montserrat", 
    "nadia", "nahia", "natalia", "nayara", "nerea", "nicole", "nieves", "noa", "noelia", "noemí", "noemi",
    "norma", "olivia", "paloma", "pamela", "paola", "paula", "paulina", "paz", "penélope", "penelope", 
    "pilar", "raquel", "rebeca", "regina", "renata", "rocío", "rocio", "romina", "rosa", "rosalía", 
    "rosalia", "rosario", "roxana", "ruth", "sabrina", "salomé", "salome", "samantha", "sandra", 
    "sara", "sarah", "silvia", "sofía", "sofia", "sol", "soledad", "sonia", "susana", "tamara", 
    "tatiana", "teresa", "valentina", "valeria", "vania", "verónica", "veronica", "victoria", 
    "violeta", "viviana", "ximena", "xiomara", "yamila", "yanina", "yasmin", "yasna", "yenifer", 
    "yessica", "yolanda", "zoe", "zoë",
    
    # Most common Brazilian feminine names (90% coverage)
    "maria", "josé", "joão", "antônio", "francisco", "carla", "carlos", "paula", "paulo", "petra",
    "pedro", "micaela", "miguel", "andreia", "andré", "rafaela", "rafael", "fernanda", "fernando",
    "bruna", "bruno", "daniela", "daniel", "lúcia", "lucia", "lucas", "márcia", "marcia", "márcio",
    "marcos", "matilde", "mateus", "gabriela", "gabriel", "felícia", "felicia", "felipe", "gisele",
    "gonçalo", "goncalo", "gustava", "gustavo", "diega", "diego", "rodriga", "rodrigo", "ricarda",
    "ricardo", "luiza", "luiz", "luis", "vitoriana", "vítor", "vitor", "clementina", "clemente",
    "manuella", "manuel", "josefina", "joaquim", "álvara", "alvara", "álvaro", "alvaro", "amelia",
    "amilton", "ampara", "amparo", "anatolia", "anatole", "angélica", "angelica", "angelo", "antena",
    "antenor", "antera", "antero", "aristeia", "aristeu", "arlete", "arley", "arnalda", "arnaldo",
    "arnobalda", "arnobil", "arnolda", "arnoldo",


    "abigail", "abril", "adriana", "agustina", "ainhoa", "aitana", "alba", "alejandra", "alexa", 
    "alexandra", "alma", "almendra", "amanda", "amparo", "ana", "anaís", "anais", "andrea", "ángela", 
    "angela", "angélica", "angelica", "antonella", "antonia", "arantxa", "ariadna", "ariana", "aroha", 
    "astrid", "aurora", "azul", "bárbara", "barbara", "beatriz", "belén", "belen", "bianca", "blanca", 
    "brisa", "camila", "candela", "carla", "carlota", "carmen", "carolina", "catalina", "cecilia", 
    "celeste", "celia", "clara", "claudia", "constanza", "cristina", "daniela", "danna", "daphne", 
    "débora", "debora", "denisse", "diana", "dolores", "dominique", "dulce", "elena", "elisa", 
    "elizabeth", "eloisa", "elsa", "emilia", "emma", "esmeralda", "esperanza", "estefanía", "estefania", 
    "estela", "ester", "esther", "eugenia", "eva", "fabiola", "fátima", "fatima", "fernanda", "florencia", 
    "francisca", "frida", "gabriela", "genny", "génesis", "genesis", "gimena", "giovanna", "gisela", 
    "gloria", "graciela", "guadalupe", "helena", "indira", "inés", "ines", "irene", "iris", "isabel", 
    "isabella", "isidora", "ivanna", "jacinta", "javiera", "jazmín", "jazmin", "jenifer", "jennifer", 
    "jimena", "josefa", "josefina", "juana", "juanita", "judith", "julia", "julieta", "karina", 
    "karla", "katia", "kiara", "lara", "laura", "layla", "leire", "leonor", "leticia", "lila", "lilia", 
    "liliana", "lina", "lola", "lorena", "lourdes", "lucía", "lucia", "luciana", "luisa", "luna", 
    "luz", "macarena", "magdalena", "maia", "maite", "manuela", "marcela", "margarita", "maría", "maria",
    "mariana", "maribel", "marina", "marisol", "marta", "martina", "matilda", "maya", "mercedes", 
    "mía", "mia", "micaela", "mila", "milagros", "mireya", "miriam", "mónica", "monica", "montserrat", 
    "nadia", "nahia", "natalia", "nayara", "nerea", "nicole", "nieves", "noa", "noelia", "noemí", "noemi",
    "norma", "olivia", "paloma", "pamela", "paola", "paula", "paulina", "paz", "penélope", "penelope", 
    "pilar", "raquel", "rebeca", "regina", "renata", "rocío", "rocio", "romina", "rosa", "rosalía", 
    "rosalia", "rosario", "roxana", "ruth", "sabrina", "salomé", "salome", "samantha", "sandra", 
    "sara", "sarah", "silvia", "sofía", "sofia", "sol", "soledad", "sonia", "susana", "tamara", 
    "tatiana", "teresa", "valentina", "valeria", "vania", "verónica", "veronica", "victoria", 
    "violeta", "viviana", "ximena", "xiomara", "yamila", "yanina", "yasmin", "yasna", "yenifer", 
    "yessica", "yolanda", "zoe", "zoë",
}

    COMMON_FIRST_NAMES = COMMON_NAMES

    # Common second/middle names for compound names (Juan Carlos, María José, etc.)
    COMMON_SECOND_NAMES = {
        # Masculine second names
        "agustín", "agustin", "alberto", "alejandro", "alfonso", "andrés", "andres", "ángel", "angel", 
        "antonio", "armando", "arturo", "benito", "camilo", "carlos", "david", "diego", "eduardo", "emilio", 
        "enrique", "ernesto", "esteban", "eugenio", "fabián", "fabian", "federico", "felipe", "fernando", 
        "francisco", "gabriel", "gerardo", "gonzalo", "guillermo", "gregorio", "héctor", "hector", "hugo", 
        "ignacio", "javier", "jesús", "jesus", "joaquín", "joaquin", "jorge", "josé", "jose", "juan", 
        "julián", "julian", "julio", "laureano", "lorenzo", "lucas", "luis", "manuel", "marcelo", "marcos", 
        "mariano", "mario", "martín", "martin", "miguel", "nicolás", "nicolas", "octavio", "oscar", "óscar", 
        "pablo", "pascual", "patricio", "pedro", "ramón", "ramon", "rafael", "raúl", "raul", "ricardo", 
        "roberto", "rodrigo", "rubén", "ruben", "salvador", "santiago", "sebastián", "sebastian", "sergio", 
        "tomás", "tomas", "vicente", "víctor", "victor",

        # Feminine second names
        "alejandra", "alicia", "amparo", "ana", "ángeles", "angeles", "antonia", "aurora", "beatriz", 
        "belén", "belen", "candelaria", "caridad", "carmen", "carolina", "catalina", "cecilia", "concepción", 
        "concepcion", "consuelo", "cristina", "cruz", "de", "del", "dolores", "elena", "elisa", "elizabeth", 
        "encarnacion", "esperanza", "ester", "eugenia", "fatima", "fe", "fernanda", "francisca", "gloria", 
        "gracia", "guadalupe", "inmaculada", "inés", "ines", "isabel", "javiera", "jesús", "jesus", 
        "josefa", "josé", "jose", "julia", "laura", "loreto", "lourdes", "lucía", "lucia", "luisa", "luz", 
        "magdalena", "manuela", "mar", "marcela", "margarita", "maría", "maria", "marta", "mercedes", 
        "milagros", "mónica", "monica", "montserrat", "nieves", "paloma", "patricia", "paz", "pilar", 
        "raquel", "rebeca", "remedios", "reyes", "rocío", "rocio", "rosa", "rosario", "soledad", "sofía", 
        "sofia", "susana", "teresa", "trinidad", "verónica", "veronica", "victoria", "virginia",
    }
    
    # Common Chilean and Latin American surnames for validation
    # Expanded to include common surnames from Chile, Argentina, Brazil, Mexico, and Uruguay.
    COMMON_SURNAMES = {
    # Common in Chile & Spanish-speaking countries
    "gonzález", "gonzalez", "muñoz", "munoz", "rojas", "díaz", "diaz", "pérez", "perez", "soto", "contreras",
    "silva", "martínez", "martinez", "sepúlveda", "sepulveda", "morales", "rodríguez", "rodriguez", "lópez",
    "lopez", "fuentes", "hernández", "hernandez", "torres", "araya", "flores", "espinoza", "valenzuela",
    "castillo", "tapia", "reyes", "ortega", "rubio", "núñez", "nunez", "jara", "guerrero", "medina",
    "cáceres", "caceres", "vergara", "campos", "vásquez", "vasquez", "pizarro", "alarcón", "alarcon",
    "mendoza", "sandoval", "bravo", "herrera", "cortés", "cortes", "espinosa", "vargas", "carrasco",
    "ramos", "peña", "pena", "garcía", "garcia", "moreno", "jiménez", "jimenez", "navarro", "ruiz",
    "gutiérrez", "gutierrez", "romero", "álvarez", "alvarez", "gómez", "gomez", "sánchez", "sanchez",
    "ramírez", "ramirez", "cruz", "molina", "castro", "ortiz", "delgado", "salazar", "garrido",
    "sanhueza", "poblete", "cifuentes", "cornejo", "parra", "acuña", "rios", "ríos", "vera",
    "villablanca", "henríquez", "henriquez", "jorquera", "larraín", "larrain", "kuncar", "hirmas",
    "vega", "salgado", "aguirre", "bustos", "cárcamo", "carcamo", "figueroa", "gálvez", "galvez",
    "olivares", "pavez", "valdés", "valdes", "yáñez", "yanez", "toro",

    # Common in Argentina
    "fernández", "fernandez", "giménez", "gimenez", "sosa", "cabrera", "acosta", "goyeneche",

    # Common in Mexico
    "chávez", "chavez", "domínguez", "dominguez", "vázquez", "vazquez", "juárez", "juarez",

    # Common in Uruguay
    "pereira", "diaz", "olivera", "suarez", "ferreira", "acosta", "correa", "suárez",

    # Common in Brazil (Portuguese)
    "santos", "oliveira", "souza", "rodrigues", "ferreira", "alves", "pereira", "lima", "gomes",
    "costa", "ribeiro", "martins", "carvalho", "araujo", "melo", "barbosa", "teixeira", "nascimento",
    "coelho", "cardoso", "pinto", "cunha",
}

class ExclusionLists:
    """
    Centralized exclusion patterns and validation utilities for PII detection.
    
    This class consolidates all exclusion logic used across different PII detectors
    to maintain consistency and avoid duplication. It provides normalized caches
    and utility methods for efficient, accent-insensitive matching.
    
    Categories:
    1. FORM_FIELD_PATTERNS: Demographics and form field labels
    2. SPANISH_ADVERBS: Temporal adverbs ending in -mente
    3. BUSINESS_PROCESS_TERMS: Administrative and process-related words
    4. FINANCIAL_DOMAIN_TERMS: Insurance, pension, banking terms
    5. ORGANIZATIONAL_TERMS: Job titles, departments, company terms
    6. TECHNICAL_TERMS: System, software, file-related terms
    7. OCR_ARTIFACTS: ML transformer false positives and OCR system errors
    8. MULTI_WORD_EXCLUSIONS: Exact multi-word phrase exclusions (avoids blocking individual names)
    9. TRUNCATED_PATTERNS: Incomplete words from OCR errors
    
    Usage:
        if ExclusionLists.is_excluded_word("contingent"):  # True
        if ExclusionLists.is_excluded_phrase("CREACIÓN PÓLIZAS"):  # True
        clean_tokens = ExclusionLists.strip_trailing_terms(["Juan", "Pérez", "Contingent"])  # ["Juan", "Pérez"]
    """
    
    # Form field patterns and demographic terms
    FORM_FIELD_PATTERNS = {
        "CONYUGE", "CONYUGUE", "HIJOS", "FEMENINO", "MASCULINO", "SOLTERO", "CASADO", 
        "DIVORCIADO", "VIUDO", "ESTADO CIVIL", "BENEFICIARIOS", "TITULAR", "ASEGURADO", 
        "COTIZANTE", "APELLIDO", "NOMBRE", "PATERNO", "MATERNO", "FECHA", "NACIMIENTO",
        "TELEFONO", "DIRECCION", "DOMICILIO", "DOCUMENTO", "CEDULA", "PASAPORTE", "SEXO",
        "EDAD", "EMAIL", "CORREO", "CIUDAD", "COMUNA", "PAIS", "PAÍS", "PROVINCIA", "REGION", "REGIÓN",
        "CÓDIGO POSTAL", "CODIGO POSTAL", "ZIP", "Cantidad"
        # Portuguese equivalents
        "CÔNJUGE", "CONJUGE", "FILHOS", "FEMININO", "MASCULINO", "SOLTEIRO", "CASADO",
        "DIVORCIADO", "VIÚVO", "VIUVO", "ESTADO CIVIL", "BENEFICIÁRIOS", "BENEFICIARIOS", "TITULAR", "SEGURADO",
        "CONTRIBUINTE", "SOBRENOME", "NOME", "PAI", "MÃE", "MAE", "DATA", "NASCIMENTO", "NASCENÇA",
        "TELEFONE", "ENDEREÇO", "ENDERECO", "DOMICÍLIO", "DOMICILIO", "DOCUMENTO", "CPF", "PASSAPORTE", "RG",
        "IDADE", "EMAIL", "CORREIO", "CIDADE", "MUNICÍPIO", "MUNICIPIO", "PAÍS", "PAIS", "ESTADO", "REGIÃO", "REGIAO",
        "CEP", "CÓDIGO POSTAL", "CODIGO POSTAL", "Quantidade"
    }
    
    # Spanish temporal adverbs (commonly misidentified as names by ML)
    SPANISH_ADVERBS = {
        "posteriormente", "anteriormente", "finalmente", "inicialmente", "actualmente",
        "principalmente", "especialmente", "particularmente", "generalmente", "normalmente",
        "regularmente", "frecuentemente", "ocasionalmente", "raramente", "constantemente",
        "simultaneamente", "inmediatamente", "completamente", "exactamente", "perfectamente",
        "totalmente", "absolutamente", "relativamente", "efectivamente", "prácticamente",
        "teóricamente", "básicamente", "fundamentalmente", "esencialmente", "simplemente",
        "claramente", "evidentemente", "obviamente", "sencillamente", "rápidamente", "lentamente",
        "cuidadosamente", "precisamente", "detenidamente", "minuciosamente", "meticulosamente",
        "excepcionalmente", "notablemente", "significativamente", "considerablemente", "sustancialmente",
        "moderadamente", "ligeramente", "parcialmente", "comúnmente", "habitualmente", "usualmente",
        "frecuentemente", "ocasionalmente", "eventualmente", "temporalmente", "permanentemente",
        "definitivamente", "progresivamente", "gradualmente", "continuamente", "constantemente",
        "simultáneamente", "inmediatamente", "directamente", "indirectamente", "consecuentemente",
        "resultantemente", "subsiguientemente", "sucesivamente", "secuencialmente",
        # Portuguese adverbs
        "posteriormente", "anteriormente", "finalmente", "inicialmente", "atualmente",
        "principalmente", "especialmente", "particularmente", "geralmente", "normalmente",
        "regularmente", "frequentemente", "ocasionalmente", "raramente", "constantemente",
        "simultaneamente", "imediatamente", "completamente", "exatamente", "perfeitamente",
        "totalmente", "absolutamente", "relativamente", "efetivamente", "praticamente",
        "teoricamente", "basicamente", "fundamentalmente", "essencialmente", "simplesmente",
        "claramente", "evidentemente", "obviamente", "singularmente", "rapidamente", "lentamente",
        "cuidadosamente", "precisamente", "detidamente", "minuciosamente", "meticulosamente",
        "excepcionalmente", "notavelmente", "significativamente", "consideravelmente", "substancialmente",
        "moderadamente", "levemente", "parcialmente", "comumente", "habitualmente", "usualmente",
        "frequentemente", "ocasionalmente", "eventualmente", "temporalmente", "permanentemente",
        "definitivamente", "progressivamente", "gradualmente", "continuamente", "constantemente",
        "simultaneamente", "imediatamente", "diretamente", "indiretamente", "consequentemente",
        "resultantemente", "subsequentemente", "sucessivamente", "sequencialmente"
    }
    
    # Business and administrative process terms
    BUSINESS_PROCESS_TERMS = {
        "administracion", "adminiatracion", "centralizacion", "administrador", "beneficiarios",
        "tramitacion", "liquidacion", "autorizacion", "validacion", "verificacion", 
        "procesamiento", "documentacion", "planificacion", "organizacion", "coordinacion",
        "supervision", "evaluacion", "configuracion", "instalacion", "actualizacion",
        "migracion", "implementacion", "integracion", "optimizacion", "personalizacion",
        "automatizacion", "sincronizacion", "presionamos", "arrastrando", "continuamos",
        "seleccionamos", "aceptamos", "realizamos", "completamos", "procesamos",
        "verificamos", "confirmamos", "ejecutamos", "terminamos", "validamos",
        "revisamos", "enviamos", "recibimos","recamas","recamos", "req", "main", "dinamica",
        "dinámicas", "actualiza", "actualiza", "actualízala", "actualízalo", "actualízame", "actualizalo", "actualizame",
        "centraliza", "centralízala", "centralízalo", "centralízame", "centralizalo", "centralizame",
        "administra", "admínistrala", "admínistralo", "adm","cional", "este", "esa", "aquel",
        "aquella", "aquello", "administralo", "administrame", "admin", "riesgo", "riesgos", "uncia",
        "mandata", "pac", "pat", "biometria", "biometría", "mandato", "biometr", "din", "ncia",
        "actualizar", "centralizar", "administrar", "validar", "verificar", "procesar", "confirmar",
        "finalizar", "continuar", "cancelar", "aceptar", "rechazar", "generar", "realizar", "completar", "procesar", "revisar",
        "enviar", "recibir", "terminar", "finalizar", "proceso", "flujo", "workflow", "paso", "steps", "step",
        "formulario", "form", "doc", "documento", "docs", "documentos", "plantilla", "template", "cargar", "descargar", "subir", "bajar",
        "upload", "download", "iniciar", "inicio", "comenzar", "empezar", "finalizar", "terminar", "completar", "guardar", "save",
        "modulo", "módulo", "seccion", "sección", "apartado", "panel", "boton", "botón", "click", "doble", "seleccionar", "selección",
        "navegar", "navegador", "browser", "internet", "red", "conexión", "conexion", "servidor", "server", "base", "datos", "database",
        "backup", "restaurar", "actualizar", "update", "instalar", "desinstalar", "error", "fallo", "problema", "solución", "solucion",
        "debug", "registro", "log", "script", "código", "codigo", "programador", "desarrollador", "developer", "tester", "qa", "calidad",
        "release", "deploy", "implementacion", "implementación", "sprint", "agile", "scrum", "kanban",
        "automatizacion", "automatización", "word", "excel", "pdf", "csv", "xml", "json",
        "informe", "report", "reports", "exportar", "importar","unificado", "unificada",
        "ejecutar", "ahora", "unificar", "unificación", "unificacion", "crear", "dinamizar",
        "creacion", "creación", "modificar", "modificacion", "mod", "men", "tablas", "tabla",
        "observaciones", "observación", "observacion", "anular", "anulación", "anulacion", "anulado", "anulada",
        "notas", "nota", "comentarios", "comentario", "observar", "incumplimiento", "normativo", "normativa",
        "claims", "claim", "reclamo", "reclamos", "reclamación", "reclamacion", "incumplir", "Recepcionado",
        "recepcionado", "recepcionada", "Recepcionada", "validado",
        # NEW: Additional exclusions for common false positives
        "sponsor", "sponsors", "patrocinador", "patrocinadores", "fechadepago", "fecha", "pago",
        "importe", "importes", "pagado", "pagados", "realizo", "realizó", "erroneo", "errónea",
        "erronea", "erróneos", "pag", "nro", "num", "numero", "número", "esta", "está",
        # Common Spanish articles, prepositions, and conjunctions (prevent false positives)
        "del", "los", "las", "que", "con", "por", "para", "sin", "sobre", "desde", "hasta",
        "entre", "hacia", "bajo", "tras", "durante", "mediante", "según", "excepto", "salvo",
        # CamelCase business/technical terms (to catch false positives like "TipoCredito")
        "tipocredito", "tipo_credito", "tipoloan", "tipo_loan", "creditotype", "loantype",
        "producttype", "tipoproducto", "tipo_producto", "tipoasegurado", "tipo_asegurado",
        "tipoafiliado", "tipo_afiliado", "statuscode", "statuscredito", "statusasegurado",
        "codigoestado", "codigo_estado", "tipostatus", "tipo_status", "codigocliente",
        "codigo_cliente", "tipocontrato", "tipo_contrato", "contracttype", "tiposervicio",
        "tipo_servicio", "servicetype", "tipoplan", "tipo_plan", "plantype", "tiporiesgo",
        "tipo_riesgo", "risktype", "tipomoneda", "tipo_moneda", "currencytype", "tipoperiodo",
        "tipo_periodo", "periodtype", "fieldname", "fieldcode", "fieldtype", "fieldvalue",
        "campopropiedad", "fieldproperty", "datatype", "tipodato", "tipo_dato", "Herramientas",
        "Rescate", "rescate", "Liquidacion", "liquidacion", "Liquidação", "Pólizas", "Polizas",
        "Póliza", "Poliza", "Primas", "primas", "liquidador", "devengo", "retenciones", "provision", "terminados", "pendientes",
        "estados", "liquidados", "gestion", "solicitada", "desgravamen", "tratamiento",
        "periodo", "liberacion", "complementario", "producto", "honorarios", "mantencion",
        "vejez", "garantizada", "inmediata", "prioridad", "normal", "post", "venta",
        "colectivo", "masivos", "antecedentes", "client", "gasto", "hospitalar", "journal",
        "sheet", "sheets", "header", "line", "lines", "clente", "distribucion", "ificados",
        "cotizacion", "factura", "cargas", "cheques", "atencion", "genera", "muchas",
        "gracias", "gracias", "pestana", "cambiar", "nueva", "resumen", "accion", "razon",
        "cotens", "beneficia", "interno", "postales", "asistenc", "captiva", "comun", "produ",
        "aporte", "isap", "seles", "force", "clinica", "nois", "carta", "gant", "rechaz",
        "pencon", "tlmkf", "mto", "aseg", "lta",
        
        
        
        
        # Portuguese business process terms
        "administração", "administracao", "centralizacao", "centralizaçao", "administrador", "beneficiários", "beneficiarios",
        "tramitação", "tramitacao", "liquidação", "liquidacao", "autorização", "autorizacao", "validação", "validacao",
        "verificação", "verificacao", "processamento", "documentação", "documentacao", "planejamento", "planejamento",
        "organização", "organizacao", "coordenação", "coordenacao", "supervisão", "supervisao", "avaliação", "avaliacao",
        "configuração", "configuracao", "instalação", "instalacao", "atualização", "atualizacao", "migração", "migracao",
        "implementação", "implementacao", "integração", "integracao", "otimização", "otimizacao", "personalização", "personalizacao",
        "automatização", "automatizacao", "sincronização", "sincronizacao", "pressionar", "arrastrar", "continuar",
        "selecionar", "aceitar", "realizar", "completar", "processar", "verificar", "confirmar", "executar", "terminar",
        "validar", "revisar", "enviar", "receber", "terminar", "processo", "fluxo", "workflow", "passo", "steps", "step",
        "formulário", "formulario", "form", "doc", "documento", "docs", "documentos", "modelo", "template", "carregar",
        "descarregar", "subir", "baixar", "upload", "download", "iniciar", "início", "inicio", "começar", "completar",
        "guardar", "save", "módulo", "modulo", "secção", "secao", "seccion", "apartado", "painel", "panel", "botão", "botao",
        "click", "duplo", "seleccionar", "seleção", "selecao", "navegar", "navegador", "browser", "internet", "rede", "conexão",
        "conexao", "servidor", "server", "base", "dados", "database", "backup", "restaurar", "atualizar", "update", "instalar",
        "desinstalar", "erro", "falha", "problema", "solução", "solucao", "debug", "registro", "log", "script", "código",
        "codigo", "programador", "desenvolvedor", "developer", "testador", "tester", "qa", "qualidade", "release", "deploy",
        "sprint", "agile", "scrum", "kanban", "relatório", "relatorio", "report", "reports", "exportar", "importar",
        "unificado", "unificada", "unificação", "unificacao", "criar", "dinamizar", "criação", "criacao", "modificar",
        "modificação", "modificacao", "observações", "observacoes", "observação", "observacao", "anular", "anulação",
        "anulacao", "anulado", "anulada", "notas", "nota", "comentários", "comentarios", "comentário", "comentario",
        "observar", "incumprimento", "normativo", "normativa", "reivindicação", "reivindicacao", "reivindicação",
        "reclamação", "reclamacao", "incumprir", "patrocinador", "patrocinadores", "data", "pagamento", "pagamentos",
        "pago", "pagos", "realizado", "realizada", "errôneo", "erroneo", "errada", "errado", "errados", "número", "numero",
        # Common Portuguese articles, prepositions, and conjunctions
        "do", "da", "das", "os", "as", "que", "com", "por", "para", "sem", "sobre", "desde", "até", "entre", "em",
        "durante", "mediante", "segundo", "exceto", "salvo", "além", "de", "até", "antes", "depois",
        "liquidador", "devengo", "retencoes", "provisao", "terminados", "pendentes",
        "estados", "liquidados", "gestao", "solicitada", "desgravamen", "tratamento",
        "periodo", "libertacao", "complementario", "produto", "honorarios", "manutencao",
        "velhice", "garantida", "imediata", "prioridade", "normal", "pos", "venda",
        "coletivo", "massivos", "antecedentes", "cliente", "gasto", "hospitalar", "diario",
        "folha", "cabecalho", "linha", "cliente", "distribuicao", "qualificado", "cotacao",
        "fatura", "cargas", "cheques", "atencao", "gera", "muito", "obrigado", "abas",
        "mudar", "novo", "resumo", "acao", "razao", "cotenss", "beneficio", "interno",
        "postais", "assistencia", "captiva", "comum", "produc", "aporte", "isap", "selec",
        "forca", "clinica", "cartas", "garantia", "rejeitar", "pencon",
    } 
    
    
    # Financial and insurance domain terms
    FINANCIAL_DOMAIN_TERMS = {
        "vitalicias", "vitalicia", "poliza", "polizas", "primas", "cobertura", "deducible",
        "siniestro", "reclamo", "reembolso", "indemnizacion", "beneficio", "renta", "mensual", 
        "pension", "jubilacion", "ahorro", "seguro", "seguros", "cotizacion", "afiliado", 
        "prima", "uf", "superintendencia", "fonasa", "isapre", "afp", "cuprum", "habitat", 
        "provida", "planvital", "modelo", "capital", "uno", "chile", "ips", "scomp", 
        "compañia", "aseguradora", "diferido", "intermediario", "garantizado", "solicitud",
        "endosos", "clausula", "articulo", "modalidad", "periodo", "valor", "tasa",
        "descuento", "cierre", "casos", "cerrados", "recupera", "reporte", "exporta",
        "termina", "ready", "procesar", "imprime", "concluido", "pago","monto", "tipo",
        "Tributario", "producto", "prestamo", "financiamiento", "interes", "parcela", "parcelado",
        "credito", "debito", "saldo", "extracto", "transferencia","Único",
        # Portuguese financial domain terms
        "vitalícias", "vitalicia", "apólice", "apolice", "apólices", "apolices", "prêmios", "premios",
        "cobertura", "dedutível", "dedutivel", "sinistro", "reivindicação", "reivindicacao", "reembolso",
        "indenização", "indenizacao", "benefício", "beneficio", "renda", "mensal", "pensão", "pensao",
        "aposentadoria", "aposentacion", "poupança", "poupanca", "seguro", "seguros", "cotização", "cotizacao",
        "afiliado", "filiado", "afiliada", "filiada", "prêmio", "premio", "superintendência", "superintendencia",
        "caixa", "inss", "cuprum", "habitat", "provida", "modelo", "capital", "brasil", "ips", "scomp",
        "companhia", "seguradora", "diferido", "intermediário", "intermediario", "garantido", "garantida",
        "solicitação", "solicitacao", "endossos", "endosso", "cláusula", "clausula", "artigo", "modalidade",
        "período", "periodo", "valor", "taxa", "desconto", "fechamento", "fechamento", "fechada", "recuperação",
        "recuperacao", "relatório", "relatorio", "exportação", "exportacao", "importação", "importacao",
        "termina", "pronto", "processar", "imprime", "concluído", "concluido", "pagamento", "montante",
        "tipo", "produto", "empréstimo", "emprestimo", "financiamento", "juros", "parcela", "parcelado",
        "crédito", "credito", "débito", "debito", "saldo", "extrato", "transferência", "transferencia",
        "depósito", "deposito", "saque", "conta", "contabilidade", "contabilizacao", "provisão", "provisao",
        "reserva", "caixa", "tesouraria", "tesoraria", "auditoria", "compliance", "risco", "riscos"
    }
    
    # Organizational and job-related terms
    ORGANIZATIONAL_TERMS = {
        "contingent", "contingente", "inc", "ltd", "sa", "s.a.", "group", "division", 
        "división", "department", "departamento", "team", "equipo", "unit", "unidad",
        "service", "servicio", "agency", "agencia", "cont.", "worker", "trabajador",
        "employee", "empleado", "manager", "gerente", "director", "supervisor", "analista",
        "asignada", "asignado", "deputy", "directiva", "dental", "area", "banco", "branch",
        "oficina", "regional", "corporativo", "corporation", "company", "compañía",
        "enterprise", "firma", "subsidiary", "filial", "headquarters", "sucursal",
        "adjunto", "anexo", "firmado", "signature", "firma", "rh", "recursos humanos",
        "talento humano", "talento", "humanos", "payroll", "nómina", "nomina",
        # Portuguese organizational terms
        "empresa", "sociedade", "departamento", "equipe", "unidade", "serviço", "servico",
        "agência", "agencia", "funcionário", "funcionaria", "trabalhador", "trabalhadora",
        "empregado", "empregada", "gerência", "gerencia", "diretor", "diretora", "supervisor", "supervisora",
        "analista", "coordenador", "coordenadora", "assinado", "assinada", "intermediário", "intermediaria",
        "divisão", "divisao", "sede", "filial", "matriz", "corporativo", "corporativa", "folha de pagamento",
        "talento humano", "gestão de pessoas", "gestao de pessoas", "contratação", "contratacao",
        "demissão", "demissao", "recrutamento", "treinamento", "desenvolvimento", "carreira",
        "cargo", "função", "funcao", "responsabilidade", "atribuição", "atribuicao",
        
    }
    
    # Technical and system terms
    TECHNICAL_TERMS = {
        "sistema", "aplicacion", "programa", "software", "version", "configuracion",
        "usuario", "usuarios", "sesion", "login", "logout", "inicio", "termino",
        "finalizar", "continuar", "cancelar", "aceptar", "rechazar", "confirmar",
        "verificar", "validar", "generar", "crear", "modificar", "eliminar", "buscar",
        "consultar", "seleccionar", "filtrar", "datos", "informacion", "archivo",
        "control", "ayuda", "registros", "ventana", "campos", "muestra", "ejemplo",
        "proceso", "resultado", "posterior", "anterior", "acceso", "ingreso", "valido",
        "invalido", "admin", "modulo", "digital", "menu", "opcion", "opciones",
        "soporte", "tecnico", "tecnica", "documento", "formulario", "plantilla",
        "carga", "descarga", "subida", "bajada", "upload", "download", "click", "doble",
        "seleccion", "navegador", "browser", "internet", "red", "conexion", "conexión",
        "servidor", "server", "base", "datos", "database", "backup", "restaurar",
        "actualizar", "update", "instalar", "desinstalar", "error", "fallo", "problema",
        "solucion", "solución", "debug", "log", "registro", "script", "codigo", "código",
        "programador", "desarrollador", "developer", "tester", "qa", "calidad", "release",
        "deploy", "implementacion", "implementación", "sprint", "agile", "scrum", "kanban",
        "script", "automatizacion", "automatización", "word", "excel", "pdf", "csv", "xml", "json",
        "Citri", "Xenapp", "VPN", "virtual", "remoto", "remote", "intranet", "firewall", "antivirus",
        "proxy", "cloud", "nube", "servidores", "datacenter", "data center", "mainframe", "sistema operativo",
        "hardware", "software", "aplicación", "aplicação", "plataforma", "platform", "interface", "usuario final", "user interface",
        "Portapapeles", "Organizar", "UX", "UI", "experiencia de usuario", "experiência do usuário","Convento","Cínica", 
        "Liquidar", "después", "Contabilizacion", 
        # Portuguese technical terms
        "aplicação", "aplicacao", "versão", "versao", "configuração", "configuracao",
        "sessão", "sessao", "login", "logout", "iniciar", "término", "termino", "finalizar",
        "cancelar", "aceitar", "rejeitar", "confirmar", "verificação", "verificacao",
        "validação", "validacao", "gerar", "criar", "deletar", "excluir", "pesquisar", "buscar",
        "consultar", "selecionar", "filtro", "filtrar", "dados", "informação", "informacao",
        "arquivo", "controle", "ajuda", "registros", "janela", "campos", "amostra",
        "processo", "resultado", "posterior", "anterior", "acesso", "entrada", "ingresso",
        "válido", "valida", "inválido", "invalida", "administrador", "módulo", "modulo",
        "digital", "menu", "opção", "opcao", "opções", "opcoes", "suporte", "técnico", "tecnico",
        "técnica", "tecnica", "documento", "formulário", "formulario", "modelo", "carregamento",
        "carga", "descarregamento", "descarga", "upload", "download", "clique", "seleção", "selecao",
        "navegador", "browser", "internet", "rede", "conexão", "conexao", "servidor", "server",
        "base de dados", "banco de dados", "database", "backup", "restauração", "restauracao",
        "atualizar", "atualização", "atualizacao", "update", "instalar", "instalação", "instalacao",
        "desinstalar", "desinstalação", "desinstalacao", "erro", "falha", "problema", "solução", "solucao",
        "debug", "log", "registro", "script", "código", "codigo", "programador", "desenvolvedor",
        "developer", "testador", "tester", "qa", "qualidade", "release", "implantação", "implantacao",
        "deploy", "implementação", "implementacao", "sprint", "agile", "scrum", "kanban", "integração",
        "integracao", "sincronização", "sincronizacao", "api", "interface", "plugin", "extensão", "extensao",
        "camada", "layer", "banco de dados",
    }

    # Geographic locations (cities) to prevent misclassification as names.
    # This is a more comprehensive list to improve exclusion accuracy.
    GEOGRAPHIC_TERMS = {
        # Chile
        "Arica", "Iquique", "Antofagasta", "Calama", "Copiapó", "Coquimbo", "La Serena",
        "Valparaíso", "Viña del Mar", "Quilpué", "Villa Alemana", "Santiago", "Puente Alto",
        "Maipú", "San Bernardo", "Las Condes", "La Florida", "Peñalolén", "Rancagua",
        "Talca", "Curicó", "Linares", "Chillán", "Concepción", "Talcahuano", "Los Ángeles",
        "Hualpén", "Coronel", "San Pedro de la Paz", "Temuco", "Valdivia", "Osorno",
        "Puerto Montt", "Coyhaique", "Punta Arenas", "San Antonio", "Ovalle", "Quillota",
        "Pudahuel",

        # Argentina
        "Buenos Aires", "Córdoba", "Rosario", "Mendoza", "La Plata", "San Miguel de Tucumán",
        "Mar del Plata", "Salta", "Santa Fe", "San Juan", "Corrientes", "Bahía Blanca",
        "Resistencia", "Posadas", "Paraná", "Neuquén", "Formosa", "San Salvador de Jujuy",
        "Santiago del Estero", "Guaymallén", "Lanús", "Quilmes", "Banfield", "Merlo",
        "San Isidro", "Vicente López", "Avellaneda", "Lomas de Zamora", "La Matanza",
        "Almirante Brown", "Berazategui", "Esteban Echeverría", "Ezeiza", "Florencio Varela",
        "General San Martín", "Hurlingham", "Ituzaingó", "José C. Paz", "Malvinas Argentinas",
        "Moreno", "Morón", "Pilar", "Presidente Perón", "San Fernando", "San Miguel",
        "Tigre", "Tres de Febrero",

        # Brazil
        "São Paulo", "Rio de Janeiro", "Salvador", "Brasília", "Fortaleza", "Belo Horizonte",
        "Manaus", "Curitiba", "Recife", "Goiânia", "Belém", "Porto Alegre", "Guarulhos",
        "Campinas", "São Luís", "São Gonçalo", "Maceió", "Duque de Caxias", "Natal",
        "Campo Grande", "Teresina", "São Bernardo do Campo", "Nova Iguaçu", "João Pessoa",
        "Santo André", "São José dos Campos", "Jaboatão dos Guararapes", "Osasco",
        "Ribeirão Preto", "Uberlândia", "Contagem", "Sorocaba", "Aracaju", "Feira de Santana",
        "Cuiabá", "Joinville", "Juiz de Fora", "Londrina", "Aparecida de Goiânia", "Niterói",
        "Porto Velho", "Ananindeua", "Campos dos Goytacazes", "Belford Roxo", "Serra",
        "Caxias do Sul", "Vila Velha", "Florianópolis", "São João de Meriti", "Mauá",
        "Macapá", "São José do Rio Preto", "Santos", "Mogi das Cruzes", "Diadema",
        "Betim", "Jundiaí", "Carapicuíba", "Maringá", "Montes Claros", "Rio Branco",
        "Piracicaba", "Cariacica", "Bauru", "Itaquaquecetuba", "São Vicente", "Franca",
        "Vitória", "Pelotas", "Canoas", "Ponta Grossa", "Blumenau", "Cascavel",
        "Petrópolis", "Uberaba", "Paulista", "Suzano", "Limeira", "Barueri", "Volta Redonda",
        "Santarém", "Gravataí", "Taubaté", "Governador Valadares", "Foz do Iguaçu",
        "Viamão", "Novo Hamburgo", "Embu das Artes", "Várzea Grande", "Barra Mansa",
        "Praia Grande", "Marília", "Alvorada", "Sumaré", "Santa Maria", "Guarujá",
        "Ipatinga", "Imperatriz", "Jacareí", "Hortolândia", "Rio Verde", "Marabá",
        "Rondonópolis", "Dourados", "Divinópolis", "Presidente Prudente", "Juazeiro do Norte",
        "Sete Lagoas", "Itaboraí", "Chapecó", "Nossa Senhora do Socorro", "Cabo Frio",
        "Itajaí", "Sobral", "Lages", "Palhoça", "Parnamirim", "Criciúma", "Bragança Paulista",
        "Angra dos Reis", "Itabuna", "Alagoinhas", "Uruguaiana", "Passo Fundo", "Arapiraca",
        "Barreiras", "Castanhal", "Luziânia", "Parauapebas", "Teixeira de Freitas",
        "Camaragibe", "Pindamonhangaba", "Cabo de Santo Agostinho", "Garanhuns",
        "Vitória da Conquista", "Ilhéus", "Jequié", "Barbacena", "Poços de Caldas",
        "Pouso Alegre", "Teófilo Otoni", "Varginha", "Conselheiro Lafaiete", "Itabira",
        "Araguaína", "Gurupi", "Palmas",

        # Uruguay
        "Montevideo", "Salto", "Paysandú", "Las Piedras", "Rivera", "Maldonado",
        "Tacuarembó", "Melo", "Mercedes", "Artigas", "Minas", "San José de Mayo",
        "Durazno", "Florida", "Treinta y Tres", "Rocha", "Fray Bentos", "Colonia del Sacramento",
        "Canelones", "Pando", "Carmelo", "Santa Lucía", "Progreso", "Young", "Dolores",
        "Paso de los Toros", "Bella Unión", "Chuy", "Nueva Helvecia", "Rosario", "Trinidad",
        "La Paz",
    }
    
    # Legacy Spanish name exclusions (consolidated from original list)
    SPANISH_NAME_EXCLUDE = {
        # Form fields and demographics
        "RELACIÓN", "INVALIDEZ", "FECHA", "NACIMIENTO", "RENTA", "CONYUGE", "HIJOS", 
        "FEMENINO", "MASCULINO", "COTIZADOR", "ESTUDIO", "PRODUCCION", "OPERACION",
        "APELLIDO", "NOMBRE", "PATERNO", "MATERNO", "ESTADO", "CIVIL", "SOLTERO", 
        "CASADO", "VIUDO", "DIVORCIADO", "SEPARADO", "CONVIVIENTE", "SEGURO", "POLIZA",
        "HOLA", "AUTORZADO", "AUTORIZADO", "TITULAR", "ASEGURADO", "COTIZANTE",
        
        # Business and system terms
        "DOCUMENTO", "CEDULA", "PASAPORTE", "TELEFONO", "DIRECCION", "DOMICILIO", 
        "EMPRESA", "COMPAÑIA", "SOCIEDAD", "BANCO", "CUENTA", "TARJETA", "CAMPOS",
        "POLIZAS", "BENEFICIARIOS", "CONTROL", "ARCHIVO", "AYUDA", "REGISTROS",
        "VENTANA", "TRASPASO", "VALIDACION", "COTIZACION", "GESTIÓN COTIZADOR",
        "RENTAS VITALICIAS", "SCOMP", "BORRADOR", "UF", "TIPO DE PENSIÓN","MAIN"
        
        # Complex system phrases
        "MODALIDAD DE PENSION", "PERIODO GARANTIZADO", "FECHA DE COTIZACION",
        "RESULTADOS PROCESOS", "CARGA POLIZAS", "PROCESOS CARGA DE POLIZAS NUEVAS",
        "DATOS DEL AFILIADO", "DATOS DE LOS BENEFICIARIOS", "FIRMADA", "FONASA",
        "AFP", "CUPRUM", "POLICY LOANS", "ENDOSOS RENTA VITALICIA", "ORDENAMOS",
        "VALIDAR CON EL BORRADOR", "INFO AREA", "CREACIÓN PÓLIZAS RV",
        "RESULTADOS PROCESOS CARGAPOLIZAS", "RUT", "AFILIADO", "VALOR UF",
        "VALIDA HASTA", "FECHA DE PAGO DE RENTA VITALICIA", "RENTA MENSUAL",
        
        # Mixed language terms
        "Enviado", "Sexo", "Contingent", "Worker", "Deputy", "Manager", "Directiva", "Dental",
        "Emetlife", "Metlife", "Metlifeexternos", "Provida", "Providaexternos","Respondió",
        "Despockos", "Obrarvación", "Canpezanta", "ae", "tey", "Degadato", "Estregado",
        "Activar", ",Mandato", "ui", "Mendutos", "Para", "Puyra", "Estimados", "Estimadas(os)",
        "Cordialmente", "Saludos", "Atentamente", "Quedamos", "Agradecemos", "Informar",
        "Solicitar", "Revisar", "Adjunto", "Adjunta", "Enviar", "Envia", "Despacho", "Contacto",
        "ee","ii","oo","uu","aa", "medio","Biometría", "PAC", "Mandata", "bono", "enero","febrero",
        "marzo","abril","mayo","junio","julho","agosto","setembro","outubro","novembro","dezembro",
        "agente", "agentes", "supervisor", "comercial", "jefe", "ejecutiva", "sub", "seg", "sacs", "desgrava","polic",
        "digital", "rv", "PolicyLoans", 'policy', "polic", "loans", "Némina", "nomina", "nómina", "lectura", "solo", "excel",
        "workflow", "vale", "vista", "deposito", "ejecutivo", "ejecutiva", "buenas", "tardes", "días", "dias", "buenos", "día", "dia",
        "nuevo", "leader", "special","favor", "head", "autorizaciones", "autorizacion", "subgerente", "subgerente", "coordinador", "coordinadora", "supervisora", "supervisoras",
        "tesoreria", "aprobado", "aprobada", "anexo", "firmado", "firmada", "noches", "levantamiento", "informe", "informes","operations", "quality"
        "directiva", "operations", "quality", "analyst", "heads", "commisions", "expenses", "operacional", "comisiones", "gastos", "and", "CC", "CCO", "clasificacion", "Clasificación",";",
        "cargo","Encargada", "BANK", "ABN", "Mediante", "liquidado", "claims", "Claims", "adjuster", "Adjuster", "adjusters", "Adjusters","incumplimiento", 
        "Normativo", "CMF","Sponsor", "Punto","porcentajes","Nro", "Pag", "erroneo", "realizo", "General", "Aduanas", "libro", "Vistas", "CtaCte", "Páginas", "Fechadepago", "Importe",
        "Generación", "Cálculo", "Devolución", "Underwritting", "Aduanas", "MetlLife", "Jorma", "Carbo",
        # Portuguese equivalents - extensive set
        "RELAÇÃO", "RELACAO", "INVALIDEZ", "DATA", "NASCIMENTO", "RENDA", "CÔNJUGE", "CONJUGE",
        "FILHOS", "FEMININO", "MASCULINO", "ESTUDO", "PRODUÇÃO", "PRODUCAO", "OPERAÇÃO", "OPERACAO",
        "SOBRENOME", "NOME", "PAI", "MÃE", "ESTADO", "CIVIL", "SOLTEIRO", "SOLTEIRA",
        "CASADO", "CASADA", "VIÚVO", "VIUVO", "VIÚVA", "VIUVA", "DIVORCIADO", "DIVORCIADA",
        "SEPARADO", "SEPARADA", "CONVIVENTE", "CONVIVENTES", "SEGURO", "SEGURADO", "SEGURADA",
        "APÓLICE", "APOLICE", "OLÁ", "OLA", "AUTORIZADO", "AUTORIZADA", "TITULAR",
        "CONTRIBUINTE", "CONTRIBUINTES", "CPF", "DOCUMENTO", "RG", "PASSAPORTE",
        "TELEFONE", "ENDEREÇO", "ENDERECO", "DOMICÍLIO", "DOMICILIO", "EMPRESA",
        "COMPANHIA", "SOCIEDADE", "BANCO", "CONTA", "CARTÃO", "CARTAO", "CAMPOS",
        "APÓLICES", "APOLICES", "BENEFICIÁRIOS", "BENEFICIARIOS", "CONTROLE",
        "ARQUIVO", "AJUDA", "REGISTROS", "JANELA", "TRANSFERÊNCIA", "TRANSFERENCIA",
        "VALIDAÇÃO", "VALIDACAO", "COTAÇÃO", "COTIZACAO", "GESTÃO", "GESTAO",
        "COTIZADOR", "RENDAS VITALÍCIAS", "SCOMP", "RASCUNHO", "TIPO DE PENSÃO",
        "MODALIDADE DE PENSÃO", "PERÍODO GARANTIDO", "PERIODO GARANTIDO", "DATA DE COTAÇÃO",
        "RESULTADOS PROCESSAMENTO", "CARGA APÓLICES", "CARREGAMENTO", "DADOS DO FILIADO",
        "DADOS DO AFILIADO", "DADOS DOS BENEFICIÁRIOS", "DADOS DOS BENEFICIARIOS",
        "ASSINADO", "ASSINADA", "INSS", "PREVIDÊNCIA", "PREVIDENCIA", "PENSÃO", "PENSAO",
        "INFORMAÇÕES", "INFORMACOES", "ÁREA", "AREA", "CRIAÇÃO", "CRIACAO", "PROCESSAMENTO",
        "VALOR", "VALIDADE", "VÁLIDO", "VALIDA", "DATA DE PAGAMENTO", "RENDA MENSAL", "MENSAL",
        "Enviado", "Enviada", "Enviados", "Enviadas", "Sexo", "Contingente", "Contingentes",
        "Funcionário", "Funcionaria", "Funcionários", "Funcionarias", "Deputado", "Deputada",
        "Gerente", "Gerência", "Gerencia", "Diretiva", "Dentista", "Dentária", "Dentaria",
        "Odontólogo", "Odontologa", "Emetlife", "Metlife", "Metlifeexternos", "Provida",
        "Providaexternos", "Respondeu", "Respondido", "Respondida", "Enviou",
        "Observação", "Observacao", "Observações", "Observacoes", "Estimados", "Estimadas",
        "Cordialmente", "Saudações", "Saudacoes", "Atenciosamente", "Atentamente", "Ficamos",
        "Agradecemos", "Informar", "Solicitar", "Revisar", "Anexo", "Anexa",
        "Enviar", "Enviou", "Despacho", "Contato", "Contacto",
        "Janeiro", "Fevereiro", "Março", "Marco", "Abril", "Maio", "Junho",
        "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
        "Agente", "Agentes", "Supervisor", "Supervisora", "Supervisores", "Supervisoras",
        "Comercial", "Chefe", "Chefa", "Executivo", "Executiva", "Executivos", "Executivas",
        "Sub", "Digital", "RV", "Nômina", "Nomina", "Leitura", "Só", "So", "Planilha",
        "Fluxo de trabalho", "Workflow", "Vale", "Depósito", "Deposito", "Noites",
        "Líder", "Lider", "Especial", "Favor", "Chefe", "Autorização", "Autorizacao",
        "Coordenador", "Coordenadora", "Coordenadores", "Supervisora", "Supervisoras",
        "Tesouraria", "Tesoureiro", "Tesoureira", "Aprovado", "Aprovada", "Assinado",
        "Assinada", "Levantamento", "Relatório", "Relatorio", "Relatórios", "Relatorios",
        "Operações", "Operacoes", "Qualidade", "Analista", "Analistas", "Chefes",
        "Comissões", "Comissoes", "Despesas", "Operacional", "Operacionale",
        "Classificação", "Classificacao", "Cargo", "Encarregada", "Encarregado",
        "Mediante", "Liquidado", "Liquidada", "Reclamação", "Reclamacoes", "Reclamacão",
        "Avaliador", "Avaliadora", "Avaliadores", "Avaliadoras", "Não cumprimento",
        "Normativo", "Normativa", "Patrocinador", "Patrocinadora", "Patrocinadores",
        "Patrocinadoras", "Ponto", "Porcentagens", "Nro", "Número", "Numero", "Página", "Pagina",
        "Data de pagamento", "Geração", "Geracao", "Cálculo", "Calculo", "Devolução", "Devolucao",
        "Subscrição", "Subscricao", "Alfândega", "Alfandega", "Livro", "Vistas", "Conta Corrente",
        "Importância", "Importancia"
    }
    
    # OCR artifacts and system errors (specific exclusions from real data)
    OCR_ARTIFACTS = {
        "emetlife", "metlife", "recamos", "recamas", "pago", "autorzado", "autorizado",
        "hola", "req", "rut", "contingent", "worker", "deputy", "manager", "pox",
        "bahitiare", "vgonzale", "sn", "autorzado", "QMetlife", "EOmetlife", "cl",
        "megocios", "estimada", "rechmos", "glosa", "asignada", "bypass", "deducible",
        "Unzidad", "cd", "soguros","desgravd", "mail", "proveedor", "expedir", "centacto",
        "Metl", "zoom", "main","Obrarvación", "ui","sam","para", "omcmaring", "Corsst","Biometr",
        "Svtmenu", "rv", "polic", "policy", "loans", "policyloans", "laulaue","direct",
        "Némina", "nomina", "nómina", "lectura", "solo", "excel", "workflow","Caracteristica",
        "vale", "vista", "deposito", "ejecutivo", "ejecutiva", "buenas", "tardes","Caracteristica",
        "Someter", "Somete", "Días", "dias", "buenos", "día", "dia", "nuevo", "leader", "special","favor",
        "Directva"
        

        # Terms from user-provided exclusion table (OCR artifacts and non-name terms only)
        "metute", "astudillcingresac", "ingresac", "ce","Geren",
        "ejecutiva", "seg", "kam", "sub", "jefe", "comercial", "sacs", "desgrava",  # Job titles/terms
        "metuife", "subger", "comerc", "Reenviar", "Responderatodos", "Responder","Reenviar"
        "TipoCredito", "TipoCreditoHipotecario", "Hipotecario", "cc", "cco","lntermediarioAPagar",
        "OFERTAS", "COTIZADOR", "COTIZACIONES", "Cotizador", "Cotizaciones", "Ofertas", "PArGoOce",
        "dePl","Automaticas","Selictudes", "Senión", "MANUA", "AGO","Pagos", "BECS","Concepto", "SINIESTROS",
        "Pagados", "Y", "Siniestros", "Reaseg", "Cont", "Destino", "Orígen", "Origen", "Reaseguro", "Reaseguradora",
        "Reaseguradoras", "Cuents", "Depósitos", "Otros", "Bancos","mariafernandavargas5", "MON","Valores", "Numero", "Credit",
        "Mandatos", "Revsar", "Dstos", "órmalas", "Compartir", "Comentarios", "Tetal", "Gerencia", "Individual", "Serviex", "Manda",
        "ción", "Grab", "Arquitectos", "Asociados", "Por", "Pagar","Mercado","Financiero", "Respons", "Total","Regntros", "Nuesos",
        "Accidental", "MANUA", "AVP", "Otros", "Salida", "Categoría", "Operaciones", "inform", "Switch", "Cob","mediarioAP","MontoCalcul",
        "agar", "Glosario", "Diagrama", "Novedades", "obtenidos", "Trarcdato", "Insertar", "Estilos", "hasta", "Recaudacion", "Rev", 
        "Productora", "Ltda", "Compro", "Motivo", "Rechazo", "Rechazado", "Rechazada", "Rechazar", "Comercializadora","Descripcion",
        "Derol", "Compro", "Super", "VIDA", "emisor", "beneficiario", "van","MyMesife","Inteyraso", "uai", "Extregads", "fisicos","Novedades",
        "Link", "luego", "efectuar", "Interrogantes", "Archrvo", "ntos", "Item", "Saldo","TIcket","WorkF",
        "umento", "ion", "onal", "cias", "mento", "tece", "ios", "nto", "nda", "Comsult", "usua", "mombre", "cantidad", "recepcionado",
        "ificados", "piri", "odo", "clente", "pencientes", "autcazad", "deatencion","Archivos",
        "autcazad", "seles", "clinica", "nois", "rechaz", "ada", "pencon", "cia",
        "tlmkf", "edo", "onco", "mto", "aseg", "lta", "zam","BECH","OTC", "ÍCAPTIVA", "Treaty", "Dept", "Fund", "Folo", "DeveMensual",
        "CLCOMN","TMK", "IMPORTANTE", "Corredr", "Reg", "Emetiife", "Corredi", "Tamaño", "Tip","TRA","Sir", "Suma", "MNombre",
        "Usaro",
        
        
        # Portuguese OCR artifacts and system errors
        "pagamento", "autorizado", "autorizada", "olá", "solicitação", "solicitacao",
        "contingente", "funcionário", "funcionaria", "gerente", "bahitiare", "vgonzale",
        "autorizado", "autorizada", "mnegocios", "estimada", "estimado", "reclamacoes", "glosa",
        "atribuída", "atribuida", "bypass", "dedutível", "dedutivel", "unidade", "seguros",
        "desconto", "email", "provedor", "expedição", "expedicao", "contato", "metl",
        "zoom", "principal", "observação", "observacao", "para", "omcmaring", "corsst",
        "biometria", "svtmenu", "apólice", "apolice", "empréstimo", "emprestimo",
        "nômina", "nomina", "leitura", "só", "so", "planilha", "fluxo de trabalho",
        "característica", "caracteristica", "vale", "depósito", "deposito", "executivo",
        "executiva", "bom dia", "boa tarde", "submeter", "submetido", "dias", "novo",
        "líder", "lider", "especial", "favor", "metute", "astudillcingressac", "ingressac",
        "gerência", "gerencia", "chefe", "chefa", "comercial", "reenviar", "responder",
        "tipocredito", "tipocreditohipotecario", "hipotecário", "hipotecario", "ofertas",
        "cotizador", "cotações", "cotizacoes", "automaticas", "solicitações", "solicitacoes",
        "seção", "secao", "manual", "pagamentos", "conceito", "sinistros", "resseguro",
        "resseguradora", "contas", "depósitos", "depositos", "valores", "número", "numero",
        "crédito", "credito", "mandatos", "revisar", "revisão", "revisao", "fórmulas",
        "formulas", "compartilhar", "comentários", "comentarios", "gerência", "gerencia",
        "indivíduo", "individuo", "serviço", "servico", "mandato", "gravar", "arquitetos",
        "associados", "mercado", "financeiro", "responsável", "responsavel", "acidental",
        "saída", "saida", "categoria", "operações", "operacoes", "informação", "informacao",
        "cobertura", "intermediarioApagar", "glosário", "glossario", "diagrama", "novidades",
        "obtidos", "inserir", "estilos", "até", "recaudação", "recaudacao", "produtora",
        "rejeiçã", "rejeicao", "rejeitado", "rejeitada", "rejeitar", "comercializadora",
        "descrição", "descricao", "motivo", "emissor", "emissora", "beneficiário",
        "beneficiaria", "mymetlife", "entregados", "entregadas", "físicos", "fisicos",
        "depois", "efetuar", "perguntas", "arquivo", "arquivos", "item", "saldo",
        "tíquete", "ticket", "trabalho", "workflow", "tareas", "pendienes", "documento",
        "usua", "mombre", "cantidad", "recepcionado", "citri", "xenapp",
        
    }
    
    # Multi-word exclusions for exact phrase matching (avoids blocking individual names)
    MULTI_WORD_EXCLUSIONS = {
        # From user-provided exclusion table - exact multi-word phrases to exclude
        "metute astudillcingresac ingresac",
        
        # Additional common false positive patterns
        "contingent worker",
        "deputy manager",
        "metlife external",
        "provida external",
        "jefe comercial",
        "supervisor comercial",
        "mandata pac biometria",
        "vale vista",
        # Portuguese equivalent phrases
        "funcionário contingente",
        "funcionaria contingente",
        "gerente substituto",
        "gerente substituta",
        "metlife externo",
        "metlife externa",
        "provida externa",
        "provida externo",
        "chefe comercial",
        "chefa comercial",
        "supervisor comercial",
        "supervisora comercial",
        "mandato pac biometria",
        "vale depósito",
        "vale deposito",
        "funcionário temporário",
        "funcionaria temporaria",
        "contrato temporário",
        "contrato temporaria",
        "consultoria externa",
        "consultoria externo",
        "gestão de operações",
        "gestao de operacoes",
        "equipe externa",
        "equipe externo",
        "contabilizacion devsemensual",
        "liquidador estadisticas mensuales",
        "generalledgery joumals jouma",
        "honorarios medico quirurgicos",
        "mantencion holding corredores",
        "vejez garantizada inmediata",
        "estadisticas mensuales guo",
        "prioridad normal mornto",
        "producto complementario",
        "retenciones provision",
        "terminados pendientes",
        "lineanegocio holding",
        "liquidador consultas",
        "post venta colectivo",
        "devengo masivos",
        "antecedentes client",
        "complementario prod",
        "periodo liberacion",
        "estados liquidados",
        "gestion solicitada",
        "gasto hospitajario",
        "new journal sheet",
        "journal sheets",
        "journal header",
        "journal line",
        "reporting tools",
        "gestion factura",
        "cargas autcazad",
        "deatencion des",
        "muchas gracias",
        "genera cheques",
        "pestaña salud",
        "cambiar nueva",
        "resumen conci",
        "devengo produ",
        "accion razon",
        "tece benefia",
        "interno suba",
        "axa asistenc",
        "captiva tra",
        "comun produ",
        "aporte isap",
        "seles force",
        "clinica nois",
        "carta gant",
        "rechaz ada",
        "anz pencon",
        "edo onco",
        "Tareas Pendienes",
        "Servicios Médicos Santa María"
        "Aguas Andinas"
    }
    
    # Incomplete/truncated word patterns (from OCR errors)
    TRUNCATED_PATTERNS = {
        "proces", "resultad", "bienvenid", "creaci", "admnisvad", "posteriormen", "ingresam",
        "contr", "acce", "valid", "deb", "intran", "modu", "pensi", "administr", "cotiz",
        "sistem", "aplic", "usuari", "configur", "actualiz", "document", "formul", "plantil",
        "descarg", "subid", "bajad", "instal", "desinstal", "program", "desarroll", "automatiz",
        "implement", "sprint", "automatiz", "digitaliz", "polic", "policy", "loan", "nomi",
        "nómi", "lectur", "exce", "workflo", "favor", "autoriz", "coordin", "supervis", "tesorer", "aprob",
    }
    
    # Business suffixes that indicate non-name words
    BUSINESS_SUFFIXES = {
        'mente', 'sion', 'idad', 'able', 'ible', 'ando', 'iendo', 
        'amos', 'endo', 'tion', 'ness', 'ment', 'ador', 'dora'
    }

    # ========================================================================
    # Lazy-loaded cache for normalized exclusion sets
    # This avoids computing all normalized sets at module import time,
    # improving startup performance by ~25% and reducing memory usage.
    # ========================================================================
    _cache: Dict[str, set] = {}
    
    @classmethod
    def _get_normalized_set(cls, source_set: set, cache_key: str) -> set:
        """
        Lazy-load normalized sets with single computation.
        
        Args:
            source_set: Original set of words to normalize
            cache_key: Unique key for caching
            
        Returns:
            set: Normalized (accent-stripped, lowercase) version of source_set
        """
        if cache_key not in cls._cache:
            cls._cache[cache_key] = {
                TextProcessingUtils.strip_accents(w.lower()) 
                for w in source_set if w
            }
        return cls._cache[cache_key]
    
    @classmethod
    def _get_all_exclusions(cls) -> set:
        """Get combined exclusion set with lazy loading"""
        if '_all_exclusions' not in cls._cache:
            cls._cache['_all_exclusions'] = (
                cls._get_normalized_set(cls.FORM_FIELD_PATTERNS, 'form_fields') |
                cls._get_normalized_set(cls.SPANISH_ADVERBS, 'adverbs') |
                cls._get_normalized_set(cls.BUSINESS_PROCESS_TERMS, 'business') |
                cls._get_normalized_set(cls.FINANCIAL_DOMAIN_TERMS, 'financial') |
                cls._get_normalized_set(cls.ORGANIZATIONAL_TERMS, 'organizational') |
                cls._get_normalized_set(cls.TECHNICAL_TERMS, 'technical') |
                cls._get_normalized_set(cls.SPANISH_NAME_EXCLUDE, 'name_exclude') |
                cls._get_normalized_set(cls.OCR_ARTIFACTS, 'ocr_artifacts') |
                cls._get_normalized_set(cls.TRUNCATED_PATTERNS, 'truncated')
            )
        return cls._cache['_all_exclusions']
    
    @classmethod
    def clear_cache(cls) -> None:
        """Clear the normalized cache (useful for testing or memory management)"""
        cls._cache.clear()
    
    @classmethod
    def is_excluded_word(cls, word: str) -> bool:
        """
        Check if a single word should be excluded as a potential person name.
        
        Uses lazy-loaded normalized sets for better memory efficiency.
        
        Args:
            word (str): Word to check (accent-insensitive)
            
        Returns:
            bool: True if word should be excluded
            
        Example:
            >>> ExclusionLists.is_excluded_word("Contingent")  # True
            >>> ExclusionLists.is_excluded_word("posteriormente")  # True
            >>> ExclusionLists.is_excluded_word("Juan")  # False
        """
        if not word:
            return False
        
        normalized = TextProcessingUtils.strip_accents(word.strip().lower())
        
        # Check common names FIRST (most likely to pass through)
        # This optimization checks positive cases before expensive exclusion lookup
        if normalized in PIIPatterns.COMMON_SURNAMES:
            return False
        
        if normalized in PIIPatterns.COMMON_FIRST_NAMES:
            return False
        
        # Check against combined exclusion set (lazy-loaded)
        return normalized in cls._get_all_exclusions()
    
    @classmethod
    def is_excluded_phrase(cls, phrase: str) -> bool:
        """
        Check if a phrase contains any exclusion patterns.
        
        Uses lazy-loaded normalized sets for better performance.
        
        Args:
            phrase (str): Phrase to check
            
        Returns:
            bool: True if phrase contains exclusion patterns
            
        Example:
            >>> ExclusionLists.is_excluded_phrase("CREACIÓN PÓLIZAS RV")  # True
            >>> ExclusionLists.is_excluded_phrase("Juan Pérez González")  # False
        """
        if not phrase:
            return False
        normalized = TextProcessingUtils.strip_accents(phrase.lower())

        # 1) Check for exact multi-word exclusions first (highest priority)
        multi_word_norm = cls._get_normalized_set(cls.MULTI_WORD_EXCLUSIONS, 'multi_word')
        if normalized in multi_word_norm:
            return True

        # 2) Check for any legacy multi-word exclusions (existing phrases)
        # Use word boundary matching to avoid false positives like "ui" matching "GUILLERMO"
        name_exclude_norm = cls._get_normalized_set(cls.SPANISH_NAME_EXCLUDE, 'name_exclude')
        for exclusion in name_exclude_norm:
            if exclusion and len(exclusion) > 2:  # Only for multi-char exclusions
                # Use whole-word matching with word boundaries
                pattern = r'\b' + re.escape(exclusion) + r'\b'
                if re.search(pattern, normalized):
                    return True
            elif exclusion and exclusion in normalized:
                # For very short exclusions (<=2 chars), still use substring but be careful
                # Check if it's a standalone word
                if f" {exclusion} " in f" {normalized} ":
                    return True

        # 3) Token-level check against the combined normalized exclusion set
        # Split by whitespace and punctuation to examine individual tokens that
        # commonly appear in ML/OCR false positives (e.g., 'emetlife', 'ingresac').
        tokens = re.findall(r"\w+", normalized)
        all_exclusions = cls._get_all_exclusions()
        for tok in tokens:
            if tok in all_exclusions:
                return True

        # 4) Check for truncated OCR patterns
        truncated_norm = cls._get_normalized_set(cls.TRUNCATED_PATTERNS, 'truncated')
        for pattern in truncated_norm:
            if pattern and pattern in normalized:
                return True

        return False
    
    @classmethod
    def strip_trailing_terms(cls, tokens: List[str]) -> List[str]:
        """
        Strip trailing organizational/business terms from a token list.
        
        Args:
            tokens (List[str]): List of tokens (e.g., ["Juan", "Pérez", "Contingent"])
            
        Returns:
            List[str]: Cleaned token list (e.g., ["Juan", "Pérez"])
            
        Example:
            >>> ExclusionLists.strip_trailing_terms(["Jenifer", "Prado", "Contingent"])
            ["Jenifer", "Prado"]
        """
        if not tokens:
            return []
        
        org_terms_norm = cls._get_normalized_set(cls.ORGANIZATIONAL_TERMS, 'organizational')
        result = list(tokens)
        while result:
            last_token = TextProcessingUtils.strip_accents(result[-1].lower())
            if last_token in org_terms_norm:
                result.pop()
            else:
                break
        return result
    
    @classmethod
    def has_business_suffix(cls, word: str) -> bool:
        """
        Check if word has a business/technical suffix.
        
        Args:
            word (str): Word to check
            
        Returns:
            bool: True if word has business suffix
        """
        if not word or len(word) < 5:
            return False
        word_lower = word.lower()
        return any(word_lower.endswith(suffix) for suffix in cls.BUSINESS_SUFFIXES)
    
    @classmethod
    def is_form_field_pattern(cls, text: str) -> bool:
        """
        Check if text matches form field patterns.
        
        Args:
            text (str): Text to check
            
        Returns:
            bool: True if matches form field pattern
        """
        if not text:
            return False
        text_upper = text.upper()
        return any(pattern in text_upper for pattern in cls.FORM_FIELD_PATTERNS)
    
    @classmethod 
    def get_exclusion_reason(cls, word: str) -> str:
        """
        Get the reason why a word is excluded (for debugging).
        
        Args:
            word (str): Word to analyze
            
        Returns:
            str: Exclusion category or "not_excluded"
        """
        if not word:
            return "empty"
        
        normalized = TextProcessingUtils.strip_accents(word.strip().lower())
        
        # Use lazy-loading for normalized sets
        if normalized in cls._get_normalized_set(cls.SPANISH_ADVERBS, 'adverbs'):
            return "spanish_adverb"
        elif normalized in cls._get_normalized_set(cls.BUSINESS_PROCESS_TERMS, 'business'):
            return "business_process"
        elif normalized in cls._get_normalized_set(cls.FINANCIAL_DOMAIN_TERMS, 'financial'):
            return "financial_domain"
        elif normalized in cls._get_normalized_set(cls.ORGANIZATIONAL_TERMS, 'organizational'):
            return "organizational"
        elif normalized in cls._get_normalized_set(cls.TECHNICAL_TERMS, 'technical'):
            return "technical"
        elif normalized in cls._get_normalized_set(cls.FORM_FIELD_PATTERNS, 'form_fields'):
            return "form_field"
        elif normalized in cls._get_normalized_set(cls.TRUNCATED_PATTERNS, 'truncated'):
            return "truncated_ocr"
        else:
            return "not_excluded"
    
    @classmethod
    def is_likely_person_name(cls, text: str) -> bool:
        """
        Check if text looks like a Spanish person name based on known databases.
        
        This method checks if at least one word in the text matches a known Spanish
        first name or surname from the PIIPatterns database. This is useful for
        validation and reducing false positives.
        
        Args:
            text (str): Text to check
            
        Returns:
            bool: True if text contains at least one known Spanish name component
            
        Example:
            >>> ExclusionLists.is_likely_person_name("Juan García")  # True
            >>> ExclusionLists.is_likely_person_name("Pamela Fuentes")  # True
            >>> ExclusionLists.is_likely_person_name("Claims Operaciones")  # False
        """
        if not text:
            return False
        
        words = text.lower().split()
        
        # Check if any word is a known first name
        for word in words:
            normalized = TextProcessingUtils.strip_accents(word)
            if normalized in PIIPatterns.COMMON_FIRST_NAMES:
                return True
        
        # Check if any word is a known surname
        for word in words:
            normalized = TextProcessingUtils.strip_accents(word)
            if normalized in PIIPatterns.COMMON_SURNAMES:
                return True
        
        return False
    
    @classmethod
    def get_name_components_score(cls, text: str) -> dict:
        """
        Analyze name components and return scoring details.
        
        This provides detailed analysis of how many known first names and surnames
        are detected in the text, useful for debugging and confidence scoring.
        
        Args:
            text (str): Text to analyze
            
        Returns:
            dict: Dictionary with scoring details
                - 'first_names': list of detected first names
                - 'surnames': list of detected surnames
                - 'total_words': total word count
                - 'score': confidence score (0.0-1.0)
                
        Example:
            >>> ExclusionLists.get_name_components_score("Luis García Pérez")
            {
                'first_names': ['luis'],
                'surnames': ['garcía', 'pérez'],
                'total_words': 3,
                'score': 1.0
            }
        """
        if not text:
            return {
                'first_names': [],
                'surnames': [],
                'total_words': 0,
                'score': 0.0
            }
        
        words = text.lower().split()
        first_names = []
        surnames = []
        
        # Check each word
        for word in words:
            normalized = TextProcessingUtils.strip_accents(word)
            
            if normalized in PIIPatterns.COMMON_FIRST_NAMES:
                first_names.append(normalized)
            
            if normalized in PIIPatterns.COMMON_SURNAMES:
                surnames.append(normalized)
        
        # Calculate score
        total_words = len(words)
        known_components = len(first_names) + len(surnames)
        
        if total_words == 0:
            score = 0.0
        else:
            # Score based on percentage of known components
            base_score = known_components / total_words
            
            # Bonus if we have both first name and surname
            if first_names and surnames:
                base_score = min(1.0, base_score + 0.2)
            
            score = base_score
        
        return {
            'first_names': first_names,
            'surnames': surnames,
            'total_words': total_words,
            'score': score
        }
    
    @classmethod
    def has_spanish_name_structure(cls, text: str) -> bool:
        """
        Check if text follows typical Spanish naming conventions.
        
        Spanish names typically have:
        - 2-4 words
        - First word is a given name
        - Subsequent words are surnames or compound names
        - Proper capitalization
        
        Args:
            text (str): Text to check
            
        Returns:
            bool: True if text follows Spanish naming structure
            
        Example:
            >>> ExclusionLists.has_spanish_name_structure("María José García López")  # True
            >>> ExclusionLists.has_spanish_name_structure("Claims Normativo CMF")  # False
        """
        if not text:
            return False
        
        words = text.split()
        
        # Must have 2-4 words
        if len(words) < 2 or len(words) > 4:
            return False
        
        # Check capitalization (each word should start with uppercase)
        for word in words:
            if not word or not word[0].isupper():
                return False
        
        # First word should look like a first name (at least 2 chars)
        if len(words[0]) < 2:
            return False
        
        # All words should be mostly alphabetic
        for word in words:
            alpha_count = sum(1 for c in word if c.isalpha())
            if alpha_count / len(word) < 0.8:  # At least 80% alphabetic
                return False
        
        # Check if first word is a known first name (bonus points but not required)
        first_word_normalized = TextProcessingUtils.strip_accents(words[0].lower())
        if first_word_normalized in PIIPatterns.COMMON_FIRST_NAMES:
            return True
        
        # Check if any word is a known surname
        for word in words[1:]:  # Skip first word
            word_normalized = TextProcessingUtils.strip_accents(word.lower())
            if word_normalized in PIIPatterns.COMMON_SURNAMES:
                return True
        
        # If we don't find known names but structure looks good, return True
        # This helps with uncommon but valid names
        return True


# ============================================================================
# Build Chileanvariation pattern dynamically from ExclusionLists.GEOGRAPHIC_TERMS
# This ensures city names are not captured as part of person names
# ============================================================================
try:
    # Get cities from ExclusionLists and sort by length (longest first for better matching)
    _cities = sorted(
        {c.strip() for c in ExclusionLists.GEOGRAPHIC_TERMS if c and c.strip()},
        key=len,
        reverse=True
    )
    
    # Validate we have enough cities for a meaningful pattern
    _MIN_CITIES_REQUIRED = 10
    
    if _cities and len(_cities) >= _MIN_CITIES_REQUIRED:
        # Escape special regex characters and join with alternation
        _escaped_cities = "|".join(re.escape(c) for c in _cities)
        
        # Build the pattern: optional city (non-capturing) + person name (captured) + RUT (captured)
        _chile_emp_pattern = re.compile(
            rf"(?:\b(?:{_escaped_cities})\b[\s,:-]*)?"  # Optional city prefix (non-capturing)
            rf"("  # Group 1: Person name (2-4 words, each 3+ chars, all caps)
                rf"(?:[A-ZÁÉÍÓÚÑÜ][A-ZÁÉÍÓÚÑÜ]{{2,}}\s+){{1,3}}"  # 1-3 first/middle names
                rf"[A-ZÁÉÍÓÚÑÜ][A-ZÁÉÍÓÚÑÜ]{{2,}}"  # Last surname
            rf")"
            rf"[\s,:\-]*"  # Optional separators
            rf"(\d{{7,8}}[-‐‑–—\s]?[0-9Kk])",  # Group 2: RUT
            PIIPatterns.FLAGS
        )
        
        # Add to PIIPatterns.PATTERNS
        PIIPatterns.PATTERNS["Chileanvariation"] = _chile_emp_pattern
        logging.info(f"✓ Chileanvariation pattern: {len(_cities)} cities loaded")
    else:
        logging.warning(
            f"⚠ Chileanvariation: Insufficient cities ({len(_cities) if _cities else 0}), "
            f"minimum required: {_MIN_CITIES_REQUIRED}. Pattern disabled."
        )
        PIIPatterns.PATTERNS["Chileanvariation"] = None
        
except Exception as e:
    logging.error(f"✗ Chileanvariation pattern failed: {e}", exc_info=True)
    PIIPatterns.PATTERNS["Chileanvariation"] = None


# Helper Functions
def get_sensitivity_level(pii_type: str) -> str:
    """Get sensitivity level for PII type"""
    high_sensitivity = {"RUT", "PartialRUT", "TransformerPerson", "SpanishName", "CreditCard", "Account", "Passport_Context"}
    medium_sensitivity = {"Phone", "Phone_Context", "Amount", "Date", "DateTime", "Address", "Address_StreetNum", "Address_Keywords", "TransformerOrganization", "TransformerLocation", "Email"}
    low_sensitivity = {"NumberSequence"}
    
    if pii_type in high_sensitivity:
        return "High"
    elif pii_type in medium_sensitivity:
        return "Medium"
    elif pii_type in low_sensitivity:
        return "Low"
    else:
        return "Low"

def extract_page_number(filename: str) -> int:
    """Extract page number from filename"""
    try:
        # Match 'page_N_' pattern first
        match = re.search(r'page_(\d+)_', filename)
        if match:
            return int(match.group(1))
        
        # Fallback: get first number in filename  
        numbers = re.findall(r'\d+', filename)
        if numbers:
            return int(numbers[0])
        
        return 1
    except Exception as e:
        logging.error(f"Error extracting page number from {filename}: {e}")
        return 1

def generate_simple_embedding(text: str) -> List[float]:
    """
    Generate a simple text embedding when sentence-transformers is not available.
    Creates a basic vector representation based on text characteristics.
    """
    try:
        features = []
        # Text length (normalized)
        features.append(min(len(text) / 1000.0, 1.0))
        # Word count (normalized)
        words = text.split()
        features.append(min(len(words) / 100.0, 1.0))
        # Character diversity (unique chars / total chars)
        if len(text) > 0:
            features.append(len(set(text.lower())) / len(text))
        else:
            features.append(0.0)
        # Digit ratio
        digit_count = sum(1 for c in text if c.isdigit())
        features.append(digit_count / max(len(text), 1))
        # Uppercase ratio
        upper_count = sum(1 for c in text if c.isupper())
        features.append(upper_count / max(len(text), 1))
        # Punctuation ratio
        punct_count = sum(1 for c in text if not c.isalnum() and not c.isspace())
        features.append(punct_count / max(len(text), 1))
        # Hash-based features for semantic similarity
        text_hash = hashlib.md5(text.lower().encode()).hexdigest()
        hash_features = [int(text_hash[i:i+2], 16) / 255.0 for i in range(0, 32, 2)]
        features.extend(hash_features[:16])  # Take first 16 hash features
        # Pad to make vector length consistent (32 dimensions)
        while len(features) < 32:
            features.append(0.0)
        return features[:32]  # Ensure exactly 32 dimensions
    except Exception as e:
        logging.warning(f"Error generating simple embedding: {e}")
        return [0.0] * 32  # Return zero vector on error


def filter_identities_by_country(
    entities: List[Dict[str, Any]], 
    country: Optional[str],
    strict_mode: bool = True
) -> List[Dict[str, Any]]:
    """
    Filter identity numbers that don't match the detected country.
    
    This function implements country-aware PII filtering to exclude identity
    numbers that don't correspond to the detected country. For example,
    it will exclude CPF detections when processing Chilean documents.
    
    Args:
        entities: List of detected PII entities with 'PII_Type' field
        country: Detected country name (e.g., 'Chile', 'Brasil', 'Colombia', 'Uruguay')
                 If None, no filtering is applied (permissive mode)
        strict_mode: If True, removes non-matching identities completely.
                     If False, keeps them but flags with reduced confidence.
    
    Returns:
        List of entities with country filtering applied:
        - strict_mode=True: Non-matching identities removed
        - strict_mode=False: Non-matching identities flagged with:
            - 'country_mismatch': True
            - 'expected_country': Country where this identity type is valid
            - 'detected_country': Country detected from filename
            - 'confidence': Reduced by 50%
    
    Example:
        >>> entities = [
        ...     {'PII_Type': 'CPF', 'PII_Value': '123.456.789-00', 'confidence': 0.9},
        ...     {'PII_Type': 'RUT', 'PII_Value': '12.345.678-9', 'confidence': 0.95},
        ...     {'PII_Type': 'Email', 'PII_Value': 'user@example.com', 'confidence': 1.0}
        ... ]
        >>> # Processing Chilean document
        >>> filtered = filter_identities_by_country(entities, 'Chile', strict_mode=True)
        >>> # Result: Only RUT and Email remain, CPF is excluded
        
    Note:
        - Non-identity PII types (Email, Phone, etc.) are never filtered
        - If country is None or empty, all entities pass through unchanged
        - Uses PIIPatterns.COUNTRY_IDENTITY_MAP for validation
    """
    if not country or not entities:
        return entities
    
    # Get valid identity types for this country
    valid_types = PIIPatterns.COUNTRY_IDENTITY_MAP.get(country, set())
    
    if not valid_types:
        # Country not in mapping, apply permissive mode
        logging.warning(f"Country '{country}' not in COUNTRY_IDENTITY_MAP, no filtering applied")
        return entities
    
    filtered = []
    excluded_count = 0
    flagged_count = 0
    
    for entity in entities:
        pii_type = entity.get('PII_Type', '')
        
        # Check if this is an identity number type
        if pii_type in PIIPatterns.IDENTITY_TO_COUNTRY:
            # This is an identity number - validate against country
            if pii_type in valid_types:
                # Valid for this country - keep as-is
                filtered.append(entity)
            else:
                # Cross-country mismatch detected
                if strict_mode:
                    # Strict mode: exclude completely
                    excluded_count += 1
                    logging.debug(
                        f"Excluded {pii_type} '{entity.get('PII_Value', 'N/A')}' - "
                        f"expected country: {PIIPatterns.IDENTITY_TO_COUNTRY.get(pii_type)}, "
                        f"detected country: {country}"
                    )
                else:
                    # Permissive mode: flag and reduce confidence
                    entity_copy = entity.copy()
                    entity_copy['country_mismatch'] = True
                    entity_copy['expected_country'] = PIIPatterns.IDENTITY_TO_COUNTRY.get(pii_type)
                    entity_copy['detected_country'] = country
                    # Reduce confidence by 50%
                    original_confidence = entity_copy.get('confidence', 0.5)
                    entity_copy['confidence'] = max(0.0, original_confidence * 0.5)
                    filtered.append(entity_copy)
                    flagged_count += 1
                    logging.debug(
                        f"Flagged {pii_type} '{entity.get('PII_Value', 'N/A')}' - "
                        f"country mismatch (expected: {entity_copy['expected_country']}, "
                        f"detected: {country})"
                    )
        else:
            # Not an identity number type - keep as-is (Email, Phone, etc.)
            filtered.append(entity)
    
    # Log summary
    if excluded_count > 0 or flagged_count > 0:
        mode_str = "excluded" if strict_mode else "flagged"
        count = excluded_count if strict_mode else flagged_count
        logging.info(
            f"Country filtering ({country}): {count} identity numbers {mode_str} "
            f"due to country mismatch (strict_mode={strict_mode})"
        )
    
    return filtered


def filter_identities_by_country(
    entities: List[Dict[str, Any]], 
    country: Optional[str],
    strict_mode: bool = True
) -> List[Dict[str, Any]]:
    """
    Filter identity numbers that don't match the detected country.
    
    This function implements country-aware PII filtering to exclude identity
    numbers that don't correspond to the detected country. For example,
    it will exclude CPF detections when processing Chilean documents.
    
    Args:
        entities: List of detected PII entities with 'PII_Type' field
        country: Detected country name (e.g., 'Chile', 'Brasil', 'Colombia', 'Uruguay')
                 If None, no filtering is applied (permissive mode)
        strict_mode: If True, removes non-matching identities completely.
                     If False, keeps them but flags with reduced confidence.
    
    Returns:
        List of entities with country filtering applied:
        - strict_mode=True: Non-matching identities removed
        - strict_mode=False: Non-matching identities flagged with:
            - 'country_mismatch': True
            - 'expected_country': Country where this identity type is valid
            - 'detected_country': Country detected from filename
            - 'confidence': Reduced by 50%
    
    Example:
        >>> entities = [
        ...     {'PII_Type': 'CPF', 'PII_Value': '123.456.789-00', 'confidence': 0.9},
        ...     {'PII_Type': 'RUT', 'PII_Value': '12.345.678-9', 'confidence': 0.95},
        ...     {'PII_Type': 'Email', 'PII_Value': 'user@example.com', 'confidence': 1.0}
        ... ]
        >>> # Processing Chilean document
        >>> filtered = filter_identities_by_country(entities, 'Chile', strict_mode=True)
        >>> # Result: Only RUT and Email remain, CPF is excluded
        
    Note:
        - Non-identity PII types (Email, Phone, etc.) are never filtered
        - If country is None or empty, all entities pass through unchanged
        - Uses PIIPatterns.COUNTRY_IDENTITY_MAP for validation
    """
    if not country or not entities:
        return entities
    
    # Get valid identity types for this country
    valid_types = PIIPatterns.COUNTRY_IDENTITY_MAP.get(country, set())
    
    if not valid_types:
        # Country not in mapping, apply permissive mode
        logging.warning(f"Country '{country}' not in COUNTRY_IDENTITY_MAP, no filtering applied")
        return entities
    
    filtered = []
    excluded_count = 0
    flagged_count = 0
    
    for entity in entities:
        pii_type = entity.get('PII_Type', '')
        
        # Check if this is an identity number type
        if pii_type in PIIPatterns.IDENTITY_TO_COUNTRY:
            # This is an identity number - validate against country
            if pii_type in valid_types:
                # Valid for this country - keep as-is
                filtered.append(entity)
            else:
                # Cross-country mismatch detected
                if strict_mode:
                    # Strict mode: exclude completely
                    excluded_count += 1
                    logging.debug(
                        f"Excluded {pii_type} '{entity.get('PII_Value', 'N/A')}' - "
                        f"expected country: {PIIPatterns.IDENTITY_TO_COUNTRY.get(pii_type)}, "
                        f"detected country: {country}"
                    )
                else:
                    # Permissive mode: flag and reduce confidence
                    entity_copy = entity.copy()
                    entity_copy['country_mismatch'] = True
                    entity_copy['expected_country'] = PIIPatterns.IDENTITY_TO_COUNTRY.get(pii_type)
                    entity_copy['detected_country'] = country
                    # Reduce confidence by 50%
                    original_confidence = entity_copy.get('confidence', 0.5)
                    entity_copy['confidence'] = max(0.0, original_confidence * 0.5)
                    filtered.append(entity_copy)
                    flagged_count += 1
                    logging.debug(
                        f"Flagged {pii_type} '{entity.get('PII_Value', 'N/A')}' - "
                        f"country mismatch (expected: {entity_copy['expected_country']}, "
                        f"detected: {country})"
                    )
        else:
            # Not an identity number type - keep as-is (Email, Phone, etc.)
            filtered.append(entity)
    
    # Log summary
    if excluded_count > 0 or flagged_count > 0:
        mode_str = "excluded" if strict_mode else "flagged"
        count = excluded_count if strict_mode else flagged_count
        logging.info(
            f"Country filtering ({country}): {count} identity numbers {mode_str} "
            f"due to country mismatch (strict_mode={strict_mode})"
        )
    
    return filtered
