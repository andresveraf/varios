#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Selenium web automation utilities template
Compatible with Python 3.13.4
"""

import os
import sys
import time
import logging
import datetime as dt
from selenium import webdriver
from selenium.webdriver.edge.options import Options
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import *
#import selenium_utils_2
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 

class SeleniumUtils():
    def __init__(self, download_folder:str=None, excecute_headless:bool=False, max_timeout:int=30):
        self._keep_web_alive     = False
        self._excecute_headless  = excecute_headless
        self._max_timeout       = max_timeout
        if not download_folder:
            execution_folder = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            download_folder  = os.path.join(execution_folder, "process_data", "selenium_downloads") 
        self.download_folder = download_folder
        self.driver = None
        self.init_edge_driver() # Initates driver and wait time
    
    def init_edge_driver(self):        
        edge_options = Options()
        # Create download folder if it doesnt exist
        os.makedirs(name=self.download_folder, exist_ok=True)
        prefs = {"profile.default_content_settings.popups": 0,    
                 "download.default_directory": self.download_folder,
                 "plugins.always_open_pdf_externally": True,
                 "download.prompt_for_download": False, # to auto download the fil
                 #"browser.helperApps.neverAsk.saveToDisk": "application/pdf", # Disable "Save As" window for PDF files }
                 }
        # if self._excecute_headless:
        #     edge_options.add_argument('--headless=new')
        edge_options.add_argument("--start-maximized")
        edge_options.add_argument('--no-sandbox')
        edge_options.add_argument('--disable-dev-shm-usage')
        edge_options.add_argument('--ignore-certificate-errors')
        edge_options.add_argument('--ignore-ssl-errors')
        edge_options.add_argument("--disable-popup-blocking")
        edge_options.add_argument("--printing") # new
        edge_options.add_experimental_option('excludeSwitches', ['enable-logging', 'disable-popup-blocking'])
        edge_options.add_experimental_option("detach", self._keep_web_alive)
        edge_options.add_experimental_option("prefs", prefs)
        edge_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64, x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3")
        #edge_options.add_argument(f"download.default.directory='output\_others'")
        # Open website
        self.driver = webdriver.Edge(options=edge_options, keep_alive=self._keep_web_alive)
        self.wait = WebDriverWait(self.driver, self._max_timeout) # Set up wait time
        logging.info("Initiated web driver")   

    def open_website(self, url:str):
        """Open website"""
        logging.info(f"Opening the website {url}...")
        self.driver.get(url)

    def close_website(self, url:str):
        logging.info(f"Closing url in driver: {url}")
        self.switch_to_tab(url=url)
        self.driver.close()
    
    def close_all_websites(self):
        logging.info(f"Closing all tabs in driver")
        windows = self.driver.window_handles
        for window in windows:
            try:
                self.driver.switch_to.window(window)
                self.driver.close()
            except Exception as error:
                logging.info(f"Failed to close window due to error {error}, continuing")
                pass
    
    def switch_to_tab(self, url:str=None, tab_index:int=None):
        windows        = self.driver.window_handles
        current_window = self.driver.current_window_handle 
        init_url       = self.driver.current_url
        if url:
            logging.info(f"Attempting to switch driver from url {init_url} to {url}")
            for window in windows:
                self.driver.switch_to.window(window)
                current_url = self.driver.current_url
                if(url in current_url):
                    logging.info(f"Found desiered tab with url {current_url}, driver updated")
                    return True
                else:
                    self.driver.switch_to.window(current_window)
            logging.warning("Failed to find tab with the given url, keeping current driver")
            return False
        elif tab_index:
            logging.info(f"Attempting to switch driver from url {init_url} to tab position {tab_index}")
            if len(windows)<=tab_index:
                self.driver.switch_to.window(windows[tab_index])
                current_url = self.driver.current_url
                logging.info(f"Found desiered tab with url {current_url}, driver updated")
            else:
                logging.warning("Index does not exist in current driver")
                return False
        logging.info("No website directions given, keeping current tab")
        return True

    def element_exists(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        if web_element is None:
            web_element = self.driver
        # Set up timeout, if not given will be class default
        if not timeout:
            timeout = self._max_timeout
        element_wait = WebDriverWait(web_element, timeout)
        # If no message given use default
        if not message:
            message = f'Could not find element with selector "{selector}" on page: {self.driver.current_url}'
        # Attempt to find element
        try:
            element_wait.until(EC.presence_of_element_located((By, selector)), message)
            return True
        except TimeoutException:
            logging.warning(f"Timeout exceeded on finding element, waited {timeout} seconds")
            if raise_exception:
                raise TimeoutException(msg=message)
            return False

    def click_element(self, By:By, selector:str, web_element=None, hover:bool=False, raise_exception:bool=True, timeout:int=None):
        """ Click element an element """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to click on'
        logging.info(f"Clicking \"{selector}\"") 
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            clicker = web_element.find_element(By, selector)
            time.sleep(0.5)
            if hover:
                hover_action = ActionChains(self.driver).move_to_element(clicker)
                hover_action.perform()
                time.sleep(0.5)
            clicker.click()
            time.sleep(0.5)
            return True
        else:
            return False
        
    def populate_field(self, By:By, selector:str, input:str, web_element=None, clear_before:bool=False, sensitive_data:bool=False, raise_exception:bool=True, timeout:int=None):
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to type in text box'
        if sensitive_data:
            logging.info(f"Filling \"{selector}\" with \"Sensitive Data\"")
        else: 
            logging.info(f"Filling \"{selector}\" with \"{input}\"") 
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            pouplater = web_element.find_element(By, selector)
            if clear_before:
                pouplater.clear()
            pouplater.send_keys(input) 
            return True
        else:
            return False
        
    def switch_frame(self, By:By, selector:str, back_to_default:bool = True):
        logging.info(f"Switching to frame \"{selector}\"")
        if back_to_default: 
            self.driver.switch_to.default_content()
        message = f'Could not find element with selector "{selector}" to switch frames'
        self.element_exists(By=By, selector=selector, message=message)         
        switch_frame = self.driver.find_element(by=By, value=selector) 
        self.driver.switch_to.frame(switch_frame)

    def close_driver(self):
        """Close website with Selenium"""
        logging.info(f"Closing the initiated driver")
        self.driver.quit()
    
    def check_unfinished_downloads(self, extensions:list=[".crdownload",".temp",".tmp"], max_mins: float = 0.1, empty_dir_seconds_timeout: int = 10, retry_seconds:int = 1, raise_exception:bool = True):
        """Checks for unfinished downloads by looking the extension file of self.download_folder. It will iterate every retry_seconds until time_out or no files with provided extension are found. 
            if raise_exception is True. It will raise exceptions when encountering non expected scenarios. 
        """
        logging.info(f"Checking for unfinished downloads on: \"{self.download_folder}\"")
        logging.info(f"With a time out of: {max_mins} minutes.")
        logging.info(f"Extension used for detecting: \"{extensions}\"")
        if not os.path.exists(self.download_folder):
            logging.info(f"Directory {self.download_folder} not found.")
            logging.info("Please check \"self.download_folder\" argument in \"SeleniumUtils\" class")
            if raise_exception:
                raise Exception(f"Directory {self.download_folder} not found. Please check \"self.download_folder\" argument in \"SeleniumUtils\" class")
        else:
            dir_list = os.listdir(self.download_folder)
            logging.info(f"{len(dir_list)} files found at given directory.")
            logging.info("Searching for unfinished downloads")
            empty_dir = True
            timeout_start = time.time()
            while time.time() < timeout_start + max_mins*60:
                dir_list = os.listdir(self.download_folder)
                if len(dir_list) == 0 and empty_dir:
                    #empty_dir = True
                    reimaining_time = int(timeout_start + empty_dir_seconds_timeout - time.time())
                    logging.info("No files found at given directory. Please check download path is correct")
                    if reimaining_time < 0:
                        logging.error(f"Empty directory time out after {empty_dir_seconds_timeout} seconds")
                        if raise_exception:
                            raise Exception(f"""\"{self.download_folder}\" path found. But, no files where found at given directory.
                                            Please check download path is correct. Else, consider increasing \"empty_dir_seconds_timeout\"
                                            from function argument""")
                        break
                    logging.info(f"{reimaining_time} remaining seconds for empty directory timeout")
                else:
                    if empty_dir:
                        empty_dir = False
                        logging.info("Files found at given directory. Reseting timer for download")
                        timeout_start = time.time()
                    reimaining_time = int(timeout_start + max_mins*60 - time.time())
                    logging.info(f"{reimaining_time} remaining seconds for download timeout")
                    unfinished_downloads_names = [file_name for file_name in dir_list  if any(extension in str(file_name) for extension in extensions)]
                    amount = len(unfinished_downloads_names)
                    if amount== 0:
                        dir_list = os.listdir(self.download_folder)
                        if len(dir_list) == 0:
                            logging.error(f"Download failed. Directory is empty. A file with in \"{extensions}\" extension types was identified, but was not saved as expected.")
                        return logging.info("No unfinished downloads detected")
                    else:
                        logging.info(f"{amount} unfinished downloads detected, checking again in {retry_seconds} seconds")
                time.sleep(retry_seconds)        
            if raise_exception:
                str_list_name = "\
-File: ".join(unfinished_downloads_names)
                logging.error(f"""
                                Download TIME OUT: {amount} unfinished downloads detected after \"max_mins = {max_mins}\" of wait.
                                Check for corrupted files with \"{extensions}\" extension in \"{self.download_folder}\". Else, consider increasing 
                                \"max_mins\" from from function argument"
                                Unfinished files found: 
                                {str_list_name}""")
                raise Exception(f"""
                                Download TIME OUT: {amount} unfinished downloads detected after \"max_mins = {max_mins}\" of wait.
                                Check for corrupted files with \"{extensions}\" extension in \"{self.download_folder}\". Else, consider increasing 
                                \"max_mins\" from from function argument"
                                Unfinished files found: 
                                {str_list_name}""")
        
    def to_element(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        if web_element is None:
            web_element = self.driver
        # Set up timeout, if not given will be class default
        if not timeout:
            timeout = self._max_timeout
        element_wait = WebDriverWait(web_element, timeout)
        # If no message given use default
        if not message:
            message = f'Could not find element with selector "{selector}" on page: {self.driver.current_url}'
        # Attempt to find element
        try:
            element = element_wait.until(EC.presence_of_element_located((By, selector)), message)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
            return True
        except TimeoutException:
            logging.warning(f"Timeout exceeded on finding element, waited {timeout} seconds")
            if raise_exception:
                raise TimeoutException(msg=message)
            return False

    def check_exist(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        try: 
            self.driver.find_element(By, selector)
        except NoSuchElementException:
            return False
        return True
