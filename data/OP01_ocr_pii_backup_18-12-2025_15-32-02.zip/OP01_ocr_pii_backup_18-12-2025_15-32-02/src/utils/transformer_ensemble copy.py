#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Transformer Ensemble for Enhanced PII Detection

This module implements a multi-model transformer ensemble that combines
predictions from multiple specialized NER models for robust PII detection.

Features:
- Spanish-optimized primary model
- Multilingual secondary model
- English fallback model
- Weighted ensemble voting
- Confidence-based filtering
- Batch processing support
- Caching for performance
"""

import logging
import hashlib
import json
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from collections import defaultdict

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
    import torch
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("transformers library not available. Transformer ensemble will be disabled.")


class TransformerCache:
    """
    Cache layer for transformer predictions to avoid redundant processing.
    Uses MD5 hash of text as cache key for fast lookups.
    """
    
    def __init__(self, cache_dir: Optional[Path] = None, enabled: bool = True):
        """
        Initialize cache.
        
        Args:
            cache_dir: Directory to store cache files
            enabled: Whether caching is enabled
        """
        self.enabled = enabled
        self.cache_dir = None
        self.hits = 0
        self.misses = 0
        
        if enabled and cache_dir:
            self.cache_dir = Path(cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            logging.info(f"Transformer cache initialized at: {self.cache_dir}")
    
    def _get_cache_key(self, text: str) -> str:
        """Generate MD5 hash as cache key"""
        return hashlib.md5(text.encode('utf-8')).hexdigest()
    
    def get(self, text: str) -> Optional[List[Dict[str, Any]]]:
        """
        Retrieve cached predictions.
        
        Args:
            text: Input text
            
        Returns:
            Cached predictions or None if not found
        """
        if not self.enabled or not self.cache_dir:
            return None
        
        cache_key = self._get_cache_key(text)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    self.hits += 1
                    return json.load(f)
            except Exception as e:
                logging.debug(f"Cache read error: {e}")
                return None
        
        self.misses += 1
        return None
    
    def set(self, text: str, predictions: List[Dict[str, Any]]):
        """
        Store predictions in cache.
        
        Args:
            text: Input text
            predictions: Predictions to cache
        """
        if not self.enabled or not self.cache_dir:
            return
        
        cache_key = self._get_cache_key(text)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(predictions, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logging.debug(f"Cache write error: {e}")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache performance statistics"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            "enabled": self.enabled,
            "hits": self.hits,
            "misses": self.misses,
            "total_requests": total,
            "hit_rate_percent": round(hit_rate, 1)
        }


class TransformerEnsemble:
    """
    Multi-model transformer ensemble for robust PII detection.
    
    Uses weighted voting across multiple specialized NER models:
    1. Spanish-optimized model (primary)
    2. Multilingual model (secondary)
    3. English model (tertiary/fallback)
    
    Predictions from all models are combined using weighted voting
    to improve accuracy and reduce false positives.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize transformer ensemble.
        
        Args:
            config: Configuration dictionary with transformer settings
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("transformers library is required but not installed. Run: pip install transformers torch")
        
        self.config = config
        self.enabled = config.get("enabled", True)
        
        if not self.enabled:
            logging.info("Transformer ensemble is disabled in config")
            return
        
        self.device = self._get_device()
        self.pipelines = {}
        self.model_weights = config.get("ensemble_weights", {
            "primary": 0.5,
            "secondary": 0.3,
            "tertiary": 0.2
        })
        
        # Initialize cache
        cache_enabled = config.get("enable_caching", True)
        cache_dir = config.get("cache_dir")
        if cache_dir:
            # Replace {PROCESS_DATA} placeholder
            cache_dir = cache_dir.replace("{PROCESS_DATA}", "../process_data")
        self.cache = TransformerCache(cache_dir=cache_dir, enabled=cache_enabled)
        
        # Load models
        self._load_models()
        
        # Summary of ensemble configuration
        logging.info("\n" + "="*70)
        logging.info("TRANSFORMER ENSEMBLE FINAL CONFIGURATION")
        logging.info("="*70)
        logging.info(f"Models in ensemble: {len(self.pipelines)}")
        logging.info(f"Device: {self.device}")
        logging.info(f"Cache: {'enabled' if cache_enabled else 'disabled'}")
        logging.info(f"Confidence threshold: {self.config.get('confidence_threshold', 0.75)}")
        logging.info(f"Ensemble voting weights: {self.model_weights}")
        logging.info(f"Max sequence length: {self.config.get('max_length', 510)}")
        if len(self.pipelines) > 0:
            logging.info(f"\nLoaded models:")
            for idx, (model_name, model_info) in enumerate(self.pipelines.items(), 1):
                logging.info(f"  {idx}. [{model_name}] {model_info['model_id']} (weight: {model_info['weight']})")
        logging.info("="*70 + "\n")
    
    def _get_device(self) -> str:
        """Detect available device (CUDA/CPU)"""
        device = self.config.get("device", "auto")
        
        if device == "auto":
            if torch.cuda.is_available():
                device = "cuda"
                logging.info("GPU (CUDA) detected and will be used")
            else:
                device = "cpu"
                logging.info("No GPU detected, using CPU")
        
        return device
    
    def _load_models(self):
        """Load all configured transformer models"""
        model_configs = [
            ("primary", self.config.get("model_name", "PlanTL-GOB-ES/roberta-base-bne-capitel-ner-plus")),
            ("secondary", self.config.get("secondary_model", "Davlan/xlm-roberta-base-ner-hrl")),
            ("tertiary", self.config.get("tertiary_model", "dslim/bert-base-NER-uncased"))
        ]
        
        logging.info("="*70)
        logging.info("TRANSFORMER ENSEMBLE MODEL LOADING STARTED")
        logging.info("="*70)
        logging.info(f"Configured models to load:")
        for idx, (name, model_id) in enumerate(model_configs, 1):
            logging.info(f"  {idx}. {name}: {model_id}")
        
        # Only load models if ensemble is enabled
        if not self.config.get("use_ensemble", True):
            # Load only primary model
            model_configs = [model_configs[0]]
            logging.info("Ensemble voting disabled, using only primary model")
        
        successful_models = []
        failed_models = []
        
        for model_name, model_id in model_configs:
            try:
                self._load_single_model(model_name, model_id)
                successful_models.append((model_name, model_id))
            except Exception as e:
                logging.warning(f"Failed to load {model_name} model ({model_id}): {e}")
                failed_models.append((model_name, model_id, str(e)))
                # Continue with available models
        
        logging.info("="*70)
        logging.info(f"MODEL LOADING SUMMARY")
        logging.info(f"  Successfully loaded: {len(successful_models)}/{len(model_configs)}")
        for name, model_id in successful_models:
            logging.info(f"    ✓ {name}: {model_id}")
        if failed_models:
            logging.info(f"  Failed to load: {len(failed_models)}")
            for name, model_id, error in failed_models:
                logging.info(f"    ✗ {name}: {model_id} - {error[:100]}...")
        logging.info(f"  Active models in ensemble: {len(self.pipelines)}")
        logging.info(f"  Model weights: {self.model_weights}")
        logging.info("="*70)
        
        if not self.pipelines:
            raise RuntimeError("No transformer models could be loaded. Check model names and internet connection.")
    
    def _load_single_model(self, name: str, model_id: str):
        """
        Load a single transformer model.
        
        Args:
            name: Model identifier (primary/secondary/tertiary)
            model_id: HuggingFace model ID
        """
        logging.info(f"  [LOADING] {name}: {model_id}")
        
        try:
            # Create NER pipeline without truncation/padding (handled at tokenizer level)
            logging.debug(f"    Pipeline config: device={self.device}, aggregation={self.config.get('aggregation_strategy', 'simple')}, batch_size={self.config.get('batch_size', 16)}")
            
            ner_pipeline = pipeline(
                "ner",
                model=model_id,
                tokenizer=model_id,
                device=0 if self.device == "cuda" else -1,
                aggregation_strategy=self.config.get("aggregation_strategy", "simple"),
                batch_size=self.config.get("batch_size", 16)
            )
            
            # Store config for later use (not passed to pipeline)
            model_weight = self.model_weights.get(name, 0.33)
            model_config = {
                "pipeline": ner_pipeline,
                "model_id": model_id,
                "weight": model_weight,
                "max_length": self.config.get("max_length", 510),
                "truncation": self.config.get("truncation", True),
                "padding": self.config.get("padding", "max_length")
            }
            self.pipelines[name] = model_config
            
            logging.info(f"  [OK] {name} model loaded successfully")
            logging.info(f"       Model ID: {model_id}")
            logging.info(f"       Weight: {model_weight} (for ensemble voting)")
            logging.info(f"       Max Length: {model_config['max_length']} tokens")
            logging.info(f"       Device: {self.device}")
            logging.info(f"       Aggregation: {self.config.get('aggregation_strategy', 'simple')}")
            
        except Exception as e:
            logging.error(f"  [FAILED] {name} model load error: {e}")
            logging.error(f"           Model ID: {model_id}")
            raise
    
    def _preprocess_text(self, text: str) -> str:
        """
        Preprocess text before tokenization to avoid length issues.
        
        Args:
            text: Input text
            
        Returns:
            Preprocessed text (truncated if necessary)
        """
        max_length = self.config.get("max_length", 510)
        
        # Very conservative estimate to avoid any token overflow
        # BERT/RoBERTa tokenizes at 1 token per ~3-4 characters average
        # Add buffer for special tokens and safety margin
        max_chars = max_length * 2.5  # Very conservative, ensures we stay under limit
        
        if len(text) > max_chars:
            # Truncate to safe length, preferring sentence boundaries
            text = text[:int(max_chars)]
            # Try to truncate at last period/newline/space
            for boundary_char in ['.', '\n', ' ']:
                last_boundary = text.rfind(boundary_char)
                if last_boundary > int(max_chars * 0.75):  # Only use if reasonably close
                    text = text[:last_boundary]
                    break
            logging.info(f"Text truncated to {len(text)} chars (was longer than {max_chars} limit for max_length={max_length})")
        
        return text.strip()
    
    def detect_entities(self, text: str) -> List[Dict[str, Any]]:
        """
        Detect entities using ensemble voting.
        
        Args:
            text: Input text to analyze
            
        Returns:
            List of detected entities with confidence scores
        """
        if not self.enabled or not text or not text.strip():
            return []
        
        # Preprocess text to avoid tokenization issues
        text = self._preprocess_text(text)
        
        # Check cache first
        cached = self.cache.get(text)
        if cached is not None:
            logging.debug("Using cached transformer predictions")
            return cached
        
        # Get predictions from all models
        all_predictions = []
        
        for model_name, model_info in self.pipelines.items():
            try:
                predictions = model_info["pipeline"](text)
                
                # Add metadata to each prediction
                for pred in predictions:
                    pred["source_model"] = model_name
                    pred["model_weight"] = model_info["weight"]
                    pred["weighted_score"] = pred["score"] * model_info["weight"]
                
                all_predictions.extend(predictions)
                logging.debug(f"{model_name} detected {len(predictions)} entities")
                
            except Exception as e:
                logging.warning(f"Error in {model_name} prediction: {e}")
        
        # Merge overlapping predictions using weighted voting
        merged = self._merge_predictions(all_predictions)
        
        # Filter by confidence threshold
        threshold = self.config.get("confidence_threshold", 0.75)
        filtered = [p for p in merged if p["score"] >= threshold]
        
        logging.debug(f"Ensemble result: {len(all_predictions)} raw -> {len(merged)} merged -> {len(filtered)} after filtering")
        
        # Cache results
        self.cache.set(text, filtered)
        
        return filtered
    
    def _merge_predictions(self, predictions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Merge overlapping predictions using weighted voting.
        
        Args:
            predictions: List of all model predictions
            
        Returns:
            List of merged predictions
        """
        if not predictions:
            return []
        
        # Sort by start position
        predictions.sort(key=lambda x: x["start"])
        
        merged = []
        current_group = [predictions[0]]
        
        for pred in predictions[1:]:
            # Check if overlaps with current group
            last_pred = current_group[-1]
            
            if self._predictions_overlap(pred, last_pred):
                current_group.append(pred)
            else:
                # Merge current group and start new one
                merged_entity = self._merge_group(current_group)
                if merged_entity:
                    merged.append(merged_entity)
                current_group = [pred]
        
        # Merge last group
        if current_group:
            merged_entity = self._merge_group(current_group)
            if merged_entity:
                merged.append(merged_entity)
        
        return merged
    
    def _predictions_overlap(self, pred1: Dict, pred2: Dict, threshold: int = 1) -> bool:
        """
        Check if two predictions overlap or are adjacent.
        
        Args:
            pred1: First prediction
            pred2: Second prediction
            threshold: Max gap to consider as overlapping
            
        Returns:
            True if predictions overlap
        """
        # Check for overlap or small gap
        gap = min(abs(pred1["start"] - pred2["end"]), abs(pred2["start"] - pred1["end"]))
        return gap <= threshold or not (pred1["end"] <= pred2["start"] or pred2["end"] <= pred1["start"])
    
    def _merge_group(self, group: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        """
        Merge a group of overlapping predictions using weighted voting.
        
        Args:
            group: List of overlapping predictions
            
        Returns:
            Merged prediction or None
        """
        if not group:
            return None
        
        if len(group) == 1:
            return group[0]
        
        # Calculate weighted average score
        total_weight = sum(p.get("model_weight", 1.0) for p in group)
        avg_score = sum(p.get("weighted_score", p["score"]) for p in group) / total_weight
        
        # Use the widest span
        start = min(p["start"] for p in group)
        end = max(p["end"] for p in group)
        
        # Vote on entity type (weighted by model confidence)
        entity_votes = defaultdict(float)
        for p in group:
            entity_type = p.get("entity_group", p.get("entity", "UNKNOWN"))
            entity_votes[entity_type] += p.get("weighted_score", p["score"])
        
        # Select entity type with highest weighted vote
        most_common_type = max(entity_votes.items(), key=lambda x: x[1])[0]
        
        # Use the best prediction as base for word extraction
        best = max(group, key=lambda x: x["score"])
        
        return {
            "entity_group": most_common_type,
            "score": avg_score,
            "word": best.get("word", ""),
            "start": start,
            "end": end,
            "source_model": "ensemble",
            "contributing_models": [p["source_model"] for p in group],
            "vote_count": len(group),
            "individual_scores": [p["score"] for p in group]
        }
    
    def batch_detect(self, texts: List[str]) -> List[List[Dict[str, Any]]]:
        """
        Batch process multiple texts.
        
        Args:
            texts: List of texts to process
            
        Returns:
            List of entity lists (one per input text)
        """
        if not self.enabled:
            return [[] for _ in texts]
        
        results = []
        
        for text in texts:
            entities = self.detect_entities(text)
            results.append(entities)
        
        return results
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache performance statistics"""
        return self.cache.get_stats()
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded models"""
        return {
            "enabled": self.enabled,
            "device": self.device,
            "models_loaded": len(self.pipelines),
            "models": {
                name: {
                    "model_id": info["model_id"],
                    "weight": info["weight"]
                }
                for name, info in self.pipelines.items()
            },
            "cache_stats": self.get_cache_stats()
        }
