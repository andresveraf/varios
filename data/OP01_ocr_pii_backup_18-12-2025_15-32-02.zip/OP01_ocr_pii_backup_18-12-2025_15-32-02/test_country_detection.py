#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test suite for country detection from filenames
Tests the ability to detect country and map to correct Excel sheet
"""

import re
import os
import sys
from pathlib import Path
from typing import Dict, Optional, Tuple

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__)))


class CountrySheetDetector:
    """Detect country from filename and return corresponding sheet name"""
    
    def __init__(self):
        # Country detection patterns (case-insensitive)
        # Priority order: more specific patterns first
        self.country_patterns = [
            ('Brasil', r'(brasil|brazil|br)'),
            ('Colombia', r'(colombia|col)'),
            ('Chile', r'(chile|cl)'),
            ('Argentina', r'(argentina|ar)'),
            ('Uruguay', r'(uruguay|uy)')
        ]
        
        # Sheet name mapping
        self.sheet_mapping = {
            'Brasil': 'Brazil',
            'Chile': 'Chile',
            'Colombia': 'Colombia',
            'Argentina': 'Argentina',
            'Uruguay': 'Uruguay'
        }
        
        # Email column mapping (for future use with Excel sheets)
        self.email_column_mapping = {
            'Brasil': 'brazil_responsible_email',
            'Chile': 'chile_responsible_email',
            'Colombia': 'colombia_responsible_email',
            'Argentina': 'argentina_responsible_email',
            'Uruguay': 'uruguay_responsible_email'
        }
    
    def detect_country(self, filename: str) -> Optional[str]:
        """
        Extract country from filename using regex patterns
        
        Args:
            filename (str): The filename to analyze
            
        Returns:
            Optional[str]: Country name if detected, None otherwise
        """
        filename_lower = filename.lower()
        
        for country, pattern in self.country_patterns:
            if re.search(pattern, filename_lower):
                return country
        return None
    
    def get_sheet_name(self, filename: str) -> Optional[str]:
        """
        Get sheet name from filename
        
        Args:
            filename (str): The filename to analyze
            
        Returns:
            Optional[str]: Sheet name if country detected, None otherwise
        """
        country = self.detect_country(filename)
        if country:
            return self.sheet_mapping.get(country)
        return None
    
    def process_file(self, filename: str) -> Dict:
        """
        Complete processing: detect country, get sheet, get email column
        
        Args:
            filename (str): The filename to process
            
        Returns:
            Dict: Processing result with country, sheet name, and status
        """
        country = self.detect_country(filename)
        
        if not country:
            return {
                'filename': filename,
                'detected_country': None,
                'sheet_name': None,
                'status': 'not_detected'
            }
        
        sheet_name = self.sheet_mapping.get(country)
        email_column = self.email_column_mapping.get(country)
        
        return {
            'filename': filename,
            'detected_country': country,
            'sheet_name': sheet_name,
            'email_column': email_column,
            'status': 'success'
        }


def run_tests():
    """Run comprehensive test suite for country detection"""
    
    detector = CountrySheetDetector()
    
    # Test cases: (filename, expected_country, expected_sheet, description)
    test_cases = [
        # Real-world examples from production
        ('Reporte PII - Arquivo: Brasil - 123.1-Gestión mandatos físicos PAC', 'Brasil', 'Brazil', 'Brazil with file number'),
        ('Reporte PII - Arquivo: Chile - 456.2-Análisis de documentos', 'Chile', 'Chile', 'Chile report'),
        ('Reporte PII - Arquivo: Colombia - 789.3-Gestión de datos', 'Colombia', 'Colombia', 'Colombia report'),
        
        # Various filename formats
        ('Reporte_Brasil_2025.xlsx', 'Brasil', 'Brazil', 'Simple Brasil format'),
        ('Chile_Reportes_Finales.xlsx', 'Chile', 'Chile', 'Chile with underscore'),
        ('Colombia-Procesamiento.pdf', 'Colombia', 'Colombia', 'Colombia with hyphen'),
        ('argentina_PAC_mandatos.xlsx', 'Argentina', 'Argentina', 'Argentina lowercase'),
        ('URUGUAY_FINAL.xlsx', 'Uruguay', 'Uruguay', 'Uruguay uppercase'),
        
        # Edge cases with country codes
        ('BR_Report_123.xlsx', 'Brasil', 'Brazil', 'Brasil code BR'),
        ('CL_Analysis.xlsx', 'Chile', 'Chile', 'Chile code CL'),
        ('COL_Data.xlsx', 'Colombia', 'Colombia', 'Colombia code COL'),
        
        # Mixed case and special characters
        ('brasil-123-gestión.xlsx', 'Brasil', 'Brazil', 'Brasil lowercase with special chars'),
        ('CHILE_FINAL_REPORT.pdf', 'Chile', 'Chile', 'Chile all caps'),
        
        # Unknown country (should not detect)
        ('Unknown_Country_File.xlsx', None, None, 'Unknown country'),
        ('Reporte_2025.xlsx', None, None, 'No country indicator'),
        ('data_processing.txt', None, None, 'Generic filename'),
        
        # Multiple countries (first match should win - orden matters)
        ('Brasil_Chile_Report.xlsx', 'Brasil', 'Brazil', 'Multiple countries - Brasil first'),
    ]
    
    print("\n" + "=" * 100)
    print("COUNTRY DETECTION TEST SUITE")
    print("=" * 100)
    
    passed = 0
    failed = 0
    failed_tests = []
    
    for filename, expected_country, expected_sheet, description in test_cases:
        result = detector.process_file(filename)
        
        country_match = result.get('detected_country') == expected_country
        sheet_match = result.get('sheet_name') == expected_sheet
        
        test_passed = country_match and sheet_match
        
        if test_passed:
            passed += 1
            status = '[PASS]'
        else:
            failed += 1
            status = '[FAIL]'
            failed_tests.append({
                'filename': filename,
                'description': description,
                'expected': (expected_country, expected_sheet),
                'actual': (result.get('detected_country'), result.get('sheet_name'))
            })
        
        print(f"\n{status} | {description}")
        print(f"       Filename: {filename}")
        print(f"       Expected: Country={expected_country}, Sheet={expected_sheet}")
        print(f"       Got:      Country={result.get('detected_country')}, Sheet={result.get('sheet_name')}")
        
        if result.get('email_column'):
            print(f"       Email Column: {result.get('email_column')}")
    
    print("\n" + "=" * 100)
    print(f"TEST RESULTS: {passed} PASSED, {failed} FAILED out of {len(test_cases)} tests")
    print("=" * 100)
    
    if failed_tests:
        print("\nFAILED TESTS DETAILS:")
        for i, test in enumerate(failed_tests, 1):
            print(f"\n{i}. {test['description']}")
            print(f"   Filename: {test['filename']}")
            print(f"   Expected: Country={test['expected'][0]}, Sheet={test['expected'][1]}")
            print(f"   Got:      Country={test['actual'][0]}, Sheet={test['actual'][1]}")
    
    print("\n")
    return failed == 0


if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
