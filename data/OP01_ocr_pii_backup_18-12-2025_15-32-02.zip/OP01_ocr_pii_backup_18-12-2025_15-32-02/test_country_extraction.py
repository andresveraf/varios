#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Test country extraction from folder name"""

import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')

def test_country_extraction():
    """Test extracting country from folder names"""
    
    test_filenames = [
        "Brazil - 123.1-Gestión mandatos  físicos PAC",
        "Chile - 14-. Rutificación mensual voluntaria  banco Estado - 2025",
        "Colombia - Some Document Name",
        "Uruguay - Another Document",
        "NoCountry Document",  # Edge case
    ]
    
    print("\n" + "="*80)
    print("COUNTRY EXTRACTION TEST")
    print("="*80 + "\n")
    
    for filename in test_filenames:
        country_from_folder = None
        
        if ' - ' in filename:
            country_from_folder = filename.split(' - ')[0].strip()
            print(f"✓ Filename: {filename}")
            print(f"  → Extracted country: '{country_from_folder}'")
        else:
            print(f"✗ Filename: {filename}")
            print(f"  → No ' - ' separator found")
        
        # Map country to sheet name
        country_to_sheet = {
            'Brazil': 'Brazil',
            'Brasil': 'Brazil',
            'Chile': 'Chile',
            'Colombia': 'Colombia',
            'Uruguay': 'Uruguay'
        }
        
        sheet_name = country_to_sheet.get(country_from_folder, 'Chile')  # Default to Chile
        print(f"  → Mapped to sheet: '{sheet_name}'")
        print()
    
    print("="*80 + "\n")


def test_manager_email_reading():
    """Test reading manager emails from Excel"""
    
    print("\n" + "="*80)
    print("MANAGER EMAIL READING TEST")
    print("="*80 + "\n")
    
    manager_list_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "input",
        "Listado encargados Chile.xlsx"
    )
    
    print(f"Excel file path: {manager_list_path}")
    print(f"File exists: {os.path.exists(manager_list_path)}\n")
    
    if not os.path.exists(manager_list_path):
        print("⚠️  ERROR: File not found!")
        return
    
    # List all sheets
    try:
        xl_file = pd.ExcelFile(manager_list_path)
        print(f"Available sheets: {xl_file.sheet_names}\n")
    except Exception as e:
        print(f"⚠️  ERROR reading file: {e}")
        return
    
    # Test each sheet
    for sheet_name in ['Brazil', 'Chile', 'Colombia', 'Uruguay']:
        print(f"\n--- Testing sheet: {sheet_name} ---")
        
        try:
            df = pd.read_excel(manager_list_path, sheet_name=sheet_name)
            print(f"✓ Sheet read successfully")
            print(f"  Columns: {df.columns.tolist()}")
            print(f"  Rows: {len(df)}")
            
            # Check for Manager_email column
            if 'Manager_email' in df.columns:
                manager_emails = df['Manager_email'].dropna().unique().tolist()
                manager_emails = [email.strip() for email in manager_emails if email and str(email).strip()]
                print(f"  Manager emails found: {len(manager_emails)}")
                for email in manager_emails:
                    print(f"    - {email}")
            else:
                print(f"  ⚠️  WARNING: 'Manager_email' column not found")
                
        except Exception as e:
            print(f"  ⚠️  ERROR: {e}")
    
    print("\n" + "="*80 + "\n")


if __name__ == "__main__":
    test_country_extraction()
    test_manager_email_reading()
