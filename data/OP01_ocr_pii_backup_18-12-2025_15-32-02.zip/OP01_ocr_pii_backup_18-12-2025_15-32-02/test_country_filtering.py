#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick test for country-filtered identity number implementation
"""

import sys
sys.path.insert(0, 'c:\\RPA\\repositorio\\OPS\\OP01_ocr_pii')

from src.utils.pii_utils import PIIValidators, PIIPatterns, filter_identities_by_country


def test_validators():
    """Test CPF and CNPJ validators"""
    print("\n" + "="*70)
    print("TEST 1: Identity Number Validators")
    print("="*70)
    
    # Test valid CPF
    valid_cpf = "123.456.789-09"  # This is a valid test CPF with correct checksum
    result = PIIValidators.validate_cpf(valid_cpf)
    print(f"✓ CPF {valid_cpf}: {'VALID' if result else 'INVALID'}")
    
    # Test invalid CPF (all same digits)
    invalid_cpf = "111.111.111-11"
    result = PIIValidators.validate_cpf(invalid_cpf)
    print(f"✓ CPF {invalid_cpf}: {'VALID' if result else 'INVALID'} (expected: INVALID)")
    
    # Test valid CNPJ
    valid_cnpj = "11.222.333/0001-81"  # Valid test CNPJ
    result = PIIValidators.validate_cnpj(valid_cnpj)
    print(f"✓ CNPJ {valid_cnpj}: {'VALID' if result else 'INVALID'}")
    
    # Test invalid CNPJ
    invalid_cnpj = "11.222.333/0001-99"  # Invalid checksum
    result = PIIValidators.validate_cnpj(invalid_cnpj)
    print(f"✓ CNPJ {invalid_cnpj}: {'VALID' if result else 'INVALID'} (expected: INVALID)")


def test_country_mapping():
    """Test country identity mapping"""
    print("\n" + "="*70)
    print("TEST 2: Country-Identity Mapping")
    print("="*70)
    
    # Test COUNTRY_IDENTITY_MAP
    print("\nCountry → Identity Types:")
    for country, identity_types in PIIPatterns.COUNTRY_IDENTITY_MAP.items():
        print(f"  {country}: {', '.join(sorted(identity_types))}")
    
    # Test IDENTITY_TO_COUNTRY
    print("\nIdentity Type → Country:")
    for identity_type in sorted(PIIPatterns.IDENTITY_TO_COUNTRY.keys()):
        country = PIIPatterns.IDENTITY_TO_COUNTRY[identity_type]
        print(f"  {identity_type}: {country}")
    
    # Test is_valid_for_country
    print("\nValidation Tests:")
    tests = [
        ('CPF', 'Brasil', True),
        ('CPF', 'Chile', False),
        ('RUT', 'Chile', True),
        ('RUT', 'Brasil', False),
        ('CC', 'Colombia', True),
        ('CI', 'Uruguay', True),
        ('CC', 'Uruguay', False),
    ]
    
    for pii_type, country, expected in tests:
        result = PIIValidators.is_valid_for_country(pii_type, country)
        status = "✓" if result == expected else "✗"
        print(f"  {status} {pii_type} in {country}: {result} (expected: {expected})")


def test_country_filtering():
    """Test filter_identities_by_country function"""
    print("\n" + "="*70)
    print("TEST 3: Country-Based Filtering")
    print("="*70)
    
    # Sample entities
    entities = [
        {'PII_Type': 'CPF', 'PII_Value': '123.456.789-09', 'confidence': 0.9, 'Source': 'regex'},
        {'PII_Type': 'CNPJ', 'PII_Value': '11.222.333/0001-81', 'confidence': 0.85, 'Source': 'regex'},
        {'PII_Type': 'RUT', 'PII_Value': '12.345.678-9', 'confidence': 0.95, 'Source': 'regex'},
        {'PII_Type': 'CC', 'PII_Value': '1.234.567-8', 'confidence': 0.88, 'Source': 'regex'},
        {'PII_Type': 'CI', 'PII_Value': '1.234.567-8', 'confidence': 0.87, 'Source': 'regex'},
        {'PII_Type': 'Email', 'PII_Value': 'user@example.com', 'confidence': 1.0, 'Source': 'regex'},
        {'PII_Type': 'Phone', 'PII_Value': '+56912345678', 'confidence': 0.9, 'Source': 'regex'},
    ]
    
    print(f"\nOriginal entities: {len(entities)}")
    for e in entities:
        print(f"  - {e['PII_Type']}: {e['PII_Value']}")
    
    # Test 1: Chile (strict mode)
    print("\n--- Test 3.1: Chilean Document (strict_mode=True) ---")
    filtered_chile = filter_identities_by_country(entities, 'Chile', strict_mode=True)
    print(f"Filtered entities: {len(filtered_chile)}")
    for e in filtered_chile:
        print(f"  ✓ {e['PII_Type']}: {e['PII_Value']}")
    print(f"Expected: RUT, Email, Phone (3 entities)")
    print(f"Actual: {len(filtered_chile)} entities")
    
    # Test 2: Brasil (strict mode)
    print("\n--- Test 3.2: Brazilian Document (strict_mode=True) ---")
    filtered_brasil = filter_identities_by_country(entities, 'Brasil', strict_mode=True)
    print(f"Filtered entities: {len(filtered_brasil)}")
    for e in filtered_brasil:
        print(f"  ✓ {e['PII_Type']}: {e['PII_Value']}")
    print(f"Expected: CPF, CNPJ, Email, Phone (4 entities)")
    print(f"Actual: {len(filtered_brasil)} entities")
    
    # Test 3: Colombia (permissive mode)
    print("\n--- Test 3.3: Colombian Document (strict_mode=False) ---")
    filtered_colombia = filter_identities_by_country(entities, 'Colombia', strict_mode=False)
    print(f"Filtered entities: {len(filtered_colombia)} (including flagged)")
    for e in filtered_colombia:
        mismatch = " [MISMATCH]" if e.get('country_mismatch') else ""
        conf = e.get('confidence', 0)
        print(f"  {e['PII_Type']}: {e['PII_Value']} (conf: {conf:.2f}){mismatch}")
    
    # Test 4: Uruguay
    print("\n--- Test 3.4: Uruguayan Document (strict_mode=True) ---")
    filtered_uruguay = filter_identities_by_country(entities, 'Uruguay', strict_mode=True)
    print(f"Filtered entities: {len(filtered_uruguay)}")
    for e in filtered_uruguay:
        print(f"  ✓ {e['PII_Type']}: {e['PII_Value']}")
    print(f"Expected: CI, Email, Phone (3 entities)")
    print(f"Actual: {len(filtered_uruguay)} entities")


def test_edge_cases():
    """Test edge cases"""
    print("\n" + "="*70)
    print("TEST 4: Edge Cases")
    print("="*70)
    
    # Test 1: No country provided
    print("\n--- Test 4.1: No Country (should return all) ---")
    entities = [
        {'PII_Type': 'CPF', 'PII_Value': '123.456.789-09'},
        {'PII_Type': 'RUT', 'PII_Value': '12.345.678-9'},
    ]
    result = filter_identities_by_country(entities, None, strict_mode=True)
    print(f"Input: {len(entities)} entities")
    print(f"Output: {len(result)} entities (expected: {len(entities)})")
    
    # Test 2: Empty entities list
    print("\n--- Test 4.2: Empty List ---")
    result = filter_identities_by_country([], 'Chile', strict_mode=True)
    print(f"Output: {len(result)} entities (expected: 0)")
    
    # Test 3: Unknown country
    print("\n--- Test 4.3: Unknown Country ---")
    entities = [{'PII_Type': 'CPF', 'PII_Value': '123.456.789-09'}]
    result = filter_identities_by_country(entities, 'Argentina', strict_mode=True)
    print(f"Input: {len(entities)} entities")
    print(f"Output: {len(result)} entities (should return all with warning)")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("COUNTRY-FILTERED IDENTITY NUMBER DETECTION - TEST SUITE")
    print("="*70)
    
    try:
        test_validators()
        test_country_mapping()
        test_country_filtering()
        test_edge_cases()
        
        print("\n" + "="*70)
        print("✓ ALL TESTS COMPLETED")
        print("="*70)
        
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
