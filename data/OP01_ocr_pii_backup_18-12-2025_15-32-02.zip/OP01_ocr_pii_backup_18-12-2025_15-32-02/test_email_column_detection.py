#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test the cleaned-up email filtering logging
Verify that country-specific column warnings are gone
"""

import os
import sys
import logging

# Configure logging to see INFO and WARNING messages
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)

sys.path.insert(0, os.path.dirname(__file__))

from src.process_scripts.S4_pii_orchestrator import S4PIIOrchestrator


def test_email_column_detection():
    """Test that email column detection works cleanly without unnecessary warnings"""
    
    print("\n" + "=" * 80)
    print("TESTING EMAIL COLUMN DETECTION - CLEAN LOGGING")
    print("=" * 80 + "\n")
    
    # Create an orchestrator instance
    try:
        orchestrator = S4PIIOrchestrator()
        print("[OK] S4PIIOrchestrator initialized\n")
    except Exception as e:
        print(f"[FAIL] Error initializing orchestrator: {e}")
        return False
    
    # Test _get_manager_emails with Argentina sheet
    print("Test 1: _get_manager_emails(sheet_name='Argentina')")
    print("-" * 80)
    emails = orchestrator._get_manager_emails(sheet_name='Argentina')
    print(f"Result: {emails}")
    print()
    
    # Test _get_manager_emails with Chile sheet
    print("Test 2: _get_manager_emails(sheet_name='Chile')")
    print("-" * 80)
    emails = orchestrator._get_manager_emails(sheet_name='Chile')
    print(f"Result: {emails}")
    print()
    
    # Test _get_manager_emails with no sheet specified
    print("Test 3: _get_manager_emails() [no sheet specified]")
    print("-" * 80)
    emails = orchestrator._get_manager_emails()
    print(f"Result: {emails}")
    print()
    
    # Test _get_responsible_email with Argentina
    print("Test 4: _get_responsible_email('Test Folder', sheet_name='Argentina')")
    print("-" * 80)
    email = orchestrator._get_responsible_email('Test Folder', sheet_name='Argentina')
    print(f"Result: {email}")
    print()
    
    print("=" * 80)
    print("[OK] ALL TESTS COMPLETED - Check logging for clean output without warnings")
    print("=" * 80)
    
    return True


if __name__ == '__main__':
    success = test_email_column_detection()
    sys.exit(0 if success else 1)
