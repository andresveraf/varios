#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test the updated email filtering by country/sheet detection
Demonstrates how _get_manager_emails and _get_responsible_email 
now filter results based on detected country.
"""

import os
import sys

# Add src to path
sys.path.insert(0, os.path.dirname(__file__))

from src.process_scripts.S4_pii_orchestrator import CountrySheetDetector


class EmailFilteringDemo:
    """Demonstrate country-based email filtering"""
    
    def __init__(self):
        self.detector = CountrySheetDetector()
    
    def demonstrate_filtering(self):
        """Show how email filtering works for different countries"""
        
        test_cases = [
            {
                'filename': 'Reporte PII - Brasil - 123.1-Gestión mandatos físicos PAC',
                'type': 'Resume Email',
                'description': 'Resume email for Brazil report'
            },
            {
                'filename': 'Reporte PII - Chile - 456.2-Análisis de documentos',
                'type': 'Folder Email',
                'description': 'Folder email for Chile report'
            },
            {
                'filename': 'Colombia - Reportes Finales - Procesamiento',
                'type': 'Folder Email',
                'description': 'Folder email for Colombia report'
            },
            {
                'filename': 'Uruguay_Procesamiento_2025.xlsx',
                'type': 'Folder Email',
                'description': 'Folder email for Uruguay report'
            },
            {
                'filename': 'Argentina_PAC_Mandatos.xlsx',
                'type': 'Folder Email',
                'description': 'Folder email for Argentina report'
            }
        ]
        
        print("=" * 100)
        print("EMAIL FILTERING BY COUNTRY DETECTION")
        print("=" * 100)
        print()
        
        for test in test_cases:
            filename = test['filename']
            
            # Detect country
            detected_country = self.detector.detect_country(filename)
            detected_sheet = self.detector.get_sheet_name(filename)
            email_column = self.detector.get_email_column(filename)
            
            print(f"Test: {test['description']}")
            print(f"Filename: {filename}")
            print(f"  Detected Country: {detected_country}")
            print(f"  Detected Sheet: {detected_sheet}")
            print(f"  Email Column to Use: {email_column}")
            print()
            
            if test['type'] == 'Resume Email':
                print(f"  ACTION: Call _get_manager_emails(sheet_name='{detected_sheet}')")
                print(f"  → Will read from '{email_column}' column in 'Listado encargados Chile.xlsx'")
            else:
                print(f"  ACTION: Call _get_responsible_email('{filename}', sheet_name='{detected_sheet}')")
                print(f"  → Will match folder AND filter emails using '{email_column}' column")
            
            print()
            print("-" * 100)
            print()
        
        print("\n" + "=" * 100)
        print("COLUMN MAPPING SUMMARY")
        print("=" * 100)
        print()
        
        print("Manager Email Columns (for resume emails):")
        print("  Brasil  → brazil_manager_email")
        print("  Chile   → chile_manager_email")
        print("  Colombia → colombia_manager_email")
        print("  Argentina → argentina_manager_email")
        print("  Uruguay → uruguay_manager_email")
        print()
        
        print("Responsible Email Columns (for folder emails):")
        print("  Brasil  → brazil_responsible_email")
        print("  Chile   → chile_responsible_email")
        print("  Colombia → colombia_responsible_email")
        print("  Argentina → argentina_responsible_email")
        print("  Uruguay → uruguay_responsible_email")
        print()
        
        print("=" * 100)
        print("IMPLEMENTATION NOTES")
        print("=" * 100)
        print()
        print("1. Both functions (_get_manager_emails and _get_responsible_email) now accept sheet_name parameter")
        print()
        print("2. If sheet_name is provided, they use country-specific email columns")
        print()
        print("3. If country-specific column doesn't exist, falls back to default column:")
        print("   - _get_manager_emails → 'Manager_email'")
        print("   - _get_responsible_email → 'Responsible_email'")
        print()
        print("4. The calling functions automatically detect the sheet from filename:")
        print("   - _send_single_resume_email: Detects sheet, passes to _get_manager_emails()")
        print("   - _send_folder_email: Detects sheet, passes to _get_responsible_email()")
        print()
        print("5. This allows for country-specific email routing without breaking existing code")
        print()


if __name__ == '__main__':
    demo = EmailFilteringDemo()
    demo.demonstrate_filtering()
