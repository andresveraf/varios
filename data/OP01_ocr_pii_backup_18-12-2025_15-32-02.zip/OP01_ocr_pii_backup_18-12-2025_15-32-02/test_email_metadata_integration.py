#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Test script for email metadata integration
Verifies that S0 correctly extracts contact info and adds it to metadata
"""

import os
import sys
import pandas as pd
from pathlib import Path

# Add src to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src')))

def test_metadata_columns():
    """Test if metadata file has the new email columns"""
    print("=" * 80)
    print("TEST 1: Verify Metadata Columns")
    print("=" * 80)
    
    metadata_path = "output/_others/files_metadata.xlsx"
    
    if not os.path.exists(metadata_path):
        print(f"❌ Metadata file not found: {metadata_path}")
        print("   Run S0_change_detector_backup.py first to generate metadata")
        return False
    
    try:
        df = pd.read_excel(metadata_path)
        print(f"✅ Metadata file loaded: {len(df)} rows, {len(df.columns)} columns")
        
        # Check for new email columns
        expected_columns = ['responsible_email', 'responsible_name', 'manager_email', 'manager_name', 'lob']
        missing_columns = [col for col in expected_columns if col not in df.columns]
        
        if missing_columns:
            print(f"❌ Missing email columns: {missing_columns}")
            print(f"   Available columns: {df.columns.tolist()}")
            return False
        else:
            print(f"✅ All email columns present: {expected_columns}")
            
        # Check if columns have data
        print("\n📊 Email Column Statistics:")
        for col in expected_columns:
            non_empty = df[col].notna().sum()
            empty = df[col].isna().sum()
            print(f"   {col:20s}: {non_empty} filled, {empty} empty")
        
        # Show sample data
        print("\n📋 Sample Data (first 3 rows):")
        sample_cols = ['original_filename', 'source_region', 'primary_subfolder'] + expected_columns
        available_sample_cols = [col for col in sample_cols if col in df.columns]
        print(df[available_sample_cols].head(3).to_string(index=False))
        
        return True
        
    except Exception as e:
        print(f"❌ Error reading metadata: {e}")
        return False


def test_excel_lookup_file():
    """Test if the Excel lookup file exists and has correct structure"""
    print("\n" + "=" * 80)
    print("TEST 2: Verify Excel Lookup File")
    print("=" * 80)
    
    excel_path = "input/Listado encargados Chile.xlsx"
    
    if not os.path.exists(excel_path):
        print(f"❌ Excel lookup file not found: {excel_path}")
        return False
    
    try:
        # Try reading Chile sheet
        df = pd.read_excel(excel_path, sheet_name='Chile')
        print(f"✅ Excel file loaded (Chile sheet): {len(df)} rows, {len(df.columns)} columns")
        
        # Check for required columns
        required_columns = ['Lob', 'Carpeta', 'Documento', 'Responsable', 'Responsible_email', 'Jefatura', 'Manager_email']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            print(f"❌ Missing required columns: {missing_columns}")
            print(f"   Available columns: {df.columns.tolist()}")
            return False
        else:
            print(f"✅ All required columns present")
        
        # Show sample data
        print("\n📋 Sample Data (first 3 rows):")
        print(df[required_columns].head(3).to_string(index=False))
        
        # Count unique values
        print("\n📊 Unique Values:")
        print(f"   LOBs: {df['Lob'].nunique()}")
        print(f"   Responsible emails: {df['Responsible_email'].nunique()}")
        print(f"   Manager emails: {df['Manager_email'].nunique()}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error reading Excel file: {e}")
        return False


def test_matching_logic():
    """Test if files in metadata can be matched to Excel lookup"""
    print("\n" + "=" * 80)
    print("TEST 3: Test Matching Logic")
    print("=" * 80)
    
    metadata_path = "output/_others/files_metadata.xlsx"
    excel_path = "input/Listado encargados Chile.xlsx"
    
    if not os.path.exists(metadata_path) or not os.path.exists(excel_path):
        print(f"❌ Required files not found")
        return False
    
    try:
        # Read both files
        metadata_df = pd.read_excel(metadata_path)
        excel_df = pd.read_excel(excel_path, sheet_name='Chile')
        
        print(f"✅ Files loaded")
        print(f"   Metadata: {len(metadata_df)} files")
        print(f"   Excel lookup: {len(excel_df)} entries")
        
        # Check matching success rate
        files_with_email = metadata_df['responsible_email'].notna().sum()
        total_files = len(metadata_df)
        match_rate = (files_with_email / total_files * 100) if total_files > 0 else 0
        
        print(f"\n📊 Matching Statistics:")
        print(f"   Files with responsible_email: {files_with_email}/{total_files} ({match_rate:.1f}%)")
        print(f"   Files without email: {total_files - files_with_email}")
        
        # Show matched files
        if files_with_email > 0:
            print("\n✅ Successfully Matched Files:")
            matched = metadata_df[metadata_df['responsible_email'].notna()]
            display_cols = ['original_filename', 'primary_subfolder', 'responsible_email', 'manager_email', 'lob']
            available_cols = [col for col in display_cols if col in matched.columns]
            print(matched[available_cols].to_string(index=False))
        
        # Show unmatched files
        unmatched_count = total_files - files_with_email
        if unmatched_count > 0:
            print(f"\n⚠️ Unmatched Files ({unmatched_count}):")
            unmatched = metadata_df[metadata_df['responsible_email'].isna()]
            display_cols = ['original_filename', 'primary_subfolder']
            available_cols = [col for col in display_cols if col in unmatched.columns]
            print(unmatched[available_cols].to_string(index=False))
        
        return match_rate > 0
        
    except Exception as e:
        print(f"❌ Error testing matching: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("\n🧪 EMAIL METADATA INTEGRATION TEST SUITE")
    print("=" * 80)
    print("This script verifies that S0 correctly extracts contact information")
    print("from 'Listado encargados Chile.xlsx' and adds it to metadata.")
    print("=" * 80)
    
    results = []
    
    # Test 1: Metadata columns
    results.append(("Metadata Columns", test_metadata_columns()))
    
    # Test 2: Excel lookup file
    results.append(("Excel Lookup File", test_excel_lookup_file()))
    
    # Test 3: Matching logic
    results.append(("Matching Logic", test_matching_logic()))
    
    # Summary
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name:30s}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    print("\n" + "=" * 80)
    if all_passed:
        print("🎉 ALL TESTS PASSED!")
        print("The email metadata integration is working correctly.")
    else:
        print("⚠️ SOME TESTS FAILED")
        print("Please check the errors above and run S0 again if needed.")
    print("=" * 80)
    
    return all_passed


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
