#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quick test to verify transformer models load without meta tensor errors
"""

import sys
import logging

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

try:
    # Import required modules
    from src.utils.fmw_utils import Config
    from src.utils.transformer_ensemble import TransformerEnsemble
    
    print("="*70)
    print("TESTING TRANSFORMER MODEL LOADING")
    print("="*70)
    
    # Load config
    config = Config()
    config_data = config.build_config()
    transformer_config = config_data.get("GLOBAL", {}).get("TRANSFORMER_CONFIG", {})
    
    print(f"\nConfiguration loaded:")
    print(f"  - Primary model: {transformer_config.get('model_name')}")
    print(f"  - Secondary model: {transformer_config.get('secondary_model')}")
    print(f"  - Tertiary model: {transformer_config.get('tertiary_model')}")
    print(f"  - Device: {transformer_config.get('device')}")
    print(f"  - Ensemble enabled: {transformer_config.get('use_ensemble')}")
    
    print("\n" + "="*70)
    print("INITIALIZING TRANSFORMER ENSEMBLE...")
    print("="*70 + "\n")
    
    # Initialize ensemble
    ensemble = TransformerEnsemble(transformer_config)
    
    print("\n" + "="*70)
    print("SUCCESS! MODEL LOADING TEST PASSED")
    print("="*70)
    
    # Get model info
    model_info = ensemble.get_model_info()
    print(f"\nLoaded models: {model_info['models_loaded']}")
    print(f"Device: {model_info['device']}")
    # print(f"Ensemble enabled: {model_info['ensemble_enabled']}")  # Key might not exist
    
    # Test prediction
    print("\n" + "="*70)
    print("TESTING PREDICTION...")
    print("="*70)
    
    test_text = "El cliente Juan Pérez Gómez con RUT 12.345.678-9 solicitó información."
    print(f"\nInput text: {test_text}")
    
    predictions = ensemble.predict(test_text)
    print(f"\nPredictions found: {len(predictions)}")
    for pred in predictions:
        print(f"  - {pred['entity_type']}: '{pred['word']}' (confidence: {pred['score']:.2f})")
    
    print("\n" + "="*70)
    print("ALL TESTS PASSED! ✓")
    print("="*70)
    
    sys.exit(0)
    
except Exception as e:
    print("\n" + "="*70)
    print("ERROR DURING TEST")
    print("="*70)
    print(f"\nError: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
