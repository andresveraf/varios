"""
Test script to verify country filtering is integrated in the detection pipeline.
Tests that country detection from file paths flows through to PII filtering.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.process_scripts.S3_regex_pii import S3_RegexPII
from src.utils.pii_utils import PIIPatterns
from src.utils.fmw_utils import read_config

# Initialize config once
CONFIG = read_config()

def test_chile_filtering():
    """Test that Chilean RUT is detected but not Brazilian CPF"""
    print("\n" + "="*80)
    print("TEST 1: Chile Path - Should detect RUT but not CPF")
    print("="*80)
    
    # Simulate a Chilean file path
    test_text = """
    Cliente: Juan Pérez
    RUT: 12.345.678-5
    CPF: 123.456.789-09
    Email: juan@example.com
    """
    
    # Simulate Chilean file path (contains "Chile")
    detector = S3_RegexPII(config=CONFIG)
    
    # Detect country from path
    country = detector._detect_country_from_path("input/chile_path/Chile - Document.pdf")
    print(f"Detected country: {country}")
    
    # Extract PII with country filtering
    results = detector.extract_pii_from_text(test_text, country=country)
    
    # Debug: print results structure
    if results:
        print(f"\nDEBUG: First result keys: {results[0].keys() if isinstance(results[0], dict) else 'Not a dict'}")
        print(f"DEBUG: First result: {results[0]}")
    
    # Check results
    entity_types = {r.get('entity_type', r.get('type', 'UNKNOWN')) for r in results}
    print(f"\nDetected PII types: {entity_types}")
    print(f"Total entities found: {len(results)}")
    
    for entity in results:
        etype = entity.get('entity_type', entity.get('type', 'UNKNOWN'))
        value = entity.get('value', entity.get('text', 'N/A'))
        print(f"  - {etype}: {value}")
    
    # Assertions
    has_rut = any(e.get('PII_Type', '') in ['RUT', 'RUT_Comma'] for e in results)
    has_cpf = any(e.get('PII_Type', '') in ['CPF', 'CPF_Context'] for e in results)
    has_email = any(e.get('PII_Type', '') == 'EMAIL' for e in results)
    
    print(f"\n[+] Has RUT: {has_rut}")
    print(f"[-] Has CPF: {has_cpf} (should be False)")
    print(f"[+] Has EMAIL: {has_email}")
    
    assert has_rut, "Should detect Chilean RUT"
    assert not has_cpf, "Should NOT detect Brazilian CPF in Chilean document"
    # Note: EMAIL detection is not guaranteed in this test
    
    print("\n[PASS] TEST PASSED: Chilean filtering works correctly")


def test_brasil_filtering():
    """Test that Brazilian CPF is detected but not Chilean RUT"""
    print("\n" + "="*80)
    print("TEST 2: Brasil Path - Should detect CPF but not RUT")
    print("="*80)
    
    test_text = """
    Cliente: João Silva
    RUT: 12.345.678-5
    CPF: 123.456.789-09
    CNPJ: 12.345.678/0001-95
    Email: joao@example.com
    """
    
    detector = S3_RegexPII(config=CONFIG)
    country = detector._detect_country_from_path("input/brasil_path/Brasil - Documento.pdf")
    print(f"Detected country: {country}")
    
    results = detector.extract_pii_from_text(test_text, country=country)
    
    entity_types = {r.get('PII_Type', 'UNKNOWN') for r in results}
    print(f"\nDetected PII types: {entity_types}")
    print(f"Total entities found: {len(results)}")
    
    for entity in results:
        etype = entity.get('PII_Type', 'UNKNOWN')
        value = entity.get('PII_Value', 'N/A')
        print(f"  - {etype}: {value}")
    
    has_rut = any(e.get('PII_Type', '') in ['RUT', 'RUT_Comma'] for e in results)
    has_cpf = any(e.get('PII_Type', '') in ['CPF', 'CPF_Context'] for e in results)
    has_cnpj = any(e.get('PII_Type', '') in ['CNPJ', 'CNPJ_Context'] for e in results)
    has_email = any(e.get('PII_Type', '') == 'EMAIL' for e in results)
    
    print(f"\n[-] Has RUT: {has_rut} (should be False)")
    print(f"[+] Has CPF: {has_cpf}")
    print(f"[+] Has CNPJ: {has_cnpj}")
    print(f"[+] Has EMAIL: {has_email}")
    
    assert not has_rut, "Should NOT detect Chilean RUT in Brazilian document"
    assert has_cpf, "Should detect Brazilian CPF"
    assert has_cnpj, "Should detect Brazilian CNPJ"
    # Note: EMAIL detection is not guaranteed in this test
    
    print("\n[PASS] TEST PASSED: Brazilian filtering works correctly")


def test_no_country_path():
    """Test that all identities are detected when no country is detected"""
    print("\n" + "="*80)
    print("TEST 3: Unknown Path - Should detect ALL identities")
    print("="*80)
    
    test_text = """
    RUT: 12.345.678-5
    CPF: 123.456.789-09
    CC: 1234567890
    CI: 1.234.567-8
    """
    
    detector = S3_RegexPII(config=CONFIG)
    country = detector._detect_country_from_path("input/unknown_folder/Document.pdf")
    print(f"Detected country: {country}")
    
    results = detector.extract_pii_from_text(test_text, country=country)
    
    entity_types = {r.get('PII_Type', 'UNKNOWN') for r in results}
    print(f"\nDetected PII types: {entity_types}")
    print(f"Total entities found: {len(results)}")
    
    for entity in results:
        etype = entity.get('PII_Type', 'UNKNOWN')
        value = entity.get('PII_Value', 'N/A')
        print(f"  - {etype}: {value}")
    
    # When no country detected, all identities should pass through
    assert len(results) >= 4, "Should detect all identity types when country is unknown"
    
    print("\n[PASS] TEST PASSED: No-country filtering works correctly (all identities detected)")


def test_country_detection_patterns():
    """Test various country detection patterns"""
    print("\n" + "="*80)
    print("TEST 4: Country Detection Patterns")
    print("="*80)
    
    detector = S3_RegexPII(config=CONFIG)
    
    test_cases = [
        ("input/chile_path/Chile - Document.pdf", "Chile"),
        ("input/brasil_path/Brasil - Documento.pdf", "Brasil"),
        ("input/colombia_path/Colombia - Archivo.pdf", "Colombia"),
        ("input/uruguay_path/Uruguay - Informe.pdf", "Uruguay"),
        ("C:\\Users\\data\\Chile\\report.pdf", "Chile"),
        ("D:\\sharepoint\\Brasil - Client Data\\file.pdf", "Brasil"),
        ("input/other/generic_file.pdf", None),
    ]
    
    print("\nTesting path patterns:")
    for path, expected in test_cases:
        detected = detector._detect_country_from_path(path)
        match = "[OK]" if detected == expected else "[FAIL]"
        print(f"{match} Path: {path}")
        print(f"   Expected: {expected}, Detected: {detected}")
        assert detected == expected, f"Failed for path: {path}"
    
    print("\n[PASS] TEST PASSED: All country detection patterns work correctly")


def main():
    """Run all integration tests"""
    print("\n" + "#"*80)
    print("# COUNTRY FILTERING PIPELINE INTEGRATION TESTS")
    print("#"*80)
    
    try:
        test_country_detection_patterns()
        test_chile_filtering()
        test_brasil_filtering()
        test_no_country_path()
        
        print("\n" + "="*80)
        print("[PASS] ALL PIPELINE INTEGRATION TESTS PASSED!")
        print("="*80)
        print("\nCountry filtering is successfully integrated into the detection pipeline.")
        print("Identity numbers will now be automatically filtered based on detected country.")
        
    except AssertionError as e:
        print(f"\n[FAIL] TEST FAILED: {e}")
        return False
    except Exception as e:
        print(f"\n[ERROR] ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
