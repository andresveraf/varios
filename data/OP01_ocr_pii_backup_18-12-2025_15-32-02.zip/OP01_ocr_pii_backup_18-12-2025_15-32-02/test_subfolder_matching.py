import pandas as pd

# Load metadata
meta = pd.read_excel('C:/RPA/repositorio/OPS/OP01_ocr_pii/output/_others/files_metadata.xlsx')
excel = pd.read_excel('C:/RPA/repositorio/OPS/OP01_ocr_pii/input/Listado encargados Chile.xlsx', sheet_name='Chile')

print('=' * 80)
print('METADATA - Extracted primary_subfolder values:')
print('=' * 80)
print(meta[['original_filename', 'primary_subfolder']].to_string())

print('\n' + '=' * 80)
print('EXCEL - Sample Documento values (first 20):')
print('=' * 80)
for i, doc in enumerate(excel['Documento'].head(20)):
    print(f"{i+1}. {doc}")

print('\n' + '=' * 80)
print('MATCHING TEST:')
print('=' * 80)

for idx, row in meta.iterrows():
    sf = row['primary_subfolder']
    filename = row['original_filename']
    
    print(f"\nFile: {filename}")
    print(f"Subfolder extracted: '{sf}'")
    
    # Try exact match
    exact_match = excel[excel['Documento'] == sf]
    if not exact_match.empty:
        print(f"✅ EXACT MATCH found!")
        print(f"   Email: {exact_match.iloc[0]['Responsible_email']}")
    else:
        # Try partial match
        partial_match = excel[excel['Documento'].str.contains(sf, case=False, na=False)]
        if not partial_match.empty:
            print(f"⚠️  PARTIAL MATCH found ({len(partial_match)} results):")
            for _, match in partial_match.head(3).iterrows():
                print(f"   - {match['Documento']} -> {match['Responsible_email']}")
        else:
            print(f"❌ NO MATCH found")
            # Show closest matches
            print(f"   Closest Documento values:")
            for doc in excel['Documento'].head(10):
                if '1-.' in doc or '5-.' in doc:
                    print(f"   - {doc}")

print('\n' + '=' * 80)
print('ANALYSIS COMPLETE')
print('=' * 80)
