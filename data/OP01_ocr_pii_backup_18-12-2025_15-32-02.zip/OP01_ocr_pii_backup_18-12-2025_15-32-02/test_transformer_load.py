#!/usr/bin/env python3
"""Quick test to verify transformer models load correctly"""

import sys
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from src.utils.fmw_utils import read_config

def test_transformer_loading():
    """Test if transformer models load without errors"""
    logger.info("="*70)
    logger.info("TESTING TRANSFORMER MODEL LOADING")
    logger.info("="*70)
    
    try:
        # Load config
        config = read_config()
        transformer_config = config['GLOBAL']['TRANSFORMER_CONFIG']
        
        logger.info(f"Primary model: {transformer_config['model_name']}")
        logger.info(f"Secondary model: {transformer_config['secondary_model']}")
        logger.info(f"Tertiary model: {transformer_config['tertiary_model']}")
        
        # Try to load transformer ensemble
        from utils.transformer_ensemble import TransformerEnsemble
        
        ensemble = TransformerEnsemble(transformer_config)
        
        logger.info("="*70)
        logger.info("SUCCESS: All models loaded successfully!")
        logger.info("="*70)
        
        # Test a simple prediction
        test_text = "Mi nombre es Juan García y mi RUT es 12.345.678-9"
        logger.info(f"\nTest text: {test_text}")
        
        result = ensemble.detect_entities(test_text)
        logger.info(f"Detected entities: {len(result)} found")
        for entity in result:
            logger.info(f"  - {entity}")
        
        return True
        
    except Exception as e:
        logger.error(f"FAILED: {e}", exc_info=True)
        return False

if __name__ == "__main__":
    success = test_transformer_loading()
    sys.exit(0 if success else 1)
