# Helper Functions Index (`src/utils`)

*Last Updated: September 30, 2025*

| Function/Class Name         | File Path                                 | Description |
|----------------------------|-------------------------------------------|-------------|
| add_dt_offset              | src/utils/fmw_utils.py                    | Add a time offset to a datetime object. |
| adjust_column_widths_and_format_headers  | src/utils/fmw_utils.py                    | Adjust the column widths in an Excel file and format the headers with blue fill, |
| batch_process_pdfs         | src/utils/pdf_utils.py                    | Process multiple PDF files in batch. |
| build_execution_summary_table  | src/utils/fmw_utils.py                    | Build and save an execution summary table as a DataFrame and JSON file. |
| build_execution_summary_table_eb  | src/utils/fmw_utils.py                    | Build and save a minimal execution summary table for EB processes. |
| BusinessException (class)  | src/utils/fmw_utils.py                    | Custom exception for business logic errors. |
| check_file_exist           | src/utils/fmw_utils.py                    | Check if a single required file exists. Raises FileNotFoundError if missing. |
| check_files_exist          | src/utils/fmw_utils.py                    | Check if all required files exist. Raises FileNotFoundError if any are missing. |
| compare_dataframes         | src/utils/pandas_utils.py                 | Compare two DataFrames and return differences. |
| Config (class)             | src/utils/fmw_utils.py                    | Loads and builds configuration from JSONC files, manages config paths and tag keys. |
| create_backup              | src/utils/fmw_utils.py                    | Copy a file to a backup folder, avoiding overwrites by renaming duplicates. |
| create_folder              | src/utils/fmw_utils.py                    | Create a folder if it does not exist. |
| create_pdf_report          | src/utils/pdf_utils.py                    | Create a comprehensive report for a PDF file. |
| create_sample_data         | src/utils/xlwings_utils/test_xlwingsutils.py | Create sample Excel file for testing. |
| create_summary_report      | src/utils/pandas_utils.py                 | Create a comprehensive summary report of DataFrame. |
| Credentials (class)        | src/utils/credentials_utils.py            | Class to initiate encripted credentials |
| delete_folder              | src/utils/fmw_utils.py                    | Delete a folder and its contents. |
| delete_old_folders         | src/utils/fmw_utils.py                    | Delete old folders according to a month offset and date format. |
| df2html                    | src/utils/send_email_utils.py             | Transforms a dataframe to an html that can be used to show the table in an email |
| dt_to_spanish              | src/utils/fmw_utils.py                    | Convert a datetime to its Spanish month or day name. |
| es_pdf_de_imagen           | src/utils/fmw_utils.py                    | Check if a PDF is image-based by analyzing text and image content using PyMuPDF. |
| example_usage              | src/utils/xlwings_utils.py                | Example usage of XLWingsUtils class. |
| example_usage              | src/utils/xlwings_utils/xlwingsutils.py   | Example usage of XLWingsUtils class. |
| ExceptionEmails (class)    | src/utils/send_exceptions_emails.py       | Handle sending exception-related emails for system, user, and business exceptions with config-based setup. |
| find_header_row_index      | src/utils/fmw_utils.py                    | Scan the first `max_rows` of an Excel file to find the row index where the target column appears. |
| get_last_log_file          | src/utils/fmw_utils.py                    | Get the most recently modified log file in the log folder. |
| get_size                   | src/utils/fmw_utils.py                    | Get the size of a file in the specified unit. |
| get_total_states           | src/utils/fmw_utils.py                    | Get the total number of states defined in main.py (lines with 'self.state_idx == '). |
| is_pdf_image_based         | src/utils/fmw_utils.py                    | Check if a PDF is image-based (scanned) by analyzing text content and images. |
| kill_processes             | src/utils/fmw_utils.py                    | Kill a list of processes by name using PowerShell. |
| last_day_in_month          | src/utils/fmw_utils.py                    | Return the last day of the month for a given datetime. |
| log_worktray_metadata      | src/utils/fmw_utils.py                    | Log worktray metadata, including status counts and file existence. |
| mask_number                | src/utils/fmw_utils.py                    | Mask a number, showing only the last digits and decimals. |
| merge_multiple_dataframes  | src/utils/pandas_utils.py                 | Merge multiple DataFrames. |
| merge_pdf_extractions      | src/utils/pdf_utils.py                    | Merge results from multiple PDF extractions. |
| number_to_currency         | src/utils/fmw_utils.py                    | Convert a number to Chilean currency format. |
| obtain_months              | src/utils/fmw_utils.py                    | Load and return Spanish month names dictionary from dates_info.json configuration file. |
| PandasUtils (class)        | src/utils/pandas_utils.py                 | A utility class for common pandas operations and data manipulation. |
| PDFUtils (class)           | src/utils/pdf_utils.py                    | A utility class for PDF processing operations using pdfplumber. |
| read_config                | src/utils/fmw_utils.py                    | Read and return the processed configuration using the Config class. |
| read_json                  | src/utils/fmw_utils.py                    | Read a JSON file and return its contents as a dictionary. |
| read_jsonc                 | src/utils/fmw_utils.py                    | Read a JSONC (JSON with comments) file and return its contents as a dictionary. |
| read_recipients_file       | src/utils/send_email_utils.py             | Reads recpients file and returns three lists to, cc, and bcc. |
| read_txt                   | src/utils/fmw_utils.py                    | Read a text file and return its contents. |
| remove_accents             | src/utils/fmw_utils.py                    | Remove accents from a string. |
| remove_path_until_tag      | src/utils/fmw_utils.py                    | Shorten a given path, removing its first part until a specific folder/tag. |
| run_all_tests              | src/utils/xlwings_utils/test_xlwingsutils.py | Run all test functions. |
| save_excel_file            | src/utils/fmw_utils.py                    | Save a pandas DataFrame to an Excel file with formatting. |
| save_json_file             | src/utils/fmw_utils.py                    | Save a dictionary as a JSON file. |
| save_txt_file              | src/utils/fmw_utils.py                    | Save a string as a text file. |
| SeleniumUtils (class)      | src/utils/selenium_utils.py               | Utility class for automating web browsers with Selenium, including driver setup and common actions. |
| send_email                 | src/utils/send_email_utils.py             | Sends email with logged account as defined by parameters |
| standardize_date_format    | src/utils/fmw_utils.py                    | Standardize date formatting across all modules with comprehensive format support. |
| standardize_single_date    | src/utils/fmw_utils.py                    | Standardize a single date value to the specified format. |
| start_logging              | src/utils/fmw_utils.py                    | Initialize logging to file and/or console with custom formatting. |
| test_basic_operations      | src/utils/xlwings_utils/test_xlwingsutils.py | Test basic file operations. |
| test_error_handling        | src/utils/xlwings_utils/test_xlwingsutils.py | Test error handling capabilities. |
| test_filtering_operations  | src/utils/xlwings_utils/test_xlwingsutils.py | Test filtering operations. |
| test_formatting_operations  | src/utils/xlwings_utils/test_xlwingsutils.py | Test formatting operations. |
| test_pivot_table_operations  | src/utils/xlwings_utils/test_xlwingsutils.py | Test pivot table creation and extraction. |
| test_row_column_operations  | src/utils/xlwings_utils/test_xlwingsutils.py | Test row and column manipulation. |
| test_search_operations     | src/utils/xlwings_utils/test_xlwingsutils.py | Test search and find operations. |
| write_process_status       | src/utils/fmw_utils.py                    | Append the process status and timestamp to a JSON file in the process_data folder. |
| XLWingsUtils (class)       | src/utils/xlwings_utils.py                | Comprehensive utility class for Excel automation using xlwings. |
| XLWingsUtils (class)       | src/utils/xlwings_utils/xlwingsutils.py   | Comprehensive utility class for Excel automation using xlwings. |

**Configuration variables are managed in `config.jsonc` at the project root. If present, use `src/utils/constants.py` for project-wide constants.**

Files excluded: monitoring.py, robot_date.py, base_workflow.py