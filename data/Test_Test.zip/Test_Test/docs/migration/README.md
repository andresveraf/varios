# Migration Documentation Directory

This directory contains all process migration documentation files. Each migration is documented in a **single comprehensive markdown file** following the standardized template.

## File Naming Convention

All migration documents must follow this naming pattern:
```
{PROCESS_NAME}_MIGRATION.md
```

**Examples:**
- `PDF_EXTRACTOR_MIGRATION.md`
- `REPORT_GENERATOR_MIGRATION.md`
- `DATA_PROCESSOR_MIGRATION.md`

## Documentation Structure

Each migration file contains 11 mandatory sections:

1. **Migration Header** - Process metadata and status
2. **Todo List & Progress Tracking** - Systematic task tracking
3. **Business Purpose Analysis** - What, why, when, stakeholders
4. **Technical Analysis** - Legacy code structure and technical debt
5. **Framework Utilities Mapping** - What utilities are used
6. **Function/Method Mapping Table** - Old → New traceability
7. **Step-by-Step Workflow Comparison** - Side-by-side comparison
8. **Architecture Comparison** - Structural changes documented
9. **Testing & Validation Results** - Test scenarios and output comparison
10. **Integration Steps** - How to add to main.py
11. **Lessons Learned & Notes** - Post-migration insights

## Critical Rules

### ✅ DO:
- Create ONE comprehensive migration file per process
- Save all migration files in this `docs/migration/` directory
- Use the `manage_todo_list` tool to track progress
- Include complete function/method mapping for traceability
- Document all comparisons (workflow, architecture, outputs)
- Update the single file progressively throughout migration

### ❌ DON'T:
- Create multiple separate documentation files (e.g., `project_analysis.md`, `migration_review.md`)
- Scatter migration information across multiple files
- Skip the todolist management
- Omit the function mapping table
- Skip testing and validation sections
- Create files outside the `docs/migration/` directory

## Migration Workflow

1. **Initialize** - Create single migration document in `docs/migration/`
2. **Track** - Use `manage_todo_list` tool for all steps
3. **Analyze** - Document business purpose and technical analysis
4. **Map** - Create function/method mapping table for traceability
5. **Implement** - Build new framework-compliant class
6. **Compare** - Document step-by-step workflow differences
7. **Test** - Validate outputs match legacy (or improvements documented)
8. **Integrate** - Add to main.py with clear instructions
9. **Finalize** - Complete lessons learned section

## Template Location

The complete migration template is embedded in the chatmode:
`.github/chatmodes/processmigration.chatmode.md`

## Questions?

Refer to the Process Migration Assistant chatmode for:
- Complete migration template
- Framework utilities reference
- Best practices and patterns
- Quality checklists
- Common migration patterns
