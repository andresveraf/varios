# System Prompt Review Summary

*Date: October 24, 2025*

## Changes Made to `copilot-instructions.md`

### 1. Added File Organization Rules

**Section 9 - File Management Rules** has been updated with:

#### Test File Management
- **Location**: All test, check, validation, verify, and debug scripts → `C:\Test\Test_Test\src\process_scripts\test\`
- **Naming Conventions**:
  - Unit Tests: `test_<module_name>.py`
  - Integration Tests: `integration_test_<feature>.py`
  - Debug Scripts: `debug_<issue_description>.py`
  - Validation Scripts: `validate_<component>.py`
  - Check Scripts: `check_<functionality>.py`

#### Documentation Management
- **Location**: All markdown files → `C:\Test\Test_Test\docs\`
- **Organization**:
  - Technical Specs: `docs/technical/`
  - User Guides: `docs/guides/`
  - API Documentation: `docs/api/`
  - Process Documentation: `docs/processes/`
  - Architecture: `docs/architecture/`

### 2. Updated Directory Structure
Added visual representation showing new directories:
- `src/process_scripts/test/` for all test files
- `docs/` with subdirectories for organized documentation

### 3. Added Comprehensive Best Practices Section

New section: **"Additional Best Practices & Recommendations"** covering:

#### Test Development Guidelines
- Test structure patterns
- Isolation and independence
- Mocking strategies
- Code coverage targets (80%+)
- Example test file structure

#### Documentation Standards
- Template requirements
- Consistent formatting
- Version tracking
- Cross-referencing
- Documentation template example

#### Project Organization Recommendations (10 items)
1. Create README in test directory ✅ *Done*
2. Create docs index ✅ *Done*
3. Add pre-commit hooks
4. Version control best practices
5. Configuration management
6. Logging strategy
7. Dependency management
8. Code review checklist
9. Performance monitoring
10. Error documentation

#### Security Best Practices
- Sensitive data handling
- Input validation
- Audit logging
- Dependency security

#### Continuous Improvement
- Code metrics tracking
- Refactoring schedule
- Knowledge sharing

## New Files Created

### 1. `src/process_scripts/test/README.md`
Comprehensive guide for test directory including:
- Purpose and structure
- File naming conventions
- How to run tests (unittest, coverage)
- Writing test guidelines
- Examples for tests, debug scripts, and validation scripts
- Best practices
- Related documentation links

### 2. `docs/README.md`
Documentation hub containing:
- Directory structure overview
- Quick links section (with placeholders for future docs)
- Documentation standards and templates
- Markdown best practices
- Contributing guidelines
- Documentation types explained
- Maintenance schedule
- Tools and resources
- Related resources

## Additional Recommendations

### Immediate Actions

1. **Create Core Documentation Files** (Referenced in `docs/README.md`):
   ```
   - docs/guides/project_overview.md
   - docs/guides/setup_guide.md
   - docs/guides/developer_onboarding.md
   - docs/technical/configuration.md
   - docs/architecture/framework_overview.md
   - docs/api/utils_api.md
   - docs/processes/code_review_checklist.md
   - docs/processes/development_workflow.md
   - docs/troubleshooting/common_errors.md
   - docs/troubleshooting/faq.md
   ```

2. **Create Configuration Template**:
   ```
   - config.template.jsonc (copy of config.jsonc with sensitive data removed)
   - docs/technical/configuration.md (documentation of all config options)
   ```

3. **Set Up Git Ignore**:
   ```gitignore
   # Add to .gitignore
   output/
   process_data/
   dev_data/
   *.log
   config.jsonc  # Don't commit actual config
   .env
   __pycache__/
   *.pyc
   .coverage
   htmlcov/
   ```

4. **Create Pre-commit Hook Script**:
   ```powershell
   # .git/hooks/pre-commit
   # Run tests before commit
   python -m unittest discover -s src/process_scripts/test
   # Run linter
   flake8 src/
   # Check for hardcoded secrets
   # (add secret scanning tool)
   ```

### Medium-Term Improvements

1. **Implement Continuous Integration**:
   - GitHub Actions or Azure Pipelines (you already have `azure-pipelines.yml`)
   - Automated test running on pull requests
   - Code coverage reporting
   - Linting and style checks

2. **Add Development Dependencies**:
   ```txt
   # requirements-dev.txt
   pytest>=7.0.0
   pytest-cov>=4.0.0
   black>=23.0.0
   flake8>=6.0.0
   mypy>=1.0.0
   pip-audit>=2.0.0
   ```

3. **Create Utils API Documentation**:
   - Auto-generate from docstrings
   - Use tools like Sphinx or pdoc
   - Keep synchronized with code

4. **Implement Logging Rotation**:
   ```python
   # In fmw_utils.py
   from logging.handlers import RotatingFileHandler
   
   handler = RotatingFileHandler(
       'output/_logs/app.log',
       maxBytes=10*1024*1024,  # 10MB
       backupCount=5
   )
   ```

5. **Add Performance Monitoring**:
   ```python
   # Create utils/performance.py
   import time
   import functools
   
   def monitor_performance(func):
       @functools.wraps(func)
       def wrapper(*args, **kwargs):
           start = time.time()
           result = func(*args, **kwargs)
           elapsed = time.time() - start
           logging.info(f"{func.__name__} took {elapsed:.2f}s")
           return result
       return wrapper
   ```

### Long-Term Enhancements

1. **Automated Documentation Generation**:
   - Script to generate API docs from code
   - Auto-update utils_index.md
   - Changelog generation from git commits

2. **Testing Infrastructure**:
   - Mock data factory for consistent test data
   - Test database/environment setup
   - Integration test suite
   - Performance/load testing framework

3. **Code Quality Dashboard**:
   - Track metrics over time
   - Code coverage trends
   - Complexity metrics
   - Technical debt tracking

4. **Developer Tools**:
   - CLI tool for common tasks (create new process, run tests, etc.)
   - Project scaffolding templates
   - Code generators for repetitive patterns

## Benefits of These Changes

### Organization
- ✅ Clear separation of test code from production code
- ✅ Centralized documentation with logical structure
- ✅ Easier onboarding for new developers
- ✅ Better maintainability

### Quality
- ✅ Encourages test-driven development
- ✅ Documentation as first-class citizen
- ✅ Security best practices enforced
- ✅ Continuous improvement mindset

### Productivity
- ✅ Faster debugging with organized test files
- ✅ Quick access to documentation
- ✅ Reduced code duplication
- ✅ Clear guidelines reduce decision fatigue

### Scalability
- ✅ Structure supports project growth
- ✅ Easy to add new features
- ✅ Knowledge preservation
- ✅ Team collaboration enhanced

## Next Steps

1. **Review the updated copilot-instructions.md** - Ensure all team members understand new structure
2. **Create subdirectories in docs/** - Set up technical/, guides/, api/, processes/, architecture/
3. **Start documenting existing code** - Begin with high-priority features
4. **Write initial test cases** - Focus on critical business logic
5. **Set up CI/CD** - Automate testing and deployment
6. **Regular reviews** - Schedule quarterly documentation and code reviews

## Questions to Consider

1. **Testing Framework**: Should we use `unittest` (current) or migrate to `pytest`?
2. **Documentation Tools**: Do we want to auto-generate API docs with Sphinx?
3. **CI/CD Platform**: Continue with Azure Pipelines or switch to GitHub Actions?
4. **Code Coverage Target**: Is 80% the right target for your project?
5. **Linting Tools**: What combination of black, flake8, mypy should we enforce?
6. **Security Scanning**: What tool for secret detection (git-secrets, truffleHog)?

## Conclusion

The updated system prompt now provides comprehensive guidance for:
- Proper file organization (test files and documentation)
- Testing best practices and structure
- Documentation standards and maintenance
- Security considerations
- Continuous improvement processes

These changes will help maintain code quality, improve collaboration, and scale the project effectively.

---

**For questions or suggestions, please update this document or discuss with the team.**
