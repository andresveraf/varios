# Copilot System Instructions for Python Automation Framework

This project is a modular Python automation and utility framework designed for web scraping, data processing, and business automation workflows.

## Project Structure Overview

```
├── main.py                     # Main entry point
├── runner.py                   # Alternative runner/launcher
├── config.jsonc                # Main configuration file
├── src/
│   ├── process_scripts/        # Main automation scripts and workflows
│   └── utils/                  # Reusable utility modules
├── input/                      # Input data files
├── output/                     # Generated output files
├── process_data/               # Temporary processing data
├── dev_data/                   # Development/testing data
├── docs/                       # Project documentation
└── github/                     # GitHub-specific files and documentation
    └── utils_index.md          # Helper functions reference
```

## Core Development Guidelines

## PRIMARY OBJECTIVE
**Take your time to think step by step.** Generate production-ready Python automation code following established framework patterns for web scraping, data processing, and business workflows.

**Think carefully about each request before responding.** Always analyze the problem thoroughly and consider multiple approaches.

### 1. Solution Methodology
- **Search & Evaluate**: Before coding, identify multiple approaches and rank them by:
  - Efficiency and performance
  - Code maintainability
  - Alignment with existing patterns
  - Error handling robustness
- **Present Best Solution**: Implement the highest-ranked approach
- **Document Alternatives**: Briefly mention other considered options when relevant

### 2. Code Quality Standards
- **Style**: Follow PEP8 and Python best practices
- **Structure**: Create modular, reusable components
- **Imports**: Use relative imports within `src/` folder
- **Error Handling**: Implement comprehensive exception handling
- **Type Hints**: Use type annotations for function parameters and returns

### 3. Documentation Requirements
- **Docstrings**: Every function/class must include:
  - Clear purpose description
  - Parameter types and descriptions
  - Return value specification
  - Usage examples
  - Raises section for exceptions
- **Comments**: Add inline comments for complex logic
- **File Headers**: Include module-level docstrings

### 4. Utility Usage Guidelines
- **Prefer Existing**: Always check `src/utils/` for existing functionality before creating new code
- **Helper Functions Index**: Reference `github/utils_index.md` for complete list of available functions
- **Key Utilities**: Always import and use these when creating new scripts:
  - `fmw_utils`: Core utilities for configuration, logging, and file operations
  - `SeleniumUtils`: Web automation and browser control
  - `Config`: Configuration management from `config.jsonc`
  - `Credentials`: Encrypted credential handling
  - `ExceptionEmails`: Error reporting via email
  - `start_logging()`: Logging initialization
- **Protected Files**: Do not modify these utility files:
  - `monitoring.py`
  - `robot_date.py` 
  - `base_workflow.py`
  - `credentials.py`
  - `send_email_utils.py`

### 5. Configuration Management
- **Main Config**: Use `config.jsonc` for application settings
- **Constants**: Use `src/utils/constants.py` for project-wide constants (if present)
- **Config Class**: Use `Config()` class from `fmw_utils.py` to load configuration

### 6. Process Script Development
- **Location**: All main automation scripts go in `src/process_scripts/`
- **Structure**: Scripts typically follow class-based architecture with `run_flow()` method
- **Dependencies**: Import utilities using relative paths from `..utils`
- **Logging**: Use `start_logging()` from `fmw_utils.py`
- **Error Handling**: Implement `ExceptionEmails` for error reporting

### 7. Common Patterns

#### Standard Process Script Template
```python
#!/usr/bin/env python3
"""
Module description here.

This script handles [specific functionality].
"""

import logging
import sys
import os
from typing import Optional

# Add src to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from utils.fmw_utils import start_logging, Config
from utils.send_exceptions_emails import ExceptionEmails
from utils.credentials_utils import Credentials

class ProcessScript:
    """Main process script class."""
    
    def __init__(self):
        """Initialize the process script with configuration and logging."""
        self.config = Config()
        self.exception_handler = ExceptionEmails()
        
    def run_flow(self) -> bool:
        """
        Execute the main workflow.
        
        Returns:
            bool: True if successful, False otherwise.
        """
        try:
            start_logging()
            logging.info("Starting process flow")
            
            # Your main logic here
            
            logging.info("Process flow completed successfully")
            return True
            
        except Exception as e:
            logging.error(f"Process flow failed: {e}")
            self.exception_handler.send_system_exception(str(e))
            return False

def main():
    """Main execution function."""
    script = ProcessScript()
    success = script.run_flow()
    return success

if __name__ == "__main__":
    main()
```

#### Selenium Automation Pattern
```python
from utils.selenium_utils import SeleniumUtils

class WebAutomationScript:
    """Web automation script using Selenium."""
    
    def __init__(self):
        self.config = Config()
        self.su: Optional[SeleniumUtils] = None
        
    def run_flow(self) -> bool:
        """Execute web automation workflow."""
        try:
            self.su = SeleniumUtils(
                download_folder=self.config.build_config()['paths']['output'],
                excecute_headless=False,
                max_timeout=30
            )
            
            # Your automation logic here
            self.su.open_website("https://example.com")
            
            return True
            
        except Exception as e:
            logging.error(f"Web automation failed: {e}")
            raise
        finally:
            if self.su:
                self.su.close_driver()
```

### 8. Available Helper Functions Quick Reference

#### Configuration & Utilities (`fmw_utils.py`)
- `start_logging()`: Initialize logging system
- `Config()`: Load and manage configuration from `config.jsonc`
- `read_json()`/`read_jsonc()`: JSON file operations
- `save_excel_file()`: Excel file handling
- `create_folder()`/`delete_folder()`: Directory management

#### Selenium Automation (`selenium_utils.py`)
- `SeleniumUtils()`: Main automation class
- `element_exists()`: Check element presence
- `click_element()`: Click with optional hover
- `populate_field()`: Fill form fields
- `switch_frame()`: Handle iframes
- `wait_for_element()`: Wait for element presence
- `take_screenshot()`: Capture page screenshots

#### Email & Communication (`send_email_utils.py`)
- `send_email()`: Send formatted emails via Outlook
- `df2html()`: Convert DataFrames to HTML tables
- `read_recipients_file()`: Load email recipients from Excel

#### Credentials Management (`credentials_utils.py`)
- `Credentials()`: Handle encrypted credentials
- `inti_desiered_credentials()`: Load specific credential sets

#### Exception Handling (`send_exceptions_emails.py`)
- `ExceptionEmails()`: Send error notifications
- `send_system_exception()`: System error reporting
- `send_business_exception()`: Business logic error reporting

### 9. Testing and Validation
- **Error Scenarios**: Always test error conditions
- **Data Validation**: Validate inputs and outputs using type hints
- **Logging**: Add appropriate logging levels (INFO, WARNING, ERROR)
- **Cleanup**: Ensure proper resource cleanup (files, drivers, connections)
- **Return Values**: Use boolean returns for `run_flow()` methods

### 10. File and Data Management
- **Input Files**: Place in `input/` directory
- **Output Files**: Generate in `output/` directory
- **Temporary Data**: Use `process_data/` for intermediate files
- **Development Data**: Use `dev_data/` for testing
- **Configuration**: Use paths from `config.jsonc` via `Config()` class

### 11. Security and Best Practices
- **Credentials**: Use `Credentials()` class for sensitive data
- **Logging**: Mark sensitive data appropriately in logging calls
- **File Permissions**: Set appropriate access permissions
- **Error Messages**: Don't expose sensitive information in error messages
- **Exception Handling**: Use `ExceptionEmails` for consistent error reporting

## Helper Functions Index

For a complete reference of all available utility functions, see [`github/utils_index.md`](utils_index.md).

Key categories include:
- **Configuration Management**: Config loading and path handling
- **Web Automation**: Selenium utilities for browser automation
- **Data Processing**: Excel, JSON, and file operations
- **Communication**: Email sending and formatting
- **Security**: Credential management and encryption
- **System Utilities**: Process management and datetime operations

### Maintaining the Utils Index

To keep [`github/utils_index.md`](utils_index.md) up-to-date, follow these practices:

#### Manual Update Process (Immediate)
- **Every utility change**: When adding, modifying, or removing functions/classes in `src/utils/`, immediately update the index
- **During development**: Add new entries to the table with proper descriptions
- **Code review**: Reviewers must verify the index is updated for any utility changes

#### Automated Update Process (Recommended)
Create an automation script to scan `src/utils/` and regenerate the index:

```python
# scripts/update_utils_index.py
import os
import ast
import re

def scan_utils_directory():
    """Scan src/utils for all functions and classes."""
    entries = []
    utils_path = "src/utils"
    
    for root, dirs, files in os.walk(utils_path):
        for file in files:
            if file.endswith('.py') and not file.startswith('__'):
                file_path = os.path.join(root, file)
                entries.extend(extract_functions_and_classes(file_path))
    
    return sorted(entries, key=lambda x: x[0].lower())

def extract_functions_and_classes(file_path):
    """Extract function and class definitions from a Python file."""
    entries = []
    relative_path = file_path.replace("\\", "/")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        try:
            tree = ast.parse(f.read())
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
                    # Skip private functions/classes
                    if not node.name.startswith('_'):
                        docstring = ast.get_docstring(node) or "No description available"
                        # Extract first line of docstring for description
                        description = docstring.split('\n')[0][:100]
                        entries.append((node.name, relative_path, description))
        except Exception as e:
            print(f"Error parsing {file_path}: {e}")
    
    return entries

def generate_markdown_table(entries):
    """Generate the markdown table for utils_index.md."""
    lines = [
        "# Helper Functions Index (`src/utils`)\n",
        "| Function/Class Name         | File Path                                 | Description |",
        "|----------------------------|-------------------------------------------|-------------|"
    ]
    
    for name, path, description in entries:
        lines.append(f"| {name:<26} | {path:<41} | {description} |")
    
    lines.extend([
        "",
        "**Configuration variables are managed in `config.jsonc` at the project root. If present, use `src/utils/constants.py` for project-wide constants.**",
        "",
        "Files excluded: monitoring.py, robot_date.py, base_workflow.py"
    ])
    
    return '\n'.join(lines)

if __name__ == "__main__":
    entries = scan_utils_directory()
    markdown_content = generate_markdown_table(entries)
    
    with open('.github/utils_index.md', 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    print(f"Updated utils_index.md with {len(entries)} entries")
```

#### Integration Options
1. **Pre-commit Hook**: Run the script before each commit
2. **CI/CD Pipeline**: Automatically update during builds
3. **Manual Execution**: Run script when utilities change
4. **VS Code Task**: Add to tasks.json for easy execution

#### Enforcement Guidelines
- **Pull Request Template**: Include checklist item for utils index updates
- **Code Review**: Mandatory verification of index accuracy
- **Documentation Sprint**: Monthly reviews to catch missed updates
- **Automated Testing**: Verify index completeness in CI/CD

#### Updating Functions Without Descriptions

When functions in the utils index show "No description available", follow this process:

1. **Identify Missing Descriptions**: Look for entries with "No description available" in utils_index.md
2. **Examine Source Code**: Read the actual function/class implementation in src/utils/
3. **Analyze Function Purpose**: Understand what the function does from its code
4. **Write Clear Description**: Create a concise description (under 100 characters) that explains:
   - What the function does
   - Key parameters or behavior
   - Return value or purpose

**Example Process:**
```python
# If you find this in utils_index.md:
| obtain_months              | src/utils/fmw_utils.py    | No description available |

# 1. Examine the source code in fmw_utils.py
def obtain_months() -> dict:
    path_json = rf"C:\RPA\...\dates_info.json"
    with open(path_json) as f:
        datos = json.load(f)
        return datos["CALENDAR_NAME"]

# 2. Update the description based on understanding:
| obtain_months              | src/utils/fmw_utils.py    | Load and return Spanish month names dictionary from dates_info.json configuration file. |
```

**Update Guidelines:**
- **Be Specific**: Describe the actual functionality, not generic terms
- **Include Key Details**: Mention important parameters, return types, or dependencies
- **Use Action Verbs**: Start with verbs like "Load", "Check", "Convert", "Send", etc.
- **Stay Concise**: Keep descriptions under 100 characters when possible
- **Maintain Consistency**: Use similar language style as existing descriptions

## Process Script Architecture

Process scripts should follow this structure:
1. **Class-based design** with clear initialization
2. **`run_flow()` method** as the main execution entry point
3. **Proper exception handling** with email notifications
4. **Resource cleanup** in finally blocks
5. **Boolean return values** indicating success/failure
6. **Comprehensive logging** throughout the workflow

## Best Practices Checklist

- [ ] Used existing utility functions from `src/utils/`
- [ ] Added comprehensive docstrings with examples
- [ ] Implemented proper error handling with `ExceptionEmails`
- [ ] Used `Config()` class for configuration management
- [ ] Followed class-based structure with `run_flow()` method
- [ ] Added appropriate logging statements
- [ ] Used type hints for function parameters and returns
- [ ] Dont use emojis in code or comments
- [ ] Ensured proper resource cleanup
- [ ] Validated inputs and outputs
- [ ] Used relative imports from `utils`
- [ ] Updated `github/utils_index.md` if new utilities were created

## Exclusions

The following files should not be modified, but can be referenced for understanding:
- `monitoring.py`
- `robot_date.py`
- `base_workflow.py`
- `credentials.py`
- `send_utils.py`

Remember: Always prioritize code maintainability, proper error handling, and clear documentation. Use the existing utility ecosystem before creating new functionality.