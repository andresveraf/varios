
# file_name:   _base_process_class.py
# modified_on: 2024-01-03 ; daniel.hermosilla.omi ; ProcessBase
import os
import sys
import logging
import pandas as pd
import datetime as dt

sys.path.append(os.path.abspath(
                    os.path.dirname(
                    os.path.dirname(
                    os.path.abspath(__file__)))))
from utils.base_workflow import Base #template to email_send #not use
from utils.robot_date import RobotDate
from utils.fmw_utils import *

class ProcessBase(Base):

    # # add the paths that are used directly in the functions in
    # # mandatory manner,these can be file names with YYMMAA extensions,download locations,etc
    # # omi. bless

    def __init__(self, config:dict):        
        Base.__init__(self, config=config)
        self.state_name               = type(self).__name__  
        self.robot_date               = RobotDate(config=config)#<<<<<<<<<<<< modify with a get time per machine omi
        logging.info(f"Robot date:     {self.robot_date}") 
        self.day,self.month,self.year = self.robot_date.set_up_int
        self.worktray_path            = self.config_global["WORKTRAY_FILE"]
        self.download_dir             = self.config_global["DOWNLOAD_DIR"]
        self.output_dir               = self.config_env["OUTPUT_DIR"].format(self.robot_date.month, self.robot_date.year) #example format dir with year 0 and mont 1
        
        print(f'self.robot_date.month:{self.robot_date.month}')
        print(f'self.robot_date.year:{self.robot_date.year}')
        print(f'self.output_dir :{self.output_dir }')
    
    def _build_business_exception(self, error:str): # template for building business exceptions
        # Set up now date
        now_string = dt.datetime.now().strftime("%d-%m-%y")
        # Get config parameters
        be_mail_type   = "BE_REPORT" # Replace BE_REPORT with the BE_NAME you add to config
        be_config_dict = self.config_emails[be_mail_type]
        be_body_file   = be_config_dict["BODY_FILE"]
        process_name   = self.config["METADATA"]["PROCESS_NAME"]
        process_code   = self.config["METADATA"]["PROCESS_CODE"]
        be_subject     = be_config_dict["SUBJECT"].format(process_code, now_string)
        # Set up email parameters
        attachments = [] # add logic if one or more BE needs attachments
        body_fields = [process_name, error]
        # Set up business exception object, do not change
        self.be_info = {
            "BODY_FILE": be_body_file,
            "SUBJECT": be_subject,
            "MAIL_TYPE": be_mail_type,
            "ATTACHMENTS": attachments,
            "BODY_FIELDS": body_fields
        }

    def valid_execution_date(self):
        " Check if the txt file exists to stop the process due to invalid execution date "
        if not os.path.exists(self.file_stop_process):
            return True
        else:
            logging.info(f"PASSING THE PROCESS FOR INVALID EXECUTION DATE...")
            return False
        
    def close_excel(self
                    , workbook
                    , save:bool=True):# use in case save diff to pandas buff
        if save:
            logging.info(f"Saving workbook {workbook.Name}")
            workbook.Save()
        logging.info(f"Closing workbook {workbook.Name}")
        workbook.Close()

    # def process_base_method_1(self): #test method omi
    #     logging.info("This is a test method of the process_base class")
    #     pass

    # def run_workflow(self):#test method omi
    #     logging.info(f"----- Starting state: {self.state_name} -----")
    #     try: # Add workflow in try block bellow
    #         self.process_base_method_1()
    #     except Exception as error:
    #         raise error  
    #     logging.info(f"Finished state: {self.state_name}")


if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    process_base = ProcessBase(config=config)
    # process_base.process_base_method_1()  #test method
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
