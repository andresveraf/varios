
# file_name:   _base_process_class.py
# modified_on: 2024-01-03 ; daniel.hermosilla.omi ; Template
import os
import sys
import logging
import datetime as dt
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 
from utils.fmw_utils import *
from process_scripts.base_process import ProcessBase


class Template_omi_new2(ProcessBase):

    # This is an example of how the funcions you create should look like
    # omi .bless

    def __init__(self, config:dict):
        ProcessBase.__init__(self, config=config) 
        self.state_name    = "Workflow"  # Change with the class name 
        self.now           = dt.datetime.now()
        self.template_parameter_1 = self.config_env["ENV_PARAM_1"]
        self.template_parameter_2 = self.config_global["GLOBAL_PARAM_1"]
        # These variables already exist by inheritance
        # self.config              = config
        # self.environment         = config["METADATA"]["ENVIRONMENT"].upper()
        # self.config_env          = config[self.environment]
        # self.config_global       = config["GLOBAL"]
        # self.config_fmw          = config["FRAMEWORK"]        
        # self.process_data        = self.config_fmw["PROCESS_DATA"]
        # self.config_emails       = self.config["EMAIL"]

    def script_function_3(self): #Change with the function name 
        logging.info(f"--- DESCRIPTIVE START FOR SPRIPT 3 ---")
        logging.info(f"----- example  this is my first script funtion_3 -----".upper())
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        print(f'This is a test business exception3')
        logging.info(f"step 3 {self.template_parameter_1}")
        logging.info(f"please describe what they are in  the fuction 3")
        return 0
    
    def script_function_4(self): #Change with the function name 
        logging.info(f"--- DESCRIPTIVE START FOR SPRIPT 4 ---")
        logging.info(f"----- example  this is my first script funtion_4 -----".upper())
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        print(f'This is a test business exception4')
        logging.info(f"tep 4 {self.template_parameter_2}")
        logging.info(f"please describe what they are in  the fuction 4 ")
        return 0

###importante para los que desarrollen run_flow corre en gran mededa todos los script y les agrega los logs
### CODEN EN script_function_3 O 4 COMO EJEMPLO    
    def run_flow(self):
        logging.info(f"----- Starting state: {self.state_name} -----")
        try: # Add workflow in try block bellow
            self.script_function_3()        
            self.script_function_4()
        except Exception as error:
            raise error  
        logging.info(f"Finished state: {self.state_name}")

if __name__ == "__main__":
    start_logging(logs_level="DEBUG", show_console_logs=True, save_logs=False)
    config = read_config()
    logging.info(f"--------- Script {os.path.basename(__file__)} started ---------")    
    state = Template_omi_new2(config=config)
    state.run_flow()
    logging.info(f"--------- Script {os.path.basename(__file__)} finished ---------")
