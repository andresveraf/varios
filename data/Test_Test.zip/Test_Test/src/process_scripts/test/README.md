# Test Scripts Directory

*Last Updated: October 24, 2025*

## Purpose

This directory contains all test, validation, verification, check, and debug scripts for the automation framework.

## Directory Structure

```
test/
├── README.md                    # This file
├── test_*.py                    # Unit tests
├── integration_test_*.py        # Integration tests
├── validate_*.py                # Validation scripts
├── check_*.py                   # Check scripts
└── debug_*.py                   # Debug scripts
```

## File Naming Conventions

- **Unit Tests**: `test_<module_name>.py` - Tests for individual modules/functions
- **Integration Tests**: `integration_test_<feature>.py` - Tests for feature workflows
- **Debug Scripts**: `debug_<issue_description>.py` - Debugging specific issues
- **Validation Scripts**: `validate_<component>.py` - Validate data/components
- **Check Scripts**: `check_<functionality>.py` - Quick functionality checks

## Running Tests

### Run All Tests
```powershell
python -m unittest discover -s src/process_scripts/test -p "test_*.py"
```

### Run Specific Test File
```powershell
python -m unittest src.process_scripts.test.test_example
```

### Run with Coverage
```powershell
pip install coverage
coverage run -m unittest discover -s src/process_scripts/test
coverage report
coverage html  # Generate HTML report
```

## Writing Tests

All test files should follow the standard framework pattern:

```python
import unittest
from unittest.mock import Mock, patch
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), '../..'))

from process_scripts.example_process import ExampleProcess

class TestExampleProcess(unittest.TestCase):
    """Test suite for ExampleProcess."""
    
    def setUp(self):
        """Set up test fixtures before each test."""
        self.process = ExampleProcess()
    
    def tearDown(self):
        """Clean up after each test."""
        pass
    
    def test_run_flow_success(self):
        """Test successful execution of run_flow."""
        result = self.process.run_flow()
        self.assertTrue(result, "run_flow should return True on success")

if __name__ == '__main__':
    unittest.main()
```

## Best Practices

1. **Test Isolation**: Each test should be independent
2. **Clear Names**: Use descriptive test method names
3. **Mock External Dependencies**: Don't make real API calls or database queries
4. **Assert Messages**: Include helpful messages in assertions
5. **Coverage**: Aim for 80%+ coverage on critical code paths
6. **Documentation**: Add docstrings to test classes and methods

## Debug Scripts

Debug scripts are for troubleshooting specific issues and don't follow strict test patterns:

```python
# debug_selenium_timeout.py
"""Debug script to investigate Selenium timeout issues."""

import logging
from src.utils.selenium_utils import SeleniumUtils
from src.utils.fmw_utils import start_logging, Config

def main():
    start_logging()
    logging.info("Starting debug session for Selenium timeouts")
    
    config = Config()
    driver = SeleniumUtils(
        download_folder=config.build_config()['paths']['output'],
        max_timeout=30
    )
    
    try:
        # Debug code here
        logging.info("Debug test completed")
    finally:
        driver.close_driver()

if __name__ == '__main__':
    main()
```

## Validation Scripts

Validation scripts verify data integrity, configuration, or system state:

```python
# validate_config.py
"""Validate configuration file structure and required fields."""

import json
import logging
from src.utils.fmw_utils import start_logging, Config

def validate_config():
    """Validate config.jsonc structure."""
    start_logging()
    config = Config()
    config_data = config.build_config()
    
    required_keys = ['paths', 'credentials', 'settings']
    
    for key in required_keys:
        if key not in config_data:
            logging.error(f"Missing required config key: {key}")
            return False
    
    logging.info("Configuration validation passed")
    return True

if __name__ == '__main__':
    validate_config()
```

## Related Documentation

- [Framework Documentation](../../../docs/README.md)
- [Copilot Instructions](../../../.github/instructions/copilot-instructions.md)
- [Utils Index](../../../.github/instructions/utils_index.md)
