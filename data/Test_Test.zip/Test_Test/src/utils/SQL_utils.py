import os
import sys
sys.path.append(os.path.abspath(
                    os.path.dirname(
                    os.path.dirname(
                    os.path.abspath(__file__)))))
import pyodbc
import pandas as pd

def abrir_conexion():
    """Establishes a connection to a SQL Server database.

    Args:
        server (str): The server address. Defaults to "10.172.128.62".
        database (str): The database name. Defaults to "BDU".
        trusted_connection (bool): Use trusted connection (Windows Authentication). Defaults to True.
        uid (str, optional): User ID for SQL Server Authentication. Defaults to None.
        pwd (str, optional): Password for SQL Server Authentication. Defaults to None.


    Returns:
        pyodbc.Connection: The database connection object if successful, raises exception on failure.
    """
    try:
        connection_string = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            # f"SERVER=10.172.128.62;" # Old base BDU
            # f"DATABASE=BDU;" # Old base BDU
            f"SERVER=clscl1metv209;" # New base BDU_NET
            f"DATABASE=BDU_NET;" # New base BDU_NET
            f"Trusted_Connection=yes;"
        )
        
        conexion = pyodbc.connect(connection_string)
        print("Connection successful!")
        return conexion
    except Exception as e:
        print(f'No se pudo conectar a la base de datos: {e}')
        raise

def abrir_conexion_old():
    """Establishes a connection to a SQL Server database.

    Args:
        server (str): The server address. Defaults to "10.172.128.62".
        database (str): The database name. Defaults to "BDU".
        trusted_connection (bool): Use trusted connection (Windows Authentication). Defaults to True.
        uid (str, optional): User ID for SQL Server Authentication. Defaults to None.
        pwd (str, optional): Password for SQL Server Authentication. Defaults to None.


    Returns:
        pyodbc.Connection: The database connection object if successful, raises exception on failure.
    """
    try:
        connection_string = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER=10.172.128.62;" # Old base BDU
            f"DATABASE=BDU;" # Old base BDU
            # f"SERVER=clscl1metv209;" # New base BDU_NET
            # f"DATABASE=BDU_NET;" # New base BDU_NET
            f"Trusted_Connection=yes;"
        )
        
        conexion = pyodbc.connect(connection_string)
        print("Connection successful!")
        return conexion
    except Exception as e:
        print(f'No se pudo conectar a la base de datos: {e}')
        raise

def obtener_datos(query, cnxn):
    """Execute SQL query and return DataFrame.
    
    Args:
        query (str): SQL query string
        cnxn: Database connection object
        
    Returns:
        pd.DataFrame: Query results
        
    Raises:
        RuntimeError: If connection is None
    """
    if cnxn is None:
        raise RuntimeError("Database connection is None. Check abrir_conexion() and DB credentials.")
    
    return pd.read_sql(query, cnxn)


def cerrar_conexion(cnxn):
    print("Cerrando conexión")
    cnxn.close()
    

# query = """
# SELECT *
# FROM PU_SOLICITU
# WHERE CPRE IN ('SOAC','SOID','SOIT','SOPA') AND CEST = 'DETE'
# ORDER BY CAGE
# """
# # print(query)


# conexion = abrir_conexion()
# df = obtener_datos(query, conexion)
# print(df)