"""
Chilean Public Holidays Scraper - Improved Version
Specifically designed for www.feriadoschilenos.cl structure
"""

import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional
import warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore')


def scrape_chilean_holidays(year: Optional[int] = None) -> pd.DataFrame:
    """
    Scrape Chilean public holidays from feriadoschilenos.cl
    """
    if year is None:
        year = datetime.now().year
    
    try:
        url = "https://www.feriadoschilenos.cl/"
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'es-CL,es;q=0.9,en;q=0.8',
            'Connection': 'keep-alive',
        }
        
        session = requests.Session()
        session.verify = False
        
        response = session.get(url, headers=headers, timeout=15)
        response.encoding = 'utf-8'
        
        print(f"Response status: {response.status_code}")
        
        # Parse with BeautifulSoup
        soup = BeautifulSoup(response.content, 'html.parser')
        
        holidays = []
        
        # Method 1: Look for specific div/section containing holidays
        # The website likely has a container with class or id related to holidays
        holiday_containers = soup.find_all(['div', 'section', 'article'], 
                                          class_=lambda x: x and any(term in str(x).lower() 
                                          for term in ['feriado', 'holiday', 'calendario', 'calendar']))
        
        print(f"Found {len(holiday_containers)} potential holiday containers")
        
        # Method 2: Find all tables and analyze them
        tables = soup.find_all('table')
        print(f"Found {len(tables)} tables on the page")
        
        for idx, table in enumerate(tables):
            print(f"\n--- Analyzing Table {idx + 1} ---")
            rows = table.find_all('tr')
            print(f"Rows in table: {len(rows)}")
            
            if len(rows) < 3:  # Skip tables with too few rows
                print("Skipping: too few rows")
                continue
            
            # Check first few rows to see if this looks like a holiday table
            sample_text = ' '.join([row.get_text() for row in rows[:3]]).lower()
            print(f"Sample text: {sample_text[:100]}...")
            
            # Look for date-related keywords in headers
            if not any(word in sample_text for word in ['fecha', 'date', 'día', 'mes', 'enero', 'febrero', 'marzo']):
                print("Skipping: doesn't look like a date table")
                continue
            
            print("This looks like a holiday table!")
            
            # Try to parse this table
            for row_idx, row in enumerate(rows):
                cols = row.find_all(['td', 'th'])
                
                if len(cols) < 2:
                    continue
                
                # Get text from columns
                col_texts = [col.get_text(strip=True) for col in cols]
                print(f"Row {row_idx}: {col_texts}")
                
                # Skip header rows
                if any(keyword in ' '.join(col_texts).lower() 
                       for keyword in ['fecha', 'date', 'nombre', 'name', 'feriado']):
                    print("  -> Header row, skipping")
                    continue
                
                # Skip rows that don't look like dates
                first_col = col_texts[0]
                if not any(char.isdigit() for char in first_col):
                    print("  -> No digits in first column, skipping")
                    continue
                
                try:
                    # Skip rows that are clearly historical data (before 2020)
                    if first_col.isdigit() and int(first_col) < 2020:
                        print(f"  -> Skipping historical year: {first_col}")
                        continue
                    
                    # Check if first column contains the target year
                    if str(year) in first_col:
                        # Try to parse the date from second column instead
                        if len(col_texts) > 1:
                            date_str = col_texts[1]
                            holiday_name = col_texts[2] if len(col_texts) > 2 else "Feriado"
                        else:
                            date_str = first_col
                            holiday_name = "Feriado"
                        
                        holiday_date = parse_chilean_date(date_str, year)
                        
                        # Validate the date is reasonable
                        if holiday_date.year == year:
                            holidays.append({
                                'date': holiday_date,
                                'name': holiday_name
                            })
                            print(f"  -> ✓ Added: {holiday_date.strftime('%Y-%m-%d')} - {holiday_name}")
                        else:
                            print(f"  -> Wrong year: {holiday_date.year}")
                    else:
                        # Try original logic for other formats
                        holiday_date = parse_chilean_date(first_col, year)
                        holiday_name = col_texts[1] if len(col_texts) > 1 else "Feriado"
                        
                        # Validate the date is reasonable
                        if holiday_date.year == year:
                            holidays.append({
                                'date': holiday_date,
                                'name': holiday_name
                            })
                            print(f"  -> ✓ Added: {holiday_date.strftime('%Y-%m-%d')} - {holiday_name}")
                        else:
                            print(f"  -> Wrong year: {holiday_date.year}")
                        
                except Exception as e:
                    print(f"  -> Parse error: {e}")
                    continue
        
        # Method 3: Try pandas read_html on all tables
        if not holidays:
            print("\n--- Trying pandas read_html method ---")
            try:
                all_tables = pd.read_html(response.content)
                print(f"Pandas found {len(all_tables)} tables")
                
                for idx, df in enumerate(all_tables):
                    print(f"\nTable {idx + 1} shape: {df.shape}")
                    print(f"Columns: {df.columns.tolist()}")
                    print(f"First few rows:\n{df.head()}")
                    
                    # Look for tables with date-like content
                    if df.shape[0] > 5 and df.shape[1] >= 2:
                        # Try to find date column
                        for col_idx in range(min(3, df.shape[1])):
                            sample_values = df.iloc[:3, col_idx].astype(str).tolist()
                            print(f"  Column {col_idx} samples: {sample_values}")
                            
                            # Check if this looks like dates
                            has_dates = any(
                                any(month in str(val).lower() for month in 
                                    ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                                     'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'])
                                or any(char.isdigit() for char in str(val))
                                for val in sample_values
                            )
                            
                            if has_dates:
                                print(f"  -> Column {col_idx} looks like dates!")
                                date_col = col_idx
                                name_col = col_idx + 1 if col_idx + 1 < df.shape[1] else col_idx
                                
                                for _, row in df.iterrows():
                                    try:
                                        # Check if we're looking at year-specific data
                                        if col_idx == 0 and str(year) in str(row.iloc[0]):
                                            # Year is in first column, date in second
                                            date_str = str(row.iloc[1]) if df.shape[1] > 1 else str(row.iloc[0])
                                            name_str = str(row.iloc[2]) if df.shape[1] > 2 else "Feriado"
                                        else:
                                            date_str = str(row.iloc[date_col])
                                            name_str = str(row.iloc[name_col])
                                        
                                        # Skip if date string doesn't look valid
                                        if 'nan' in date_str.lower() or len(date_str.strip()) < 3:
                                            continue
                                        
                                        holiday_date = parse_chilean_date(date_str, year)
                                        
                                        if holiday_date.year == year:
                                            holidays.append({
                                                'date': holiday_date,
                                                'name': name_str.strip()
                                            })
                                    except Exception as e:
                                        continue
                                
                                if holidays:
                                    break
                        
                        if holidays:
                            break
                            
            except Exception as e:
                print(f"Pandas method error: {e}")
        
        # Create DataFrame from collected holidays
        if holidays:
            df = pd.DataFrame(holidays)
            df['date'] = pd.to_datetime(df['date'])
            df = df.drop_duplicates(subset=['date'])
            df = df.sort_values('date').reset_index(drop=True)
            
            # Filter to ensure we only have holidays for the requested year
            df = df[df['date'].dt.year == year]
            
            # If we have fewer than 8 holidays, likely the scraping didn't work well
            if len(df) >= 8:
                print(f"\n✓ Successfully scraped {len(df)} holidays!")
                return df
            else:
                print(f"\n⚠ Only found {len(df)} holidays, using fallback data")
                return get_fallback_holidays(year)
        
        # If nothing worked, use fallback
        print("\nNo holidays found, using fallback data")
        return get_fallback_holidays(year)
        
    except Exception as e:
        print(f"Error scraping: {e}")
        import traceback
        traceback.print_exc()
        return get_fallback_holidays(year)


def parse_chilean_date(date_str: str, year: int) -> datetime:
    """
    Parse Chilean date format with improved logic
    """
    months_es = {
        'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4,
        'mayo': 5, 'junio': 6, 'julio': 7, 'agosto': 8,
        'septiembre': 9, 'octubre': 10, 'noviembre': 11, 'diciembre': 12
    }
    
    date_str = str(date_str).lower().strip()
    
    # Remove day names and extra parentheses
    for day in ['lunes', 'martes', 'miércoles', 'miercoles', 'jueves', 'viernes', 'sábado', 'sabado', 'domingo']:
        date_str = date_str.replace(day, '')
    
    # Remove parentheses and content
    import re
    date_str = re.sub(r'\([^)]*\)', '', date_str)
    date_str = date_str.strip().strip(',').strip()
    
    # Skip invalid entries
    if '¿' in date_str or '—' in date_str or 'no se' in date_str or len(date_str.strip()) < 3:
        raise ValueError(f"Invalid date format: {date_str}")
    
    # Format: "20 de junio" or "1 de enero"
    if ' de ' in date_str:
        parts = date_str.split(' de ')
        if len(parts) >= 2:
            try:
                day = int(parts[0].strip())
                month_name = parts[1].strip().split()[0]  # Take first word in case of extra text
                month = months_es.get(month_name)
                if month and 1 <= day <= 31:
                    return datetime(year, month, day)
            except (ValueError, TypeError):
                pass
    
    # Format: "DD-MM-YYYY"
    if '-' in date_str:
        parts = date_str.split('-')
        if len(parts) == 3:
            try:
                return datetime(int(parts[2]), int(parts[1]), int(parts[0]))
            except (ValueError, TypeError):
                pass
        elif len(parts) == 2:
            try:
                return datetime(year, int(parts[1]), int(parts[0]))
            except (ValueError, TypeError):
                pass
    
    # Format: "DD/MM/YYYY" or "DD/MM"
    if '/' in date_str:
        parts = date_str.split('/')
        if len(parts) == 3:
            try:
                return datetime(int(parts[2]), int(parts[1]), int(parts[0]))
            except (ValueError, TypeError):
                pass
        elif len(parts) == 2:
            try:
                return datetime(year, int(parts[1]), int(parts[0]))
            except (ValueError, TypeError):
                pass
    
    # Try direct datetime parsing
    try:
        parsed = pd.to_datetime(date_str)
        if parsed.year < 1900:  # If year is missing, use provided year
            return datetime(year, parsed.month, parsed.day)
        return parsed.to_pydatetime()
    except:
        pass
    
    raise ValueError(f"Could not parse date: {date_str}")


def get_fallback_holidays(year: int) -> pd.DataFrame:
    """
    Fallback holidays data for Chile
    """
    # Fixed holidays that don't change year to year
    fixed_holidays = [
        ('01-01', 'Año Nuevo'),
        ('05-01', 'Día del Trabajo'),
        ('05-21', 'Día de las Glorias Navales'),
        ('06-29', 'San Pedro y San Pablo'),
        ('07-16', 'Día de la Virgen del Carmen'),
        ('08-15', 'Asunción de la Virgen'),
        ('09-18', 'Día de la Independencia Nacional'),
        ('09-19', 'Día de las Glorias del Ejército'),
        ('10-12', 'Encuentro de Dos Mundos'),
        ('11-01', 'Día de Todos los Santos'),
        ('12-08', 'Inmaculada Concepción'),
        ('12-25', 'Navidad'),
    ]
    
    holidays_data = []
    
    # Add fixed holidays
    for date_str, name in fixed_holidays:
        holidays_data.append((f'{year}-{date_str}', name))
    
    # Add variable holidays based on specific years
    if year == 2025:
        holidays_data.extend([
            ('2025-04-18', 'Viernes Santo'),
            ('2025-04-19', 'Sábado Santo'),
            ('2025-10-31', 'Día de las Iglesias Evangélicas y Protestantes'),
        ])
    elif year == 2024:
        holidays_data.extend([
            ('2024-03-29', 'Viernes Santo'),
            ('2024-03-30', 'Sábado Santo'),
            ('2024-09-20', 'Feriado adicional'),
            ('2024-10-27', 'Día de las Iglesias Evangélicas y Protestantes'),
        ])
    elif year == 2026:
        holidays_data.extend([
            ('2026-04-03', 'Viernes Santo'),
            ('2026-04-04', 'Sábado Santo'),
            ('2026-10-31', 'Día de las Iglesias Evangélicas y Protestantes'),
        ])
    else:
        # For other years, use generic Easter calculation (approximate)
        # This is a simplified approach - for production use, implement proper Easter calculation
        import calendar
        
        # Approximate Easter dates for common years
        easter_dates = {
            2023: ('04-07', '04-08'),
            2027: ('03-26', '03-27'),
            2028: ('04-14', '04-15'),
            2029: ('03-30', '03-31'),
            2030: ('04-19', '04-20'),
        }
        
        if year in easter_dates:
            good_friday, holy_saturday = easter_dates[year]
            holidays_data.extend([
                (f'{year}-{good_friday}', 'Viernes Santo'),
                (f'{year}-{holy_saturday}', 'Sábado Santo'),
            ])
        
        # Add Protestant Day (usually last Friday of October or October 31st)
        # Find last Friday of October
        last_day = calendar.monthrange(year, 10)[1]
        for day in range(last_day, 0, -1):
            if calendar.weekday(year, 10, day) == 4:  # Friday is 4
                holidays_data.append((f'{year}-10-{day:02d}', 'Día de las Iglesias Evangélicas y Protestantes'))
                break
    
    df = pd.DataFrame(holidays_data, columns=['date', 'name'])
    df['date'] = pd.to_datetime(df['date'])
    
    print(f"Using fallback data for year {year}")
    return df


def is_working_day(date: datetime, holidays_df: pd.DataFrame) -> bool:
    """Check if a date is a working day"""
    if date.weekday() >= 5:  # Weekend
        return False
    
    if not holidays_df.empty:
        holiday_dates = pd.to_datetime(holidays_df['date']).dt.date
        if date.date() in holiday_dates.values:
            return False
    
    return True


def get_last_working_day(reference_date: Optional[datetime] = None, 
                         holidays_df: Optional[pd.DataFrame] = None) -> datetime:
    """Get the last working day before reference_date"""
    if reference_date is None:
        reference_date = datetime.now()
    
    if holidays_df is None:
        holidays_df = scrape_chilean_holidays(reference_date.year)
    
    current_date = reference_date - timedelta(days=1)
    max_iterations = 15
    iterations = 0
    
    while not is_working_day(current_date, holidays_df) and iterations < max_iterations:
        current_date -= timedelta(days=1)
        if current_date.year != reference_date.year:
            holidays_df = scrape_chilean_holidays(current_date.year)
        iterations += 1
    
    return current_date


def get_all_working_days(start_date: datetime, end_date: datetime,
                        holidays_df: Optional[pd.DataFrame] = None) -> List[datetime]:
    """Get all working days between two dates"""
    if holidays_df is None:
        holidays_df = scrape_chilean_holidays(start_date.year)
    
    working_days = []
    current_date = start_date
    
    while current_date <= end_date:
        if is_working_day(current_date, holidays_df):
            working_days.append(current_date)
        current_date += timedelta(days=1)
    
    return working_days


# Example usage
if __name__ == "__main__":
    print("=" * 70)
    print("Chilean Holidays Scraper - Enhanced Debugging Version")
    print("=" * 70)
    
    # Get current year
    current_year = datetime.now().year
    
    # Scrape holidays with detailed output
    print(f"\n1. Scraping Chilean holidays for {current_year}...")
    print("-" * 70)
    holidays = scrape_chilean_holidays(current_year)
    
    print("\n" + "=" * 70)
    if not holidays.empty:
        print(f"✓ Found {len(holidays)} holidays for {current_year}:\n")
        print(holidays.to_string(index=False))
    else:
        print("⚠ No holidays found")
    
    # Test last working day
    print("\n" + "=" * 70)
    print("2. Finding last working day...")
    print("-" * 70)
    
    today = datetime.now()
    last_working = get_last_working_day(today, holidays)
    
    print(f"\nReference date: {today.strftime('%Y-%m-%d (%A)')}")
    print(f"Last working day: {last_working.strftime('%Y-%m-%d (%A)')}")
    print(f"Is reference date a working day? {is_working_day(today, holidays)}")
    
    # Working days in current month
    print("\n" + "=" * 70)
    print(f"3. Working days in {today.strftime('%B %Y')}...")
    print("-" * 70)
    
    start = datetime(today.year, today.month, 1)
    end = datetime(today.year, today.month + 1, 1) - timedelta(days=1) if today.month < 12 else datetime(today.year, 12, 31)
    working_days = get_all_working_days(start, end, holidays)
    
    print(f"\nTotal working days: {len(working_days)}")
    print(f"Working days: {[d.strftime('%d') for d in working_days]}")