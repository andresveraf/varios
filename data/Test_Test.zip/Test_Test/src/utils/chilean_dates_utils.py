"""
Chilean Public Holidays Scraper - Simple Class Version
Specifically designed for www.feriadoschilenos.cl structure
"""

import os
import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional
import warnings
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore')


class ChileHolidayScraper:
    """
    Simple class to scrape Chilean public holidays and calculate working days.
    """
    
    def __init__(self):
        """Initialize the scraper with month mappings."""
        self.months_es = {
            'enero': 1, 'febrero': 2, 'marzo': 3, 'abril': 4,
            'mayo': 5, 'junio': 6, 'julio': 7, 'agosto': 8,
            'septiembre': 9, 'octubre': 10, 'noviembre': 11, 'diciembre': 12
        } 



    def scrape_holidays(self, year: Optional[int] = None) -> pd.DataFrame:
        """
        Scrape Chilean public holidays from feriadoschilenos.cl
        
        Args:
            year (int, optional): Year to scrape holidays for. Defaults to current year.
            
        Returns:
            pd.DataFrame: DataFrame with 'date' and 'name' columns
        """
        if year is None:
            year = datetime.now().year
        
        try:
            url = "https://www.feriadoschilenos.cl/"
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'es-CL,es;q=0.9,en;q=0.8',
                'Connection': 'keep-alive',
            }
            
            session = requests.Session()
            session.verify = False
            
            response = session.get(url, headers=headers, timeout=15)
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.content, 'html.parser')
            holidays = []
            
            # Find all tables and analyze them
            tables = soup.find_all('table')
            
            for table in tables:
                rows = table.find_all('tr')
                
                if len(rows) < 3:
                    continue
                
                # Check if this looks like a holiday table
                sample_text = ' '.join([row.get_text() for row in rows[:3]]).lower()
                
                if not any(word in sample_text for word in ['fecha', 'date', 'día', 'mes', 'enero', 'febrero', 'marzo']):
                    continue
                
                # Parse this table
                for row in rows:
                    cols = row.find_all(['td', 'th'])
                    
                    if len(cols) < 2:
                        continue
                    
                    col_texts = [col.get_text(strip=True) for col in cols]
                    
                    # Skip header rows
                    if any(keyword in ' '.join(col_texts).lower() 
                           for keyword in ['fecha', 'date', 'nombre', 'name', 'feriado']):
                        continue
                    
                    # Skip rows that don't look like dates
                    first_col = col_texts[0]
                    if not any(char.isdigit() for char in first_col):
                        continue
                    
                    try:
                        if str(year) in first_col and len(col_texts) > 1:
                            date_str = col_texts[1]
                            holiday_name = col_texts[2] if len(col_texts) > 2 else "Feriado"
                        else:
                            date_str = first_col
                            holiday_name = col_texts[1] if len(col_texts) > 1 else "Feriado"
                        
                        holiday_date = self._parse_date(date_str, year)
                        
                        if holiday_date.year == year:
                            holidays.append({
                                'date': holiday_date,
                                'name': holiday_name
                            })
                        
                    except Exception:
                        continue
            
            # Create DataFrame from collected holidays
            if holidays:
                df = pd.DataFrame(holidays)
                df['date'] = pd.to_datetime(df['date'])
                df = df.drop_duplicates(subset=['date'])
                df = df.sort_values('date').reset_index(drop=True)
                df = df[df['date'].dt.year == year]
                
                if len(df) >= 8:
                    return df
            
            # Use fallback if scraping didn't work well
            return self._get_fallback_holidays(year)
            
        except Exception:
            return self._get_fallback_holidays(year)


    def _parse_date(self, date_str: str, year: int) -> datetime:
        """
        Parse Chilean date format with improved logic
        
        Args:
            date_str (str): Date string to parse
            year (int): Year to use if not specified in date string
            
        Returns:
            datetime: Parsed date
        """
        date_str = str(date_str).lower().strip()
        
        # Remove day names and extra parentheses
        for day in ['lunes', 'martes', 'miércoles', 'miercoles', 'jueves', 'viernes', 'sábado', 'sabado', 'domingo']:
            date_str = date_str.replace(day, '')
        
        # Remove parentheses and content
        import re
        date_str = re.sub(r'\([^)]*\)', '', date_str)
        date_str = date_str.strip().strip(',').strip()
        
        # Skip invalid entries
        if '¿' in date_str or '—' in date_str or 'no se' in date_str or len(date_str.strip()) < 3:
            raise ValueError(f"Invalid date format: {date_str}")
        
        # Format: "20 de junio" or "1 de enero"
        if ' de ' in date_str:
            parts = date_str.split(' de ')
            if len(parts) >= 2:
                try:
                    day = int(parts[0].strip())
                    month_name = parts[1].strip().split()[0]
                    month = self.months_es.get(month_name)
                    if month and 1 <= day <= 31:
                        return datetime(year, month, day)
                except (ValueError, TypeError):
                    pass
        
        # Format: "DD-MM-YYYY"
        if '-' in date_str:
            parts = date_str.split('-')
            if len(parts) == 3:
                try:
                    return datetime(int(parts[2]), int(parts[1]), int(parts[0]))
                except (ValueError, TypeError):
                    pass
            elif len(parts) == 2:
                try:
                    return datetime(year, int(parts[1]), int(parts[0]))
                except (ValueError, TypeError):
                    pass
        
        # Format: "DD/MM/YYYY" or "DD/MM"
        if '/' in date_str:
            parts = date_str.split('/')
            if len(parts) == 3:
                try:
                    return datetime(int(parts[2]), int(parts[1]), int(parts[0]))
                except (ValueError, TypeError):
                    pass
            elif len(parts) == 2:
                try:
                    return datetime(year, int(parts[1]), int(parts[0]))
                except (ValueError, TypeError):
                    pass
        
        # Try direct datetime parsing
        try:
            parsed = pd.to_datetime(date_str)
            if parsed.year < 1900:
                return datetime(year, parsed.month, parsed.day)
            return parsed.to_pydatetime()
        except:
            pass
        
        raise ValueError(f"Could not parse date: {date_str}")

    def _get_fallback_holidays(self, year: int) -> pd.DataFrame:
        """
        Fallback holidays data for Chile
        
        Args:
            year (int): Year to get holidays for
            
        Returns:
            pd.DataFrame: DataFrame with fallback holiday data
        """
        # Fixed holidays that don't change year to year
        fixed_holidays = [
            ('01-01', 'Año Nuevo'),
            ('05-01', 'Día del Trabajo'),
            ('05-21', 'Día de las Glorias Navales'),
            ('06-29', 'San Pedro y San Pablo'),
            ('07-16', 'Día de la Virgen del Carmen'),
            ('08-15', 'Asunción de la Virgen'),
            ('09-18', 'Día de la Independencia Nacional'),
            ('09-19', 'Día de las Glorias del Ejército'),
            ('10-12', 'Encuentro de Dos Mundos'),
            ('11-01', 'Día de Todos los Santos'),
            ('12-08', 'Inmaculada Concepción'),
            ('12-25', 'Navidad'),
        ]
        
        holidays_data = []
        
        # Add fixed holidays
        for date_str, name in fixed_holidays:
            holidays_data.append((f'{year}-{date_str}', name))
        
        # Add variable holidays based on specific years
        if year == 2025:
            holidays_data.extend([
                ('2025-04-18', 'Viernes Santo'),
                ('2025-04-19', 'Sábado Santo'),
                ('2025-10-31', 'Día de las Iglesias Evangélicas y Protestantes'),
            ])
        elif year == 2024:
            holidays_data.extend([
                ('2024-03-29', 'Viernes Santo'),
                ('2024-03-30', 'Sábado Santo'),
                ('2024-09-20', 'Feriado adicional'),
                ('2024-10-27', 'Día de las Iglesias Evangélicas y Protestantes'),
            ])
        elif year == 2026:
            holidays_data.extend([
                ('2026-04-03', 'Viernes Santo'),
                ('2026-04-04', 'Sábado Santo'),
                ('2026-10-31', 'Día de las Iglesias Evangélicas y Protestantes'),
            ])
        else:
            # For other years, use generic Easter calculation
            import calendar
            
            easter_dates = {
                2023: ('04-07', '04-08'),
                2027: ('03-26', '03-27'),
                2028: ('04-14', '04-15'),
                2029: ('03-30', '03-31'),
                2030: ('04-19', '04-20'),
            }
            
            if year in easter_dates:
                good_friday, holy_saturday = easter_dates[year]
                holidays_data.extend([
                    (f'{year}-{good_friday}', 'Viernes Santo'),
                    (f'{year}-{holy_saturday}', 'Sábado Santo'),
                ])
            
            # Add Protestant Day (usually last Friday of October)
            last_day = calendar.monthrange(year, 10)[1]
            for day in range(last_day, 0, -1):
                if calendar.weekday(year, 10, day) == 4:  # Friday is 4
                    holidays_data.append((f'{year}-10-{day:02d}', 'Día de las Iglesias Evangélicas y Protestantes'))
                    break
        
        df = pd.DataFrame(holidays_data, columns=['date', 'name'])
        df['date'] = pd.to_datetime(df['date'])
        
        return df

    def is_working_day(self, date: datetime, holidays_df: Optional[pd.DataFrame] = None) -> bool:
        """
        Check if a date is a working day
        
        Args:
            date (datetime): Date to check
            holidays_df (pd.DataFrame, optional): Holiday dataframe. If None, will scrape for the year.
            
        Returns:
            bool: True if it's a working day, False otherwise
        """
        if date.weekday() >= 5:  # Weekend
            return False
        
        if holidays_df is None:
            holidays_df = self.scrape_holidays(date.year)
        
        if not holidays_df.empty:
            holiday_dates = pd.to_datetime(holidays_df['date']).dt.date
            if date.date() in holiday_dates.values:
                return False
        
        return True

    def last_working(self, reference_date: Optional[datetime] = None) -> datetime:
        """
        Get the last working day before reference_date
        
        Args:
            reference_date (datetime, optional): Reference date. Defaults to current datetime.
            
        Returns:
            datetime: Last working day before reference date
        """
        if reference_date is None:
            reference_date = datetime.now()
        
        holidays_df = self.scrape_holidays(reference_date.year)
        
        current_date = reference_date - timedelta(days=1)
        max_iterations = 15
        iterations = 0
        
        while not self.is_working_day(current_date, holidays_df) and iterations < max_iterations:
            current_date -= timedelta(days=1)
            if current_date.year != reference_date.year:
                holidays_df = self.scrape_holidays(current_date.year)
            iterations += 1
        
        return current_date

    def get_all_working_days(self, start_date: datetime, end_date: datetime,
                            holidays_df: Optional[pd.DataFrame] = None) -> List[datetime]:
        """
        Get all working days between two dates
        
        Args:
            start_date (datetime): Start date
            end_date (datetime): End date
            holidays_df (pd.DataFrame, optional): Holiday dataframe. If None, will scrape for the year.
            
        Returns:
            List[datetime]: List of working days
        """
        if holidays_df is None:
            holidays_df = self.scrape_holidays(start_date.year)
        
        working_days = []
        current_date = start_date
        
        while current_date <= end_date:
            if self.is_working_day(current_date, holidays_df):
                working_days.append(current_date)
            current_date += timedelta(days=1)
        
        return working_days


# Backwards compatibility functions for existing code
def last_working(reference_date: Optional[datetime] = None) -> datetime:
    """
    Backwards compatibility function - Get the last working day before reference_date
    
    Args:
        reference_date (datetime, optional): Reference date. Defaults to current datetime.
        
    Returns:
        datetime: Last working day before reference date
    """
    scraper = ChileHolidayScraper()
    return scraper.last_working(reference_date)


# Example usage and testing
if __name__ == "__main__":
    print("=" * 70)
    print("Chilean Holidays Scraper - Simple Class Version")
    print("=" * 70)
    
    # Initialize scraper
    scraper = ChileHolidayScraper()
    
    # Get current year
    current_year = datetime.now().year
    
    # Scrape holidays
    print(f"\n1. Scraping Chilean holidays for {current_year}...")
    print("-" * 70)
    holidays = scraper.scrape_holidays(current_year)
    
    print("\n" + "=" * 70)
    if not holidays.empty:
        print(f"✓ Found {len(holidays)} holidays for {current_year}:\n")
        print(holidays.to_string(index=False))
    else:
        print("⚠ No holidays found")
    
    # Test last working day
    print("\n" + "=" * 70)
    print("2. Finding last working day...")
    print("-" * 70)
    
    today = datetime.now()
    last_working_day = scraper.last_working(today)
    
    print(f"\nReference date: {today.strftime('%Y-%m-%d (%A)')}")
    print(f"Last working day: {last_working_day.strftime('%Y-%m-%d (%A)')}")
    print(f"Is reference date a working day? {scraper.is_working_day(today)}")
    
    # Working days in current month
    print("\n" + "=" * 70)
    print(f"3. Working days in {today.strftime('%B %Y')}...")
    print("-" * 70)
    
    start = datetime(today.year, today.month, 1)
    end = datetime(today.year, today.month + 1, 1) - timedelta(days=1) if today.month < 12 else datetime(today.year, 12, 31)
    working_days = scraper.get_all_working_days(start, end)
    
    print(f"\nTotal working days: {len(working_days)}")
    print(f"Working days: {[d.strftime('%d') for d in working_days]}")
    
    

"""
from src.utils.chile_holiday_scraper import ChileHolidayScraper

scraper = ChileHolidayScraper()
last_working_day = scraper.last_working(datetime.now())
holidays = scraper.scrape_holidays(2025)


## Option 2
from src.utils.chile_holiday_scraper import last_working

last_working_day = last_working(datetime.now())


lw_dt = last_working(self.now)
self.last_working = lw_dt.date() if hasattr(lw_dt, "date") else lw_dt  # >> 2025-10-02

"""