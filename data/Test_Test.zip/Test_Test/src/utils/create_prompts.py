from verbalized_sampling import verbalize

# Generate diverse responses
dist = verbalize(
    "Write a marketing tagline for a coffee shop",
    k=5,
    tau=0.10,
    temperature=0.9
)
# Sample from the distribution
tagline = dist.sample(seed=42)
print(tagline.text)