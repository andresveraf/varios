
import pdfplumber

def extract_tables_from_pdf(pdf_path, max_page=None):
    tables = []
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages):
            if max_page and i + 1 > max_page:
                break
            page_tables = page.extract_tables()
            for table in page_tables:
                tables.append((i + 1, table))  # Store page number with table
    return tables

# Ejemplo de uso
pdf_file = rf"C:\RPA\repositorio\OPS\OP01_ocr_pii\input\_file_input\Chile - Manual de Agencia Propia\Chile - Manual de Agencia Propia.pdf"
tables = extract_tables_from_pdf(pdf_file)
for i, (page_num, table) in enumerate(tables):
    print(f"Table {i + 1} (Page {page_num}):")
    print(table)
    print("-" * 80)
