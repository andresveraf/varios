"""
fmw_utils.py

Utility functions and classes for configuration management, logging, file operations, datetime utilities, and process management.

This module provides reusable helpers for the automation framework, including:
- Logging initialization
- Configuration loading and path handling
- JSON/Excel file operations
- Directory and process management
- Date/time utilities
- Miscellaneous helpers (masking, currency formatting, etc.)

Typical usage example:

    from utils.fmw_utils import start_logging, Config, save_excel_file
    import pandas as pd

    # Initialize logging
    start_logging(log_folder="output/_logs", save_logs=True)

    # Load configuration
    config = Config().build_config()

    # Save a DataFrame to Excel
    df = pd.DataFrame({"A": [1,2], "B": [3,4]})
    save_excel_file(df, "output/test.xlsx")

"""

import re
import io
import os
import json
import shutil
import logging
import subprocess
import unicodedata
import pandas as pd
import datetime as dt
from dateutil.relativedelta import relativedelta


def start_logging(log_folder: str = "", logs_level: str = "INFO", show_console_logs: bool = True, save_logs: bool = False, 
                  label: str = "", timestamp_format: str = "%Y%m%d_%H%M%S"):
    """
    Initialize logging to file and/or console with custom formatting.

    Args:
        log_folder (str): Path to the folder where logs will be saved.
        logs_level (str): Logging level (e.g., 'INFO', 'DEBUG').
        show_console_logs (bool): Whether to show logs in the console.
        save_logs (bool): Whether to save logs to a file.
        label (str): Optional label for the log file name.
        timestamp_format (str): Format for the timestamp in the log file name.

    Returns:
        int: 0 if logging initialized successfully.

    Example:
        start_logging(log_folder="output/_logs", save_logs=True)
    """

    now_str         = dt.datetime.now() 
    month           = dt_to_spanish(now_str,capitalize=True)        ###  SE USA LA FUNCION DT TO SPANISH PARA OBTENER EL MES SEGUN LA VARIABLE NOW_STR
    year            = now_str.year                                  ###  SE EXTRAE EL A�O DE LA FECHA ACTUAL 
    logs_ym_folder  = os.path.join(log_folder,f"_{year}\_{month}") ###  SE HACE UN JOIN PARA GENERAR EL PATH "_2024/_MES"
    
    if(os.path.exists(logs_ym_folder) == False):                    ###  VALIDAR SI EL PATH GENERADO ANTERIORMENTE NO EXISTE
        os.makedirs(logs_ym_folder)                                 ###  SI NO EXISTE, SE CREA


    logFormatter_file    = logging.Formatter('%(asctime)-15s [%(levelname)-5.5s] %(message)s')
    logFormatter_console = logFormatter_file
    logs_now_filepath    = os.path.join(logs_ym_folder,f"{label}_{now_str.strftime(timestamp_format)}.log") ## SE MODIFICA EL PATH DEL LOG, RESULTANDO EN /OUTPUT/_LOGS/_2024/_MES/LOG_XXX.LOG


    # assign root logger
    rootLogger = logging.getLogger()
    rootLogger.setLevel(logs_level)
    if show_console_logs:
        # show logs on console
        consoleHandler = logging.StreamHandler()
        consoleHandler.setFormatter(logFormatter_console)
        rootLogger.addHandler(consoleHandler)
    if save_logs:
        create_folder(folder_path=log_folder)
        # write logs in log file
        fileHandler = logging.FileHandler(logs_now_filepath, mode="a")
        fileHandler.setFormatter(logFormatter_file)
        rootLogger.addHandler(fileHandler)
    logging.info(f"--------- Logging started ---------")
    if save_logs:
        logging.info(f"Log file: {logs_now_filepath}")
    return 0


class Config:
    """
    Loads and builds configuration from JSONC files, manages config paths and tag keys.

    Usage:
        config = Config().build_config()
    """
    def __init__(self):
        self.execution_folder = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        self.config   = None
        self.tag_keys = dict()

    def build_config(self):
        """
        Build and return the full configuration dictionary with absolute paths and tag keys.

        Returns:
            dict: The processed configuration dictionary.
        """
        # utils.py must be in modules folder
        # Replace auto user in all paths
        self.config = self.read_config()
        self.config = {k.upper(): v for k, v in self.config.items()}
        self.config = self.build_absolute_config_paths(config=self.config) # Create absolute paths
        self.get_config_tag_keys(config=self.config)                       # Create tags keys dict
        config_env  = self.config[self.config["METADATA"]["ENVIRONMENT"]]  # Assig env dict
        self.get_config_tag_keys(config=config_env)                        # Update tags keys dict with env dict
        self.config = self.build_absolute_config_paths(config=self.config) # Update values with env tag keys
        self.config = self.build_absolute_config_paths(config=self.config) # Update values with env tag keys
        self.config = self.build_absolute_config_paths(config=self.config) # Update values with env tag keys
        return self.config

    def read_config(self):
        """
        Read the main config file (config.jsonc) and return as a dictionary.

        Returns:
            dict: The configuration dictionary.
        Raises:
            Exception: If config file is not found.
        """
        config_file = os.path.join(self.execution_folder, "config.jsonc")
        if os.path.exists(config_file):
            config = read_jsonc(file_path=config_file)
            config = {k.upper(): v for k, v in config.items()}
            return config
        else: 
            raise Exception("Could not read config file: utils.py must be located in modules/utils folder and config.json in framework folder")

    def get_config_tag_keys(self, config: dict):
        """
        Recursively collect tag keys from config dictionaries.

        Args:
            config (dict): Configuration dictionary to scan for tag keys.
        """
        for key, value in config.items():
            if type(value) is dict:
                self.get_config_tag_keys(value)
            elif type(value) is str:
                self.tag_keys[key] = value

    def build_absolute_config_paths(self, config: dict):
        """
        Convert relative config paths to absolute paths and replace tag keys.

        Args:
            config (dict): Configuration dictionary to process.
        Returns:
            dict: Configuration with absolute paths.
        """
        for key, value in config.items():
            if type(value) is dict:
                value = self.build_absolute_config_paths(value)
            elif type(value) is str:
                if value.startswith("../"):
                    value_no_code = os.path.normpath(value[3:]) # remove "../"
                    value = os.path.join(self.execution_folder,value_no_code)
                if '\\Users\\' in value:
                    path_vals = value.split("\\")
                    user_idx  = path_vals.index("Users") + 1
                    value     = value.replace(path_vals[user_idx], os.getlogin())
                elif "/Users/" in value:
                    path_vals = value.split("/")
                    user_idx  = path_vals.index("Users") + 1
                    value     = value.replace(path_vals[user_idx], os.getlogin())
                tags_in_value = list(filter(lambda tag_key: "{"+tag_key+"}" in value, self.tag_keys.keys()))
                # print(f"{key}: {value} | {tags_in_value}")
                if len(tags_in_value) > 0:
                    value = value.replace("{"+tags_in_value[0]+"}", self.tag_keys[tags_in_value[0]])
                value = value.replace("{WORKING_FOLDER}", f"{os.getcwd()}/")
                config[key] = value.replace("{USER_PROFILE}", os.environ['USERPROFILE'])
        return config
 

def read_config():
    """
    Read and return the processed configuration using the Config class.

    Returns:
        dict: The processed configuration dictionary.
    """
    config_class = Config()
    config = config_class.build_config()
    return config
    

def read_json(file_path: str):
    """
    Read a JSON file and return its contents as a dictionary.

    Args:
        file_path (str): Path to the JSON file.
    Returns:
        dict: Contents of the JSON file.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)
    

def read_jsonc(file_path: str):
    """
    Read a JSONC (JSON with comments) file and return its contents as a dictionary.

    Args:
        file_path (str): Path to the JSONC file.
    Returns:
        dict: Contents of the JSONC file.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        file_content = f.read()
    file_content = re.sub(r'\/\/.*?\
|\/\*.*?\*\/', "", file_content, flags=re.DOTALL)
    file_obj = io.StringIO(file_content)
    return json.load(file_obj)



def save_json_file(dicData: dict, file_path: str):
    """
    Save a dictionary as a JSON file.

    Args:
        dicData (dict): Data to save.
        file_path (str): Path to save the JSON file.
    """
    print(f"Saving json file as: {file_path}")
    with open(file_path, "w") as file:
        json.dump(dicData, file, indent=4, sort_keys=True)


def delete_folder(folder_path: str):
    """
    Delete a folder and its contents.

    Args:
        folder_path (str): Path to the folder to delete.
    """
    logging.info(f"Deleting folder: {folder_path}")
    if os.path.exists(folder_path):
        shutil.rmtree(folder_path, ignore_errors=False, onerror=None)


def create_folder(folder_path: str):
    """
    Create a folder if it does not exist.

    Args:
        folder_path (str): Path to the folder to create.
    """
    logging.info(f"Creating folder {folder_path}")
    if not os.path.exists(folder_path):
        # Create the folder
        os.makedirs(folder_path, exist_ok=True)


def save_excel_file(df: pd.DataFrame, file_path: str, sheet_name: str = "base", overwrite: bool = False, index: bool = False):
    """
    Save a pandas DataFrame to an Excel file with formatting.

    Args:
        df (pd.DataFrame): DataFrame to save.
        file_path (str): Path to the Excel file.
        sheet_name (str): Name of the Excel sheet.
        overwrite (bool): Whether to overwrite the file if it exists.
        index (bool): Whether to write row indices.
    Returns:
        int: 0 if successful.
    """
    logging.info(f"Saving dataframe with shape: {df.shape}")
    # Create the file if not already exists
    if not os.path.exists(file_path) or overwrite:
        writer = pd.ExcelWriter(file_path, engine='xlsxwriter')
        df.to_excel(writer, sheet_name=sheet_name, index=index)  # send df to writer
        worksheet = writer.sheets[sheet_name]                    # pull worksheet object
        for idx, col in enumerate(df):                           # loop through all columns
            series  = df[col]
            max_len = min(max(series.astype(str).map(len).max(), len(str(series.name))) + 3, 50)
            if pd.isna(max_len):
                max_len = len(col) + 3
            worksheet.set_column(idx, idx, max_len)             # set column
        writer.close()
    else:
        # save the dataframe to the same excel file
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='a', if_sheet_exists="overlay") as writer:
            df.to_excel(writer, sheet_name=sheet_name, index=index)
        logging.info(f"File saved as {file_path}")
    return 0


def kill_processes(processes: list):
    """
    Kill a list of processes by name using PowerShell.

    Args:
        processes (list): List of process names to kill.
    Returns:
        int: 0 if successful.
    """
    processes = [process.lower().strip() for process in processes]
    logging.info(f"Killing process: {processes}")
    for proc in processes:
        logging.debug(f"Killing process: {proc}")
        process_status = subprocess.run(["powershell", "-command", f"taskkill /IM {proc} /F"]
                                        , capture_output=True)
        logging.debug(f"Process {proc} killed")
    return 0     


def add_dt_offset(in_dt: dt.datetime = dt.datetime.now(), months: int = 0, years: int = 0, days: int = 0, hours: int = 0, minutes: int = 0, seconds: int = 0):
    """
    Add a time offset to a datetime object.

    Args:
        in_dt (datetime): Input datetime.
        months (int): Months to add.
        years (int): Years to add.
        days (int): Days to add.
        hours (int): Hours to add.
        minutes (int): Minutes to add.
        seconds (int): Seconds to add.
    Returns:
        datetime: Resulting datetime after offset.
    """
    return in_dt + relativedelta(years=years, months=months, days=days, hours=hours, minutes=minutes, seconds=seconds)


def last_day_in_month(in_dt: dt.datetime):
    """
    Return the last day of the month for a given datetime.

    Args:
        in_dt (datetime): Input datetime.
    Returns:
        datetime: Last day of the month.
    """
    next_month = add_dt_offset(in_dt=in_dt, months=1).replace(day=1)
    last_day   = add_dt_offset(in_dt=next_month, days=-1)
    return last_day

def obtain_months() -> dict:
    
    path_json = rf"C:\RPA\PRV1015_Comprobantes_pagos_banco_estado\src\utils\dates_info.json"
    with open(path_json) as f:
        datos = json.load(f)
        return datos["CALENDAR_NAME"]
    


def dt_to_spanish(in_dt: dt.datetime, month_or_day: str = "month", capitalize: bool = False):
    """
    Convert a datetime to its Spanish month or day name.

    Args:
        in_dt (datetime): Input datetime.
        month_or_day (str): 'month' or 'day'.
        capitalize (bool): Whether to capitalize the result.
    Returns:
        str: Spanish name of the month or day.
        
    Example usage:
        var = dt_to_spanish(dt.datetime.now(), month_or_day="month", capitalize=True)
        Julio
        
    """
    months_dict = {
        1: 'enero',
        2: 'febrero',
        3: 'marzo',
        4: 'abril',
        5: 'mayo',
        6: 'junio',
        7: 'julio',
        8: 'agosto',
        9: 'septiembre',
        10: 'octubre',
        11: 'noviembre',
        12: 'diciembre'
    }
    days_dict = {
        0: 'lunes',
        1: 'martes',
        2: 'miercoles',
        3: 'jueves',
        4: 'viernes',
        5: 'sabado',
        6: 'domingo'
    }
    if month_or_day.lower() == "month":
        month_num = int(in_dt.month)
        output    = months_dict[month_num]
    elif month_or_day.lower() == "day":
        day_num   = in_dt.weekday()
        output    = days_dict[day_num]
    else:
        raise Exception(f"Input to month_or_day variable: {month_or_day} does not match expected answers")
    if capitalize:
        output = output.capitalize()
    return output

print(dt_to_spanish(dt.datetime.now(), month_or_day="month", capitalize=True) ) # Example usage to test the function


def log_worktray_metadata(config: dict, wt_status_col: str = "STATUS"):
    """
    Log worktray metadata, including status counts and file existence.

    Args:
        config (dict): Configuration dictionary.
        wt_status_col (str): Name of the status column in the worktray.
    Returns:
        int: 0 if successful.
    """
    logging.info("--- Logging worktray metadata ---")
    global_keys = config["GLOBAL"].keys()
    process_with_worktray = any(["WORKTRAY" in key.upper() for key in global_keys])
    logging.info(f"Process with worktray: {process_with_worktray}")
    process_data_path = config["FRAMEWORK"]["PROCESS_DATA"]
    worktray_path = os.path.join(process_data_path, "worktray.xlsx")
    logging.info(f"Worktray path: {worktray_path}")
    worktray_exists = os.path.exists(worktray_path)
    logging.info(f"Worktray exists: {worktray_exists}")
    wt_status = dict()
    wt_rows   = 0
    if process_with_worktray:
        if worktray_exists:
            df_worktray = pd.read_excel(io=worktray_path)
            logging.info(f"Worktray shape: {df_worktray.shape}")
            wt_rows   = df_worktray.shape[0]
            wt_status = df_worktray[wt_status_col].value_counts().to_dict()
    else:
        wt_rows = 1
    logging.info(f"Worktray rows: {wt_rows}")
    logging.info(f"Worktray status: {wt_status}")
    return 0


def get_total_states():
    """
    Get the total number of states defined in main.py (lines with 'self.state_idx == ').

    Returns:
        int: Number of states found.
    """
    execution_folder = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    main_file        = os.path.join(execution_folder, "main.py")
    with open(main_file, "r", encoding="utf-8") as f:
        main_file_text = f.read().splitlines()
    state_lines = [line for line in main_file_text if "self.state_idx == " in line]
    return len(state_lines)


def mask_number(nfloat, digits_to_show, decimals_to_show):
    """
    Mask a number, showing only the last digits and decimals.

    Args:
        nfloat (float): Number to mask.
        digits_to_show (int): Number of digits to show.
        decimals_to_show (int): Number of decimals to show.
    Returns:
        str: Masked number as a string.
    """
    #nfloat = round(nfloat, ndigits=decimals_to_show)    
    number = "{:.{}f}".format(nfloat, decimals_to_show )
    total_digits_to_show = digits_to_show + (0 if decimals_to_show == 0 else decimals_to_show + 1)
    mask = f"{'*' * (len(number) - total_digits_to_show)}{number[-(total_digits_to_show):]}"
    return (mask)


def get_size(file_path, unit='bytes'):
    """
    Get the size of a file in the specified unit.

    Args:
        file_path (str): Path to the file.
        unit (str): Unit ('bytes', 'kb', 'mb', 'gb').
    Returns:
        float: File size in the specified unit.
    Raises:
        ValueError: If unit is not recognized.
    """
    file_size = os.path.getsize(file_path)
    exponents_map = { 'bytes': 0, 'kb': 1, 'mb': 2, 'gb': 3 }        
    if unit not in exponents_map:
        raise ValueError("Must select from             ['bytes', 'kb', 'mb', 'gb']")
    else:
        size = file_size / 1024 ** exponents_map[unit]
        return round(size, 3)


def get_last_log_file(log_folder: str):
    """
    Get the most recently modified log file in the log folder.

    Args:
        log_folder (str): Path to the log folder.
    Returns:
        str: Path to the last log file.
    """
    now_str     = dt.datetime.now()         
    month   = dt_to_spanish(now_str,capitalize=True)
    year    = now_str.year
    folder = os.path.join(log_folder,f"_{year}\\_{month}")
    
    log_files = [os.path.join(folder, file_name) for file_name in os.listdir(path=folder)]
    log_files.sort(reverse=True)
    last_log_file = log_files[0]
    logging.info(f"Execution log file: {os.path.basename(last_log_file)}")
    return last_log_file


def build_execution_summary_table(config: dict, file_exe_report, dti_start_exe=dt.datetime.now(), dti_final_exe=dt.datetime.now(), 
                                status=None, processed_states=None, total_state=None):
    """
    Build and save an execution summary table as a DataFrame and JSON file.

    Args:
        config (dict): Configuration dictionary.
        file_exe_report (str): Path to save the execution report JSON.
        dti_start_exe (datetime): Start time.
        dti_final_exe (datetime): End time.
        status (str): Execution status.
        processed_states (int): Number of processed states.
        total_state (int): Total number of states.
    Returns:
        pd.DataFrame: Execution summary as a DataFrame.
    """
    dic_exe_data = dict()
    # Add execution metadata
    dic_exe_data["EXECUTION_STATUS"] = status
    dic_exe_data["PROCESSED_STATES"] = processed_states
    dic_exe_data["TOTAL_STATES"]     = total_state
    dic_exe_data["START_TIME"]       = dti_start_exe.strftime("%Y-%m-%d_%H:%M:%S")
    dic_exe_data["END_TIME"]         = dti_final_exe.strftime("%Y-%m-%d_%H:%M:%S")
    # Add process METADATA
    dic_exe_data.update(config["METADATA"])
    # Convert dictionary to dataframe
    df_exe_report = pd.DataFrame(data=dic_exe_data.items(), columns=["PARAMETER", "VALUE"])
    # Save dataframe as json file
    save_json_file(dicData=dic_exe_data, file_path=file_exe_report)
    return df_exe_report


def remove_path_until_tag(path: str, tag: str, include_tag: bool = True) -> str:
    """
    Shorten a given path, removing its first part until a specific folder/tag.

    Args:
        path (str): Path to be shortened.
        tag (str): Target folder/tag to split the path.
        include_tag (bool): If True, path starts with the tag folder; else, with subfolder.
    Returns:
        str: Shortened path.
    """
    path_parts  = []
    found_tag   = False
    out_path    = path
    path_exists = True
    while path_exists:
        head, tail = os.path.split(path)
        path_parts.insert(0, tail)
        if tag in [head, tail]:
            found_tag = True
            if head == tag:
                path_parts.insert(0, os.path.split(head)[-1])
            break
        path = head
        path_exists = head and tail
    if found_tag:
        if not include_tag:
            path_parts.pop(0)  # Remove the tag from the path
        out_path = os.path.join(*path_parts)
    return out_path

def save_txt_file(input_txt: str, out_path: str):
    """
    Save a string as a text file.

    Args:
        input_txt (str): Text to save.
        out_path (str): Path to save the text file.
    Returns:
        int: 0 if successful.
    """
    create_folder(os.path.dirname(out_path))
    f = open(out_path, "w", encoding="utf-8")
    f.write(input_txt)
    f.close()
    return 0

def read_txt(file_path: str):
    """
    Read a text file and return its contents.

    Args:
        file_path (str): Path to the text file.
    Returns:
        str: Contents of the text file.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()

def remove_accents(string: str) -> str:
    """
    Remove accents from a string.

    Args:
        string (str): Input string.
    Returns:
        str: String without accents.
    """
    nfkd_form = unicodedata.normalize('NFKD', string)
    not_accents_string = ''.join([c for c in nfkd_form if not unicodedata.combining(c)])
    return not_accents_string


def number_to_currency(number: float, type_format: str = "currency", sign: bool = True) -> str:
    """
    Convert a number to Chilean currency format.

    Args:
        number (float): Number to convert.
        type_format (str): Format type ('dots_only', 'two_decimal', 'currency').
        sign (bool): Add the peso sign ($) if True.
    Returns:
        str: Formatted currency string.
    """
    if type_format == "dots_only":
        currency_string = "{:,}".format(number)
    elif type_format == "two_decimal":
        currency_string = "{:.2f}".format(number)
    elif type_format == "currency":
        currency_string = "{:,.2f}".format(number)
    if sign:
        currency_string = "$" + currency_string          
    currency_string_spanish = currency_string.replace(".", ";"). replace(",", ".").replace(";", ",")
    return currency_string_spanish


def delete_old_folders(parent_folder: str, month_offset: int = -1, date_formats: list = ["%Y%m", "%Y_%m"]):
    """
    Delete old folders according to a month offset and date format.

    Args:
        parent_folder (str): Parent folder containing dated subfolders.
        month_offset (int): Offset in months for deletion threshold.
        date_formats (list): List of date formats for folder names.
    Returns:
        int: 0 if successful.
    """
    logging.info(f"--- delete_old_folders --- ")
    logging.info(f"Parent folder: {parent_folder}")
    limit_folder_date = add_dt_offset(dt.datetime.today(), months=month_offset)
    int_limit_date_folder = int(limit_folder_date.strftime("%Y%m"))
    logging.info(f"Limit date: {int_limit_date_folder} | Month offset: {month_offset}")
    deleted_folders  = list()
    for rootdir, dirs, files in os.walk(parent_folder):
        for date_format in date_formats:
            try:
                folder_name = os.path.basename(rootdir)
                dti_month_folder = dt.datetime.strptime(folder_name, date_format)
            except Exception as error:
                # logging.warning(f"Error: {error}")
                continue
            int_month_folder = int(dti_month_folder.strftime("%Y%m"))
            # if month folder is too old, delete folder
            if int_month_folder < int_limit_date_folder:
                delete_folder(folder_path=rootdir)
                deleted_folders.append(int_month_folder)
    logging.info(f"Deleted folders ({len(deleted_folders)}): {list(set(deleted_folders))}")
    return 0
    
def create_backup(in_filepath_backup: str, out_backup_folder: str):
    """
    Copy a file to a backup folder, avoiding overwrites by renaming duplicates.

    Args:
        in_filepath_backup (str): Path to the file to back up.
        out_backup_folder (str): Folder to save the backup.
    Returns:
        int: 0 if successful.
    """
    create_folder(out_backup_folder)
    filename             = os.path.basename(in_filepath_backup)
    out_filepath_backup  = os.path.join(out_backup_folder, filename)
    if os.path.exists(out_filepath_backup):
        list_files       = os.listdir(out_backup_folder)
        split_extention  = os.path.splitext(filename)
        name_without_ext = split_extention[0]
        extention        = split_extention[1]
        list_same_files  = [file for file in list_files if name_without_ext in file]
        new_name         = f"{name_without_ext}_({str(len(list_same_files)).zfill(2)})"
        new_filename     = f"{new_name}{extention}"
        out_filepath_backup = os.path.join(out_backup_folder, new_filename)
    logging.info(f"Saving backup file as: {out_filepath_backup}")
    shutil.copy(src=in_filepath_backup, dst=out_filepath_backup)
    return 0


def build_execution_summary_table_eb(config: dict, file_exe_report, status=None):
    """
    Build and save a minimal execution summary table for EB processes.

    Args:
        config (dict): Configuration dictionary.
        file_exe_report (str): Path to save the execution report JSON.
        status (str): Execution status.
    Returns:
        pd.DataFrame: Execution summary as a DataFrame.
    """
    dic_exe_data = dict()
    # Add execution metadata
    dic_exe_data["EXECUTION_STATUS"] = status
    # Convert dictionary to dataframe
    df_exe_report = pd.DataFrame(data=dic_exe_data.items(), columns=["PARAMETER", "VALUE"])
    # Save dataframe as json file
    save_json_file(dicData=dic_exe_data, file_path=file_exe_report)
    return df_exe_report

def check_files_exist(files):
    """
    Check if all required files exist. Raises FileNotFoundError if any are missing.

    Args:
        files (list): List of file paths to check.
    Raises:
        FileNotFoundError: If any files are missing.
        
    self.check_files_exist(self.required_files)
            logging.info("All required files exist")
    """
    missing = [f for f in files if not os.path.exists(f)]
    if missing:
        raise FileNotFoundError(f"Missing files: {missing}")
    
def find_header_row_index(file_path: str, target_column: str, max_rows: int = 20) -> int:
    """
    Scan the first `max_rows` of an Excel file to find the row index where the target column appears.
    
    Args:
        file_path (str): Path to the Excel file.
        target_column (str): The column name to search for.
        max_rows (int): Number of rows to scan from the top of the file.
    
    Returns:
        int: The row index (0-based) where the target column is found, or -1 if not found.
    """
    preview = pd.read_excel(file_path, header=None, nrows=max_rows)
    for idx, row in preview.iterrows():
        if target_column in row.values:
            return idx
    return -1
    
def check_file_exist(file_path: str):
    """
    Check if a single required file exists. Raises FileNotFoundError if missing.

    Args:
        file_path (str): Path to the file to check.

    Raises:
        FileNotFoundError: If the file is missing.

    Example:
        check_file_exist("input/data.xlsx")
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Missing file: {file_path}")


def standardize_single_date(date_value, output_format: str = '%d-%m-%Y', input_formats: list = None) -> str:
    """
    Standardize a single date value to the specified format.

    Args:
        date_value (str): Single date string in various formats.
        output_format (str): Desired output date format. Defaults to '%d-%m-%Y'.
        input_formats (list): List of expected input formats to try. If None, uses common formats.

    Returns:
        str: Standardized date string in the specified output format, or None if parsing failed.

    Example:
        # Single date conversion
        result = standardize_single_date('01/15/2023', '%Y-%m-%d')
        # Returns: '2023-01-15'
        
        result = standardize_single_date('15-01-2023', '%d/%m/%Y')
        # Returns: '15/01/2023'
    """
    if date_value is None or date_value == '':
        return None
    
    # Convert single value to Series
    date_series = pd.Series([date_value])
    
    # Use the main function
    result_series = standardize_date_format(date_series, output_format, input_formats)
    
    # Return the single result or None if parsing failed
    if result_series.isna().iloc[0]:
        return None
    return result_series.iloc[0]


def standardize_date_format(date_series, output_format: str = '%d-%m-%Y', input_formats: list = None) -> pd.Series:
    """
    Standardize date formatting across all modules with comprehensive format support.

    Args:
        date_series (pd.Series): Series containing dates in various formats.
        output_format (str): Desired output date format. Defaults to '%d-%m-%Y'.
        input_formats (list): List of expected input formats to try. If None, uses common formats.

    Returns:
        pd.Series: Standardized date series in the specified output format.

    Raises:
        TypeError: If date_series is not a pandas Series.
        ValueError: If output_format is invalid.

    Example:
        # Basic usage
        dates = pd.Series(['01/15/2023', '2023-01-15', '15-01-2023'])
        standardized = standardize_date_format(dates, '%Y-%m-%d')
        
        # With custom input formats
        custom_formats = ['%m/%d/%Y', '%Y-%m-%d', '%d-%m-%Y']
        standardized = standardize_date_format(dates, '%d/%m/%Y', custom_formats)
    """
    if not isinstance(date_series, pd.Series):
        raise TypeError("date_series must be a pandas Series")
    
    # Default input formats to try if none specified
    if input_formats is None:
        input_formats = [
            '%d-%m-%Y',     # 15-01-2023
            '%d/%m/%Y',     # 15/01/2023
            '%Y-%m-%d',     # 2023-01-15
            '%Y/%m/%d',     # 2023/01/15
            '%m/%d/%Y',     # 01/15/2023
            '%m-%d-%Y',     # 01-15-2023
            '%d.%m.%Y',     # 15.01.2023
            '%Y.%m.%d',     # 2023.01.15
            '%d %m %Y',     # 15 01 2023
            '%Y %m %d',     # 2023 01 15
        ]
    
    # Copy the series to avoid modifying the original
    result_series = date_series.copy()
    converted_dates = pd.Series(index=date_series.index, dtype='datetime64[ns]')
    
    # Try pandas built-in parser first (handles many formats automatically)
    try:
        converted_dates = pd.to_datetime(date_series, errors='coerce', dayfirst=True, infer_datetime_format=True)
        logging.debug("Successfully parsed dates using pandas automatic detection")
    except Exception as e:
        logging.warning(f"Pandas automatic date parsing failed: {e}")
    
    # For any dates that couldn't be parsed, try specific formats
    null_mask = converted_dates.isna()
    if null_mask.any():
        logging.info(f"Attempting to parse {null_mask.sum()} dates with specific formats")
        
        for fmt in input_formats:
            # Only try to convert dates that are still null
            remaining_mask = converted_dates.isna()
            if not remaining_mask.any():
                break
                
            try:
                # Try current format on remaining null dates
                temp_dates = pd.to_datetime(date_series[remaining_mask], format=fmt, errors='coerce')
                # Update converted_dates where we got valid results
                valid_mask = temp_dates.notna()
                if valid_mask.any():
                    converted_dates.loc[remaining_mask] = temp_dates
                    logging.debug(f"Format '{fmt}' successfully parsed {valid_mask.sum()} dates")
            except Exception as e:
                logging.debug(f"Format '{fmt}' failed: {e}")
                continue
    
    # Count successful conversions
    successful_conversions = converted_dates.notna().sum()
    total_dates = len(date_series)
    failed_conversions = total_dates - successful_conversions
    
    if failed_conversions > 0:
        logging.warning(f"Failed to parse {failed_conversions} out of {total_dates} dates")
        logging.debug(f"Failed dates: {date_series[converted_dates.isna()].tolist()}")
    else:
        logging.info(f"Successfully parsed all {total_dates} dates")
    
    # Convert to output format
    try:
        formatted_dates = converted_dates.dt.strftime(output_format)
        logging.info(f"Standardized {successful_conversions} dates to format '{output_format}'")
        return formatted_dates
    except Exception as e:
        logging.error(f"Failed to format dates with output format '{output_format}': {e}")
        raise ValueError(f"Invalid output format '{output_format}': {e}")


def is_pdf_image_based(pdf_path: str, min_text_threshold: int = 50, check_all_pages: bool = False) -> bool:
    """
    Check if a PDF is image-based (scanned) by analyzing text content and images.

    Args:
        pdf_path (str): Path to the PDF file to analyze.
        min_text_threshold (int): Minimum characters needed to consider a page as text-based. Defaults to 50.
        check_all_pages (bool): If True, checks all pages; if False, stops at first text-based page. Defaults to False.

    Returns:
        bool: True if PDF appears to be image-based (scanned), False if it contains readable text.

    Raises:
        FileNotFoundError: If the PDF file doesn't exist.
        Exception: If the PDF cannot be opened or processed.

    Example:
        # Check if PDF is image-based
        is_scanned = is_pdf_image_based("document.pdf")
        
        # Check with custom threshold and all pages
        is_scanned = is_pdf_image_based("document.pdf", min_text_threshold=100, check_all_pages=True)
    """
    import fitz  # PyMuPDF
    
    if not os.path.exists(pdf_path):
        raise FileNotFoundError(f"PDF file not found: {pdf_path}")
    
    logging.info(f"Analyzing PDF for image-based content: {pdf_path}")
    
    try:
        doc = fitz.open(pdf_path)
        total_pages = len(doc)
        pages_with_text = 0
        pages_with_images = 0
        total_text_chars = 0
        
        logging.debug(f"PDF has {total_pages} pages")
        
        for page_num in range(total_pages):
            page = doc[page_num]
            
            # Extract text from page
            text = page.get_text().strip()
            text_length = len(text)
            total_text_chars += text_length
            
            # Get images from page
            images = page.get_images()
            image_count = len(images)
            
            logging.debug(f"Page {page_num + 1}: {text_length} characters, {image_count} images")
            
            # Count pages with meaningful text
            if text_length >= min_text_threshold:
                pages_with_text += 1
                logging.debug(f"Page {page_num + 1} has sufficient text ({text_length} chars)")
                
                # If not checking all pages and we found text, it's not purely image-based
                if not check_all_pages:
                    doc.close()
                    logging.info(f"PDF contains readable text (found on page {page_num + 1})")
                    return False
            
            # Count pages with images
            if image_count > 0:
                pages_with_images += 1
        
        doc.close()
        
        # Analysis results
        avg_text_per_page = total_text_chars / total_pages if total_pages > 0 else 0
        text_ratio = pages_with_text / total_pages if total_pages > 0 else 0
        image_ratio = pages_with_images / total_pages if total_pages > 0 else 0
        
        logging.info(f"PDF Analysis - Pages with text: {pages_with_text}/{total_pages} ({text_ratio:.1%})")
        logging.info(f"PDF Analysis - Pages with images: {pages_with_images}/{total_pages} ({image_ratio:.1%})")
        logging.info(f"PDF Analysis - Average text per page: {avg_text_per_page:.1f} characters")
        
        # Determine if PDF is image-based
        # Consider it image-based if:
        # 1. Less than 30% of pages have sufficient text, AND
        # 2. More than 50% of pages have images, OR
        # 3. Average text per page is very low (less than min_text_threshold/2)
        is_image_based = (
            (text_ratio < 0.3 and image_ratio > 0.5) or 
            (avg_text_per_page < min_text_threshold / 2)
        )
        
        result_msg = "image-based (scanned)" if is_image_based else "text-based"
        logging.info(f"PDF determined to be: {result_msg}")
        
        return is_image_based
        
    except Exception as e:
        logging.error(f"Error analyzing PDF {pdf_path}: {e}")
        raise Exception(f"Failed to analyze PDF: {e}")

def es_pdf_de_imagen(pdf_path):
    import fitz  # PyMuPDF
    doc = fitz.open(pdf_path)
    for page in doc:
        text = page.get_text()
        images = page.get_images()
        # Si no hay texto pero sí imágenes, probablemente es un escaneo
        if not text.strip() and images:
            return True
    return False

def write_process_status(self, status: str, message: str = ""):
    """
    Append the process status and timestamp to a JSON file in the process_data folder.
    Each run is added as a new entry in a list.

    Args:
        status (str): Final status of the process (e.g., "SUCCESS", "FAILED").
        message (str): Optional message or error details.
    Example:
        self.write_process_status("SUCCESS")
        self.write_process_status("FAILED", "File not found")
    """
    process_data_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../process_data"))
    os.makedirs(process_data_dir, exist_ok=True)
    status_file = os.path.join(process_data_dir, "process_status.json")
    status_dict = {
        "datetime": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": status,
        "message": message
    }
    # Read existing log if present
    if os.path.exists(status_file):
        with open(status_file, "r", encoding="utf-8") as f:
            try:
                log = json.load(f)
                if not isinstance(log, list):
                    log = [log]
            except Exception:
                log = []
    else:
        log = []
    log.append(status_dict)
    with open(status_file, "w", encoding="utf-8") as f:
        json.dump(log, f, ensure_ascii=False, indent=2)
    logging.info(f"Process status appended to {status_file}")
    
    
def adjust_column_widths_and_format_headers(file_path):
    """
    Adjust the column widths in an Excel file and format the headers with blue fill,
    bold text, and white font color.

    Parameters:
    - file_path: str, the path to the Excel file.

    Returns:
    None
    """
    from openpyxl import load_workbook
    from openpyxl.styles import PatternFill, Font
    from openpyxl.utils import get_column_letter
    # Define the header style
    header_fill = PatternFill(start_color='0000FF', end_color='0000FF', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')

    # Load the workbook and iterate through each sheet
    workbook = load_workbook(file_path)
    for sheet_name in workbook.sheetnames:
        worksheet = workbook[sheet_name]
        
        # Iterate through each column and set the column width to the max length of content
        for col_idx, column in enumerate(worksheet.columns, 1):
            max_length = 0
            column = [cell for cell in column if cell.value]  # Filter out None cells
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(cell.value)
                except:
                    pass
            adjusted_width = (max_length + 2) * 1.2  # Adjust the width factor as needed
            worksheet.column_dimensions[get_column_letter(col_idx)].width = adjusted_width

            # Apply the header style to the first cell in the column
            if column:
                header_cell = worksheet.cell(row=1, column=col_idx)
                header_cell.fill = header_fill
                header_cell.font = header_font

    # Save the workbook
    workbook.save(file_path)
    
class BusinessException(Exception):
    """
    Custom exception for business logic errors.
    """
    pass
    
if __name__ == "__main__":
    # Example usage: initialize logging and print config
    start_logging()
    config = read_config()
    print("Config")
    for k, v in config.items():
        print(f"{k}: {v}")
        print()
    # delete_old_folders(parent_folder=r"C:\DATA\test\parent_folder", month_offset=0)

