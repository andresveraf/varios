
# file_name:   monitoring.py
# created_on:  2023-06-28 ; daniel.hermosilla
# modified_on: 2023-06-29 ; daniel.hermosilla
# modified_on: 2023-08-22 ; vicente.diaz ; Update robot user

import os
import sys
import datetime as dt
sys.path.append(os.path.abspath(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # move to modules 
# from fmw_utils import *
######## IF TEST, DELETE SCR. ########
from src.utils.fmw_utils import *
from google.cloud import bigquery
from google.oauth2 import service_account
from pathlib import Path
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=UserWarning)
from cryptography.fernet import Fernet
import getpass
user = getpass.getuser()
sys.path.append(f"C:\\Users\\{user}\\MetLife\\RPA_Transformacion_Operaciones - Documentos\\RPA\\LIBS\\azure_utils")
# from __init__ import AzureUtils # type: ignore
###parameters###
CREDENTIAL_NAME= "MONITORING"
CREDENTIALS_FILE= f"C:\\Users\\{user}\\MetLife\\Acelerar Transformación - OPS - Documentos\\Metlife\\credenciales\\credenciales_bots.xlsx"
TABLE_GCP   =   'Monitor_RPA_copy'

def encrypt_msg(msg:str, key:str) -> str:
    fernet        = Fernet(key)
    encrypted_msg = fernet.encrypt(msg.encode()).decode()
    return encrypted_msg

def decrypt_msg(encrypted_msg:str, key:str) -> str:
    fernet        = Fernet(key)
    decrypted_msg = fernet.decrypt(encrypted_msg).decode()
    return decrypted_msg

def generate_key() -> str:
    key= Fernet.generate_key().decode()
    return key

def get_credential_from_input_file(credential_name:str, credentials_file:str) -> dict:
    logging.info(f"--- Reading credentials: {credential_name} ---")
    # Run script after this
    logging.info(f"Credentials file: {credentials_file}")
    if os.path.exists(credentials_file):
        cred_excel = pd.read_excel(credentials_file, sheet_name="base")
        cred_excel.set_index(keys="Parameter", drop=True, inplace=True)
        if credential_name in cred_excel.index: 
            logging.info(f"Found credentials for {credential_name}")
            desiered_creds_dict = {
                "USER": cred_excel["User"][credential_name],
                "KEY": cred_excel["Key"][credential_name],
                "ENCRYPTED_STRING": cred_excel["Encrypted string"][credential_name]
            }
            password = decrypt_msg(encrypted_msg=desiered_creds_dict["ENCRYPTED_STRING"], key=desiered_creds_dict["KEY"])
            logging.info("Succesfully aquiered credentials")
            dic_creds = {"user": desiered_creds_dict['USER'], "password": password}
            return dic_creds
        else: 
            logging.warning(f"Credentials named: '{credential_name}' could not be found on credentials file")
    else:
        raise Exception(f"Credentials excel file could not be found on path: {credentials_file}")


# class GcpUtils:
#     dict_creds       = get_credential_from_input_file(credential_name=CREDENTIAL_NAME, credentials_file=CREDENTIALS_FILE)
#     key = dict_creds['password']
#     def Insert_row_gcp_monitor2(df,key_path=key):

#         # Esta apuntando al dataset en duro...
#         for column in df.columns:
#             if df[column].dtypes == 'datetime64[ns]':
#                 df[column] = df[column].dt.strftime("%Y-%m-%d")
#             if df[column].dtypes == object:
                
#                 df[column] = df[column].str.encode('UTF-16').str.decode('UTF-16').str.replace("'","").str.replace('Ã‰','E').str.replace('Ã‘','Ñ').str.replace('CompaÃ±ia','Compañia').str.replace('MARTÃ NEZ','MARTINEZ')                 .str.replace('Ã“','O').str.replace('Ã“','O').str.replace('Ã A','IA').str.replace('HERNÃ N','HERNAN').str.replace('HENRÃ QUEZ','HENRIQUEZ').str.replace('LAVÃ N','LAVIN')                 .str.replace('FundaciÃ³n Educacional AlcÃ¡ntara PeÃ±alolÃ©n','Fundacion Educacional Alcantara Peñalolen')                 .str.replace('Ãš','U').str.replace('Ã ','A').str.replace('ANGELIZÂ¿CA','ANGELICA').replace('#','Ñ').str.replace('ACU?A','ACUÑA')                 .str.replace('NU?EZ','NUÑEZ').str.replace('ZU¿æIGA','ZUÑIGA').str.replace('SANTIBA¿æEZ','SANTIBAÑEZ').str.replace('¿æ','Ñ').str.encode('UTF-8').str.decode('UTF-8')

#         credentials = service_account.Credentials.from_service_account_file(key_path)
#         client = bigquery.Client(credentials=credentials, project=credentials.project_id)
#         tablere=client.dataset('bgqbi_dt001').table(TABLE_GCP)
#         rows_to_insert = df.to_dict('records')
#         errors=client.insert_rows_json(tablere, rows_to_insert)

#         if errors == []:
#             print("New rows have been added.")
#         else:
#             print("Encountered errors while inserting rows: {}".format(errors))

class Monitoring:
    def __init__(self, config:dict=None):     
        now_str     = dt.datetime.now()         
        month   = dt_to_spanish(now_str,capitalize=True)
        year    = now_str.year
        self.config         = config if config==None else read_config()
        self.process_code   = self.config["METADATA"]["PROCESS_CODE"]
        self.process_name   = self.config["METADATA"]["PROCESS_NAME"]
        self.path_log       = self.config["FRAMEWORK"]["LOG_FOLDER"]+f"\\_{year}\\_{month}" ## se modifica la ruta de los logs

    def RegistrarEjecutivo(self,nombre_proyecto:str,cnt_registros:int,cnt_registros_total:int,lob_name:str,lobs_area:str,hostname:str,tipo:str,fecha:str,inicio:int,fin:int,tiempo_ejecucion:int,status:str, process_code:str):
        try:
            df=pd.DataFrame([{}])
            df=df.assign(NOMBRE_PROYECTO=None,REG_A_PROCESAR=None,REG_PROCESADOS=None,N_GERENCIA=None,N_AREA=None,HOSTNAME=None,TIPO_E=None,FECHA=None,INICIO=None,FIN=None,TIEMPO_EJECUCION=None,STATUS=None, PROCESS_CODE=None)
            df['NOMBRE_PROYECTO']=nombre_proyecto
            df['REG_A_PROCESAR']=cnt_registros
            df['REG_PROCESADOS']=cnt_registros_total
            df['N_GERENCIA']=lob_name
            df['N_AREA']=lobs_area
            df['HOSTNAME']=hostname
            df['TIPO_E']=tipo
            df['FECHA']=fecha
            df['INICIO']=inicio
            df['FIN']=fin
            df['TIEMPO_EJECUCION']=tiempo_ejecucion
            df['STATUS']=status
            df['PROCESS_CODE'] = process_code

        except Exception as e:
            print('El registro a df, a tenido un error: ',e)

        return df

    def find_log(self,path_log,proces_code):
        archivos=os.listdir(path_log)
        archivos_filtrados= [archivo for archivo in archivos if archivo.endswith(".log")and archivo.startswith(proces_code)]
        archivos_filtrados.sort(reverse=True)
        ultimo_archivo=archivos_filtrados[0] if archivos_filtrados else None
        if ultimo_archivo:
            print('El ultimo archivo es: ',ultimo_archivo)
        else:
            print("No se encontraron archivos .log con el formato especificado")
        return ultimo_archivo

    def extraer_fecha(self,linea):
        patron =r'\d{4}[-]\d{2}[-]\d{2}'
        coincidencia= re.findall(patron,linea)
        if coincidencia:
            fecha=coincidencia[0]
            return fecha
        
    def extraer_hora(self,linea):
        patron =r'\d{2}[:]\d{2}[:]\d{2}'
        coincidencia= re.findall(patron,linea)
        if coincidencia:
            hora_ini=coincidencia[0]
            return hora_ini
        
    def extraer_States_in(self,linea):
        patron =r'\d+'
        coincidencia= re.findall(patron,linea)
        if coincidencia:
            states_in=coincidencia[0]
            return states_in   
        
    def extraer_States_total(self,linea):
        patron =r'/(\d+)'
        coincidencia= re.findall(patron,linea)
        if coincidencia:
            states_total=coincidencia[0]
            return states_total
        
    def tiempo_a_seg(self,linea):
        horas,minutos,segundos=linea.split(':')
        segundos,milisegundos=segundos.split('.')
        total_segundos = int(horas)*3600+int(minutos)*60+int(segundos)
        return total_segundos 

    def read_to_log(self,path_log:str,log_file_path:str):
        log_info={
            'Process name':'',
            'REG_A_PROCESAR':'',
            'REG_PROCESADOS':'',
            'N_Gerencia':'',
            'N_Area':'',
            'Hostname':'',
            'Environment':'',
            'Fecha':'',
            'H_ini':'',
            'H_fin':'',
            'Elapsed time':'',
            'Status':'',
        }
        lista2=[]
        b=path_log+'\\'+log_file_path
        a=Path(b)
        log_file_path=a.resolve()
        with open(log_file_path,'r',encoding='latin1') as file:
            try: 
                for line in file:
                    if 'Process name' in line:
                        proces_name=line.split('Process name:')[1].strip()
                        log_info['Process name']=proces_name 
                    if 'States Completed:' in line:
                        value=line.split('States Completed:')[1].strip()
                        states_in=self.extraer_States_in(value)
                        log_info['REG_PROCESADOS']=int(states_in)
                    if 'States Completed' in line:
                        value=line.split('States Completed:')[1].strip()
                        states_total=self.extraer_States_total(value)
                        log_info['REG_A_PROCESAR']=int(states_total)
                    if 'N_Area' in line:
                        value=line.split('N_Area:')[1].strip()
                        log_info['N_Area']=value
                    if 'N_Gerencia' in line:
                        value=line.split('N_Gerencia:')[1].strip()
                        log_info['N_Gerencia']=value              
                    if 'Hostname' in line:
                        value=line.split('Hostname:')[1].strip()
                        log_info['Hostname']=value
                    if 'Environment' in line:
                        value=line.split('Environment:')[1].strip()
                        log_info['Environment']=value
                    if '--------- Logging started ---------'in line:
                        fecha=self.extraer_fecha(line)
                        log_info['Fecha']=fecha
                    if '--------- Logging started ---------'in line:
                        hora=self.extraer_hora(line)
                        log_info['H_ini']=hora    
                    if 'PROCESS_CODE' in line:
                        value=line.split('PROCESS_CODE:')[1].strip()
                        log_info['PROCESS_CODE']=value
                    if 'Elapsed time (robot.py)' in line:
                        value=line.split('Elapsed time (robot.py):')[1].strip()
                        value=self.tiempo_a_seg(value)
                        log_info['Elapsed time']=value
                        hora=self.extraer_hora(line)
                        log_info['H_fin']=hora
                    if 'Status' in line:
                        value=line.split('Status:')[1].strip()
                        log_info['Status']=value
            except Exception as e:
                print(e)

        lista2=list(log_info.values())

        return lista2

    def uplog(self):
        try:
            config = read_config()
            PROCESS_CODE = config["METADATA"]["PROCESS_CODE"]
            a=self.find_log(self.path_log,self.process_code)
            NOMBRE_PROYECTO,CANT_REG,R_PROCESAR_TOTAL,LOBS,LOBS_AREA,HOSTNAME,TIPO,FECHA,H_INICIO,H_FIN,T_TOTAL,STATUS=self.read_to_log(self.path_log,a)
            df=self.RegistrarEjecutivo(NOMBRE_PROYECTO,CANT_REG,R_PROCESAR_TOTAL,LOBS,LOBS_AREA,HOSTNAME,TIPO,FECHA,H_INICIO,H_FIN,T_TOTAL,STATUS,PROCESS_CODE)
            df.to_json(f'{self.config["FRAMEWORK"]["MONITORING_FOLDER"]}/{self.process_name}{dt.datetime.now().strftime("%Y%m%d_%H%M%S")}.json', orient='records')
        except Exception as e:
            logging.warning('No se pudo realizar el proceso de subida de log: ',e)


if __name__ == "__main__":
    config = read_config()

    # start: cryptography utils
    # user = getpass.getuser()
    # try:
    #     message = f"C:\\Users\\{user}\\MetLife\\RPA_Transformacion_Operaciones - gcp_utils\\sa-cloudsdkserver-czprod@v13499clinsdtdataczprod00001.iam.gserviceaccount.com.json"
    # except Exception as e:
    #     print('No existe la ruta')
    # print("Original string: ", message)
    # # generate a key for encryption and decryption
    # # You can use fernet to generate the key or use random key generator
    # key = "PA4uW2UopsdlBqQ7aLkEfCc3fICCJ3z_DCZq1fak_-s="
    # # key = generate_key()
    # print(f"Key: {key}")
    # encrypted_msg = encrypt_msg(message, key)
    # print("Encrypted string: ", encrypted_msg)
    # decrypted_msg = decrypt_msg(encrypted_msg, key)
    # print("Decrypted string: ", decrypted_msg)
    # end: cryptography utils

    # dict_creds       = get_credential_from_input_file(credential_name=CREDENTIAL_NAME, credentials_file=CREDENTIALS_FILE)
    # print(f"Creds: {dict_creds}")

    monitor = Monitoring(config=config)
    monitor.uplog()