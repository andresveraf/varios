r"""
Pandas Utilities Framework
A comprehensive collection of utility functions for data manipulation using pandas.
"""

import pandas as pd
import numpy as np
from typing import Any, List, Dict, Optional, Union, Tuple, Callable
import logging
from pathlib import Path
import re
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PandasUtils:
    """
    A utility class for common pandas operations and data manipulation.
    """
    
    def __init__(self):
        """Initialize the PandasUtils class."""
        self.df = None
        self.backup_df = None
        
    def load_data(self, 
                  source: Union[str, Path, pd.DataFrame],
                  file_type: str = 'auto',
                  **kwargs) -> pd.DataFrame:
        """
        Load data from various sources.
        
        Args:
            source: File path, URL, or DataFrame
            file_type: Type of file ('auto', 'csv', 'excel', 'json', 'parquet', 'sql')
            **kwargs: Additional arguments for pandas read functions
            
        Returns:
            Loaded DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pu.load_data('data.csv')
            >>> df = pu.load_data('data.xlsx', sheet_name='Sheet1')
            >>> df = pu.load_data('data.json', orient='records')
        """
        try:
            if isinstance(source, pd.DataFrame):
                self.df = source.copy()
                return self.df
            
            source_path = Path(source)
            
            if file_type == 'auto':
                file_type = source_path.suffix.lower()[1:]
            
            if file_type == 'csv':
                self.df = pd.read_csv(source, **kwargs)
            elif file_type in ['xlsx', 'xls', 'excel']:
                self.df = pd.read_excel(source, **kwargs)
            elif file_type == 'json':
                self.df = pd.read_json(source, **kwargs)
            elif file_type == 'parquet':
                self.df = pd.read_parquet(source, **kwargs)
            elif file_type == 'feather':
                self.df = pd.read_feather(source, **kwargs)
            elif file_type == 'hdf':
                self.df = pd.read_hdf(source, **kwargs)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            logger.info(f"Loaded data from {source}: {self.df.shape}")
            return self.df
            
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            raise
    
    def save_data(self,
                  df: Optional[pd.DataFrame] = None,
                  file_path: Union[str, Path] = None,
                  file_type: str = 'auto',
                  **kwargs) -> None:
        """
        Save DataFrame to various formats.
        
        Args:
            df: DataFrame to save (uses self.df if None)
            file_path: Output file path
            file_type: Output format ('auto', 'csv', 'excel', 'json', 'parquet')
            **kwargs: Additional arguments for pandas to_* functions
            
        Example:
            >>> pu = PandasUtils()
            >>> pu.load_data('input.csv')
            >>> pu.save_data(file_path='output.xlsx', index=False)
            >>> pu.save_data(file_path='output.json', orient='records')
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame to save")
        
        try:
            file_path = Path(file_path)
            
            if file_type == 'auto':
                file_type = file_path.suffix.lower()[1:]
            
            if file_type == 'csv':
                df.to_csv(file_path, **kwargs)
            elif file_type in ['xlsx', 'xls', 'excel']:
                df.to_excel(file_path, **kwargs)
            elif file_type == 'json':
                df.to_json(file_path, **kwargs)
            elif file_type == 'parquet':
                df.to_parquet(file_path, **kwargs)
            elif file_type == 'feather':
                df.to_feather(file_path, **kwargs)
            elif file_type == 'hdf':
                df.to_hdf(file_path, **kwargs)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
            
            logger.info(f"Saved data to {file_path}: {df.shape}")
            
        except Exception as e:
            logger.error(f"Error saving data: {e}")
            raise
    
    # ==================== DATA EXPLORATION ====================
    
    def quick_info(self, df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """
        Get quick information about the DataFrame.
        
        Args:
            df: DataFrame to analyze (uses self.df if None)
            
        Returns:
            Dictionary with basic info
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3], 'B': ['a', 'b', 'c']})
            >>> info = pu.quick_info(df)
            >>> print(info['shape'])  # (3, 2)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        info = {
            'shape': df.shape,
            'columns': list(df.columns),
            'dtypes': df.dtypes.to_dict(),
            'memory_usage': df.memory_usage(deep=True).sum(),
            'null_counts': df.isnull().sum().to_dict(),
            'null_percentage': (df.isnull().sum() / len(df) * 100).to_dict()
        }
        
        return info
    
    def data_quality_report(self, df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """
        Generate a comprehensive data quality report.
        
        Args:
            df: DataFrame to analyze (uses self.df if None)
            
        Returns:
            DataFrame with quality metrics
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, None, 4], 'B': ['a', 'b', 'c', 'a']})
            >>> report = pu.data_quality_report(df)
            >>> print(report)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        report_data = []
        
        for col in df.columns:
            col_data = {
                'column': col,
                'dtype': str(df[col].dtype),
                'non_null_count': df[col].count(),
                'null_count': df[col].isnull().sum(),
                'null_percentage': (df[col].isnull().sum() / len(df)) * 100,
                'unique_count': df[col].nunique(),
                'unique_percentage': (df[col].nunique() / len(df)) * 100
            }
            
            if pd.api.types.is_numeric_dtype(df[col]):
                col_data.update({
                    'mean': df[col].mean(),
                    'std': df[col].std(),
                    'min': df[col].min(),
                    'max': df[col].max(),
                    'zeros_count': (df[col] == 0).sum(),
                    'negative_count': (df[col] < 0).sum() if df[col].dtype in ['int64', 'float64'] else 0
                })
            
            report_data.append(col_data)
        
        return pd.DataFrame(report_data)
    
    def find_duplicates(self, 
                       df: Optional[pd.DataFrame] = None,
                       subset: Optional[List[str]] = None,
                       keep: str = 'first') -> pd.DataFrame:
        """
        Find duplicate rows in DataFrame.
        
        Args:
            df: DataFrame to check (uses self.df if None)
            subset: Columns to check for duplicates (all columns if None)
            keep: Which duplicates to keep ('first', 'last', False)
            
        Returns:
            DataFrame with duplicate rows
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 2, 3], 'B': ['a', 'b', 'b', 'c']})
            >>> duplicates = pu.find_duplicates(df)
            >>> print(duplicates)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        duplicates = df[df.duplicated(subset=subset, keep=keep)]
        logger.info(f"Found {len(duplicates)} duplicate rows")
        return duplicates
    
    def detect_outliers(self,
                       df: Optional[pd.DataFrame] = None,
                       columns: Optional[List[str]] = None,
                       method: str = 'iqr',
                       threshold: float = 1.5) -> Dict[str, pd.Series]:
        """
        Detect outliers in numeric columns.
        
        Args:
            df: DataFrame to analyze (uses self.df if None)
            columns: Columns to check (all numeric if None)
            method: Method to use ('iqr', 'zscore', 'modified_zscore')
            threshold: Threshold for outlier detection
            
        Returns:
            Dictionary with outlier indices for each column
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3, 100], 'B': [1, 2, 3, 4]})
            >>> outliers = pu.detect_outliers(df, method='iqr')
            >>> print(outliers)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        if columns is None:
            columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        outliers = {}
        
        for col in columns:
            if col not in df.columns:
                continue
                
            if method == 'iqr':
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - threshold * IQR
                upper_bound = Q3 + threshold * IQR
                outliers[col] = df[(df[col] < lower_bound) | (df[col] > upper_bound)].index
                
            elif method == 'zscore':
                z_scores = np.abs((df[col] - df[col].mean()) / df[col].std())
                outliers[col] = df[z_scores > threshold].index
                
            elif method == 'modified_zscore':
                median = df[col].median()
                mad = np.median(np.abs(df[col] - median))
                modified_z_scores = 0.6745 * (df[col] - median) / mad
                outliers[col] = df[np.abs(modified_z_scores) > threshold].index
        
        return outliers
    
    # ==================== DATA CLEANING ====================
    
    def clean_column_names(self, df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """
        Clean column names by removing special characters and spaces.
        
        Args:
            df: DataFrame to clean (uses self.df if None)
            
        Returns:
            DataFrame with cleaned column names
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'Column Name!': [1, 2], 'Another@Column': [3, 4]})
            >>> cleaned = pu.clean_column_names(df)
            >>> print(cleaned.columns.tolist())  # ['column_name', 'another_column']
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        # Clean column names
        cleaned_columns = []
        for col in df.columns:
            # Convert to lowercase and replace special characters with underscore
            clean_col = re.sub(r'[^a-zA-Z0-9]', '_', str(col).lower())
            # Remove multiple underscores
            clean_col = re.sub(r'_+', '_', clean_col)
            # Remove leading/trailing underscores
            clean_col = clean_col.strip('_')
            cleaned_columns.append(clean_col)
        
        df_cleaned = df.copy()
        df_cleaned.columns = cleaned_columns
        
        logger.info(f"Cleaned {len(df.columns)} column names")
        return df_cleaned
    
    def remove_duplicates(self,
                         df: Optional[pd.DataFrame] = None,
                         subset: Optional[List[str]] = None,
                         keep: str = 'first') -> pd.DataFrame:
        """
        Remove duplicate rows from DataFrame.
        
        Args:
            df: DataFrame to clean (uses self.df if None)
            subset: Columns to check for duplicates (all columns if None)
            keep: Which duplicates to keep ('first', 'last', False)
            
        Returns:
            DataFrame without duplicates
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 2, 3], 'B': ['a', 'b', 'b', 'c']})
            >>> cleaned = pu.remove_duplicates(df)
            >>> print(len(cleaned))  # 3
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        original_count = len(df)
        df_cleaned = df.drop_duplicates(subset=subset, keep=keep)
        removed_count = original_count - len(df_cleaned)
        
        logger.info(f"Removed {removed_count} duplicate rows")
        return df_cleaned
    
    def handle_missing_values(self,
                             df: Optional[pd.DataFrame] = None,
                             strategy: str = 'drop',
                             fill_value: Any = None,
                             columns: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Handle missing values in DataFrame.
        
        Args:
            df: DataFrame to clean (uses self.df if None)
            strategy: Strategy to handle missing values ('drop', 'fill', 'forward', 'backward')
            fill_value: Value to fill missing values with
            columns: Columns to process (all columns if None)
            
        Returns:
            DataFrame with handled missing values
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, None, 3], 'B': [None, 2, 3]})
            >>> cleaned = pu.handle_missing_values(df, strategy='fill', fill_value=0)
            >>> print(cleaned.isnull().sum())
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_cleaned = df.copy()
        
        if columns is None:
            columns = df.columns
        
        for col in columns:
            if col not in df.columns:
                continue
                
            if strategy == 'drop':
                df_cleaned = df_cleaned.dropna(subset=[col])
            elif strategy == 'fill':
                if fill_value is None:
                    # Use mean for numeric, mode for categorical
                    if pd.api.types.is_numeric_dtype(df[col]):
                        fill_value = df[col].mean()
                    else:
                        fill_value = df[col].mode().iloc[0] if not df[col].mode().empty else 'Unknown'
                df_cleaned[col] = df_cleaned[col].fillna(fill_value)
            elif strategy == 'forward':
                df_cleaned[col] = df_cleaned[col].fillna(method='ffill')
            elif strategy == 'backward':
                df_cleaned[col] = df_cleaned[col].fillna(method='bfill')
        
        logger.info(f"Handled missing values using strategy: {strategy}")
        return df_cleaned
    
    def remove_outliers(self,
                       df: Optional[pd.DataFrame] = None,
                       columns: Optional[List[str]] = None,
                       method: str = 'iqr',
                       threshold: float = 1.5) -> pd.DataFrame:
        """
        Remove outliers from DataFrame.
        
        Args:
            df: DataFrame to clean (uses self.df if None)
            columns: Columns to check (all numeric if None)
            method: Method to use ('iqr', 'zscore', 'modified_zscore')
            threshold: Threshold for outlier detection
            
        Returns:
            DataFrame without outliers
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3, 100], 'B': [1, 2, 3, 4]})
            >>> cleaned = pu.remove_outliers(df, method='iqr')
            >>> print(len(cleaned))
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        outliers = self.detect_outliers(df, columns, method, threshold)
        
        # Get all outlier indices
        all_outlier_indices = set()
        for col_outliers in outliers.values():
            all_outlier_indices.update(col_outliers)
        
        df_cleaned = df.drop(list(all_outlier_indices))
        removed_count = len(df) - len(df_cleaned)
        
        logger.info(f"Removed {removed_count} outlier rows")
        return df_cleaned
    
    # ==================== DATA TRANSFORMATION ====================
    
    def normalize_data(self,
                      df: Optional[pd.DataFrame] = None,
                      columns: Optional[List[str]] = None,
                      method: str = 'minmax') -> pd.DataFrame:
        """
        Normalize numeric columns in DataFrame.
        
        Args:
            df: DataFrame to normalize (uses self.df if None)
            columns: Columns to normalize (all numeric if None)
            method: Normalization method ('minmax', 'zscore', 'robust')
            
        Returns:
            DataFrame with normalized columns
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3, 4], 'B': [10, 20, 30, 40]})
            >>> normalized = pu.normalize_data(df, method='minmax')
            >>> print(normalized)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_normalized = df.copy()
        
        if columns is None:
            columns = df.select_dtypes(include=[np.number]).columns.tolist()
        
        for col in columns:
            if col not in df.columns:
                continue
                
            if method == 'minmax':
                df_normalized[col] = (df[col] - df[col].min()) / (df[col].max() - df[col].min())
            elif method == 'zscore':
                df_normalized[col] = (df[col] - df[col].mean()) / df[col].std()
            elif method == 'robust':
                median = df[col].median()
                mad = np.median(np.abs(df[col] - median))
                df_normalized[col] = (df[col] - median) / mad
        
        logger.info(f"Normalized {len(columns)} columns using {method} method")
        return df_normalized
    
    def encode_categorical(self,
                          df: Optional[pd.DataFrame] = None,
                          columns: Optional[List[str]] = None,
                          method: str = 'onehot') -> pd.DataFrame:
        """
        Encode categorical columns.
        
        Args:
            df: DataFrame to encode (uses self.df if None)
            columns: Columns to encode (all categorical if None)
            method: Encoding method ('onehot', 'label', 'ordinal')
            
        Returns:
            DataFrame with encoded columns
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': ['cat', 'dog', 'bird'], 'B': [1, 2, 3]})
            >>> encoded = pu.encode_categorical(df, columns=['A'], method='onehot')
            >>> print(encoded.columns.tolist())
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_encoded = df.copy()
        
        if columns is None:
            columns = df.select_dtypes(include=['object', 'category']).columns.tolist()
        
        for col in columns:
            if col not in df.columns:
                continue
                
            if method == 'onehot':
                # One-hot encoding
                dummies = pd.get_dummies(df[col], prefix=col)
                df_encoded = pd.concat([df_encoded.drop(col, axis=1), dummies], axis=1)
            elif method == 'label':
                # Label encoding
                df_encoded[col] = pd.Categorical(df[col]).codes
            elif method == 'ordinal':
                # Ordinal encoding (assumes ordered categories)
                df_encoded[col] = pd.Categorical(df[col], ordered=True).codes
        
        logger.info(f"Encoded {len(columns)} categorical columns using {method} method")
        return df_encoded
    
    def create_bins(self,
                   df: Optional[pd.DataFrame] = None,
                   column: str = None,
                   bins: Union[int, List[float]] = 5,
                   labels: Optional[List[str]] = None) -> pd.DataFrame:
        """
        Create bins for a numeric column.
        
        Args:
            df: DataFrame to process (uses self.df if None)
            column: Column to bin
            bins: Number of bins or list of bin edges
            labels: Labels for the bins
            
        Returns:
            DataFrame with new binned column
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]})
            >>> binned = pu.create_bins(df, 'A', bins=3, labels=['Low', 'Medium', 'High'])
            >>> print(binned)
        """
        df = df if df is not None else self.df
        if df is None or column is None:
            raise ValueError("DataFrame and column must be provided")
        
        df_binned = df.copy()
        
        try:
            df_binned[f'{column}_binned'] = pd.cut(df[column], bins=bins, labels=labels)
            logger.info(f"Created bins for column {column}")
            return df_binned
        except Exception as e:
            logger.error(f"Error creating bins: {e}")
            raise
    
    # ==================== DATE/TIME OPERATIONS ====================
    
    def parse_dates(self,
                   df: Optional[pd.DataFrame] = None,
                   columns: Optional[List[str]] = None,
                   format: Optional[str] = None) -> pd.DataFrame:
        """
        Parse date columns to datetime.
        
        Args:
            df: DataFrame to process (uses self.df if None)
            columns: Columns to parse (auto-detect if None)
            format: Date format string
            
        Returns:
            DataFrame with parsed date columns
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'date': ['2023-01-01', '2023-01-02'], 'value': [1, 2]})
            >>> parsed = pu.parse_dates(df, columns=['date'])
            >>> print(parsed.dtypes)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_parsed = df.copy()
        
        if columns is None:
            # Auto-detect date columns
            columns = []
            for col in df.columns:
                if df[col].dtype == 'object':
                    # Try to parse a sample
                    try:
                        pd.to_datetime(df[col].dropna().iloc[0])
                        columns.append(col)
                    except:
                        continue
        
        for col in columns:
            if col not in df.columns:
                continue
                
            try:
                df_parsed[col] = pd.to_datetime(df[col], format=format)
                logger.info(f"Parsed column {col} as datetime")
            except Exception as e:
                logger.warning(f"Could not parse column {col}: {e}")
        
        return df_parsed
    
    def extract_date_features(self,
                             df: Optional[pd.DataFrame] = None,
                             date_column: str = None,
                             features: List[str] = None) -> pd.DataFrame:
        """
        Extract date features from a datetime column.
        
        Args:
            df: DataFrame to process (uses self.df if None)
            date_column: Column containing dates
            features: Features to extract ('year', 'month', 'day', 'weekday', 'quarter')
            
        Returns:
            DataFrame with extracted date features
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'date': pd.date_range('2023-01-01', periods=5), 'value': [1,2,3,4,5]})
            >>> features = pu.extract_date_features(df, 'date', ['year', 'month', 'weekday'])
            >>> print(features.columns.tolist())
        """
        df = df if df is not None else self.df
        if df is None or date_column is None:
            raise ValueError("DataFrame and date_column must be provided")
        
        if features is None:
            features = ['year', 'month', 'day', 'weekday', 'quarter']
        
        df_features = df.copy()
        
        # Ensure column is datetime
        if not pd.api.types.is_datetime64_any_dtype(df[date_column]):
            df_features[date_column] = pd.to_datetime(df[date_column])
        
        for feature in features:
            if feature == 'year':
                df_features[f'{date_column}_year'] = df_features[date_column].dt.year
            elif feature == 'month':
                df_features[f'{date_column}_month'] = df_features[date_column].dt.month
            elif feature == 'day':
                df_features[f'{date_column}_day'] = df_features[date_column].dt.day
            elif feature == 'weekday':
                df_features[f'{date_column}_weekday'] = df_features[date_column].dt.weekday
            elif feature == 'quarter':
                df_features[f'{date_column}_quarter'] = df_features[date_column].dt.quarter
            elif feature == 'hour':
                df_features[f'{date_column}_hour'] = df_features[date_column].dt.hour
            elif feature == 'minute':
                df_features[f'{date_column}_minute'] = df_features[date_column].dt.minute
        
        logger.info(f"Extracted {len(features)} date features from {date_column}")
        return df_features
    
    # ==================== AGGREGATION OPERATIONS ====================
    
    def smart_groupby(self,
                     df: Optional[pd.DataFrame] = None,
                     group_by: Union[str, List[str]] = None,
                     agg_dict: Optional[Dict[str, Union[str, List[str]]]] = None,
                     include_count: bool = True) -> pd.DataFrame:
        """
        Perform smart groupby operations with automatic aggregation.
        
        Args:
            df: DataFrame to group (uses self.df if None)
            group_by: Column(s) to group by
            agg_dict: Dictionary of column -> aggregation functions
            include_count: Whether to include count of groups
            
        Returns:
            Grouped DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': ['x', 'x', 'y'], 'B': [1, 2, 3], 'C': [4, 5, 6]})
            >>> grouped = pu.smart_groupby(df, 'A', {'B': 'sum', 'C': 'mean'})
            >>> print(grouped)
        """
        df = df if df is not None else self.df
        if df is None or group_by is None:
            raise ValueError("DataFrame and group_by must be provided")
        
        if agg_dict is None:
            # Auto-generate aggregation dict
            agg_dict = {}
            for col in df.columns:
                if col not in (group_by if isinstance(group_by, list) else [group_by]):
                    if pd.api.types.is_numeric_dtype(df[col]):
                        agg_dict[col] = ['sum', 'mean', 'count']
                    else:
                        agg_dict[col] = ['count', 'nunique']
        
        grouped = df.groupby(group_by).agg(agg_dict)
        
        # Flatten column names if necessary
        if isinstance(grouped.columns, pd.MultiIndex):
            grouped.columns = ['_'.join(col).strip('_') for col in grouped.columns]
        
        if include_count:
            grouped['group_count'] = df.groupby(group_by).size()
        
        grouped = grouped.reset_index()
        
        logger.info(f"Grouped by {group_by} with {len(agg_dict)} aggregations")
        return grouped
    
    def pivot_advanced(self,
                      df: Optional[pd.DataFrame] = None,
                      index: Union[str, List[str]] = None,
                      columns: Union[str, List[str]] = None,
                      values: Union[str, List[str]] = None,
                      aggfunc: str = 'sum',
                      fill_value: Any = 0) -> pd.DataFrame:
        """
        Advanced pivot table with multiple options.
        
        Args:
            df: DataFrame to pivot (uses self.df if None)
            index: Column(s) to use as index
            columns: Column(s) to use as columns
            values: Column(s) to aggregate
            aggfunc: Aggregation function
            fill_value: Value to fill missing entries
            
        Returns:
            Pivoted DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({
            ...     'A': ['foo', 'foo', 'bar', 'bar'],
            ...     'B': ['one', 'two', 'one', 'two'],
            ...     'C': [1, 2, 3, 4]
            ... })
            >>> pivoted = pu.pivot_advanced(df, index='A', columns='B', values='C')
            >>> print(pivoted)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        try:
            pivoted = df.pivot_table(
                index=index,
                columns=columns,
                values=values,
                aggfunc=aggfunc,
                fill_value=fill_value
            )
            
            logger.info(f"Created pivot table with shape {pivoted.shape}")
            return pivoted
            
        except Exception as e:
            logger.error(f"Error creating pivot table: {e}")
            raise
    
    # ==================== FILTERING AND SELECTION ====================
    
    def filter_data(self,
                   df: Optional[pd.DataFrame] = None,
                   conditions: Dict[str, Any] = None,
                   query_string: Optional[str] = None) -> pd.DataFrame:
        """
        Filter DataFrame based on conditions.
        
        Args:
            df: DataFrame to filter (uses self.df if None)
            conditions: Dictionary of column -> condition
            query_string: Query string for complex conditions
            
        Returns:
            Filtered DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3, 4], 'B': ['a', 'b', 'c', 'd']})
            >>> filtered = pu.filter_data(df, conditions={'A': [1, 2], 'B': ['a', 'b']})
            >>> print(filtered)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_filtered = df.copy()
        
        if conditions:
            for col, condition in conditions.items():
                if col not in df.columns:
                    continue
                    
                if isinstance(condition, list):
                    df_filtered = df_filtered[df_filtered[col].isin(condition)]
                elif isinstance(condition, dict):
                    # Handle range conditions
                    if 'min' in condition:
                        df_filtered = df_filtered[df_filtered[col] >= condition['min']]
                    if 'max' in condition:
                        df_filtered = df_filtered[df_filtered[col] <= condition['max']]
                else:
                    df_filtered = df_filtered[df_filtered[col] == condition]
        
        if query_string:
            df_filtered = df_filtered.query(query_string)
        
        logger.info(f"Filtered DataFrame from {len(df)} to {len(df_filtered)} rows")
        return df_filtered
    
    def sample_data(self,
                   df: Optional[pd.DataFrame] = None,
                   n: Optional[int] = None,
                   frac: Optional[float] = None,
                   stratify: Optional[str] = None,
                   random_state: Optional[int] = None) -> pd.DataFrame:
        """
        Sample data from DataFrame.
        
        Args:
            df: DataFrame to sample (uses self.df if None)
            n: Number of samples
            frac: Fraction of samples
            stratify: Column to stratify by
            random_state: Random seed
            
        Returns:
            Sampled DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': range(100), 'B': ['x']*50 + ['y']*50})
            >>> sampled = pu.sample_data(df, n=10, stratify='B', random_state=42)
            >>> print(len(sampled))
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        if stratify and stratify in df.columns:
            # Stratified sampling
            sampled_dfs = []
            for group in df[stratify].unique():
                group_df = df[df[stratify] == group]
                if n:
                    group_n = int(n * len(group_df) / len(df))
                    sampled_dfs.append(group_df.sample(n=group_n, random_state=random_state))
                elif frac:
                    sampled_dfs.append(group_df.sample(frac=frac, random_state=random_state))
            
            df_sampled = pd.concat(sampled_dfs, ignore_index=True)
        else:
            # Regular sampling
            if n:
                df_sampled = df.sample(n=n, random_state=random_state)
            elif frac:
                df_sampled = df.sample(frac=frac, random_state=random_state)
            else:
                df_sampled = df.sample(frac=0.1, random_state=random_state)
        
        logger.info(f"Sampled {len(df_sampled)} rows from {len(df)} total")
        return df_sampled
    
    # ==================== UTILITY FUNCTIONS ====================
    
    def backup_dataframe(self, df: Optional[pd.DataFrame] = None) -> None:
        """
        Create a backup of the DataFrame.
        
        Args:
            df: DataFrame to backup (uses self.df if None)
            
        Example:
            >>> pu = PandasUtils()
            >>> pu.load_data('data.csv')
            >>> pu.backup_dataframe()
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        self.backup_df = df.copy()
        logger.info("Created backup of DataFrame")
    
    def restore_dataframe(self) -> pd.DataFrame:
        """
        Restore DataFrame from backup.
        
        Returns:
            Restored DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> pu.load_data('data.csv')
            >>> pu.backup_dataframe()
            >>> # ... perform operations ...
            >>> restored = pu.restore_dataframe()
        """
        if self.backup_df is None:
            raise ValueError("No backup available")
        
        self.df = self.backup_df.copy()
        logger.info("Restored DataFrame from backup")
        return self.df
    
    def memory_usage_optimization(self, df: Optional[pd.DataFrame] = None) -> pd.DataFrame:
        """
        Optimize memory usage of DataFrame.
        
        Args:
            df: DataFrame to optimize (uses self.df if None)
            
        Returns:
            Optimized DataFrame
            
        Example:
            >>> pu = PandasUtils()
            >>> df = pd.DataFrame({'A': [1, 2, 3], 'B': ['a', 'b', 'c']})
            >>> optimized = pu.memory_usage_optimization(df)
            >>> print(optimized.dtypes)
        """
        df = df if df is not None else self.df
        if df is None:
            raise ValueError("No DataFrame provided")
        
        df_optimized = df.copy()
        
        for col in df_optimized.columns:
            col_type = df_optimized[col].dtype
            
            if col_type == 'object':
                # Try to convert to categorical if cardinality is low
                if df_optimized[col].nunique() / len(df_optimized) < 0.5:
                    df_optimized[col] = df_optimized[col].astype('category')
            
            elif col_type == 'int64':
                # Downcast integers
                df_optimized[col] = pd.to_numeric(df_optimized[col], downcast='integer')
            
            elif col_type == 'float64':
                # Downcast floats
                df_optimized[col] = pd.to_numeric(df_optimized[col], downcast='float')
        
        original_memory = df.memory_usage(deep=True).sum()
        optimized_memory = df_optimized.memory_usage(deep=True).sum()
        
        logger.info(f"Memory usage reduced from {original_memory} to {optimized_memory}")
        return df_optimized

# ==================== STANDALONE UTILITY FUNCTIONS ====================

def compare_dataframes(df1: pd.DataFrame, df2: pd.DataFrame) -> Dict[str, Any]:
    """
    Compare two DataFrames and return differences.
    
    Args:
        df1: First DataFrame
        df2: Second DataFrame
        
    Returns:
        Dictionary with comparison results
        
    Example:
        >>> df1 = pd.DataFrame({'A': [1, 2, 3], 'B': [4, 5, 6]})
        >>> df2 = pd.DataFrame({'A': [1, 2, 4], 'B': [4, 5, 6]})
        >>> comparison = compare_dataframes(df1, df2)
        >>> print(comparison)
    """
    comparison = {
        'shapes_equal': df1.shape == df2.shape,
        'columns_equal': list(df1.columns) == list(df2.columns),
        'dtypes_equal': df1.dtypes.equals(df2.dtypes),
        'values_equal': df1.equals(df2),
        'shape_df1': df1.shape,
        'shape_df2': df2.shape,
        'columns_df1': list(df1.columns),
        'columns_df2': list(df2.columns)
    }
    
    if comparison['shapes_equal'] and comparison['columns_equal']:
        # Find different rows
        try:
            mask = ~(df1 == df2).all(axis=1)
            comparison['different_rows'] = df1[mask].index.tolist()
            comparison['num_different_rows'] = mask.sum()
        except:
            comparison['different_rows'] = []
            comparison['num_different_rows'] = 0
    
    return comparison

def merge_multiple_dataframes(dfs: List[pd.DataFrame], 
                            how: str = 'inner',
                            on: Optional[str] = None,
                            suffixes: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Merge multiple DataFrames.
    
    Args:
        dfs: List of DataFrames to merge
        how: How to merge ('inner', 'outer', 'left', 'right')
        on: Column to merge on
        suffixes: Suffixes for overlapping columns
        
    Returns:
        Merged DataFrame
        
    Example:
        >>> df1 = pd.DataFrame({'A': [1, 2], 'B': [3, 4]})
        >>> df2 = pd.DataFrame({'A': [1, 2], 'C': [5, 6]})
        >>> df3 = pd.DataFrame({'A': [1, 2], 'D': [7, 8]})
        >>> merged = merge_multiple_dataframes([df1, df2, df3], on='A')
        >>> print(merged)
    """
    if not dfs:
        raise ValueError("No DataFrames provided")
    
    if len(dfs) == 1:
        return dfs[0]
    
    result = dfs[0]
    
    for i, df in enumerate(dfs[1:], 1):
        suffix = suffixes[i] if suffixes and i < len(suffixes) else f'_{i}'
        result = pd.merge(result, df, how=how, on=on, suffixes=('', suffix))
    
    return result

def create_summary_report(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create a comprehensive summary report of DataFrame.
    
    Args:
        df: DataFrame to summarize
        
    Returns:
        Summary report DataFrame
        
    Example:
        >>> df = pd.DataFrame({'A': [1, 2, 3, 4], 'B': ['a', 'b', 'c', 'd']})
        >>> summary = create_summary_report(df)
        >>> print(summary)
    """
    pu = PandasUtils()
    
    # Basic info
    info = pu.quick_info(df)
    quality = pu.data_quality_report(df)
    
    # Create summary
    summary = pd.DataFrame({
        'Metric': [
            'Total Rows',
            'Total Columns',
            'Total Memory Usage (bytes)',
            'Numeric Columns',
            'Object Columns',
            'Total Missing Values',
            'Duplicate Rows'
        ],
        'Value': [
            df.shape[0],
            df.shape[1],
            info['memory_usage'],
            len(df.select_dtypes(include=[np.number]).columns),
            len(df.select_dtypes(include=['object']).columns),
            df.isnull().sum().sum(),
            df.duplicated().sum()
        ]
    })
    
    return summary

# ==================== EXAMPLE USAGE ====================

if __name__ == "__main__":
    # Example usage of PandasUtils
    
    # Create sample data
    np.random.seed(42)
    sample_data = pd.DataFrame({
        'id': range(1, 101),
        'name': [f'Person_{i}' for i in range(1, 101)],
        'age': np.random.randint(18, 80, 100),
        'salary': np.random.normal(50000, 15000, 100),
        'department': np.random.choice(['IT', 'HR', 'Finance', 'Marketing'], 100),
        'hire_date': pd.date_range('2020-01-01', periods=100, freq='D'),
        'performance_score': np.random.choice([1, 2, 3, 4, 5], 100)
    })
    
    # Add some missing values and duplicates
    sample_data.loc[10:15, 'salary'] = np.nan
    sample_data.loc[20:22, 'department'] = np.nan
    sample_data = pd.concat([sample_data, sample_data.iloc[0:5]], ignore_index=True)
    
    # Initialize PandasUtils
    pu = PandasUtils()
    pu.df = sample_data
    
    print("=== PANDAS UTILS DEMO ===")
    print(f"Original data shape: {sample_data.shape}")
    
    # Data quality report
    print("\n=== DATA QUALITY REPORT ===")
    quality_report = pu.data_quality_report()
    print(quality_report.head())
    
    # Handle missing values
    print("\n=== HANDLING MISSING VALUES ===")
    cleaned_data = pu.handle_missing_values(strategy='fill')
    print(f"Missing values after cleaning: {cleaned_data.isnull().sum().sum()}")
    
    # Remove duplicates
    print("\n=== REMOVING DUPLICATES ===")
    no_duplicates = pu.remove_duplicates(cleaned_data)
    print(f"Shape after removing duplicates: {no_duplicates.shape}")
    
    # Detect and remove outliers
    print("\n=== OUTLIER DETECTION ===")
    outliers = pu.detect_outliers(no_duplicates, columns=['salary'], method='iqr')
    print(f"Outliers found in salary: {len(outliers['salary'])}")
    
    no_outliers = pu.remove_outliers(no_duplicates, columns=['salary'])
    print(f"Shape after removing outliers: {no_outliers.shape}")
    
    # Normalize data
    print("\n=== DATA NORMALIZATION ===")
    normalized = pu.normalize_data(no_outliers, columns=['age', 'salary'], method='minmax')
    print(f"Normalized age range: {normalized['age'].min():.2f} to {normalized['age'].max():.2f}")
    
    # Encode categorical data
    print("\n=== CATEGORICAL ENCODING ===")
    encoded = pu.encode_categorical(no_outliers, columns=['department'], method='onehot')
    print(f"Columns after encoding: {len(encoded.columns)}")
    
    # Extract date features
    print("\n=== DATE FEATURE EXTRACTION ===")
    with_date_features = pu.extract_date_features(no_outliers, 'hire_date', 
                                                  ['year', 'month', 'weekday'])
    print(f"New date columns: {[col for col in with_date_features.columns if 'hire_date' in col]}")
    
    # Smart groupby
    print("\n=== SMART GROUPBY ===")
    grouped = pu.smart_groupby(no_outliers, 'department', 
                              {'age': 'mean', 'salary': ['mean', 'count']})
    print(grouped)
    
    # Pivot table
    print("\n=== PIVOT TABLE ===")
    # Create performance categories for pivot
    no_outliers['performance_category'] = pd.cut(no_outliers['performance_score'], 
                                                bins=[0, 2, 4, 5], 
                                                labels=['Low', 'Medium', 'High'])
    
    pivot = pu.pivot_advanced(no_outliers, 
                             index='department', 
                             columns='performance_category', 
                             values='salary',
                             aggfunc='mean')
    print(pivot)
    
    # Filter data
    print("\n=== DATA FILTERING ===")
    filtered = pu.filter_data(no_outliers, 
                             conditions={'age': {'min': 30, 'max': 50}, 
                                       'department': ['IT', 'Finance']})
    print(f"Filtered data shape: {filtered.shape}")
    
    # Sample data
    print("\n=== DATA SAMPLING ===")
    sampled = pu.sample_data(no_outliers, n=20, stratify='department', random_state=42)
    print(f"Sampled data shape: {sampled.shape}")
    print(f"Department distribution: {sampled['department'].value_counts()}")
    
    # Memory optimization
    print("\n=== MEMORY OPTIMIZATION ===")
    original_memory = no_outliers.memory_usage(deep=True).sum()
    optimized = pu.memory_usage_optimization(no_outliers)
    optimized_memory = optimized.memory_usage(deep=True).sum()
    print(f"Memory reduction: {original_memory} -> {optimized_memory} bytes")
    
    # Save processed data
    print("\n=== SAVING DATA ===")
    pu.save_data(optimized, 'processed_data.csv', index=False)
    pu.save_data(optimized, 'processed_data.xlsx', index=False)
    print("Data saved to CSV and Excel files")
    
    print("\n=== DEMO COMPLETED ===")
    print("All pandas utilities demonstrated successfully!")