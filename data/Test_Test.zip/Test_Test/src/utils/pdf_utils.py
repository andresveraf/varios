r"""
PDF Utilities Framework
A comprehensive collection of utility functions for PDF processing using pdfplumber.
"""

import pdfplumber
import pandas as pd
import numpy as np
from typing import Any, List, Dict, Optional, Union, Tuple, Callable
import logging
from pathlib import Path
import re
from datetime import datetime
import json
import csv
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class PDFUtils:
    """
    A utility class for PDF processing operations using pdfplumber.
    """
    
    def __init__(self):
        """Initialize the PDFUtils class."""
        self.pdf = None
        self.current_page = None
        self.extracted_data = {}
        
    def __enter__(self):
        """Context manager entry"""
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - cleanup"""
        self.close_pdf()
    
    # ==================== PDF LOADING AND BASIC OPERATIONS ====================
    
    def load_pdf(self, file_path: Union[str, Path], password: Optional[str] = None) -> pdfplumber.PDF:
        """
        Load a PDF file for processing.
        
        Args:
            file_path: Path to the PDF file
            password: Password for encrypted PDFs
            
        Returns:
            pdfplumber PDF object
            
        Example:
            >>> pu = PDFUtils()
            >>> pdf = pu.load_pdf('document.pdf')
            >>> print(f"Pages: {len(pdf.pages)}")
        """
        try:
            self.pdf = pdfplumber.open(file_path, password=password)
            logger.info(f"Loaded PDF: {file_path} with {len(self.pdf.pages)} pages")
            return self.pdf
        except Exception as e:
            logger.error(f"Error loading PDF {file_path}: {e}")
            raise
    
    def close_pdf(self) -> None:
        """
        Close the current PDF file.
        
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> pu.close_pdf()
        """
        if self.pdf:
            self.pdf.close()
            self.pdf = None
            logger.info("Closed PDF file")
    
    def get_pdf_info(self, pdf: Optional[pdfplumber.PDF] = None) -> Dict[str, Any]:
        """
        Get basic information about the PDF.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            Dictionary with PDF information
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> info = pu.get_pdf_info()
            >>> print(info['num_pages'])
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        info = {
            'num_pages': len(pdf.pages),
            'metadata': pdf.metadata,
            'page_sizes': []
        }
        
        # Get page sizes
        for page in pdf.pages:
            info['page_sizes'].append({
                'page_number': page.page_number,
                'width': page.width,
                'height': page.height
            })
        
        return info
    
    # ==================== TEXT EXTRACTION ====================
    
    def extract_text_from_page(self, 
                              page_number: int,
                              pdf: Optional[pdfplumber.PDF] = None,
                              x0: Optional[float] = None,
                              y0: Optional[float] = None,
                              x1: Optional[float] = None,
                              y1: Optional[float] = None) -> str:
        """
        Extract text from a specific page or region.
        
        Args:
            page_number: Page number (1-indexed)
            pdf: PDF object (uses self.pdf if None)
            x0, y0, x1, y1: Coordinates for text extraction region
            
        Returns:
            Extracted text
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> text = pu.extract_text_from_page(1)
            >>> print(text[:100])
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        if page_number < 1 or page_number > len(pdf.pages):
            raise ValueError(f"Page {page_number} out of range")
        
        page = pdf.pages[page_number - 1]
        
        if all(coord is not None for coord in [x0, y0, x1, y1]):
            # Extract from specific region
            cropped = page.crop((x0, y0, x1, y1))
            text = cropped.extract_text()
        else:
            # Extract from entire page
            text = page.extract_text()
        
        return text or ""
    
    def extract_text_from_all_pages(self, 
                                   pdf: Optional[pdfplumber.PDF] = None,
                                   combine_pages: bool = True) -> Union[str, List[str]]:
        """
        Extract text from all pages.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            combine_pages: Whether to combine all pages into one string
            
        Returns:
            Combined text string or list of page texts
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> all_text = pu.extract_text_from_all_pages()
            >>> print(f"Total characters: {len(all_text)}")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        page_texts = []
        for i, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            page_texts.append(text)
            logger.debug(f"Extracted {len(text)} characters from page {i}")
        
        if combine_pages:
            return "\n\n".join(page_texts)
        else:
            return page_texts
    
    def search_text_in_pdf(self, 
                          search_term: str,
                          pdf: Optional[pdfplumber.PDF] = None,
                          case_sensitive: bool = False,
                          whole_word: bool = False) -> List[Dict[str, Any]]:
        """
        Search for text across all pages.
        
        Args:
            search_term: Text to search for
            pdf: PDF object (uses self.pdf if None)
            case_sensitive: Whether search is case sensitive
            whole_word: Whether to match whole words only
            
        Returns:
            List of matches with page numbers and positions
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> matches = pu.search_text_in_pdf('important')
            >>> print(f"Found {len(matches)} matches")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        matches = []
        flags = 0 if case_sensitive else re.IGNORECASE
        
        if whole_word:
            pattern = rf'\b{re.escape(search_term)}\b'
        else:
            pattern = re.escape(search_term)
        
        for i, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            
            for match in re.finditer(pattern, text, flags):
                matches.append({
                    'page_number': i,
                    'start_pos': match.start(),
                    'end_pos': match.end(),
                    'matched_text': match.group(),
                    'context': text[max(0, match.start()-50):match.end()+50].strip()
                })
        
        logger.info(f"Found {len(matches)} matches for '{search_term}'")
        return matches
    
    def extract_text_with_coordinates(self, 
                                     page_number: int,
                                     pdf: Optional[pdfplumber.PDF] = None) -> List[Dict[str, Any]]:
        """
        Extract text with coordinate information.
        
        Args:
            page_number: Page number (1-indexed)
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            List of text elements with coordinates
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> chars = pu.extract_text_with_coordinates(1)
            >>> print(f"Found {len(chars)} characters with coordinates")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        if page_number < 1 or page_number > len(pdf.pages):
            raise ValueError(f"Page {page_number} out of range")
        
        page = pdf.pages[page_number - 1]
        chars = page.chars
        
        text_elements = []
        for char in chars:
            text_elements.append({
                'text': char['text'],
                'x0': char['x0'],
                'y0': char['y0'],
                'x1': char['x1'],
                'y1': char['y1'],
                'fontname': char.get('fontname', ''),
                'size': char.get('size', 0)
            })
        
        return text_elements
    
    # ==================== TABLE EXTRACTION ====================
    
    def extract_tables_from_page(self, 
                                page_number: int,
                                pdf: Optional[pdfplumber.PDF] = None,
                                table_settings: Optional[Dict[str, Any]] = None) -> List[List[List[str]]]:
        """
        Extract tables from a specific page.
        
        Args:
            page_number: Page number (1-indexed)
            pdf: PDF object (uses self.pdf if None)
            table_settings: Custom table extraction settings
            
        Returns:
            List of tables (each table is a list of rows)
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> tables = pu.extract_tables_from_page(1)
            >>> print(f"Found {len(tables)} tables")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        if page_number < 1 or page_number > len(pdf.pages):
            raise ValueError(f"Page {page_number} out of range")
        
        page = pdf.pages[page_number - 1]
        
        if table_settings:
            tables = page.extract_tables(table_settings)
        else:
            tables = page.extract_tables()
        
        logger.info(f"Extracted {len(tables)} tables from page {page_number}")
        return tables
    
    def extract_tables_from_all_pages(self, 
                                     pdf: Optional[pdfplumber.PDF] = None,
                                     table_settings: Optional[Dict[str, Any]] = None) -> Dict[int, List[List[List[str]]]]:
        """
        Extract tables from all pages.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            table_settings: Custom table extraction settings
            
        Returns:
            Dictionary with page numbers as keys and tables as values
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> all_tables = pu.extract_tables_from_all_pages()
            >>> print(f"Found tables on {len(all_tables)} pages")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        all_tables = {}
        
        for i, page in enumerate(pdf.pages, 1):
            if table_settings:
                tables = page.extract_tables(table_settings)
            else:
                tables = page.extract_tables()
            
            if tables:
                all_tables[i] = tables
                logger.debug(f"Found {len(tables)} tables on page {i}")
        
        total_tables = sum(len(tables) for tables in all_tables.values())
        logger.info(f"Extracted {total_tables} tables from {len(all_tables)} pages")
        return all_tables
    
    def tables_to_dataframes(self, 
                            tables: List[List[List[str]]],
                            has_header: bool = True) -> List[pd.DataFrame]:
        """
        Convert extracted tables to pandas DataFrames.
        
        Args:
            tables: List of tables from extract_tables methods
            has_header: Whether the first row contains headers
            
        Returns:
            List of pandas DataFrames
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> tables = pu.extract_tables_from_page(1)
            >>> dfs = pu.tables_to_dataframes(tables)
            >>> print(dfs[0].head())
        """
        dataframes = []
        
        for i, table in enumerate(tables):
            if not table:
                continue
            
            try:
                if has_header and len(table) > 1:
                    df = pd.DataFrame(table[1:], columns=table[0])
                else:
                    df = pd.DataFrame(table)
                
                # Clean the DataFrame
                df = df.dropna(how='all')  # Remove empty rows
                df = df.loc[:, ~df.columns.duplicated()]  # Remove duplicate columns
                
                dataframes.append(df)
                logger.debug(f"Converted table {i+1} to DataFrame: {df.shape}")
                
            except Exception as e:
                logger.warning(f"Could not convert table {i+1} to DataFrame: {e}")
        
        return dataframes
    
    def find_table_by_content(self, 
                             search_text: str,
                             pdf: Optional[pdfplumber.PDF] = None,
                             table_settings: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Find tables containing specific text.
        
        Args:
            search_text: Text to search for in tables
            pdf: PDF object (uses self.pdf if None)
            table_settings: Custom table extraction settings
            
        Returns:
            List of dictionaries with page number and table index
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> matching_tables = pu.find_table_by_content('revenue')
            >>> print(f"Found {len(matching_tables)} tables containing 'revenue'")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        matching_tables = []
        all_tables = self.extract_tables_from_all_pages(pdf, table_settings)
        
        for page_num, tables in all_tables.items():
            for table_idx, table in enumerate(tables):
                # Convert table to string for searching
                table_text = "\n".join(["\t".join(row) for row in table if row])
                
                if search_text.lower() in table_text.lower():
                    matching_tables.append({
                        'page_number': page_num,
                        'table_index': table_idx,
                        'table_data': table
                    })
        
        logger.info(f"Found {len(matching_tables)} tables containing '{search_text}'")
        return matching_tables
    
    # ==================== ADVANCED EXTRACTION ====================
    
    def extract_forms_and_fields(self, 
                                pdf: Optional[pdfplumber.PDF] = None) -> Dict[str, Any]:
        """
        Extract form fields and their values from PDF.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            Dictionary with form field information
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('form.pdf')
            >>> fields = pu.extract_forms_and_fields()
            >>> print(f"Found {len(fields)} form fields")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        # Note: pdfplumber doesn't directly extract form fields
        # This is a basic implementation that looks for form-like patterns
        
        form_data = {
            'text_fields': [],
            'checkboxes': [],
            'potential_fields': []
        }
        
        for page_num, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            
            # Look for patterns that might indicate form fields
            field_patterns = [
                r'([A-Za-z\s]+):\s*([_]{3,}|\.\.\.|___)',  # Label: ____
                r'([A-Za-z\s]+)\s*\[\s*\]',  # Label [ ]
                r'☐\s*([A-Za-z\s]+)',  # ☐ Label
                r'☑\s*([A-Za-z\s]+)',  # ☑ Label
            ]
            
            for pattern in field_patterns:
                matches = re.finditer(pattern, text, re.IGNORECASE)
                for match in matches:
                    form_data['potential_fields'].append({
                        'page_number': page_num,
                        'field_label': match.group(1).strip(),
                        'pattern_matched': pattern,
                        'full_match': match.group(0)
                    })
        
        return form_data
    
    def extract_metadata(self, pdf: Optional[pdfplumber.PDF] = None) -> Dict[str, Any]:
        """
        Extract comprehensive metadata from PDF.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            Dictionary with PDF metadata
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> metadata = pu.extract_metadata()
            >>> print(metadata['title'])
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        metadata = {
            'basic_info': pdf.metadata or {},
            'num_pages': len(pdf.pages),
            'page_info': []
        }
        
        # Analyze each page
        for i, page in enumerate(pdf.pages, 1):
            page_info = {
                'page_number': i,
                'width': page.width,
                'height': page.height,
                'rotation': getattr(page, 'rotation', 0),
                'char_count': len(page.chars),
                'image_count': len(page.images),
                'has_text': bool(page.extract_text()),
                'has_tables': bool(page.extract_tables())
            }
            metadata['page_info'].append(page_info)
        
        return metadata
    
    def extract_images_info(self, 
                           page_number: Optional[int] = None,
                           pdf: Optional[pdfplumber.PDF] = None) -> List[Dict[str, Any]]:
        """
        Extract information about images in PDF.
        
        Args:
            page_number: Specific page number (all pages if None)
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            List of image information dictionaries
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> images = pu.extract_images_info()
            >>> print(f"Found {len(images)} images")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        images_info = []
        
        if page_number:
            pages = [pdf.pages[page_number - 1]]
            page_numbers = [page_number]
        else:
            pages = pdf.pages
            page_numbers = range(1, len(pdf.pages) + 1)
        
        for page, page_num in zip(pages, page_numbers):
            for img in page.images:
                image_info = {
                    'page_number': page_num,
                    'x0': img['x0'],
                    'y0': img['y0'],
                    'x1': img['x1'],
                    'y1': img['y1'],
                    'width': img['width'],
                    'height': img['height'],
                    'object_id': img.get('object_id'),
                    'stream_id': img.get('stream_id')
                }
                images_info.append(image_info)
        
        logger.info(f"Found {len(images_info)} images")
        return images_info
    
    # ==================== TEXT ANALYSIS ====================
    
    def analyze_text_structure(self, 
                              pdf: Optional[pdfplumber.PDF] = None) -> Dict[str, Any]:
        """
        Analyze the structure of text in the PDF.
        
        Args:
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            Dictionary with text structure analysis
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> structure = pu.analyze_text_structure()
            >>> print(f"Average words per page: {structure['avg_words_per_page']}")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        analysis = {
            'total_pages': len(pdf.pages),
            'total_characters': 0,
            'total_words': 0,
            'total_lines': 0,
            'pages_with_text': 0,
            'font_analysis': defaultdict(int),
            'page_details': []
        }
        
        for i, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            chars = page.chars
            
            if text.strip():
                analysis['pages_with_text'] += 1
            
            char_count = len(text)
            word_count = len(text.split())
            line_count = len(text.split('\n'))
            
            analysis['total_characters'] += char_count
            analysis['total_words'] += word_count
            analysis['total_lines'] += line_count
            
            # Font analysis
            for char in chars:
                font_name = char.get('fontname', 'Unknown')
                font_size = char.get('size', 0)
                analysis['font_analysis'][f"{font_name}-{font_size}"] += 1
            
            page_detail = {
                'page_number': i,
                'characters': char_count,
                'words': word_count,
                'lines': line_count,
                'has_content': bool(text.strip())
            }
            analysis['page_details'].append(page_detail)
        
        # Calculate averages
        if analysis['total_pages'] > 0:
            analysis['avg_chars_per_page'] = analysis['total_characters'] / analysis['total_pages']
            analysis['avg_words_per_page'] = analysis['total_words'] / analysis['total_pages']
            analysis['avg_lines_per_page'] = analysis['total_lines'] / analysis['total_pages']
        
        return analysis
    
    def extract_patterns(self, 
                        patterns: Dict[str, str],
                        pdf: Optional[pdfplumber.PDF] = None) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extract specific patterns from PDF text.
        
        Args:
            patterns: Dictionary of pattern_name -> regex_pattern
            pdf: PDF object (uses self.pdf if None)
            
        Returns:
            Dictionary with pattern matches
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> patterns = {
            ...     'emails': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
            ...     'phones': r'\b\d{3}-\d{3}-\d{4}\b'
            ... }
            >>> matches = pu.extract_patterns(patterns)
            >>> print(f"Found {len(matches['emails'])} emails")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        results = {pattern_name: [] for pattern_name in patterns}
        
        for page_num, page in enumerate(pdf.pages, 1):
            text = page.extract_text() or ""
            
            for pattern_name, pattern in patterns.items():
                matches = re.finditer(pattern, text, re.IGNORECASE)
                
                for match in matches:
                    results[pattern_name].append({
                        'page_number': page_num,
                        'matched_text': match.group(),
                        'start_pos': match.start(),
                        'end_pos': match.end(),
                        'context': text[max(0, match.start()-30):match.end()+30].strip()
                    })
        
        # Log results
        for pattern_name, matches in results.items():
            logger.info(f"Found {len(matches)} matches for pattern '{pattern_name}'")
        
        return results
    
    # ==================== DATA EXPORT ====================
    
    def export_text_to_file(self, 
                           output_path: Union[str, Path],
                           pdf: Optional[pdfplumber.PDF] = None,
                           include_page_numbers: bool = True) -> None:
        """
        Export extracted text to a file.
        
        Args:
            output_path: Path for output file
            pdf: PDF object (uses self.pdf if None)
            include_page_numbers: Whether to include page separators
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> pu.export_text_to_file('extracted_text.txt')
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        output_path = Path(output_path)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            for i, page in enumerate(pdf.pages, 1):
                if include_page_numbers:
                    f.write(f"\n{'='*50}\nPAGE {i}\n{'='*50}\n\n")
                
                text = page.extract_text() or ""
                f.write(text)
                f.write("\n\n")
        
        logger.info(f"Exported text to {output_path}")
    
    def export_tables_to_csv(self, 
                            output_dir: Union[str, Path],
                            pdf: Optional[pdfplumber.PDF] = None,
                            table_settings: Optional[Dict[str, Any]] = None) -> List[str]:
        """
        Export all tables to CSV files.
        
        Args:
            output_dir: Directory for output CSV files
            pdf: PDF object (uses self.pdf if None)
            table_settings: Custom table extraction settings
            
        Returns:
            List of created file paths
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> files = pu.export_tables_to_csv('output_tables/')
            >>> print(f"Created {len(files)} CSV files")
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
        
        all_tables = self.extract_tables_from_all_pages(pdf, table_settings)
        created_files = []
        
        for page_num, tables in all_tables.items():
            for table_idx, table in enumerate(tables):
                if not table:
                    continue
                
                filename = f"page_{page_num}_table_{table_idx + 1}.csv"
                filepath = output_dir / filename
                
                with open(filepath, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerows(table)
                
                created_files.append(str(filepath))
                logger.debug(f"Exported table to {filepath}")
        
        logger.info(f"Exported {len(created_files)} tables to CSV files")
        return created_files
    
    def export_tables_to_excel(self, 
                              output_path: Union[str, Path],
                              pdf: Optional[pdfplumber.PDF] = None,
                              table_settings: Optional[Dict[str, Any]] = None) -> None:
        """
        Export all tables to Excel file with multiple sheets.
        
        Args:
            output_path: Path for output Excel file
            pdf: PDF object (uses self.pdf if None)
            table_settings: Custom table extraction settings
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> pu.export_tables_to_excel('extracted_tables.xlsx')
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        all_tables = self.extract_tables_from_all_pages(pdf, table_settings)
        dataframes = {}
        
        for page_num, tables in all_tables.items():
            for table_idx, table in enumerate(tables):
                if not table:
                    continue
                
                sheet_name = f"Page_{page_num}_Table_{table_idx + 1}"
                
                # Convert to DataFrame
                if len(table) > 1:
                    df = pd.DataFrame(table[1:], columns=table[0])
                else:
                    df = pd.DataFrame(table)
                
                dataframes[sheet_name] = df
        
        # Export to Excel
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            for sheet_name, df in dataframes.items():
                df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        logger.info(f"Exported {len(dataframes)} tables to {output_path}")
    
    def export_analysis_to_json(self, 
                               output_path: Union[str, Path],
                               pdf: Optional[pdfplumber.PDF] = None) -> None:
        """
        Export comprehensive PDF analysis to JSON.
        
        Args:
            output_path: Path for output JSON file
            pdf: PDF object (uses self.pdf if None)
            
        Example:
            >>> pu = PDFUtils()
            >>> pu.load_pdf('document.pdf')
            >>> pu.export_analysis_to_json('pdf_analysis.json')
        """
        pdf = pdf or self.pdf
        if not pdf:
            raise ValueError("No PDF loaded")
        
        analysis = {
            'pdf_info': self.get_pdf_info(pdf),
            'metadata': self.extract_metadata(pdf),
            'text_structure': self.analyze_text_structure(pdf),
            'images_info': self.extract_images_info(pdf=pdf),
            'extraction_timestamp': datetime.now().isoformat()
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(analysis, f, indent=2, default=str)
        
        logger.info(f"Exported analysis to {output_path}")

# ==================== STANDALONE UTILITY FUNCTIONS ====================

def batch_process_pdfs(pdf_paths: List[Union[str, Path]], 
                      process_function: Callable,
                      output_dir: Optional[Union[str, Path]] = None,
                      **kwargs) -> List[Any]:
    """
    Process multiple PDF files in batch.
    
    Args:
        pdf_paths: List of PDF file paths
        process_function: Function to apply to each PDF
        output_dir: Directory for output files
        **kwargs: Additional arguments for process_function
        
    Returns:
        List of results from processing each PDF
        
    Example:
        >>> def extract_text(pdf_utils, pdf_path):
        ...     pdf_utils.load_pdf(pdf_path)
        ...     return pdf_utils.extract_text_from_all_pages()
        >>> 
        >>> results = batch_process_pdfs(['doc1.pdf', 'doc2.pdf'], extract_text)
    """
    results = []
    
    if output_dir:
        output_dir = Path(output_dir)
        output_dir.mkdir(exist_ok=True)
    
    for pdf_path in pdf_paths:
        try:
            with PDFUtils() as pu:
                result = process_function(pu, pdf_path, **kwargs)
                results.append(result)
                logger.info(f"Processed: {pdf_path}")
        except Exception as e:
            logger.error(f"Failed to process {pdf_path}: {e}")
            results.append(None)
    
    return results

def merge_pdf_extractions(extraction_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Merge results from multiple PDF extractions.
    
    Args:
        extraction_results: List of extraction result dictionaries
        
    Returns:
        Merged extraction results
        
    Example:
        >>> results = [{'text': 'Page 1'}, {'text': 'Page 2'}]
        >>> merged = merge_pdf_extractions(results)
        >>> print(merged['combined_text'])
    """
    merged = {
        'total_pdfs': len(extraction_results),
        'combined_text': '',
        'all_tables': [],
        'all_patterns': defaultdict(list),
        'total_pages': 0
    }
    
    for result in extraction_results:
        if result is None:
            continue
            
        if 'text' in result:
            merged['combined_text'] += result['text'] + "\n\n"
        
        if 'tables' in result:
            merged['all_tables'].extend(result['tables'])
        
        if 'patterns' in result:
            for pattern_name, matches in result['patterns'].items():
                merged['all_patterns'][pattern_name].extend(matches)
        
        if 'pages' in result:
            merged['total_pages'] += result['pages']
    
    return merged

def create_pdf_report(pdf_path: Union[str, Path], 
                     output_path: Union[str, Path]) -> Dict[str, Any]:
    """
    Create a comprehensive report for a PDF file.
    
    Args:
        pdf_path: Path to PDF file
        output_path: Path for output report
        
    Returns:
        Report summary
        
    Example:
        >>> report = create_pdf_report('document.pdf', 'report.json')
        >>> print(f"Report created with {report['total_pages']} pages analyzed")
    """
    with PDFUtils() as pu:
        pu.load_pdf(pdf_path)
        
        # Comprehensive analysis
        report = {
            'source_file': str(pdf_path),
            'analysis_timestamp': datetime.now().isoformat(),
            'basic_info': pu.get_pdf_info(),
            'metadata': pu.extract_metadata(),
            'text_analysis': pu.analyze_text_structure(),
            'images_info': pu.extract_images_info(),
            'forms_info': pu.extract_forms_and_fields(),
            'table_count': 0,
            'sample_text': ''
        }
        
        # Count tables
        all_tables = pu.extract_tables_from_all_pages()
        report['table_count'] = sum(len(tables) for tables in all_tables.values())
        
        # Extract sample text
        if len(pu.pdf.pages) > 0:
            sample_text = pu.extract_text_from_page(1)
            report['sample_text'] = sample_text[:500] + "..." if len(sample_text) > 500 else sample_text
        
        # Export report
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"Created comprehensive report: {output_path}")
        return {
            'total_pages': report['basic_info']['num_pages'],
            'total_tables': report['table_count'],
            'has_images': len(report['images_info']) > 0,
            'report_path': str(output_path)
        }

# ==================== EXAMPLE USAGE ====================

if __name__ == "__main__":
    # Example usage of PDFUtils
    
    print("=== PDF UTILS DEMO ===")
    
    # Note: This demo assumes you have a PDF file to test with
    # Replace 'sample.pdf' with an actual PDF file path
    sample_pdf = "sample.pdf"
    
    try:
        with PDFUtils() as pu:
            # Load PDF
            pu.load_pdf(sample_pdf)
            
            # Basic info
            print("\n=== PDF INFORMATION ===")
            info = pu.get_pdf_info()
            print(f"Number of pages: {info['num_pages']}")
            print(f"Page sizes: {info['page_sizes'][:3]}...")  # Show first 3 pages
            
            # Extract text
            print("\n=== TEXT EXTRACTION ===")
            if info['num_pages'] > 0:
                first_page_text = pu.extract_text_from_page(1)
                print(f"First page text (first 200 chars): {first_page_text[:200]}...")
                
                all_text = pu.extract_text_from_all_pages()
                print(f"Total text length: {len(all_text)} characters")
            
            # Search text
            print("\n=== TEXT SEARCH ===")
            search_results = pu.search_text_in_pdf("the", case_sensitive=False)
            print(f"Found 'the' {len(search_results)} times")
            
            # Extract tables
            print("\n=== TABLE EXTRACTION ===")
            all_tables = pu.extract_tables_from_all_pages()
            total_tables = sum(len(tables) for tables in all_tables.values())
            print(f"Found {total_tables} tables across {len(all_tables)} pages")
            
            if total_tables > 0:
                # Convert first table to DataFrame
                first_page_tables = list(all_tables.values())[0]
                if first_page_tables:
                    dfs = pu.tables_to_dataframes(first_page_tables)
                    if dfs:
                        print(f"First table shape: {dfs[0].shape}")
                        print(f"First table columns: {list(dfs[0].columns)}")
            
            # Analyze structure
            print("\n=== TEXT STRUCTURE ANALYSIS ===")
            structure = pu.analyze_text_structure()
            print(f"Average words per page: {structure['avg_words_per_page']:.1f}")
            print(f"Pages with text: {structure['pages_with_text']}/{structure['total_pages']}")
            
            # Extract patterns
            print("\n=== PATTERN EXTRACTION ===")
            patterns = {
                'emails': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',
                'urls': r'https?://[^\s]+',
                'numbers': r'\b\d+\b'
            }
            pattern_results = pu.extract_patterns(patterns)
            for pattern_name, matches in pattern_results.items():
                print(f"Found {len(matches)} {pattern_name}")
            
            # Extract metadata
            print("\n=== METADATA ===")
            metadata = pu.extract_metadata()
            print(f"Basic metadata: {metadata['basic_info']}")
            
            # Images info
            print("\n=== IMAGES ===")
            images = pu.extract_images_info()
            print(f"Found {len(images)} images")
            
            # Export examples
            print("\n=== EXPORT EXAMPLES ===")
            pu.export_text_to_file("extracted_text.txt")
            print("Exported text to extracted_text.txt")
            
            if total_tables > 0:
                csv_files = pu.export_tables_to_csv("output_tables")
                print(f"Exported {len(csv_files)} CSV files")
            
            pu.export_analysis_to_json("pdf_analysis.json")
            print("Exported analysis to pdf_analysis.json")
            
    except FileNotFoundError:
        print(f"Demo PDF file '{sample_pdf}' not found.")
        print("Please provide a valid PDF file path to test the utilities.")
    except Exception as e:
        print(f"Error in demo: {e}")
    
    print("\n=== DEMO COMPLETED ===")
    print("PDF utilities demonstrated successfully!")