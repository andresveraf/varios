"""
selenium_utils.py

Utility class for automating web browsers with Selenium, including driver setup and common actions.

Typical usage example:

    from utils.selenium_utils import SeleniumUtils
    from selenium.webdriver.common.by import By

    su = SeleniumUtils(download_folder="output/_others", excecute_headless=False)
    su.open_website("https://example.com")
    su.click_element(By.XPATH, "//button[@id='submit']")
    su.close_driver()

"""
import os
import sys
import time
import glob
import logging
import datetime as dt
from selenium import webdriver
from selenium.webdriver.edge.options import Options
from selenium.webdriver import ActionChains
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import *
# ...existing code...

class SeleniumUtils():
    """
    Utility class for automating web browsers with Selenium, including driver setup and common actions.

    Example:
        from utils.selenium_utils import SeleniumUtils
        su = SeleniumUtils(download_folder="output/_others", excecute_headless=False)
        su.open_website("https://example.com")
        su.close_driver()
    """
    def __init__(self, download_folder:str=None, excecute_headless:bool=False, max_timeout:int=30):
        """
        Initialize SeleniumUtils with Edge driver and options.

        Args:
            download_folder (str): Folder for downloads. Defaults to process_data/selenium_downloads.
            excecute_headless (bool): Whether to run browser in headless mode.
            max_timeout (int): Default max wait time for elements.
        """
        self._keep_web_alive     = False
        self._excecute_headless  = excecute_headless
        self._max_timeout       = max_timeout
        if not download_folder:
            execution_folder = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            download_folder  = os.path.join(execution_folder, "process_data", "selenium_downloads") 
        self.download_folder = download_folder
        self.driver = None
        self.init_edge_driver() # Initiates driver and wait time
    
    def init_edge_driver(self):        
        """
        Initialize the Edge web driver with custom options and preferences.
        Sets up download folder, browser options, and zoom level.
        """
        edge_options = Options()
        # Create download folder if it doesnt exist
        os.makedirs(name=self.download_folder, exist_ok=True)
        prefs = {"profile.default_content_settings.popups": 0,    
                 "download.default_directory": self.download_folder,
                 "plugins.always_open_pdf_externally": True,
                 "download.prompt_for_download": False, # to auto download the fil
                 #"browser.helperApps.neverAsk.saveToDisk": "application/pdf", # Disable "Save As" window for PDF files }
                 }
        # if self._excecute_headless:
        #     edge_options.add_argument('--headless=new')
        edge_options.add_argument("--start-maximized")
        edge_options.add_argument('--no-sandbox')
        edge_options.add_argument('--disable-dev-shm-usage')
        edge_options.add_argument('--ignore-certificate-errors')
        edge_options.add_argument('--ignore-ssl-errors')
        edge_options.add_argument("--disable-popup-blocking")
        edge_options.add_argument("--printing") # new
        edge_options.add_experimental_option('excludeSwitches', ['enable-logging', 'disable-popup-blocking'])
        edge_options.add_experimental_option("detach", self._keep_web_alive)
        edge_options.add_experimental_option("prefs", prefs)
        edge_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64, x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3")
        #edge_options.add_argument(f"download.default.directory='output\_others'")
        # Open website
        self.driver = webdriver.Edge(options=edge_options, keep_alive=self._keep_web_alive)
        self.wait = WebDriverWait(self.driver, self._max_timeout) # Set up wait time
        # Set browser zoom level (e.g., 90%)
        logging.info("Initiated web driver")   
        zoom_percent = 50  # Change this value as needed (e.g., 100 for default)
        self.driver.execute_script(f"document.body.style.zoom='{zoom_percent}%'")
        logging.info(f"Set browser zoom to {zoom_percent}%")

    def open_website(self, url:str):
        """
        Open a website in the browser.

        Args:
            url (str): The URL to open.
        Example:
            su.open_website("https://example.com")
        """
        logging.info(f"Opening the website {url}...")
        self.driver.get(url)

    def close_website(self, url:str):
        """
        Close a specific website tab by URL.

        Args:
            url (str): The URL of the tab to close.
        Example:
            su.close_website("https://example.com")
        """
        logging.info(f"Closing url in driver: {url}")
        self.switch_to_tab(url=url)
        self.driver.close()
    
    def close_all_websites(self):
        """
        Close all open browser tabs.
        Example:
            su.close_all_websites()
        """
        logging.info(f"Closing all tabs in driver")
        windows = self.driver.window_handles
        for window in windows:
            try:
                self.driver.switch_to.window(window)
                self.driver.close()
            except Exception as error:
                logging.info(f"Failed to close window due to error {error}, continuing")
                pass
    
    def switch_to_tab(self, url:str=None, tab_index:int=None):
        """
        Switch to a browser tab by URL or index.

        Args:
            url (str, optional): URL to match.
            tab_index (int, optional): Index of the tab.
        Returns:
            bool: True if switched successfully, False otherwise.
        Example:
            su.switch_to_tab(url="https://example.com")
            su.switch_to_tab(tab_index=1)
        """
        windows        = self.driver.window_handles
        current_window = self.driver.current_window_handle 
        init_url       = self.driver.current_url
        if url:
            logging.info(f"Attempting to switch driver from url {init_url} to {url}")
            for window in windows:
                self.driver.switch_to.window(window)
                current_url = self.driver.current_url
                if(url in current_url):
                    logging.info(f"Found desiered tab with url {current_url}, driver updated")
                    return True
                else:
                    self.driver.switch_to.window(current_window)
            logging.warning("Failed to find tab with the given url, keeping current driver")
            return False
        elif tab_index:
            logging.info(f"Attempting to switch driver from url {init_url} to tab position {tab_index}")
            if len(windows)<=tab_index:
                self.driver.switch_to.window(windows[tab_index])
                current_url = self.driver.current_url
                logging.info(f"Found desiered tab with url {current_url}, driver updated")
            else:
                logging.warning("Index does not exist in current driver")
                return False
        logging.info("No website directions given, keeping current tab")
        return True

    def element_exists(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        """
        Check if a web element exists on the page.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            raise_exception (bool): Raise exception if not found.
            message (str): Custom error message.
            timeout (int): Max wait time.
            web_element: Parent element to search within.
        Returns:
            bool: True if element exists, False otherwise.
        Example:
            su.element_exists(By.XPATH, "//div[@id='main']")
        """
        if web_element is None:
            web_element = self.driver
        # Set up timeout, if not given will be class default
        if not timeout:
            timeout = self._max_timeout
        element_wait = WebDriverWait(web_element, timeout)
        # If no message given use default
        if not message:
            message = f'Could not find element with selector "{selector}" on page: {self.driver.current_url}'
        # Attempt to find element
        try:
            element_wait.until(EC.presence_of_element_located((By, selector)), message)
            return True
        except TimeoutException:
            logging.warning(f"Timeout exceeded on finding element, waited {timeout} seconds")
            if raise_exception:
                raise TimeoutException(msg=message)
            return False

    def click_element(self, By:By, selector:str, web_element=None, hover:bool=False, raise_exception:bool=True, timeout:int=30):
        """
        Click a web element, with optional hover.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            hover (bool): Hover before clicking.
            raise_exception (bool): Raise exception if not found.
            timeout (int): Max wait time.
        Returns:
            bool: True if clicked, False otherwise.
        Example:
            su.click_element(By.XPATH, "//button[@id='submit']")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to click on'
        logging.info(f"Clicking \"{selector}\"") 
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            clicker = web_element.find_element(By, selector)
            time.sleep(0.5)
            if hover:
                hover_action = ActionChains(self.driver).move_to_element(clicker)
                hover_action.perform()
                time.sleep(0.5)
            clicker.click()
            time.sleep(0.5)
            return True
        else:
            return False
        
    def populate_field(self, By:By, selector:str, input:str, web_element=None, clear_before:bool=False, sensitive_data:bool=False, raise_exception:bool=True, timeout:int=None):
        """
        Fill a form field with text.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            input (str): Text to input.
            web_element: Parent element to search within.
            clear_before (bool): Clear field before input.
            sensitive_data (bool): Mask input in logs.
            raise_exception (bool): Raise exception if not found.
            timeout (int): Max wait time.
        Returns:
            bool: True if populated, False otherwise.
        Example:
            su.populate_field(By.ID, "username", "myuser")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to type in text box'
        if sensitive_data:
            logging.info(f"Filling \"{selector}\" with \"Sensitive Data\"")
        else: 
            logging.info(f"Filling \"{selector}\" with \"{input}\"") 
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            pouplater = web_element.find_element(By, selector)
            if clear_before:
                pouplater.clear()
            pouplater.send_keys(input) 
            return True
        else:
            return False
        
    def send_keys(self, By:By, selector:str, value, web_element=None, clear_first:bool=False, timeout:int=None) -> bool:
        """
        Send keyboard input to an element.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            value: Text/keys to send.
            web_element: Parent element to search within.
            clear_first (bool): Clear field before sending keys.
            timeout (int): Max wait time.
        Returns:
            bool: True if keys sent, False otherwise.
        Example:
            su.send_keys(By.ID, "search", "test")
        """
        if web_element is None:
            web_element = self.driver
        
        message = f'Could not find element with selector "{selector}" to send keys'
        logging.info(f"Sending keys to element \"{selector}\"")

        element_exists = self.element_exists(
            By=By, 
            selector=selector,
            raise_exception=True,
            message=message,
            timeout=timeout,
            web_element=web_element
        )

        if element_exists:
            try:
                element = web_element.find_element(By, selector)
                if clear_first:
                    element.clear()
                element.send_keys(value)
                return True
            except Exception as e:
                logging.error(f"Failed to send keys to element: {str(e)}")
                return False
        return False
        
    def switch_frame(self, by, value):
        """
        Switch to a specific iframe on the page.

        Args:
            by (By): Selenium By selector type.
            value (str): Selector value.
        Returns:
            bool: True if switched, False otherwise.
        Example:
            su.switch_frame(By.ID, "frame1")
        self.driver.switch_frame(By.NAME, "mainFrame")
        # or by index
        self.driver.switch_frame(By.INDEX, 0)
        """
        try:
            logging.info(f"\nAttempting to switch to {value}...")
            self.driver.switch_to.frame(self.driver.find_element(by, value))
            return True
        except Exception as e:
            logging.error(f"Error switching to frame {value}: {e}")
            return False

    def close_driver(self):
        """
        Close the Selenium web driver and all browser windows.
        Example:
            su.close_driver()
        """
        logging.info(f"Closing the initiated driver")
        self.driver.quit()
    
    def check_unfinished_downloads(self, extensions:list=[".crdownload",".temp",".tmp"], max_mins: float = 0.1, empty_dir_seconds_timeout: int = 10, retry_seconds:int = 1, raise_exception:bool = True):
        """
        Check for unfinished downloads in the download folder.

        Args:
            extensions (list): List of extensions indicating incomplete downloads.
            max_mins (float): Max minutes to wait.
            empty_dir_seconds_timeout (int): Timeout for empty directory.
            retry_seconds (int): Seconds between checks.
            raise_exception (bool): Raise exception if unfinished downloads found.
        Example:
            su.check_unfinished_downloads()
        """
        logging.info(f"Checking for unfinished downloads on: \"{self.download_folder}\"")
        logging.info(f"With a time out of: {max_mins} minutes.")
        logging.info(f"Extension used for detecting: \"{extensions}\"")
        if not os.path.exists(self.download_folder):
            logging.info(f"Directory {self.download_folder} not found.")
            logging.info("Please check \"self.download_folder\" argument in \"SeleniumUtils\" class")
            if raise_exception:
                raise Exception(f"Directory {self.download_folder} not found. Please check \"self.download_folder\" argument in \"SeleniumUtils\" class")
        else:
            dir_list = os.listdir(self.download_folder)
            logging.info(f"{len(dir_list)} files found at given directory.")
            logging.info("Searching for unfinished downloads")
            empty_dir = True
            timeout_start = time.time()
            while time.time() < timeout_start + max_mins*60:
                dir_list = os.listdir(self.download_folder)
                if len(dir_list) == 0 and empty_dir:
                    #empty_dir = True
                    reimaining_time = int(timeout_start + empty_dir_seconds_timeout - time.time())
                    logging.info("No files found at given directory. Please check download path is correct")
                    if reimaining_time < 0:
                        logging.error(f"Empty directory time out after {empty_dir_seconds_timeout} seconds")
                        if raise_exception:
                            raise Exception(f"""\"{self.download_folder}\" path found. But, no files where found at given directory.
                                            Please check download path is correct. Else, consider increasing \"empty_dir_seconds_timeout\"
                                            from function argument""")
                        break
                    logging.info(f"{reimaining_time} remaining seconds for empty directory timeout")
                else:
                    if empty_dir:
                        empty_dir = False
                        logging.info("Files found at given directory. Reseting timer for download")
                        timeout_start = time.time()
                    reimaining_time = int(timeout_start + max_mins*60 - time.time())
                    logging.info(f"{reimaining_time} remaining seconds for download timeout")
                    unfinished_downloads_names = [file_name for file_name in dir_list  if any(extension in str(file_name) for extension in extensions)]
                    amount = len(unfinished_downloads_names)
                    if amount== 0:
                        dir_list = os.listdir(self.download_folder)
                        if len(dir_list) == 0:
                            logging.error(f"Download failed. Directory is empty. A file with in \"{extensions}\" extension types was identified, but was not saved as expected.")
                        return logging.info("No unfinished downloads detected")
                    else:
                        logging.info(f"{amount} unfinished downloads detected, checking again in {retry_seconds} seconds")
                time.sleep(retry_seconds)        
            if raise_exception:
                str_list_name = "\
-File: ".join(unfinished_downloads_names)
                logging.error(f"""
                                Download TIME OUT: {amount} unfinished downloads detected after \"max_mins = {max_mins}\" of wait.
                                Check for corrupted files with \"{extensions}\" extension in \"{self.download_folder}\". Else, consider increasing 
                                \"max_mins\" from from function argument"
                                Unfinished files found: 
                                {str_list_name}""")
                raise Exception(f"""
                                Download TIME OUT: {amount} unfinished downloads detected after \"max_mins = {max_mins}\" of wait.
                                Check for corrupted files with \"{extensions}\" extension in \"{self.download_folder}\". Else, consider increasing 
                                \"max_mins\" from from function argument"
                                Unfinished files found: 
                                {str_list_name}""")
                
    def wait_for_element_visibility(self, By:By, selector:str, timeout:int=None, raise_exception:bool=True):
        """
        Wait for an element to be visible on the page.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            timeout (int): Max wait time.
            raise_exception (bool): Raise exception if not visible.
        Returns:
            bool: True if visible, False otherwise.
        Example:
            su.wait_for_element_visibility(By.XPATH, "//div[@id='main']")
        """
        if not timeout:
            timeout = self._max_timeout
        message = f'Element with selector "{selector}" did not become visible within {timeout} seconds'
        logging.info(f"Waiting for element \"{selector}\" to become visible")
        try:
            WebDriverWait(self.driver, timeout).until(EC.visibility_of_element_located((By, selector)))
            return True
        except TimeoutException:
            logging.warning(f"Timeout waiting for element visibility: {message}")
            if raise_exception:
                raise TimeoutException(msg=message)
            return False
        
    def to_element(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        """
        Scroll to a specific element on the page.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            raise_exception (bool): Raise exception if not found.
            message (str): Custom error message.
            timeout (int): Max wait time.
            web_element: Parent element to search within.
        Returns:
            bool: True if scrolled, False otherwise.
        Example:
            su.to_element(By.ID, "footer")
        """
        if web_element is None:
            web_element = self.driver
        # Set up timeout, if not given will be class default
        if not timeout:
            timeout = self._max_timeout
        element_wait = WebDriverWait(web_element, timeout)
        # If no message given use default
        if not message:
            message = f'Could not find element with selector "{selector}" on page: {self.driver.current_url}'
        # Attempt to find element
        try:
            element = element_wait.until(EC.presence_of_element_located((By, selector)), message)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
            return True
        except TimeoutException:
            logging.warning(f"Timeout exceeded on finding element, waited {timeout} seconds")
            if raise_exception:
                raise TimeoutException(msg=message)
            return False

    def check_exist(self, By:By, selector:str, raise_exception:bool=True, message:str=None, timeout:int=None, web_element=None):
        """
        Check if an element exists using find_element (no wait).

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
        Returns:
            bool: True if found, False otherwise.
        Example:
            su.check_exist(By.ID, "logo")
        """
        try: 
            self.driver.find_element(By, selector)
        except NoSuchElementException:
            return False
        return True


    def get_text(self, By:By, selector:str, web_element=None, raise_exception:bool=True, timeout:int=None):
        """
        Get the text of a web element.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            raise_exception (bool): Raise exception if not found.
            timeout (int): Max wait time.
        Returns:
            str: Text of the element, or empty string if not found.
        Example:
            su.get_text(By.XPATH, "//h1")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to get text'
        logging.info(f"Getting text from \"{selector}\"")
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            element = web_element.find_element(By, selector)
            return element.text
        else:
            return ""

    def wait_for_page_load(self, timeout:int=None):
        """
        Wait for the page to load completely.

        Args:
            timeout (int): Max wait time.
        Returns:
            bool: True if loaded, False otherwise.
        Example:
            su.wait_for_page_load()
        """
        if not timeout:
            timeout = self._max_timeout
        logging.info(f"Waiting for page to load completely")
        try:
            WebDriverWait(self.driver, timeout).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )
            return True
        except TimeoutException:
            logging.warning(f"Timeout waiting for page to load completely")
            return False

    def find_elements(self, By:By, selector:str, web_element=None, raise_exception:bool=False, timeout:int=None):
        """
        Find all elements matching a selector.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            raise_exception (bool): Raise exception if not found.
            timeout (int): Max wait time.
        Returns:
            list: List of found elements.
        Example:
            su.find_elements(By.CLASS_NAME, "item")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find any elements with selector "{selector}"'
        logging.info(f"Finding all elements with selector \"{selector}\"")
        
        # Primero verificamos si existe al menos un elemento
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        
        if element_exists:
            elements = web_element.find_elements(By, selector)
            logging.info(f"Found {len(elements)} elements with selector \"{selector}\"")
            return elements
        else:
            return []
    
    def find_element(self, By:By, selector:str, web_element=None, raise_exception:bool=True, timeout:int=None):
        """
        Find a single element matching a selector.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            raise_exception (bool): Raise exception if not found.
            timeout (int): Max wait time.
        Returns:
            WebElement: The found element, or None if not found.
        Example:
            su.find_element(By.ID, "submit")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}"'
        logging.info(f"Finding element with selector \"{selector}\"")
        
        # Verificamos si existe el elemento
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=raise_exception, message=message, timeout=timeout, web_element=web_element)
        
        if element_exists:
            element = web_element.find_element(By, selector)
            logging.info(f"Found element with selector \"{selector}\"")
            return element
        else:
            return None
        
    def hover_element(self, By:By, selector:str, web_element=None, timeout:int=None):
        """
        Hover the mouse over a web element.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            timeout (int): Max wait time.
        Returns:
            bool: True if hover succeeded, False otherwise.
        Example:
            su.hover_element(By.ID, "menu")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to hover over'
        logging.info(f"Hovering over element \"{selector}\"")
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=True, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            element = web_element.find_element(By, selector)
            actions = ActionChains(self.driver)
            actions.move_to_element(element).perform()
            time.sleep(0.5)  # Small pause to ensure hover effect is registered
            return True
        return False

    def execute_script(self, script:str, *args):
        """
        Execute a JavaScript script in the browser.

        Args:
            script (str): JavaScript code to execute.
            *args: Optional arguments for the script.
        Returns:
            Any: Result of the script execution.
        Example:
            su.execute_script("alert('Hello!')")
        """
        logging.info(f"Executing JavaScript script")
        return self.driver.execute_script(script, *args)

    def scroll_to_element(self, By:By, selector:str, web_element=None, timeout:int=None):
        """
        Scroll the page to a specific element.

        Args:
            By (By): Selenium By selector type.
            selector (str): Selector string.
            web_element: Parent element to search within.
            timeout (int): Max wait time.
        Returns:
            bool: True if scrolled, False otherwise.
        Example:
            su.scroll_to_element(By.ID, "footer")
        """
        if web_element is None:
            web_element = self.driver
        message = f'Could not find element with selector "{selector}" to scroll to'
        logging.info(f"Scrolling to element \"{selector}\"")
        element_exists = self.element_exists(By=By, selector=selector, raise_exception=True, message=message, timeout=timeout, web_element=web_element)
        if element_exists:
            element = web_element.find_element(By, selector)
            self.driver.execute_script("arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element)
            time.sleep(1)  # Allow smooth scrolling to complete
            return True
        return False

    def screenshot(self, filename:str=None):
        """
        Take a screenshot of the current page.

        Args:
            filename (str): File name for the screenshot.
        Returns:
            str: Path to the screenshot file.
        Example:
            su.screenshot("output/screen.png")
        """
        if not filename:
            timestamp = time.strftime("%Y%m%d-%H%M%S")
            filename = f"screenshot_{timestamp}.png"
        
        # Asegurarse de que la ruta existe
        dir_path = os.path.dirname(filename)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        
        logging.info(f"Taking screenshot: {filename}")
        self.driver.save_screenshot(filename)
        return filename

    def wait_for_element(self, by, selector, timeout=30):
        """
        Wait for an element to be present and visible on the page.

        Args:
            by (By): Selenium By selector type.
            selector (str): Selector string.
            timeout (int): Max wait time.
        Returns:
            WebElement: The found element.
        Raises:
            TimeoutException: If not found in time.
        Example:
            su.wait_for_element(By.ID, "main")
        """

        try:
            logging.info(f"Finding element with selector \"{selector}\"")
            element = WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located((by, selector))
            )
            return element
        except TimeoutException as e:
            logging.error(f"Timeout waiting for element with selector \"{selector}\" after {timeout} seconds")
            raise
            
    def switch_to_default_content(self):
        """
        Switch the Selenium driver context to the default content (main document).
        Example:
            driver.switch_to_default_content()
        """
        try:
            logging.info("Switching to default content (main document)")
            self.driver.switch_to.default_content()
            # name actual frame
            logging.info("Switched to default content successfully")
            # logging the name of the actual frame
            current_frame = self.driver.execute_script("return window.name;")
            logging.info(f"Current frame name: {current_frame}")   
        except Exception as e:  
            logging.error(f"Failed to switch to default content: {e}")
            current_frame = self.driver.execute_script("return window.name;")
            logging.info(f"Current frame name: {current_frame}") 
            
    def current_frame(self):
        """
        Get the name of the current frame in the Selenium driver.
        
        Returns:
            str: Name of the current frame.
        Example:
            frame_name = driver.actual_frame()
        """
        try:
            current_frame = self.driver.execute_script("return window.name;")
            logging.info(f"Current frame name: {current_frame}")
            return current_frame
        except Exception as e:
            logging.error(f"Failed to get current frame name: {e}")
            return None

    def extract_and_switch_to_frame(self):
        """
        List all frames, print their names/ids, and switch to the first one found.
        """
        frames = self.driver.driver.find_elements("tag name", "frame")
        for idx, frame in enumerate(frames):
            name = frame.get_attribute("name")
            fid = frame.get_attribute("id")
            logging.info(f"Frame {idx}: name={name}, id={fid}")
        if frames:
            # Example: switch to the first frame
            self.driver.driver.switch_to.frame(frames[0])
            logging.info("Switched to the first frame.")
        else:
            logging.info("No frames found on the page.")

    def scroll_to_bottom(self):
        """
        Scroll to the bottom of the current page using JavaScript.
        Example:
            su.scroll_to_bottom()
        """
        logging.info("Scrolling to the bottom of the page")
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(1)
        
    def scroll_down_with_mouse(self, times:int=1):
        """
        Simulate mouse scroll down by sending PAGE_DOWN key.

        Args:
            times (int): Number of times to scroll down.
        Example:
            su.scroll_down_with_mouse(times=3)
        """
        actions = ActionChains(self.driver)
        for _ in range(times):
            actions.send_keys(Keys.PAGE_DOWN).perform()
            time.sleep(0.2)  # Optional: wait for content to load
        logging.info(f"Scrolled down {times} times using mouse scroll")    
    
    def scroll_up_with_mouse(self, times:int=1):
        """
        Simulate mouse scroll up by sending ARROW_UP key.

        Args:
            times (int): Number of times to scroll up.
        Example:
            su.scroll_up_with_mouse(times=2)
        """
        actions = ActionChains(self.driver)
        for _ in range(times):
            actions.send_keys(Keys.ARROW_UP).perform()
            time.sleep(0.3)  # Optional: wait for content to load
        logging.info(f"Scrolled up {times} times using mouse scroll")    
    
    def scroll_to_end_with_mouse(self):
        """
        Simulate mouse scroll to the bottom by sending END key.
        Example:
            su.scroll_to_end_with_mouse()
        """
        actions = ActionChains(self.driver)
        actions.send_keys(Keys.END).perform()
        time.sleep(0.5)
        
    def press_tab(self, times:int=3):
        """
        Simulate mouse scroll down by sending PAGE_DOWN key.

        Args:
            times (int): Number of times to scroll down.
        Example:
            su.scroll_down_with_mouse(times=3)
        """
        actions = ActionChains(self.driver)
        for _ in range(times):
            actions.send_keys(Keys.TAB).perform()
            time.sleep(0.2)  # Optional: wait for content to load
        logging.info(f"Scrolled down {times} times using mouse scroll")    
    
    def send_keys_with_actionchains(self, value: str) -> bool:
        """
        Send keyboard input (text or special keys) to the currently focused element using ActionChains.

        Args:
            value (str): The text or keys to send.

        Returns:
            bool: True if keys sent successfully, False otherwise.

        Example:
            su.send_keys_with_actionchains("test123")
            su.send_keys_with_actionchains(Keys.ENTER)

        Raises:
            Exception: If sending keys fails.
        """
        from selenium.webdriver.common.action_chains import ActionChains

        try:
            actions = ActionChains(self.driver)
            actions.send_keys(value).perform()
            logging.info(f"Sent keys '{value}' using ActionChains to the focused element.")
            return True
        except Exception as e:
            logging.error(f"Failed to send keys with ActionChains: {e}")
            return False
    
    def list_all_frames(self):
        """
        Log all iframe and frame elements on the current page.
        Example:
            su.list_all_frames()
        """
        frames = self.driver.find_elements("tag name", "iframe")
        logging.info(f"Found {len(frames)} iframe(s) on the page:")
        for idx, frame in enumerate(frames):
            name = frame.get_attribute("name")
            fid = frame.get_attribute("id")
            logging.info(f"Frame {idx}: id='{fid}', name='{name}'")
        # Optionally, also list <frame> tags (rare, but possible)
        frames2 = self.driver.find_elements("tag name", "frame")
        if frames2:
            logging.info(f"Found {len(frames2)} <frame> tag(s) on the page:")
            for idx, frame in enumerate(frames2):
                name = frame.get_attribute("name")
                fid = frame.get_attribute("id")
                logging.info(f"Frame {idx}: id='{fid}', name='{name}'")
                
    def switch_to_main_frame(self) -> None:
        """
        Switch Selenium context back to the main (default) frame.

        Raises:
            Exception: If switching to the main frame fails.
        
        If list_all_frames() reports 0, you are already in the main document.

        Example:
            self.switch_to_main_frame()
        """
        try:
            self.driver.switch_to.default_content()
        except Exception as error:
            raise Exception(f"Failed to switch to main frame: {error}")
        
    
    def get_current_url(self):
        """
        Return the current URL of the Selenium driver.

        Returns:
            str: The current URL.
        Example:
            url = su.get_current_url()
        """
        return self.driver.current_url
    
    def save_current_html(self, filename: str = "page_dump.html") -> None:
        """
        Save the current page's HTML source to a file for debugging.

        Args:
            filename (str): The filename to save the HTML to.

        Example:
            self.save_current_html("after_estado_tramites.html")
        """
        try:
            html_source = self.driver.page_source
            with open(filename, "w", encoding="utf-8") as f:
                f.write(html_source)
            logging.info(f"Saved current HTML to {filename}")
        except Exception as error:
            logging.error(f"Failed to save HTML: {error}")
        
    
    def wait_for_download_completion(self, download_dir: str, file_pattern: str, timeout: int = 300) -> bool:
        """
        Wait for file download completion in a directory with enhanced pattern matching and error handling.

        Args:
            download_dir (str): Directory where files are downloaded.
            file_pattern (str): Pattern to match downloaded files (supports glob patterns like '*.pdf', 'DetalleNomina_*', or exact names).
            timeout (int): Max wait time in seconds.

        Returns:
            bool: True if download completed successfully, False otherwise.

        Raises:
            FileNotFoundError: If download directory doesn't exist.

        Example:
            su.wait_for_download_completion("output/_others", "*.pdf")
            su.wait_for_download_completion("output/_others", "DetalleNomina_123*")
            su.wait_for_download_completion("output/_others", "report.pdf")
        """
        import glob
        import os
        import time
        
        # Validate download directory exists
        if not os.path.exists(download_dir):
            logging.error(f"Download directory '{download_dir}' does not exist")
            raise FileNotFoundError(f"Download directory '{download_dir}' does not exist")
        
        start_time = time.time()
        initial_file_count = len(os.listdir(download_dir))
        check_interval = 2  # Check every 2 seconds
        last_progress_log = 0
        
        logging.info(f"Waiting for download completion in '{download_dir}' with pattern '{file_pattern}'")
        logging.info(f"Initial file count: {initial_file_count}, timeout: {timeout}s")
        
        # Normalize pattern for glob matching
        if not any(char in file_pattern for char in ['*', '?', '[']):
            # Exact filename - add wildcard for partial matches during download
            glob_pattern = f"*{file_pattern}*"
        else:
            # Already contains wildcards
            glob_pattern = file_pattern
        
        while time.time() - start_time < timeout:
            try:
                elapsed_time = time.time() - start_time
                
                # Log progress every 30 seconds
                if elapsed_time - last_progress_log >= 30:
                    remaining_time = timeout - elapsed_time
                    logging.info(f"Download check in progress... {remaining_time:.0f}s remaining")
                    last_progress_log = elapsed_time
                
                # Check for files matching the pattern
                pattern_path = os.path.join(download_dir, glob_pattern)
                matching_files = glob.glob(pattern_path)
                
                # Filter out incomplete download files
                complete_files = [
                    f for f in matching_files 
                    if not f.endswith(('.crdownload', '.tmp', '.part', '.download'))
                ]
                
                if complete_files:
                    # Check if any matching file is complete
                    for file_path in complete_files:
                        if self._is_download_complete(file_path):
                            file_size = os.path.getsize(file_path)
                            logging.info(f"Download completed: {os.path.basename(file_path)} ({file_size:,} bytes)")
                            return True
                
                # Check for active downloads (partial files)
                partial_extensions = ['.crdownload', '.tmp', '.part', '.download']
                partial_files = []
                for ext in partial_extensions:
                    partial_files.extend(glob.glob(os.path.join(download_dir, f"*{ext}")))
                
                # Check if any partial files match our pattern
                pattern_partial_files = [
                    f for f in partial_files 
                    if any(pattern_part in os.path.basename(f) for pattern_part in file_pattern.replace('*', '').split())
                ]
                
                if pattern_partial_files:
                    logging.debug(f"Found {len(pattern_partial_files)} partial download files matching pattern, continuing to wait...")
                elif partial_files:
                    logging.debug(f"Found {len(partial_files)} partial download files (not matching pattern), continuing to wait...")
                else:
                    current_file_count = len(os.listdir(download_dir))
                    if current_file_count > initial_file_count:
                        logging.debug("New files detected in directory, continuing to wait...")
                    else:
                        logging.debug("No matching files or active downloads detected yet...")
                
                time.sleep(check_interval)
                
            except Exception as e:
                logging.warning(f"Error checking download status: {e}")
                time.sleep(check_interval)
        
        # Final check for any files that might have completed just as timeout occurred
        try:
            pattern_path = os.path.join(download_dir, glob_pattern)
            matching_files = glob.glob(pattern_path)
            complete_files = [
                f for f in matching_files 
                if not f.endswith(('.crdownload', '.tmp', '.part', '.download'))
            ]
            
            for file_path in complete_files:
                if self._is_download_complete(file_path):
                    logging.info(f"Download completed just before timeout: {os.path.basename(file_path)}")
                    return True
        except Exception as e:
            logging.warning(f"Error in final download check: {e}")
        
        logging.error(f"Download timeout after {timeout} seconds for pattern '{file_pattern}'")
        return False
    
    def is_file_download_complete(file_path: str) -> bool:
        """
        Check if file download is complete by monitoring file size stability.

        Args:
            file_path (str): Path to the file.
        Returns:
            bool: True if complete, False otherwise.
        Example:
            SeleniumUtils.is_file_download_complete("output/_others/file.txt")
        """
        try:
            if not os.path.exists(file_path):
                return False
                
            initial_size = os.path.getsize(file_path)
            time.sleep(2)
            final_size = os.path.getsize(file_path)
            
            # File is complete if size is stable and > 0
            return initial_size == final_size and final_size > 0
            
        except Exception:
            return False

    def _is_download_complete(self, file_path: str) -> bool:
        """
        Check if a file download is complete by verifying file stability.

        Args:
            file_path (str): Path to the file.
        Returns:
            bool: True if complete, False otherwise.
        """
        try:
            if not os.path.exists(file_path):
                return False
                
            # Check if file has .crdownload or .tmp extension (incomplete)
            if file_path.endswith(('.crdownload', '.tmp')):
                return False
                
            # Check file size stability (file size doesn't change over 2 seconds)
            initial_size = os.path.getsize(file_path)
            time.sleep(2)
            current_size = os.path.getsize(file_path)
            
            if initial_size == current_size and current_size > 0:
                logging.debug(f"File appears complete: {os.path.basename(file_path)} ({current_size} bytes)")
                return True
            else:
                logging.debug(f"File still growing: {os.path.basename(file_path)} ({initial_size} -> {current_size} bytes)")
                return False
                
        except Exception as e:
            logging.warning(f"Error checking file completion for {file_path}: {e}")
            return False
    
    def check_file_downloaded(self, download_dir: str, file_pattern: str) -> bool:
        """
        Check if a file matching the pattern exists and is fully downloaded.

        Args:
            download_dir (str): Download directory.
            file_pattern (str): Pattern to match file name.
        Returns:
            bool: True if found and complete, False otherwise.
        Example:
            su.check_file_downloaded("output/_others", "Mis_Nominas_30062025")
        """
        logging.info(f"Checking for downloaded file in '{download_dir}' with pattern '{file_pattern}'")
        files = glob.glob(os.path.join(download_dir, f"*{file_pattern}*"))
        for file in files:
            if not (file.endswith('.crdownload') or file.endswith('.part')):
                logging.info(f"Downloaded file found: {file}")
                return True
        logging.warning(f"No completed file found for pattern '{file_pattern}' in '{download_dir}'")
        return False
    
    def keep_session_active(self):
        """
        Keep the browser session active by performing a minimal action.
        Example:
            su.keep_session_active()
        """
        try:
            # Try to move the mouse to the body element to keep the session alive
            body = self.find_element(By.TAG_NAME, "body", timeout=1)
            if body:
                ActionChains(self.driver).move_to_element(body).perform()
                self.driver.execute_script(
                    "arguments[0].dispatchEvent(new MouseEvent('mousemove', {bubbles: true}));", body
                )
                logging.debug("Session kept active by mousemove on body element.")
            else:
                raise Exception("Body element not found")
        except Exception as e:
            logging.debug(f"Could not perform mousemove to keep session active: {e}")
            # As a fallback, try scrolling a bit
            try:
                self.driver.execute_script("window.scrollBy(0,1); window.scrollBy(0,-1);")
                logging.debug("Session kept active by scrolling.")
            except Exception as scroll_e:
                logging.debug(f"Could not scroll to keep session active: {scroll_e}")
                
    def search_value_in_all_frames(
        self,
        value: str,
        by: By = By.XPATH,
        selector_template: str = "//*[contains(text(), '{value}')]"
    ) -> list:
        """
        Recursively search for a value (text) in all iframes and frames (including nested) on the current page.

        Args:
            value (str): The text value to search for.
            by (By): Selenium By selector type (default: By.XPATH).
            selector_template (str): Selector template with '{value}' placeholder.

        Returns:
            list: List of dicts with frame path info and element(s) if found.

        Example:
            results = su.search_value_in_all_frames("Resolución aprobada")
            for r in results:
                print(f"Found in frame path {r['frame_path']} (id={r['id']}, name={r['name']})")

        Raises:
            Exception: If frame switching fails.
        """
        results = []
        self.driver.switch_to.default_content()

        def _search_in_frames(frame_path: list):
            # Find all frames/iframes in the current context
            frames = self.driver.find_elements(By.TAG_NAME, "iframe") + self.driver.find_elements(By.TAG_NAME, "frame")
            for idx, frame in enumerate(frames):
                frame_id = frame.get_attribute("id")
                frame_name = frame.get_attribute("name")
                current_path = frame_path + [idx]
                try:
                    self.driver.switch_to.default_content()
                    # Switch through the frame path to reach the current nested frame
                    for p in frame_path:
                        nested_frames = self.driver.find_elements(By.TAG_NAME, "iframe") + self.driver.find_elements(By.TAG_NAME, "frame")
                        self.driver.switch_to.frame(nested_frames[p])
                    self.driver.switch_to.frame(frame)
                    selector = selector_template.format(value=value)
                    elements = self.driver.find_elements(by, selector)
                    if elements:
                        logging.info(f"Value '{value}' found in frame path {current_path} (id={frame_id}, name={frame_name})")
                        results.append({
                            "frame_path": current_path,
                            "id": frame_id,
                            "name": frame_name,
                            "elements": elements
                        })
                    # Recursively search in nested frames
                    _search_in_frames(current_path)
                except Exception as e:
                    logging.warning(f"Could not search in frame path {current_path}: {e}")
                finally:
                    self.driver.switch_to.default_content()

        _search_in_frames([])
        return results
    
    
    
    def rename_downloaded_file(self, old_pattern: str, new_filename: str, wait_time: int = 30) -> str:
        """
        Rename the most recent downloaded file matching a pattern in the download folder.

        Args:
            old_pattern (str): Glob pattern to match the downloaded file (e.g., '*.pdf' or 'DetalleNomina_*.pdf').
            new_filename (str): New filename (with extension) for the file.
            wait_time (int): Max seconds to wait for the file to appear.

        Returns:
            str: Full path to the renamed file.

        Raises:
            FileNotFoundError: If no matching file is found within the wait time.
            Exception: If renaming fails.

        Example:
            su.rename_downloaded_file('*.pdf', 'my_report.pdf')
        """
        import glob
        import shutil

        download_dir = self.download_folder
        end_time = time.time() + wait_time
        matched_file = None

        logging.info(f"Waiting for file matching '{old_pattern}' in '{download_dir}' to appear...")
        
        while time.time() < end_time:
            files = glob.glob(os.path.join(download_dir, old_pattern))
            # Filter out incomplete downloads and ensure files are complete
            complete_files = []
            for f in files:
                if not f.endswith(('.crdownload', '.tmp', '.part')):
                    if self._is_download_complete(f):
                        complete_files.append(f)
            
            if complete_files:
                # Pick the most recently modified file
                matched_file = max(complete_files, key=os.path.getmtime)
                logging.info(f"Found matching file: {os.path.basename(matched_file)}")
                break
            
            time.sleep(1)

        if not matched_file:
            logging.error(f"No file matching '{old_pattern}' found in '{download_dir}' after {wait_time} seconds.")
            raise FileNotFoundError(f"No file matching '{old_pattern}' found in '{download_dir}' after {wait_time} seconds.")

        new_path = os.path.join(download_dir, new_filename)
        
        # Check if destination file already exists
        if os.path.exists(new_path):
            logging.warning(f"Destination file '{new_path}' already exists. It will be overwritten.")
        
        try:
            shutil.move(matched_file, new_path)
            logging.info(f"Successfully renamed '{os.path.basename(matched_file)}' to '{new_filename}'")
            return new_path
        except Exception as e:
            logging.error(f"Failed to rename '{os.path.basename(matched_file)}' to '{new_filename}': {e}")
            raise
        
    def get_current_element_xpath(self, element=None):
        """
        Get the XPath of the current active element or a specific element.
        Works with SeleniumUtils framework.
        
        Args:
            element: Specific WebElement to get XPath for. If None, gets active element.
            
        Returns:
            str: XPath of the element
            
        Example:
            # Get current element's XPath
            xpath = self.get_current_element_xpath()
            logging.info(f"Current XPath: {xpath}")
        """
        try:
            if element is None:
                # Get currently active/focused element using SeleniumUtils
                element = self.driver.switch_to.active_element
            
            # JavaScript to generate XPath
            js_script = """
            function getElementXPath(element) {
                if (element && element.id !== '') {
                    return '//*[@id="' + element.id + '"]';
                }
                if (element === document.body) {
                    return '/html/body';
                }
                
                var ix = 0;
                var siblings = element.parentNode.childNodes;
                for (var i = 0; i < siblings.length; i++) {
                    var sibling = siblings[i];
                    if (sibling === element) {
                        var tagName = element.tagName.toLowerCase();
                        return getElementXPath(element.parentNode) + '/' + tagName + '[' + (ix + 1) + ']';
                    }
                    if (sibling.nodeType === 1 && sibling.tagName === element.tagName) {
                        ix++;
                    }
                }
            }
            return getElementXPath(arguments[0]);
            """
            
            xpath = self.driver.execute_script(js_script, element)
            return xpath
            
        except Exception as e:
            logging.warning(f"Could not get element XPath: {e}")
            return "Unknown XPath"

    def log_current_position(self, description="Current position"):
        """
        Log the current driver position with XPath and element details.
        Works with SeleniumUtils framework.
        
        Args:
            description: Description of what we're checking
            
        Example:
            self.log_current_position("After clicking submit button")
        """
        try:
            # Get active element using SeleniumUtils
            active_element = self.driver.switch_to.active_element
            
            # Get XPath
            xpath = self.get_current_element_xpath(active_element)
            
            # Get element details
            tag_name = active_element.tag_name
            element_id = active_element.get_attribute('id') or 'No ID'
            element_class = active_element.get_attribute('class') or 'No class'
            element_text = active_element.text[:50] + ('...' if len(active_element.text) > 50 else '')
            
            # Current URL using SeleniumUtils
            current_url = self.get_current_url()
            
            # Current window title
            window_title = self.driver.title
            
            logging.info(f"🎯 {description}:")
            logging.info(f"   XPath: {xpath}")
            logging.info(f"   Element: <{tag_name} id='{element_id}' class='{element_class}'")
            logging.info(f"   Text: '{element_text}'")
            logging.info(f"   URL: {current_url}")
            logging.info(f"   Title: {window_title}")
            
            # Check if we're in an iframe using SeleniumUtils
            try:
                frame_info = self.driver.execute_script("""
                    if (window.self !== window.top) {
                        return {
                            'in_frame': true,
                            'frame_name': window.name || 'unnamed',
                            'frame_url': window.location.href
                        };
                    } else {
                        return {'in_frame': false};
                    }
                """)
                
                if frame_info['in_frame']:
                    logging.info(f"   Frame: Inside iframe '{frame_info['frame_name']}' - {frame_info['frame_url']}")
                else:
                    logging.info(f"   Frame: Main document (not in iframe)")
                    
            except Exception as e:
                logging.debug(f"Could not check iframe status: {e}")
            
        except Exception as e:
            logging.error(f"Error getting current position: {e}")

    def view_current_context(self):
        """
        Enhanced version of view_iframes that also shows current position.
        Works with SeleniumUtils framework.
        """
        try:
            logging.info("🔍 CURRENT DRIVER CONTEXT:")
            
            # Get current URL and title using SeleniumUtils
            current_url = self.get_current_url()
            window_title = self.driver.title
            logging.info(f"   URL: {current_url}")
            logging.info(f"   Title: {window_title}")
            
            # Check iframe context using SeleniumUtils
            try:
                is_in_frame = self.driver.execute_script("return window.self !== window.top;")
                if is_in_frame:
                    frame_location = self.driver.execute_script("return window.location.href;")
                    logging.info(f"   🖼️  Inside iframe: {frame_location}")
                else:
                    logging.info(f"   📄 Main document (not in iframe)")
            except:
                logging.info(f"   ❓ Could not determine iframe context")
            
            # List all available iframes using SeleniumUtils
            iframes = self.driver.find_elements(By.TAG_NAME, "iframe")
            logging.info(f"   📋 Available iframes: {len(iframes)}")
            
            for i, iframe in enumerate(iframes):
                iframe_id = iframe.get_attribute('id') or f'iframe-{i}'
                iframe_name = iframe.get_attribute('name') or 'No name'
                iframe_src = iframe.get_attribute('src') or 'No src'
                logging.info(f"      Frame {i}: id='{iframe_id}', name='{iframe_name}', src='{iframe_src[:60]}...'")
            
            # Get current active element position
            self.log_current_position("Active element")
            
        except Exception as e:
            logging.error(f"Error in view_current_context: {e}")

    def where_am_i(self):
        """Quick one-line position check - works with SeleniumUtils framework"""
        try:
            active_element = self.driver.switch_to.active_element
            xpath = self.get_current_element_xpath(active_element)
            url = self.get_current_url()
            logging.info(f"🎯 POSITION: {xpath} | URL: {url}")
        except Exception as e:
            logging.info(f"🎯 POSITION: Error getting position - {e}")