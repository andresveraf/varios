
from process_scripts.base_process import ProcessBase
import os
import datetime as dt

class ProcessFile_Webscraping(ProcessBase):



    def __init__(self, config:dict):
        ProcessBase.__init__(self, config=config) 
        self.state_name    = "Workflow"  # Change with the class name 
        self.now           = dt.datetime.now()
        # Get the last month and year for the email subject
        last_month_date = self.now.replace(day=1) - dt.timedelta(days=1)
        last_period = last_month_date.strftime("%Y-%m")
        



logging = ""
df = ""  # Assuming df is defined somewhere in your code

# Reorder columns :
column_to_move = 'REGIMEN'
target_column = 'NOMBRE'

# Get the current list of columns as a mutable list
cols = df.columns.tolist()

# --- Robustness check (optional, but recommended) ---
if column_to_move not in cols:
    logging.warning(f"Error: Column '{column_to_move}' not found in DataFrame.")
    # You might want to exit or handle this error differently
elif target_column not in cols:
    logging.warning(f"Error: Target column '{target_column}' not found in DataFrame.")
    # You might want to exit or handle this error differently
else:
    # 1. Remove the column to move from its current position
    cols.remove(column_to_move)

    # 2. Find the index of the target column in the *modified* list
    # (The index might have shifted after removing 'column_to_move')
    target_index = cols.index(target_column)

    # 3. Insert the column to move right after the target column's index
    cols.insert(target_index + 1, column_to_move)

    # 4. Reindex the DataFrame with the new column order
# This creates a new DataFrame with the columns in the desired order
df = df[cols]




# Strip columns
# Data Cleaning with error handling
logging.info("Starting string data cleaning")
str_cols = df.select_dtypes(include=['object']).columns
logging.info(f"String columns identified for cleaning: {list(str_cols)}")
if len(str_cols) > 0:
    # Strip whitespace from all string columns
    df[str_cols] = df[str_cols].applymap(lambda x: x.strip() if isinstance(x, str) else x)
    logging.debug(f"Cleaned {len(str_cols)} string columns")
    
    
# Ruts with letters before the '-' is for the data extraction of the PDF, the next line is to standardize the RUT format
df['Rut'] = df['Rut'].astype(str).str.replace(r'[^0-9]+', '', regex=True) + '-' + df['Rut'].astype(str).str.extract(r'-([a-zA-Z0-9])$')[0]
#str.replace(r'[^0-9]+', '', regex=True): removes all non-digit characters from the part before the dash.
#str.extract(r'-([a-zA-Z0-9])$')[0]: extracts the check digit after the dash.

def clean_rut(rut):
    import re
    if not isinstance(rut, str) or not rut or rut.lower() == 'nan':
        return None
    rut = rut.replace(' ', '')  # Remove all spaces
    match = re.match(r'^(\d+)-([a-zA-Z0-9])$', rut)
    if match:
        return f"{match.group(1)}-{match.group(2)}"
    # If dash is missing, try to extract digits and last character
    digits = ''.join(re.findall(r'\d+', rut))
    check = re.findall(r'[a-zA-Z0-9]$', rut)
    if digits and check:
        return f"{digits}-{check[0]}"
    return None

df['Rut'] = df['Rut'].apply(clean_rut)


# It will convert values like 20240530500850.0 to 20240530500850 as required.
df['Archivo'] = df['Archivo'].astype(str).str.replace('.0','',regex=False)


##############################################################
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill
def apply_business_format(self, excel_path: str):
        """
        Apply business formatting to the final Excel file.
        - Bold headers with wrap text
        - Set header background color
        - Center header alignment
        - Auto-adjust column widths with a maximum of 20 characters
        - Apply wrap text only to header row

        Args:
            excel_path (str): Path to the Excel file to format

        Returns:
            None

        Raises:
            Exception: If Excel formatting fails

        Example:
            self.apply_business_format("/path/to/results.xlsx")
        """
        try:
            logging.info(f"Applying business formatting to Excel file: {excel_path}")
            
            wb = openpyxl.load_workbook(excel_path)
            ws = wb.active

            # Format header row (row 1) with wrap text
            for cell in ws[1]:
                cell.font = Font(bold=True, size=12, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="16537E")
                cell.alignment = Alignment(horizontal="center", wrap_text=True)

            # Auto-adjust column widths with max 20 characters
            for col in ws.columns:
                max_length = 0
                col_letter = col[0].column_letter
                
                # Calculate max length without modifying cell formatting
                for cell in col:
                    try:
                        cell_length = len(str(cell.value)) if cell.value is not None else 0
                        if cell_length > max_length:
                            max_length = cell_length
                    except Exception:
                        pass
                
                # Set column width with maximum of 20
                adjusted_width = min(max_length + 2, 20)
                ws.column_dimensions[col_letter].width = adjusted_width

            wb.save(excel_path)
            logging.info("Business formatting applied successfully")
            
        except Exception as e:
            error_msg = f"Error applying business formatting to Excel file: {e}"
            logging.error(error_msg)
            raise BusinessException(error_msg)
        
        
        
        
finally:
    # Ensure the Selenium driver is closed at the end of the process
    try:
        self.driver.close_driver()
        logging.info("Selenium driver closed successfully.")
    except Exception as close_error:
        logging.warning(f"Error closing Selenium driver: {close_error}")
logging.info(f"Finished state: {self.state_name}")







    def send_email(self) -> None:
        """
        Send email with processing results and summary statistics.

        Raises:
            Exception: If there's an error during email sending process.
        """
        logging.info("Preparing to send email with results...")
        try:
            # Sharepoint Sobrevivencia - Inicio
            # Create body content
            
            
            link_url = "https://my.metlife.com/teams/RS-Sobrevivencia/SitePages/Inicio.aspx?RootFolder=%2Fteams%2FRS%2DSobrevivencia%2FDocumentos%20compartidos%2FSolicitu&FolderCTID=0x012000C52AB31AEAA28D4CA022D5884214D03C&View=%7BF4A63379%2D5EA6%2D4952%2D8445%2D5086A2E08D0D%7D"
            anchor = f'<a href="{link_url}" target="_blank" rel="noopener noreferrer">Acceder al archivo en SharePoint</a>'

            body_content = f"""Buenos dias, informamos que el archivo Solicitu de Sobrevivencia, Solicitu de Beneficiarios con información del Registro Civil ha sido generado exitosamente.
            y se encuentra en el SharePoint habilitado para el proceso: <br>
                        <div>
                            {anchor}
                        </div>"""
            
            # Create a temporary body file
            body_file_path = "temp_email_body.txt"
            with open(body_file_path, "w", encoding="utf-8") as f:
                f.write(body_content)
            
            # Get email wrapper file from config
            wrapper_file = self.config["EMAIL"]["WRAPPER_FILE"]
            

            
            send_email(
                subject=f'Solicitu Sobrevivencia {self.now.strftime("%d-%m-%Y")}',
                to=['andres.n.vera@provida.cl',],  # 'jose.fernandez@metlife.cl','nicolas.pinto@metlife.cl' // 'vgomezg@provida.cl','jose.fernandez@metlife.cl',
                cc=[],
                bcc=[],
                body_file=body_file_path,
                wrapper_file=wrapper_file,
                body_fields=[],
                wrapper_fields=[],
                attachments=[self.output_filepath_sobrevivencia] if os.path.exists(self.output_filepath_sobrevivencia) else [],
                environment=self.config["METADATA"]["ENVIRONMENT"]
            )
            
            # Clean up temporary file
            if os.path.exists(body_file_path):
                os.remove(body_file_path)
                
            logging.info("Email sent successfully")
        except Exception as e:
            logging.error(f"Error sending email: {e}")
            
            
            
            
#################################
import inspect

def example_function(self):
    """
    Example function to demonstrate logging the function name.
    """
    func_name = inspect.currentframe().f_code.co_name
    logging.info(f"--- START FOR SCRIPT: {func_name} ---")