# Utilities Index (`src/utils`)

This local utilities index is the preferred canonical reference for available helper functions and classes in the codebase. Keep it updated when utils change.

- `fmw_utils.py` - Core framework utilities: `start_logging()`, `Config()`, `read_json()`, `save_excel_file()`, `create_folder()`, `delete_folder()`, `kill_processes()`, date utilities.
- `selenium_utils.py` - Browser automation: `SeleniumUtils()`, `init_edge_driver()`, `open_website()`, `element_exists()`, `click_element()`, `populate_field()`, `wait_for_element()`, `take_screenshot()`.
- `send_email_utils.py` - Email utilities: `send_email()`, `df2html()`, `read_recipients_file()`.
- `send_exceptions_emails.py` - Exception email handling: `ExceptionEmails()`, `send_system_exception()`, `send_business_exception()`.
- `credentials_utils.py` - Credentials handling: `Credentials()`, `decrypt_msg()`, `inti_desiered_credentials()`.
- `xlwings_utils.py` - Excel automation helpers and entrypoints.

Notes:

- When adding new utility functions, update this file with a one-line entry and file path.
- This file is the preferred place to look for helpers during migration.
