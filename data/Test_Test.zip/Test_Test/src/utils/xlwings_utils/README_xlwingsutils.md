# XLWings Utilities Documentation

## Overview

The `XLWingsUtils` class provides a comprehensive set of utilities for Excel automation using the xlwings library. This class encapsulates common Excel operations and provides a clean, object-oriented interface for working with Excel files, sheets, data filtering, pivot tables, and formatting.

## Features

### Core Functionality
- **Application Management**: Start/stop Excel application with custom settings
- **File Operations**: Open, close, save workbooks with error handling
- **Sheet Management**: Create, delete, rename worksheets
- **Data Operations**: Import/export pandas DataFrames
- **Filtering**: Apply various types of filters (text, date, criteria-based)
- **Pivot Tables**: Create and extract data from pivot tables
- **Formatting**: Apply professional formatting to ranges and headers
- **Search Operations**: Find cells and values based on criteria
- **Row/Column Operations**: Insert, delete, copy ranges

### Error Handling
- Comprehensive exception handling for all operations
- Logging support for debugging and monitoring
- Safe cleanup of resources using context managers

## Installation

```python
# Required packages
pip install xlwings pandas
```

## Basic Usage

### Context Manager (Recommended)

```python
from xlwingsutils import XLWingsUtils

# Use with context manager for automatic cleanup
with XLWingsUtils(visible=True, display_alerts=False) as xl_utils:
    wb = xl_utils.open_workbook("data.xlsx")
    sheet = wb.sheets[0]
    
    # Perform operations
    df = xl_utils.sheet_to_dataframe(sheet)
    print(f"Loaded {len(df)} rows")
    
    # Workbook automatically closed when exiting context
```

### Manual Management

```python
# Manual initialization and cleanup
xl_utils = XLWingsUtils(visible=False)
xl_utils.start_app()

try:
    wb = xl_utils.open_workbook("data.xlsx")
    # ... perform operations
finally:
    xl_utils.close_all_workbooks()
    xl_utils.quit_app()
```

## Detailed Examples

### 1. Data Processing Workflow

```python
import pandas as pd
from xlwingsutils import XLWingsUtils

def process_sales_data(file_path: str):
    """Process sales data with filtering and analysis."""
    
    with XLWingsUtils(visible=True) as xl_utils:
        # Open workbook
        wb = xl_utils.open_workbook(file_path)
        sheet = wb.sheets['Sales Data']
        
        # Apply date filter for current month
        xl_utils.apply_date_filter(sheet, "A", "01", "31", 2024, 10)
        
        # Get filtered data
        df = xl_utils.sheet_to_dataframe(sheet, header=True)
        
        # Calculate totals
        total_sales = xl_utils.sum_visible_cells(sheet, "D", 2)
        print(f"Total sales for filtered period: ${total_sales:,.2f}")
        
        # Create summary sheet
        summary_sheet = xl_utils.add_sheet(wb, "Summary")
        
        # Write summary data
        summary_df = df.groupby('Region')['Sales'].sum().reset_index()
        xl_utils.dataframe_to_sheet(summary_df, summary_sheet, "A1")
        
        # Format header
        xl_utils.format_header_row(summary_sheet, "A1:B1")
        xl_utils.autofit_columns(summary_sheet)
        
        # Save results
        wb.save()
        return df

# Usage
sales_df = process_sales_data("monthly_sales.xlsx")
```

### 2. Pivot Table Creation

```python
def create_sales_analysis(source_file: str, output_file: str):
    """Create comprehensive sales analysis with pivot tables."""
    
    with XLWingsUtils(visible=True) as xl_utils:
        # Open source data
        wb = xl_utils.open_workbook(source_file)
        data_sheet = wb.sheets['RawData']
        
        # Create analysis sheet
        analysis_sheet = xl_utils.add_sheet(wb, "Analysis")
        
        # Create multiple pivot tables
        
        # 1. Sales by Region and Product
        xl_utils.create_pivot_table(
            source_sheet=data_sheet,
            target_sheet=analysis_sheet,
            target_cell="A1",
            pivot_name="RegionProductSales",
            row_fields=["Region", "Product"],
            data_fields=[("Sales", -4157), ("Quantity", -4157)],  # Sum
            filter_fields={"Year": ["2024"]}
        )
        
        # 2. Monthly trends
        xl_utils.create_pivot_table(
            source_sheet=data_sheet,
            target_sheet=analysis_sheet,
            target_cell="H1",
            pivot_name="MonthlyTrends",
            row_fields=["Month"],
            col_fields=["Product"],
            data_fields=[("Sales", -4157)]
        )
        
        # Extract pivot data for further processing
        region_data = xl_utils.extract_pivot_table_data(analysis_sheet, "RegionProductSales")
        if region_data is not None:
            print("Region analysis completed successfully")
        
        # Save analysis
        wb.save_as(output_file)

# Usage
create_sales_analysis("raw_sales.xlsx", "sales_analysis.xlsx")
```

### 3. Data Cleaning and Validation

```python
def clean_financial_data(file_path: str):
    """Clean and validate financial data."""
    
    with XLWingsUtils(visible=False) as xl_utils:
        wb = xl_utils.open_workbook(file_path)
        sheet = wb.sheets['Financial Data']
        
        # Convert text numbers to actual numbers
        xl_utils.convert_text_to_numbers(sheet, ["C", "D", "E", "F"], start_row=2)
        
        # Find and highlight errors
        error_location = xl_utils.find_cell(sheet, "#N/A")
        if error_location:
            row, col = error_location
            print(f"Found error at row {row}, column {col}")
        
        # Apply filters to find problematic data
        xl_utils.apply_autofilter(sheet, "G", ["ERROR", "INVALID"])
        
        # Get clean data
        xl_utils.clear_filters(sheet)
        clean_df = xl_utils.sheet_to_dataframe(sheet)
        
        # Validate data ranges
        validation_results = {}
        for column in ["Amount", "Quantity"]:
            if column in clean_df.columns:
                validation_results[column] = {
                    'min': clean_df[column].min(),
                    'max': clean_df[column].max(),
                    'nulls': clean_df[column].isnull().sum()
                }
        
        print("Data validation results:", validation_results)
        
        # Save cleaned version
        clean_sheet = xl_utils.add_sheet(wb, "Clean Data")
        xl_utils.dataframe_to_sheet(clean_df, clean_sheet, "A1")
        
        wb.save()
        return clean_df

# Usage
cleaned_data = clean_financial_data("financial_raw.xlsx")
```

### 4. Report Generation

```python
def generate_monthly_report(data_files: list, report_date: str):
    """Generate consolidated monthly report from multiple files."""
    
    with XLWingsUtils(visible=True) as xl_utils:
        # Create new workbook for report
        xl_utils.start_app()
        wb = xl_utils.app.books.add()
        
        # Rename default sheet
        summary_sheet = wb.sheets[0]
        xl_utils.rename_sheet(summary_sheet, "Executive Summary")
        
        all_data = []
        
        # Process each data file
        for i, file_path in enumerate(data_files):
            try:
                source_wb = xl_utils.open_workbook(file_path)
                source_sheet = source_wb.sheets[0]
                
                # Extract data
                df = xl_utils.sheet_to_dataframe(source_sheet)
                df['Source'] = f"File_{i+1}"
                all_data.append(df)
                
                # Create individual sheet for this data
                file_sheet = xl_utils.add_sheet(wb, f"Data_{i+1}")
                xl_utils.dataframe_to_sheet(df, file_sheet, "A1")
                xl_utils.format_header_row(file_sheet, "A1:Z1")
                xl_utils.autofit_columns(file_sheet)
                
                xl_utils.close_workbook(source_wb)
                
            except Exception as e:
                print(f"Error processing {file_path}: {e}")
        
        # Consolidate data
        if all_data:
            consolidated_df = pd.concat(all_data, ignore_index=True)
            
            # Create summary
            summary_stats = consolidated_df.groupby('Source').agg({
                'Sales': ['sum', 'mean', 'count'],
                'Quantity': ['sum', 'mean']
            }).round(2)
            
            # Write summary to main sheet
            xl_utils.dataframe_to_sheet(summary_stats, summary_sheet, "A3")
            
            # Add title and formatting
            summary_sheet.range("A1").value = f"Monthly Report - {report_date}"
            summary_sheet.range("A1").api.Font.Size = 16
            summary_sheet.range("A1").api.Font.Bold = True
            
            xl_utils.format_header_row(summary_sheet, "A3:Z3")
            xl_utils.autofit_columns(summary_sheet)
        
        # Save report
        report_filename = f"Monthly_Report_{report_date.replace('/', '_')}.xlsx"
        wb.save_as(report_filename)
        print(f"Report saved as: {report_filename}")

# Usage
data_files = ["sales_north.xlsx", "sales_south.xlsx", "sales_west.xlsx"]
generate_monthly_report(data_files, "2024/10")
```

### 5. Error Handling and Corrupted Files

```python
def process_files_with_error_handling(file_paths: list):
    """Process multiple files with comprehensive error handling."""
    
    results = {
        'successful': [],
        'failed': [],
        'corrupted': []
    }
    
    with XLWingsUtils(visible=False) as xl_utils:
        for file_path in file_paths:
            try:
                # Try normal opening first
                wb = xl_utils.open_workbook(file_path)
                
                # Process successfully opened file
                sheet = wb.sheets[0]
                df = xl_utils.sheet_to_dataframe(sheet)
                
                print(f"Successfully processed {file_path}: {len(df)} rows")
                results['successful'].append(file_path)
                
                xl_utils.close_workbook(wb)
                
            except FileNotFoundError:
                print(f"File not found: {file_path}")
                results['failed'].append(file_path)
                
            except Exception as e:
                print(f"Error with {file_path}: {e}")
                
                # Try opening with error suppression for corrupted files
                wb_corrupted = xl_utils.open_workbook_with_errors(file_path)
                if wb_corrupted:
                    try:
                        sheet = wb_corrupted.sheets[0]
                        df = xl_utils.sheet_to_dataframe(sheet)
                        print(f"Recovered corrupted file {file_path}: {len(df)} rows")
                        results['corrupted'].append(file_path)
                        xl_utils.close_workbook(wb_corrupted)
                    except:
                        print(f"Could not recover {file_path}")
                        results['failed'].append(file_path)
                else:
                    results['failed'].append(file_path)
    
    return results

# Usage
file_list = ["data1.xlsx", "data2.xls", "corrupted.xlsx", "missing.xlsx"]
processing_results = process_files_with_error_handling(file_list)
print("Processing Results:", processing_results)
```

## Error Handling Best Practices

1. **Always use context managers** when possible for automatic cleanup
2. **Check file existence** before attempting to open
3. **Handle specific exceptions** for better error messages
4. **Use logging** for debugging and monitoring
5. **Validate data** after import operations
6. **Close workbooks explicitly** when not using context managers

## Performance Tips

1. **Set `visible=False`** for better performance when UI is not needed
2. **Disable `display_alerts`** to prevent interruptions
3. **Use `screen_updating=False`** for faster operations
4. **Process data in chunks** for large datasets
5. **Clear filters** before applying new ones
6. **Use appropriate data types** when converting to DataFrames

## Constants Reference

### AutoFilter Operators
- `xlFilterValues = 7`: Filter by list of values
- `xlAnd = 1`: AND operation
- `xlOr = 2`: OR operation

### Pivot Table Functions
- `xlSum = -4157`: Sum values
- `xlCount = -4112`: Count values
- `xlAverage = -4106`: Average values
- `xlMax = -4136`: Maximum values
- `xlMin = -4139`: Minimum values

### Orientation Constants
- `xlRowField = 1`: Row field in pivot table
- `xlColumnField = 2`: Column field in pivot table
- `xlPageField = 3`: Filter field in pivot table
- `xlDataField = 4`: Data field in pivot table

## Troubleshooting

### Common Issues

1. **Excel process not closing**: Always use context managers or call `quit_app()`
2. **Permission errors**: Ensure files are not open in Excel
3. **Memory issues**: Process large files in chunks
4. **COM errors**: Restart Python session if Excel becomes unresponsive
5. **Path issues**: Use absolute paths when possible

### Debug Mode

```python
import logging

# Enable detailed logging
logging.basicConfig(level=logging.DEBUG)

with XLWingsUtils(visible=True) as xl_utils:
    # Operations will now log detailed information
    pass
```

This utility class provides a robust foundation for Excel automation tasks while maintaining clean, readable code and proper error handling.
