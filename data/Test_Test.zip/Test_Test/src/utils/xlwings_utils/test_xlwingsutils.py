#!/usr/bin/env python3
"""
Test script for XLWingsUtils class.

This script demonstrates the functionality of the XLWingsUtils class
with practical examples and test cases.

Usage:
    python test_xlwingsutils.py
"""

import os
import pandas as pd
import logging
from xlwingsutils import XLWingsUtils


def create_sample_data():
    """Create sample Excel file for testing."""
    sample_data = {
        'Date': pd.date_range('2024-01-01', periods=100, freq='D'),
        'Region': ['North', 'South', 'East', 'West'] * 25,
        'Product': ['Product A', 'Product B', 'Product C'] * 33 + ['Product A'],
        'Sales': [1000 + i * 10 for i in range(100)],
        'Quantity': [10 + i for i in range(100)],
        'Category': ['Electronics', 'Clothing', 'Books'] * 33 + ['Electronics']
    }
    
    df = pd.DataFrame(sample_data)
    
    # Create sample file using xlwings
    with XLWingsUtils(visible=False) as xl_utils:
        xl_utils.start_app()
        wb = xl_utils.app.books.add()
        sheet = wb.sheets[0]
        
        xl_utils.rename_sheet(sheet, "SampleData")
        xl_utils.dataframe_to_sheet(df, sheet, "A1", header=True)
        xl_utils.format_header_row(sheet, "A1:F1")
        xl_utils.autofit_columns(sheet)
        
        wb.save_as("sample_data.xlsx")
        print("Sample data file created: sample_data.xlsx")
    
    return "sample_data.xlsx"


def test_basic_operations():
    """Test basic file operations."""
    print("\n=== Testing Basic Operations ===")
    
    sample_file = create_sample_data()
    
    with XLWingsUtils(visible=True, display_alerts=False) as xl_utils:
        # Test opening workbook
        wb = xl_utils.open_workbook(sample_file)
        print(f"✓ Opened workbook: {wb.name}")
        
        # Test sheet operations
        sheet = wb.sheets['SampleData']
        print(f"✓ Accessed sheet: {sheet.name}")
        
        # Test getting last row/column
        last_row = xl_utils.get_last_row(sheet)
        last_col = xl_utils.get_last_column(sheet)
        print(f"✓ Data range: {last_row} rows, {last_col} columns")
        
        # Test converting to DataFrame
        df = xl_utils.sheet_to_dataframe(sheet)
        print(f"✓ Converted to DataFrame: {len(df)} rows, {len(df.columns)} columns")
        
        # Test adding new sheet
        analysis_sheet = xl_utils.add_sheet(wb, "Analysis")
        print(f"✓ Added new sheet: {analysis_sheet.name}")
        
        # Test writing DataFrame to new sheet
        summary_df = df.groupby('Region')['Sales'].sum().reset_index()
        xl_utils.dataframe_to_sheet(summary_df, analysis_sheet, "A1")
        print("✓ Written summary data to new sheet")
        
        wb.save()
        print("✓ Workbook saved")


def test_filtering_operations():
    """Test filtering operations."""
    print("\n=== Testing Filtering Operations ===")
    
    with XLWingsUtils(visible=True) as xl_utils:
        wb = xl_utils.open_workbook("sample_data.xlsx")
        sheet = wb.sheets['SampleData']
        
        # Test text filter
        xl_utils.apply_autofilter(sheet, "B", ["North", "South"])
        print("✓ Applied region filter (North, South)")
        
        # Test sum of visible cells
        total_sales = xl_utils.sum_visible_cells(sheet, "D", 2)
        print(f"✓ Sum of visible sales: ${total_sales:,.2f}")
        
        # Clear filters
        xl_utils.clear_filters(sheet)
        print("✓ Cleared filters")
        
        # Test date filter
        xl_utils.apply_date_filter(sheet, "A", "01", "31", 2024, 1)
        print("✓ Applied date filter for January 2024")
        
        # Get filtered data
        filtered_df = xl_utils.sheet_to_dataframe(sheet)
        print(f"✓ Filtered data: {len(filtered_df)} rows")
        
        xl_utils.clear_filters(sheet)
        wb.save()


def test_search_operations():
    """Test search and find operations."""
    print("\n=== Testing Search Operations ===")
    
    with XLWingsUtils(visible=True) as xl_utils:
        wb = xl_utils.open_workbook("sample_data.xlsx")
        sheet = wb.sheets['SampleData']
        
        # Test finding cell
        location = xl_utils.find_cell(sheet, "Region")
        if location:
            row, col = location
            print(f"✓ Found 'Region' at row {row}, column {col}")
        
        # Test finding values in column
        results = xl_utils.find_values_in_column(
            sheet, ["North", "South"], "B", "D"
        )
        print(f"✓ Found values by region: {len(results['North'])} North, {len(results['South'])} South")
        
        wb.save()


def test_pivot_table_operations():
    """Test pivot table creation and extraction."""
    print("\n=== Testing Pivot Table Operations ===")
    
    with XLWingsUtils(visible=True) as xl_utils:
        wb = xl_utils.open_workbook("sample_data.xlsx")
        sheet = wb.sheets['SampleData']
        
        # Create pivot sheet
        pivot_sheet = xl_utils.add_sheet(wb, "PivotAnalysis")
        
        # Create pivot table
        try:
            xl_utils.create_pivot_table(
                source_sheet=sheet,
                target_sheet=pivot_sheet,
                target_cell="A1",
                pivot_name="RegionSalesAnalysis",
                row_fields=["Region"],
                col_fields=["Product"],
                data_fields=[("Sales", -4157)]  # Sum
            )
            print("✓ Created pivot table: RegionSalesAnalysis")
            
            # Extract pivot data
            pivot_df = xl_utils.extract_pivot_table_data(pivot_sheet, "RegionSalesAnalysis")
            if pivot_df is not None:
                print(f"✓ Extracted pivot data: {len(pivot_df)} rows")
            
        except Exception as e:
            print(f"⚠ Pivot table creation failed: {e}")
        
        wb.save()


def test_formatting_operations():
    """Test formatting operations."""
    print("\n=== Testing Formatting Operations ===")
    
    with XLWingsUtils(visible=True) as xl_utils:
        wb = xl_utils.open_workbook("sample_data.xlsx")
        
        # Create formatting test sheet
        format_sheet = xl_utils.add_sheet(wb, "FormattingTest")
        
        # Create test data
        test_data = pd.DataFrame({
            'Product': ['Item 1', 'Item 2', 'Item 3'],
            'Sales': [1000, 2000, 3000],
            'Profit': [100, 200, 300]
        })
        
        xl_utils.dataframe_to_sheet(test_data, format_sheet, "A1")
        print("✓ Added test data")
        
        # Format header
        xl_utils.format_header_row(format_sheet, "A1:C1", bg_color=(0, 100, 200))
        print("✓ Formatted header row")
        
        # Autofit columns
        xl_utils.autofit_columns(format_sheet, "A1:C4")
        print("✓ Autofitted columns")
        
        # Test number conversion
        xl_utils.convert_text_to_numbers(format_sheet, ["B", "C"], 2)
        print("✓ Converted text to numbers")
        
        wb.save()


def test_row_column_operations():
    """Test row and column manipulation."""
    print("\n=== Testing Row/Column Operations ===")
    
    with XLWingsUtils(visible=True) as xl_utils:
        wb = xl_utils.open_workbook("sample_data.xlsx")
        
        # Create test sheet
        test_sheet = xl_utils.add_sheet(wb, "RowColumnTest")
        
        # Add initial data
        initial_data = pd.DataFrame({
            'A': [1, 2, 3],
            'B': [4, 5, 6],
            'C': [7, 8, 9]
        })
        xl_utils.dataframe_to_sheet(initial_data, test_sheet, "A1")
        print("✓ Added initial data")
        
        # Insert rows
        xl_utils.insert_rows(test_sheet, 2, 2)
        print("✓ Inserted 2 rows at row 2")
        
        # Insert columns
        xl_utils.insert_columns(test_sheet, "B", 1)
        print("✓ Inserted 1 column at B")
        
        # Copy range
        xl_utils.copy_range(test_sheet, "A1:C1", test_sheet, "A10")
        print("✓ Copied range A1:C1 to A10")
        
        wb.save()


def test_error_handling():
    """Test error handling capabilities."""
    print("\n=== Testing Error Handling ===")
    
    with XLWingsUtils(visible=False) as xl_utils:
        # Test file not found
        try:
            wb = xl_utils.open_workbook("nonexistent_file.xlsx")
        except FileNotFoundError:
            print("✓ Correctly handled FileNotFoundError")
        
        # Test opening with error suppression
        wb_none = xl_utils.open_workbook_with_errors("nonexistent_file.xlsx")
        if wb_none is None:
            print("✓ Error suppression returned None for missing file")
        
        print("✓ Error handling tests completed")


def run_all_tests():
    """Run all test functions."""
    print("Starting XLWingsUtils Test Suite")
    print("=" * 50)
    
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    try:
        test_basic_operations()
        test_filtering_operations()
        test_search_operations()
        test_pivot_table_operations()
        test_formatting_operations()
        test_row_column_operations()
        test_error_handling()
        
        print("\n" + "=" * 50)
        print("✓ All tests completed successfully!")
        print("Check the generated 'sample_data.xlsx' file for results.")
        
    except Exception as e:
        print(f"\n❌ Test suite failed with error: {e}")
        logging.error(f"Test suite error: {e}")
    
    finally:
        # Cleanup
        if os.path.exists("sample_data.xlsx"):
            print(f"\nSample file available at: {os.path.abspath('sample_data.xlsx')}")


if __name__ == "__main__":
    run_all_tests()
