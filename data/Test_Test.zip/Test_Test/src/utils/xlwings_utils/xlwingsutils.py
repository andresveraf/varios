import os
import logging
import xlwings as xw
import pandas as pd
from xlwings import constants
import datetime
from typing import Optional, List, Dict, Union, Any, Tuple


class XLWingsUtils:
    """
    Comprehensive utility class for Excel automation using xlwings.
    
    This class provides methods for common Excel operations including:
    - File operations (open, save, close)
    - Sheet management (create, delete, rename)
    - Data filtering and manipulation
    - Pivot table creation and management
    - Cell formatting and styling
    - Data import/export operations
    """
    
    def __init__(self, visible: bool = False, display_alerts: bool = False, 
                 screen_updating: bool = True):
        """
        Initialize XLWings utility class.
        
        Args:
            visible (bool): Whether Excel application should be visible. Defaults to False.
            display_alerts (bool): Whether to display Excel alerts. Defaults to False.
            screen_updating (bool): Whether to update screen during operations. Defaults to True.
        
        Example:
            >>> xl_utils = XLWingsUtils(visible=True, display_alerts=False)
            >>> xl_utils.open_workbook("data.xlsx")
        """
        self.app: Optional[xw.App] = None
        self.visible = visible
        self.display_alerts = display_alerts
        self.screen_updating = screen_updating
        self.workbooks: Dict[str, xw.Book] = {}
        
    def __enter__(self):
        """Context manager entry."""
        self.start_app()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close_all_workbooks()
        self.quit_app()
    
    def start_app(self) -> xw.App:
        """
        Start Excel application with configured settings.
        
        Returns:
            xw.App: Excel application instance.
            
        Example:
            >>> xl_utils = XLWingsUtils()
            >>> app = xl_utils.start_app()
        """
        if self.app is None:
            self.app = xw.App(visible=self.visible)
            self.app.display_alerts = self.display_alerts
            self.app.screen_updating = self.screen_updating
        return self.app
    
    def quit_app(self) -> None:
        """
        Quit Excel application and cleanup.
        
        Example:
            >>> xl_utils.quit_app()
        """
        if self.app:
            try:
                self.app.quit()
            except Exception as e:
                logging.warning(f"Error quitting Excel app: {e}")
            finally:
                self.app = None
    
    def open_workbook(self, file_path: str, update_links: bool = False, 
                     read_only: bool = False) -> xw.Book:
        """
        Open Excel workbook with error handling.
        
        Args:
            file_path (str): Path to Excel file.
            update_links (bool): Whether to update external links. Defaults to False.
            read_only (bool): Whether to open in read-only mode. Defaults to False.
            
        Returns:
            xw.Book: Opened workbook instance.
            
        Raises:
            FileNotFoundError: If file doesn't exist.
            Exception: If file cannot be opened.
            
        Example:
            >>> wb = xl_utils.open_workbook("data.xlsx", update_links=False)
            >>> print(f"Opened workbook: {wb.name}")
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        if self.app is None:
            self.start_app()
            
        try:
            wb = self.app.books.open(file_path, update_links=update_links, read_only=read_only)
            self.workbooks[file_path] = wb
            logging.info(f"Successfully opened workbook: {file_path}")
            return wb
        except Exception as e:
            logging.error(f"Error opening workbook {file_path}: {e}")
            raise
    
    def open_workbook_with_errors(self, file_path: str) -> Optional[xw.Book]:
        """
        Open Excel workbook with error suppression for corrupted files.
        
        Args:
            file_path (str): Path to Excel file.
            
        Returns:
            xw.Book or None: Opened workbook or None if failed.
            
        Example:
            >>> wb = xl_utils.open_workbook_with_errors("corrupted_file.xls")
            >>> if wb:
            ...     print("File opened successfully")
        """
        if self.app is None:
            self.start_app()
            
        self.app.display_alerts = False
        self.app.screen_updating = False
        
        try:
            wb = self.app.books.open(file_path)
            logging.info(f"Successfully opened workbook with error handling: {file_path}")
            return wb
        except Exception as e:
            logging.error(f"Error reading Excel file with xlwings: {e}")
            return None
    
    def close_workbook(self, workbook: Union[xw.Book, str], save: bool = False) -> None:
        """
        Close workbook safely.
        
        Args:
            workbook (xw.Book or str): Workbook instance or file path.
            save (bool): Whether to save before closing. Defaults to False.
            
        Example:
            >>> xl_utils.close_workbook(wb, save=True)
        """
        try:
            if isinstance(workbook, str):
                workbook = self.workbooks.get(workbook)
            
            if workbook:
                if save:
                    workbook.save()
                workbook.close()
                # Remove from tracked workbooks
                for path, wb in list(self.workbooks.items()):
                    if wb == workbook:
                        del self.workbooks[path]
                        break
        except Exception as e:
            logging.error(f"Error closing workbook: {e}")
    
    def close_all_workbooks(self, save: bool = False) -> None:
        """
        Close all open workbooks.
        
        Args:
            save (bool): Whether to save all workbooks before closing. Defaults to False.
            
        Example:
            >>> xl_utils.close_all_workbooks(save=True)
        """
        for wb in list(self.workbooks.values()):
            self.close_workbook(wb, save=save)
    
    def rename_sheet(self, sheet: xw.Sheet, new_name: str) -> None:
        """
        Rename worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to rename.
            new_name (str): New name for the sheet.
            
        Example:
            >>> sheet = wb.sheets['Sheet1']
            >>> xl_utils.rename_sheet(sheet, 'Data')
        """
        try:
            sheet.name = new_name
            logging.info(f"Sheet renamed to: {new_name}")
        except Exception as e:
            logging.error(f"Error renaming sheet: {e}")
            raise
    
    def add_sheet(self, workbook: xw.Book, name: str, before: Optional[xw.Sheet] = None) -> xw.Sheet:
        """
        Add new worksheet to workbook.
        
        Args:
            workbook (xw.Book): Workbook to add sheet to.
            name (str): Name for new sheet.
            before (xw.Sheet, optional): Sheet to insert before.
            
        Returns:
            xw.Sheet: New worksheet.
            
        Example:
            >>> new_sheet = xl_utils.add_sheet(wb, 'Analysis')
        """
        try:
            if before:
                sheet = workbook.sheets.add(name=name, before=before)
            else:
                sheet = workbook.sheets.add(name=name)
            logging.info(f"Added new sheet: {name}")
            return sheet
        except Exception as e:
            logging.error(f"Error adding sheet {name}: {e}")
            raise
    
    def delete_sheet(self, sheet: Union[xw.Sheet, str]) -> None:
        """
        Delete worksheet.
        
        Args:
            sheet (xw.Sheet or str): Worksheet or sheet name to delete.
            
        Example:
            >>> xl_utils.delete_sheet('Sheet1')
        """
        try:
            if isinstance(sheet, str):
                # Assume we need to find the sheet by name in available workbooks
                for wb in self.workbooks.values():
                    if sheet in [s.name for s in wb.sheets]:
                        sheet = wb.sheets[sheet]
                        break
            
            sheet.delete()
            logging.info(f"Deleted sheet: {sheet.name}")
        except Exception as e:
            logging.error(f"Error deleting sheet: {e}")
            raise
    
    def apply_autofilter(self, sheet: xw.Sheet, column: str, criteria: Union[str, List[str]], 
                        operator: int = 7) -> None:
        """
        Apply autofilter to column.
        
        Args:
            sheet (xw.Sheet): Worksheet to apply filter.
            column (str): Column letter to filter.
            criteria (str or list): Filter criteria.
            operator (int): Filter operator (7 for xlFilterValues). Defaults to 7.
            
        Example:
            >>> xl_utils.apply_autofilter(sheet, "A", ["Value1", "Value2"])
            >>> xl_utils.apply_autofilter(sheet, "B", ">=1000")
        """
        try:
            sheet.api.AutoFilterMode = False
            if isinstance(criteria, list):
                sheet.api.Range(f'{column}:{column}').AutoFilter(1, criteria, operator)
            else:
                sheet.api.Range(f'{column}:{column}').AutoFilter(1, criteria)
            logging.info(f"Applied autofilter to column {column}")
        except Exception as e:
            logging.error(f"Error applying autofilter: {e}")
            raise
    
    def apply_date_filter(self, sheet: xw.Sheet, column: str, start_date: str, 
                         end_date: str, year: int, month: int) -> None:
        """
        Apply date range filter to column.
        
        Args:
            sheet (xw.Sheet): Worksheet to apply filter.
            column (str): Column letter to filter.
            start_date (str): Start date in format "DD".
            end_date (str): End date in format "DD".
            year (int): Year for filter.
            month (int): Month for filter.
            
        Example:
            >>> xl_utils.apply_date_filter(sheet, "O", "01", "31", 2024, 10)
        """
        try:
            last_row = self.get_last_row(sheet, column)
            filter_criteria = f">={year}-{month:02d}-{start_date}"
            filter_criteria_end = f"<={year}-{month:02d}-{end_date}"
            
            sheet.api.AutoFilterMode = False
            sheet.api.Range(f"{column}1:{column}{last_row}").AutoFilter(
                Field=1, Criteria1=filter_criteria, Operator=2, Criteria2=filter_criteria_end)
            
            logging.info(f"Applied date filter to column {column}: {filter_criteria} to {filter_criteria_end}")
        except Exception as e:
            logging.error(f"Error applying date filter: {e}")
            raise
    
    def clear_filters(self, sheet: xw.Sheet) -> None:
        """
        Clear all filters from worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to clear filters from.
            
        Example:
            >>> xl_utils.clear_filters(sheet)
        """
        try:
            sheet.api.AutoFilterMode = False
            logging.info("Cleared all filters")
        except Exception as e:
            logging.error(f"Error clearing filters: {e}")
    
    def get_last_row(self, sheet: xw.Sheet, column: str = "A") -> int:
        """
        Get last row with data in specified column.
        
        Args:
            sheet (xw.Sheet): Worksheet to check.
            column (str): Column letter to check. Defaults to "A".
            
        Returns:
            int: Last row number with data.
            
        Example:
            >>> last_row = xl_utils.get_last_row(sheet, "A")
            >>> print(f"Last row: {last_row}")
        """
        try:
            return sheet.range(f'{column}{sheet.cells.last_cell.row}').end('up').row
        except Exception as e:
            logging.error(f"Error getting last row: {e}")
            return 1
    
    def get_last_column(self, sheet: xw.Sheet, row: int = 1) -> int:
        """
        Get last column with data in specified row.
        
        Args:
            sheet (xw.Sheet): Worksheet to check.
            row (int): Row number to check. Defaults to 1.
            
        Returns:
            int: Last column number with data.
            
        Example:
            >>> last_col = xl_utils.get_last_column(sheet)
        """
        try:
            return sheet.range(f'A{row}').end('right').column
        except Exception as e:
            logging.error(f"Error getting last column: {e}")
            return 1
    
    def sheet_to_dataframe(self, sheet: xw.Sheet, range_addr: Optional[str] = None, 
                          header: bool = True, index: bool = False) -> pd.DataFrame:
        """
        Convert sheet range to pandas DataFrame.
        
        Args:
            sheet (xw.Sheet): Worksheet to convert.
            range_addr (str, optional): Range address. If None, uses used range.
            header (bool): Whether first row contains headers. Defaults to True.
            index (bool): Whether to use first column as index. Defaults to False.
            
        Returns:
            pd.DataFrame: Converted data.
            
        Example:
            >>> df = xl_utils.sheet_to_dataframe(sheet, "A1:D10")
            >>> df = xl_utils.sheet_to_dataframe(sheet)  # Use entire used range
        """
        try:
            if range_addr:
                data = sheet.range(range_addr).options(pd.DataFrame, header=header, index=index).value
            else:
                data = sheet.used_range.options(pd.DataFrame, header=header, index=index).value
            
            return data if data is not None else pd.DataFrame()
        except Exception as e:
            logging.error(f"Error converting sheet to DataFrame: {e}")
            return pd.DataFrame()
    
    def dataframe_to_sheet(self, df: pd.DataFrame, sheet: xw.Sheet, 
                          start_cell: str = "A1", header: bool = True, 
                          index: bool = False) -> None:
        """
        Write pandas DataFrame to sheet.
        
        Args:
            df (pd.DataFrame): DataFrame to write.
            sheet (xw.Sheet): Target worksheet.
            start_cell (str): Starting cell address. Defaults to "A1".
            header (bool): Whether to include headers. Defaults to True.
            index (bool): Whether to include index. Defaults to False.
            
        Example:
            >>> xl_utils.dataframe_to_sheet(df, sheet, "B2", header=True)
        """
        try:
            sheet.range(start_cell).options(index=index, header=header).value = df
            logging.info(f"DataFrame written to sheet at {start_cell}")
        except Exception as e:
            logging.error(f"Error writing DataFrame to sheet: {e}")
            raise
    
    def insert_rows(self, sheet: xw.Sheet, start_row: int, count: int = 1) -> None:
        """
        Insert rows in worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to modify.
            start_row (int): Row number to start insertion.
            count (int): Number of rows to insert. Defaults to 1.
            
        Example:
            >>> xl_utils.insert_rows(sheet, 5, 3)  # Insert 3 rows starting at row 5
        """
        try:
            if count == 1:
                sheet.range(f'{start_row}:{start_row}').insert('down')
            else:
                sheet.range(f'{start_row}:{start_row + count - 1}').insert('down')
            logging.info(f"Inserted {count} rows starting at row {start_row}")
        except Exception as e:
            logging.error(f"Error inserting rows: {e}")
            raise
    
    def insert_columns(self, sheet: xw.Sheet, column: str, count: int = 1, 
                      shift: str = 'right') -> None:
        """
        Insert columns in worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to modify.
            column (str): Column letter to start insertion.
            count (int): Number of columns to insert. Defaults to 1.
            shift (str): Direction to shift ('right' or 'left'). Defaults to 'right'.
            
        Example:
            >>> xl_utils.insert_columns(sheet, "C", 2)  # Insert 2 columns at C
        """
        try:
            if count == 1:
                sheet.range(f'{column}:{column}').insert(shift=shift)
            else:
                end_col = chr(ord(column) + count - 1)
                sheet.range(f'{column}:{end_col}').insert(shift=shift)
            logging.info(f"Inserted {count} columns starting at {column}")
        except Exception as e:
            logging.error(f"Error inserting columns: {e}")
            raise
    
    def delete_rows(self, sheet: xw.Sheet, start_row: int, count: int = 1) -> None:
        """
        Delete rows from worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to modify.
            start_row (int): Row number to start deletion.
            count (int): Number of rows to delete. Defaults to 1.
            
        Example:
            >>> xl_utils.delete_rows(sheet, 10, 2)  # Delete 2 rows starting at row 10
        """
        try:
            if count == 1:
                sheet.range(f'{start_row}:{start_row}').delete()
            else:
                sheet.range(f'{start_row}:{start_row + count - 1}').delete()
            logging.info(f"Deleted {count} rows starting at row {start_row}")
        except Exception as e:
            logging.error(f"Error deleting rows: {e}")
            raise
    
    def delete_columns(self, sheet: xw.Sheet, column: str, count: int = 1) -> None:
        """
        Delete columns from worksheet.
        
        Args:
            sheet (xw.Sheet): Worksheet to modify.
            column (str): Column letter to start deletion.
            count (int): Number of columns to delete. Defaults to 1.
            
        Example:
            >>> xl_utils.delete_columns(sheet, "D", 1)  # Delete column D
        """
        try:
            if count == 1:
                sheet.range(f'{column}:{column}').delete()
            else:
                end_col = chr(ord(column) + count - 1)
                sheet.range(f'{column}:{end_col}').delete()
            logging.info(f"Deleted {count} columns starting at {column}")
        except Exception as e:
            logging.error(f"Error deleting columns: {e}")
            raise
    
    def copy_range(self, source_sheet: xw.Sheet, source_range: str, 
                  target_sheet: xw.Sheet, target_cell: str, 
                  paste_type: str = 'values') -> None:
        """
        Copy range from source to target location.
        
        Args:
            source_sheet (xw.Sheet): Source worksheet.
            source_range (str): Source range address.
            target_sheet (xw.Sheet): Target worksheet.
            target_cell (str): Target cell address.
            paste_type (str): Type of paste ('values', 'formats', 'formulas'). Defaults to 'values'.
            
        Example:
            >>> xl_utils.copy_range(sheet1, "A1:C10", sheet2, "E1", "values")
        """
        try:
            source_sheet.range(source_range).copy()
            if paste_type == 'values':
                target_sheet.range(target_cell).api.PasteSpecial()
            else:
                target_sheet.range(target_cell).paste(paste=paste_type)
            
            # Clear clipboard
            if hasattr(target_sheet.book.app, 'api'):
                target_sheet.book.app.api.CutCopyMode = False
            
            logging.info(f"Copied range {source_range} to {target_cell}")
        except Exception as e:
            logging.error(f"Error copying range: {e}")
            raise
    
    def format_header_row(self, sheet: xw.Sheet, range_addr: str, 
                         bg_color: Tuple[int, int, int] = (68, 114, 196),
                         font_color: int = 16777215, bold: bool = True,
                         alignment: int = -4108) -> None:
        """
        Format header row with professional styling.
        
        Args:
            sheet (xw.Sheet): Worksheet to format.
            range_addr (str): Range address for header row.
            bg_color (tuple): RGB background color. Defaults to professional blue.
            font_color (int): Font color code. Defaults to white.
            bold (bool): Whether to make font bold. Defaults to True.
            alignment (int): Horizontal alignment code. Defaults to center.
            
        Example:
            >>> xl_utils.format_header_row(sheet, "A1:G1")
        """
        try:
            header_row = sheet.range(range_addr)
            header_row.color = bg_color
            header_row.api.Font.Bold = bold
            header_row.api.Font.Color = font_color
            header_row.api.HorizontalAlignment = alignment
            logging.info(f"Formatted header row: {range_addr}")
        except Exception as e:
            logging.error(f"Error formatting header row: {e}")
            raise
    
    def autofit_columns(self, sheet: xw.Sheet, range_addr: Optional[str] = None) -> None:
        """
        Autofit column widths for specified range.
        
        Args:
            sheet (xw.Sheet): Worksheet to autofit.
            range_addr (str, optional): Range to autofit. If None, autofits entire used range.
            
        Example:
            >>> xl_utils.autofit_columns(sheet, "A1:E10")
            >>> xl_utils.autofit_columns(sheet)  # Autofit entire used range
        """
        try:
            if range_addr:
                sheet.range(range_addr).columns.autofit()
            else:
                sheet.used_range.columns.autofit()
            logging.info("Autofitted columns")
        except Exception as e:
            logging.error(f"Error autofitting columns: {e}")
    
    def sum_visible_cells(self, sheet: xw.Sheet, column: str, start_row: int = 1,
                         end_row: Optional[int] = None) -> float:
        """
        Sum visible cells in filtered column using SUBTOTAL function.
        
        Args:
            sheet (xw.Sheet): Worksheet containing data.
            column (str): Column letter to sum.
            start_row (int): Starting row number. Defaults to 1.
            end_row (int, optional): Ending row number. If None, uses last row.
            
        Returns:
            float: Sum of visible cells.
            
        Example:
            >>> total = xl_utils.sum_visible_cells(sheet, "C", 2, 100)
        """
        try:
            if end_row is None:
                end_row = self.get_last_row(sheet, column)
            
            # Use temporary cell for SUBTOTAL formula
            temp_cell = "ZZ1"
            formula = f"=SUBTOTAL(9,{column}{start_row}:{column}{end_row})"
            sheet.range(temp_cell).value = formula
            result = sheet.range(temp_cell).value
            sheet.range(temp_cell).clear_contents()
            
            return float(result) if result is not None else 0.0
        except Exception as e:
            logging.error(f"Error summing visible cells: {e}")
            return 0.0
    
    def find_cell(self, sheet: xw.Sheet, search_text: str) -> Optional[Tuple[int, str]]:
        """
        Find cell containing specific text.
        
        Args:
            sheet (xw.Sheet): Worksheet to search.
            search_text (str): Text to search for.
            
        Returns:
            tuple or None: (row_index, column_letter) if found, None otherwise.
            
        Example:
            >>> location = xl_utils.find_cell(sheet, "Total Sales")
            >>> if location:
            ...     row, col = location
            ...     print(f"Found at row {row}, column {col}")
        """
        try:
            found_cell = sheet.api.UsedRange.Find(search_text)
            if found_cell:
                row_index = found_cell.Row
                column_letter = xw.utils.col_name(found_cell.Column)
                return (row_index, column_letter)
            return None
        except Exception as e:
            logging.error(f"Error finding cell: {e}")
            return None
    
    def find_values_in_column(self, sheet: xw.Sheet, search_terms: List[str], 
                             search_column: str, value_column: str) -> Dict[str, List[Any]]:
        """
        Find values in one column based on criteria in another column.
        
        Args:
            sheet (xw.Sheet): Worksheet to search.
            search_terms (list): List of terms to search for.
            search_column (str): Column letter to search in.
            value_column (str): Column letter to extract values from.
            
        Returns:
            dict: Dictionary with search terms as keys and lists of found values.
            
        Example:
            >>> results = xl_utils.find_values_in_column(sheet, ["Sales", "Marketing"], "A", "B")
        """
        try:
            results = {term: [] for term in search_terms}
            last_row = self.get_last_row(sheet, search_column)
            
            for row in range(1, last_row + 1):
                search_value = sheet.range(f"{search_column}{row}").value
                if search_value:
                    search_value_str = str(search_value).strip().upper()
                    for term in search_terms:
                        if term.upper() in search_value_str:
                            value = sheet.range(f"{value_column}{row}").value
                            results[term].append(value)
            
            return results
        except Exception as e:
            logging.error(f"Error finding values in column: {e}")
            return {term: [] for term in search_terms}
    
    def create_pivot_table(self, source_sheet: xw.Sheet, target_sheet: xw.Sheet,
                          target_cell: str, pivot_name: str, row_fields: List[str],
                          col_fields: List[str] = None, data_fields: List[Tuple[str, int]] = None,
                          filter_fields: Dict[str, List[str]] = None) -> None:
        """
        Create pivot table with specified configuration.
        
        Args:
            source_sheet (xw.Sheet): Source worksheet with data.
            target_sheet (xw.Sheet): Target worksheet for pivot table.
            target_cell (str): Cell address for pivot table placement.
            pivot_name (str): Name for the pivot table.
            row_fields (list): List of field names for rows.
            col_fields (list, optional): List of field names for columns.
            data_fields (list, optional): List of (field_name, function) tuples for data.
            filter_fields (dict, optional): Dictionary of field filters.
            
        Example:
            >>> xl_utils.create_pivot_table(
            ...     source_sheet, target_sheet, "A1", "SalesPivot",
            ...     row_fields=["Region", "Product"],
            ...     data_fields=[("Sales", -4157)]  # -4157 = Sum
            ... )
        """
        try:
            # Get data range
            last_row = self.get_last_row(source_sheet)
            last_col = self.get_last_column(source_sheet)
            
            # Create pivot cache
            excel_app = source_sheet.book.app.api
            wb = excel_app.Workbooks(source_sheet.book.name)
            ws_source = wb.Worksheets(source_sheet.name)
            ws_target = wb.Worksheets(target_sheet.name)
            
            pivot_cache = wb.PivotCaches().Create(
                SourceType=1,  # xlSrcRange
                SourceData=ws_source.Range(f"A1:{xw.utils.col_name(last_col)}{last_row}")
            )
            
            # Create pivot table
            pivot_table = pivot_cache.CreatePivotTable(
                TableDestination=ws_target.Range(target_cell),
                TableName=pivot_name
            )
            
            # Configure row fields
            for i, field in enumerate(row_fields, 1):
                pivot_table.PivotFields(field).Orientation = 1  # xlRowField
                pivot_table.PivotFields(field).Position = i
            
            # Configure column fields
            if col_fields:
                for i, field in enumerate(col_fields, 1):
                    pivot_table.PivotFields(field).Orientation = 2  # xlColumnField
                    pivot_table.PivotFields(field).Position = i
            
            # Configure data fields
            if data_fields:
                for field_name, function in data_fields:
                    data_field = pivot_table.PivotFields(field_name)
                    data_field.Orientation = 4  # xlDataField
                    data_field.Function = function
            
            # Apply filters
            if filter_fields:
                for field_name, filter_values in filter_fields.items():
                    filter_field = pivot_table.PivotFields(field_name)
                    filter_field.Orientation = 3  # xlPageField
                    filter_field.EnableMultiplePageItems = True
                    
                    for pi in filter_field.PivotItems():
                        pi.Visible = pi.Name in filter_values
            
            # Refresh pivot table
            pivot_table.RefreshTable()
            
            logging.info(f"Created pivot table: {pivot_name}")
        except Exception as e:
            logging.error(f"Error creating pivot table: {e}")
            raise
    
    def extract_pivot_table_data(self, sheet: xw.Sheet, pivot_name: str) -> Optional[pd.DataFrame]:
        """
        Extract data from pivot table to DataFrame.
        
        Args:
            sheet (xw.Sheet): Worksheet containing pivot table.
            pivot_name (str): Name of the pivot table.
            
        Returns:
            pd.DataFrame or None: Extracted pivot table data.
            
        Example:
            >>> df = xl_utils.extract_pivot_table_data(sheet, "SalesPivot")
            >>> if df is not None:
            ...     print(df.head())
        """
        try:
            pivot_table = sheet.api.PivotTables(pivot_name)
            pivot_table.RefreshTable()
            
            # Get the entire table range
            pivot_range = sheet.range(pivot_table.TableRange2)
            df = pivot_range.options(pd.DataFrame, header=True, index=False).value
            
            return df
        except Exception as e:
            logging.error(f"Error extracting pivot table '{pivot_name}': {e}")
            return None
    
    def refresh_workbook(self, workbook: xw.Book) -> None:
        """
        Refresh all data connections in workbook.
        
        Args:
            workbook (xw.Book): Workbook to refresh.
            
        Example:
            >>> xl_utils.refresh_workbook(wb)
        """
        try:
            workbook.api.RefreshAll()
            logging.info("Refreshed workbook data connections")
        except Exception as e:
            logging.error(f"Error refreshing workbook: {e}")
    
    def convert_text_to_numbers(self, sheet: xw.Sheet, columns: List[str], 
                               start_row: int = 2) -> None:
        """
        Convert text formatted numbers to actual numbers.
        
        Args:
            sheet (xw.Sheet): Worksheet to modify.
            columns (list): List of column letters to convert.
            start_row (int): Starting row number. Defaults to 2.
            
        Example:
            >>> xl_utils.convert_text_to_numbers(sheet, ["B", "C", "D"], 2)
        """
        try:
            last_row = self.get_last_row(sheet)
            for col in columns:
                range_to_convert = sheet.range(f'{col}{start_row}:{col}{last_row}')
                range_to_convert.api.TextToColumns(
                    Destination=range_to_convert.api, 
                    DataType=1
                )
            logging.info(f"Converted text to numbers in columns: {columns}")
        except Exception as e:
            logging.error(f"Error converting text to numbers: {e}")
            raise


def example_usage():
    """
    Example usage of XLWingsUtils class.
    
    This function demonstrates various operations available in the utility class.
    """
    
    # Initialize utility class with context manager
    with XLWingsUtils(visible=True, display_alerts=False) as xl_utils:
        
        # Open workbook
        wb = xl_utils.open_workbook("sample_data.xlsx")
        sheet = wb.sheets[0]
        
        # Rename sheet
        xl_utils.rename_sheet(sheet, "ProcessedData")
        
        # Apply filters
        xl_utils.apply_autofilter(sheet, "A", ["Category1", "Category2"])
        
        # Get filtered data as DataFrame
        df = xl_utils.sheet_to_dataframe(sheet, header=True)
        print(f"Retrieved {len(df)} rows of data")
        
        # Sum visible cells after filtering
        total_sales = xl_utils.sum_visible_cells(sheet, "C", 2)
        print(f"Total sales: {total_sales}")
        
        # Format header row
        xl_utils.format_header_row(sheet, "A1:E1")
        
        # Create new sheet for analysis
        analysis_sheet = xl_utils.add_sheet(wb, "Analysis")
        
        # Create pivot table
        xl_utils.create_pivot_table(
            source_sheet=sheet,
            target_sheet=analysis_sheet,
            target_cell="A1",
            pivot_name="SalesAnalysis",
            row_fields=["Category"],
            data_fields=[("Sales", -4157)]  # Sum
        )
        
        # Extract pivot table data
        pivot_df = xl_utils.extract_pivot_table_data(analysis_sheet, "SalesAnalysis")
        if pivot_df is not None:
            print("Pivot table data extracted successfully")
        
        # Find specific values
        location = xl_utils.find_cell(sheet, "Total")
        if location:
            row, col = location
            print(f"Found 'Total' at row {row}, column {col}")
        
        # Save and close
        wb.save()
        print("Workbook saved successfully")


if __name__ == "__main__":
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Run example
    try:
        example_usage()
    except Exception as e:
        logging.error(f"Example execution failed: {e}")
