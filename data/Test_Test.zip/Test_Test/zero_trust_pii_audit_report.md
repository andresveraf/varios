# 🔐 Zero-Trust PII Security Audit Report

**Scan Date**: 2025-08-11  
**Auditor**: andres-n-vera_met (Security Specialist)

---

## ✅ Summary

- **Compliance Status**: ❌ **FAIL**
- **Overall Risk**: **High**
- **Findings Count**: **5**

---

## 🔍 Detailed Findings

### **Finding #1**
- **Location**: *2. SOP Emision-Creacion Poliza RV.docx*, Page 1
- **Type**: **Direct Personal Identifiers**
- **Content**: "Nombres y Apellidos del Causante", "Nro. de Rut", "Nro. de solicitud", "Nro. de oferta"
- **Risk Level**: **High**
- **Recommendation**: Apply **irreversible redaction** to all fields referencing customer identity, including RUT and names.

---

### **Finding #2**
- **Location**: *Procedimiento Recaudación Mensual COL VF 20221019.docx*, Multiple Sections
- **Type**: **Contact Information & Implicit Identifiers**
- **Content**: Repeated references to "Mail", "Número de factura", "Número de póliza"
- **Risk Level**: **Medium**
- **Recommendation**: Replace with anonymized placeholders (e.g., "factura_001", "poliza_ABC123"). Ensure email references are generic or removed.

---

### **Finding #3**
- **Location**: *78.-Comisiones_v2 (Traspaso).docx*, Multiple Sections
- **Type**: **Direct Identifiers**
- **Content**: "Rut", "Nombre", "Código de agente", "Número de póliza"
- **Risk Level**: **High**
- **Recommendation**: Redact all RUTs and names. Replace agent codes and policy numbers with generic identifiers.

---

### **Finding #4**
- **Location**: *78.-Comisiones_v2 (Traspaso).docx*, Email Instructions
- **Type**: **Contact Information**
- **Content**: Multiple real email addresses (e.g., `pgonzalezo@metlife.cl`, `scarlett.quezada@metlife.cl`)
- **Risk Level**: **Medium**
- **Recommendation**: Replace with generic placeholders (e.g., `user@example.com`) or internal role-based aliases.

---

### **Finding #5**
- **Location**: *Procedimiento Recaudación Mensual COL VF 20221019.docx*, Annexes
- **Type**: **Financial Identifiers**
- **Content**: Bank account numbers (e.g., “Cuenta 23868-06”, “2595938-8”), transaction details
- **Risk Level**: **High**
- **Recommendation**: Mask or replace with generic account references (e.g., “Cuenta XXXX-XX”).

---

## 🧠 Root Cause Analysis & Strategic Recommendations

- **Suspected Cause**: Use of **live production data** and **real customer identifiers** in internal documentation for training and operational purposes.

---

## 🛠️ Tiered Recommendations

### 1. **Immediate Containment**
- Remove all three documents from internal circulation.
- Apply irreversible redaction to all RUTs, names, emails, policy numbers, and financial identifiers.

### 2. **Process Improvement**
- Introduce a **mandatory data sanitization step** before publishing or sharing documentation.
- Implement tools for **automated anonymization** of screenshots and text fields.

### 3. **Training & Awareness**
- Schedule a **refresher course** for all documentation authors on handling PII under Zero-Trust principles.
- Include examples of **implicit identifiers** and how they can lead to data leakage.
